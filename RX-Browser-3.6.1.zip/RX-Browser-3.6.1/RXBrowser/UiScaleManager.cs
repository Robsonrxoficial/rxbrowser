﻿using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Aplica escala de fonte sem multiplicar fontes já escaladas em chamadas futuras.</summary>
internal static class UiScaleManager
{
    private sealed class FontState
    {
        public FontState(Font original) => Original = original;
        public Font Original { get; }
        public Font? Applied { get; set; }
    }

    private static readonly ConditionalWeakTable<Control, FontState> States = new();

    public static void Apply(Control root, int percentage)
    {
        ArgumentNullException.ThrowIfNull(root);
        var factor = Math.Clamp(percentage, 90, 140) / 100f;
        ApplyRecursive(root, factor);
    }

    private static void ApplyRecursive(Control control, float factor)
    {
        try
        {
            var state = States.GetValue(control, item => new FontState(new Font(item.Font, item.Font.Style)));
            var size = Math.Clamp(state.Original.Size * factor, 7f, 26f);
            if (state.Applied is null || Math.Abs(state.Applied.Size - size) > 0.1f)
            {
                var next = new Font(state.Original.FontFamily, size, state.Original.Style,
                    state.Original.Unit, state.Original.GdiCharSet, state.Original.GdiVerticalFont);
                var previous = state.Applied;
                state.Applied = next;
                control.Font = next;
                previous?.Dispose();
            }
        }
        catch { /* Um controle que não aceita alteração de fonte não deve interromper o navegador. */ }

        foreach (Control child in control.Controls)
            ApplyRecursive(child, factor);
    }
}
