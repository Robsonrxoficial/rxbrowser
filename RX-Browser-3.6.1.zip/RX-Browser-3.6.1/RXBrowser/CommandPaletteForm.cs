﻿namespace RXBrowser;

internal sealed record BrowserCommand(string Id, string Title, string Description, string Category);

/// <summary>Pesquisa ações do navegador sem precisar navegar por vários menus.</summary>
internal sealed class CommandPaletteForm : Form
{
    private readonly TextBox _search = new();
    private readonly ListBox _results = new();
    private readonly List<BrowserCommand> _commands;
    public string? SelectedCommandId { get; private set; }

    public CommandPaletteForm(IEnumerable<BrowserCommand> commands)
    {
        _commands = commands.ToList();
        Text = "Paleta de comandos — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(650, 520);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), ColumnCount = 1, RowCount = 3, BackColor = BackColor };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        Controls.Add(root);

        _search.Dock = DockStyle.Fill;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = Color.FromArgb(232, 240, 248);
        _search.Font = new Font("Segoe UI", 12F);
        _search.PlaceholderText = "Pesquisar comandos…";
        _search.TextChanged += (_, _) => RefreshResults();
        _search.KeyDown += Search_KeyDown;
        root.Controls.Add(_search, 0, 0);

        _results.Dock = DockStyle.Fill;
        _results.BackColor = Color.FromArgb(20, 27, 37);
        _results.ForeColor = Color.FromArgb(232, 240, 248);
        _results.BorderStyle = BorderStyle.None;
        _results.Font = new Font("Segoe UI", 10F);
        _results.IntegralHeight = false;
        _results.DoubleClick += (_, _) => AcceptSelection();
        _results.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AcceptSelection(); }
        };
        root.Controls.Add(_results, 0, 1);

        root.Controls.Add(new Label
        {
            Text = "↑ ↓ navegar   •   Enter executar   •   Esc fechar",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(145, 162, 182),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 2);

        RefreshResults();
        Shown += (_, _) => _search.Focus();
    }

    private void RefreshResults()
    {
        var query = _search.Text.Trim();
        var matches = _commands.Where(command =>
            query.Length == 0 ||
            command.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
            command.Description.Contains(query, StringComparison.OrdinalIgnoreCase) ||
            command.Category.Contains(query, StringComparison.OrdinalIgnoreCase))
            .OrderBy(command => command.Category)
            .ThenBy(command => command.Title)
            .Take(80)
            .ToList();

        _results.BeginUpdate();
        _results.Items.Clear();
        foreach (var command in matches)
            _results.Items.Add(new CommandListItem(command));
        _results.EndUpdate();
        if (_results.Items.Count > 0) _results.SelectedIndex = 0;
    }

    private void Search_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Down && _results.Items.Count > 0)
        {
            e.SuppressKeyPress = true;
            _results.Focus();
            _results.SelectedIndex = Math.Min(_results.Items.Count - 1, Math.Max(0, _results.SelectedIndex + 1));
        }
        else if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            AcceptSelection();
        }
        else if (e.KeyCode == Keys.Escape)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }

    private void AcceptSelection()
    {
        if (_results.SelectedItem is not CommandListItem item) return;
        SelectedCommandId = item.Command.Id;
        DialogResult = DialogResult.OK;
        Close();
    }

    private sealed class CommandListItem(BrowserCommand command)
    {
        public BrowserCommand Command { get; } = command;
        public override string ToString() => $"{Command.Title}    [{Command.Category}]    — {Command.Description}";
    }
}
