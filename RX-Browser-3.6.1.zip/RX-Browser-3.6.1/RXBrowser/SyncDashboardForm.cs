﻿namespace RXBrowser;

internal sealed class SyncDashboardForm : Form
{
    public string? RequestedAction { get; private set; }

    public SyncDashboardForm(string profileName, bool enabled, string folder, int intervalMinutes,
        DateTime lastPublishedUtc, BackupSyncDashboardSummary summary)
    {
        Text = "Painel de sincronização — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(700, 470);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label
        {
            Text = "RX SYNC CENTER",
            Left = 24, Top = 20, Width = 640, Height = 34,
            ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Black", 17F, FontStyle.Bold)
        });
        Controls.Add(new Label
        {
            Text = $"Perfil: {profileName}    •    Estado: {(enabled ? "PUBLICAÇÃO AUTOMÁTICA ATIVA" : "PUBLICAÇÃO AUTOMÁTICA DESATIVADA")}",
            Left = 26, Top = 62, Width = 646, Height = 26,
            ForeColor = enabled ? Color.FromArgb(92, 220, 169) : Color.FromArgb(172, 184, 198),
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold)
        });

        var cards = new TableLayoutPanel { Left = 24, Top = 104, Width = 650, Height = 105, ColumnCount = 3, RowCount = 1, BackColor = BackColor };
        for (var i = 0; i < 3; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.433F));
        AddCard(cards, 0, "DISPOSITIVOS", summary.DeviceCount.ToString(), Color.FromArgb(55, 211, 235));
        AddCard(cards, 1, "BACKUPS REMOTOS", summary.OtherDeviceCount.ToString(), Color.FromArgb(128, 170, 255));
        AddCard(cards, 2, "DADOS NA PASTA", FormatBytes(summary.SharedBytes), Color.FromArgb(92, 220, 169));
        Controls.Add(cards);

        var details = new Panel { Left = 24, Top = 222, Width = 650, Height = 126, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(14) };
        details.Controls.Add(new Label { Text = "PASTA COMPARTILHADA", Left = 12, Top = 10, Width = 610, Height = 20, ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold) });
        details.Controls.Add(new Label { Text = string.IsNullOrWhiteSpace(folder) ? "Nenhuma pasta configurada" : folder, Left = 12, Top = 32, Width = 610, Height = 34, ForeColor = ForeColor, AutoEllipsis = true });
        var ownTimestamp = summary.OwnBackupUtc ?? (lastPublishedUtc == DateTime.MinValue ? null : lastPublishedUtc);
        var localDate = ownTimestamp?.ToLocalTime().ToString("dd/MM/yyyy HH:mm") ?? "Ainda não publicado";
        var remoteDate = summary.LatestRemoteUtc?.ToLocalTime().ToString("dd/MM/yyyy HH:mm") ?? "Nenhum backup remoto encontrado";
        details.Controls.Add(new Label { Text = $"Última publicação deste dispositivo: {localDate}\nBackup remoto mais recente: {remoteDate}\nIntervalo automático: {(enabled ? intervalMinutes + " min" : "desativado")}", Left = 12, Top = 70, Width = 610, Height = 48, ForeColor = Color.FromArgb(158, 174, 194) });
        Controls.Add(details);

        Controls.Add(new Label
        {
            Text = "Os arquivos contêm favoritos, espaços de trabalho e preferências não secretas. Senhas, PINs, cookies, histórico, downloads, permissões, extensões e dados do WebView2 ficam fora da sincronização.",
            Left = 28, Top = 365, Width = 640, Height = 42,
            ForeColor = Color.FromArgb(137, 154, 176), Font = new Font("Segoe UI", 8.5F)
        });

        var close = MakeButton("Fechar", 88);
        close.SetBounds(580, 420, 94, 34);
        close.DialogResult = DialogResult.Cancel;
        Controls.Add(close);
        var settings = MakeButton("Configurar", 108);
        settings.SetBounds(24, 420, 108, 34);
        settings.Click += (_, _) => Complete("settings");
        Controls.Add(settings);
        var import = MakeButton("Importar outro dispositivo", 176);
        import.SetBounds(140, 420, 176, 34);
        import.Enabled = !string.IsNullOrWhiteSpace(folder);
        import.Click += (_, _) => Complete("import");
        Controls.Add(import);
        var publish = MakeButton("Publicar agora", 128, true);
        publish.SetBounds(324, 420, 128, 34);
        publish.Enabled = !string.IsNullOrWhiteSpace(folder);
        publish.Click += (_, _) => Complete("publish");
        Controls.Add(publish);
        CancelButton = close;
    }

    private void Complete(string action)
    {
        RequestedAction = action;
        DialogResult = DialogResult.OK;
        Close();
    }

    private static void AddCard(TableLayoutPanel host, int column, string label, string value, Color accent)
    {
        var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 27, 37), Margin = new Padding(4) };
        card.Controls.Add(new Label { Text = value, Dock = DockStyle.Top, Height = 48, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI Semibold", 17, FontStyle.Bold), ForeColor = accent });
        card.Controls.Add(new Label { Text = label, Dock = DockStyle.Bottom, Height = 24, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 7.5F, FontStyle.Bold), ForeColor = Color.FromArgb(151, 169, 190) });
        host.Controls.Add(card, column, 0);
    }

    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024d).ToString("0.0") + " KB";
        return (bytes / (1024d * 1024d)).ToString("0.0") + " MB";
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button { Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49), ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor, Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
