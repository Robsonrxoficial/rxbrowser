﻿namespace RXBrowser;

/// <summary>
/// Host-based ad protection using curated local domain sets and an optional user list.
/// It is intentionally not advertised as a full EasyList/uBlock-compatible engine.
/// </summary>
internal static class AdBlocker
{
    private static readonly string[] BasicDomains =
    [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "amazon-adsystem.com", "adsrvr.org", "adroll.com", "criteo.com", "criteo.net",
        "taboola.com", "outbrain.com", "pubmatic.com", "openx.net", "rubiconproject.com",
        "adnxs.com", "adnxs-simple.com", "sharethrough.com", "casalemedia.com", "advertising.com",
        "smartadserver.com", "teads.tv", "zemanta.com", "yieldmo.com", "lijit.com"
    ];

    private static readonly string[] BalancedDomains =
    [
        "33across.com", "a-mo.net", "adblade.com", "adcolony.com", "adform.net", "adhigh.net",
        "adingo.jp", "adition.com", "adkernel.com", "adlucent.com", "admanmedia.com", "admedo.com",
        "adnami.io", "adnetasia.com", "adnium.com", "adocean.pl", "adpone.com", "adriver.ru",
        "adsafeprotected.com", "adskeeper.co.uk", "adspirit.de", "adspyglass.com", "adstir.com",
        "adtelligent.com", "adthrive.com", "adverline.com", "advertserve.com", "adways.com",
        "amgdgt.com", "appnexus.com", "bidswitch.net", "contextweb.com", "de17a.com", "districtm.io",
        "e-planning.net", "exoclick.com", "eyereturn.com", "flashtalking.com", "freewheel.tv",
        "gamoshi.com", "geniee.jp", "imonomy.com", "inmobi.com", "jadserve.com", "lijit.com",
        "loopme.com", "mathtag.com", "media.net", "mediamath.com", "mgid.com", "moatads.com",
        "myvisualiq.net", "nativo.com", "nexage.com", "onetag.com", "optimise.net", "permutive.com",
        "popcash.net", "popads.net", "revcontent.com", "revjet.com", "sovrn.com", "spotx.tv",
        "undertone.com", "vertamedia.com", "wideorbit.com", "xad.com", "zemanta.com"
    ];

    private static readonly string[] StrictDomains =
    [
        "acdn.adnxs.com", "ad.gt", "ad.plus", "adap.tv", "adbit.co", "adbrite.com", "adcash.com",
        "adclickmedia.com", "adexc.net", "adgorithms.com", "adinsight.com", "adk2.com", "admarketplace.net",
        "adpepper.com", "adpushup.com", "adsby.bid", "adskeeper.com", "adspirit.com", "adsterra.com",
        "adtags.mobi", "adtelligent.com", "adtrue.com", "adversal.com", "adzerk.net", "alliednative.com",
        "bannerflow.com", "bidtellect.com", "bidvertiser.com", "brightcom.com", "connatix.com", "conversantmedia.com",
        "undertone.com", "clicksor.com", "clubwpt.com", "converge-digital.com", "engagebdr.com", "epom.com",
        "g.doubleclick.net", "gntbcst.com", "infolinks.com", "inmobi.com", "insticator.com", "intentiq.com",
        "ironsrc.com", "lijit.com", "liveintent.com", "mediaforge.com", "monetate.net", "my6sense.com",
        "nativeads.com", "nielsen.com", "ninthdecimal.com", "owneriq.net", "playwire.com", "popin.cc",
        "pubgears.com", "quantcast.com", "revcontent.com", "shareaholic.com", "slickstream.com", "startapp.com",
        "tapad.com", "triplelift.com", "trafficjunky.com", "undertone.com", "videologygroup.com", "vidoomy.com",
        "weborama.fr", "xaxis.com", "zedo.com"
    ];

    public static int BuiltInRuleCount(string? level) => level switch
    {
        "Basic" => BasicDomains.Length,
        "Strict" => BasicDomains.Concat(BalancedDomains).Concat(StrictDomains).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
        _ => BasicDomains.Concat(BalancedDomains).Distinct(StringComparer.OrdinalIgnoreCase).Count()
    };

    public static bool ShouldBlock(
        Uri requestUri,
        string topLevelHost,
        IReadOnlyCollection<string> siteAllowList,
        IReadOnlyCollection<string> customDomains,
        string level)
    {
        if (requestUri.Scheme is not ("http" or "https")) return false;
        var host = NormalizeHost(requestUri.Host);
        var pageHost = NormalizeHost(topLevelHost);
        if (host.Length == 0 || pageHost.Length == 0) return false;
        if (siteAllowList.Any(allowed => HostMatches(pageHost, allowed))) return false;
        if (customDomains.Any(domain => HostMatches(host, domain))) return true;
        if (HostMatches(host, pageHost) || HostMatches(pageHost, host)) return false;

        IEnumerable<string> rules = level switch
        {
            "Basic" => BasicDomains,
            "Strict" => BasicDomains.Concat(BalancedDomains).Concat(StrictDomains),
            _ => BasicDomains.Concat(BalancedDomains)
        };
        return rules.Any(domain => HostMatches(host, domain));
    }

    public static string NormalizeDomain(string value)
    {
        var domain = (value ?? string.Empty).Trim().TrimStart('.').TrimEnd('.').ToLowerInvariant();
        if (domain.StartsWith("*.", StringComparison.Ordinal)) domain = domain[2..];
        return domain;
    }

    private static string NormalizeHost(string value) => (value ?? string.Empty).Trim().TrimEnd('.').ToLowerInvariant();

    public static bool IsValidDomain(string value)
    {
        var domain = NormalizeDomain(value);
        return domain.Length is > 0 and <= 253 &&
               !domain.Contains('/') && !domain.Contains(':') &&
               Uri.CheckHostName(domain) == UriHostNameType.Dns && domain.Contains('.');
    }

    public static bool HostMatches(string host, string domain)
    {
        var normalized = NormalizeDomain(domain);
        return normalized.Length > 0 &&
               (host.Equals(normalized, StringComparison.OrdinalIgnoreCase) ||
                host.EndsWith("." + normalized, StringComparison.OrdinalIgnoreCase));
    }
}
