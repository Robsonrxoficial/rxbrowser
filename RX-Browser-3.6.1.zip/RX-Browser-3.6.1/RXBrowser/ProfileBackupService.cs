﻿using System.IO.Compression;
using System.Text.Json;

namespace RXBrowser;

/// <summary>Exporta apenas preferências e itens organizacionais não secretos do perfil.</summary>
internal static class ProfileBackupService
{
    private const string DataEntryName = "profile-data.json";
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };
    private const long MaximumBackupEntryBytes = 8 * 1024 * 1024;

    public static void Export(string destinationPath, BrowserData current)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationPath);
        ArgumentNullException.ThrowIfNull(current);
        var snapshot = Clone(current);
        Sanitize(snapshot);
        var json = JsonSerializer.Serialize(snapshot, Options);

        using var archive = ZipFile.Open(destinationPath, ZipArchiveMode.Create);
        var dataEntry = archive.CreateEntry(DataEntryName, CompressionLevel.Optimal);
        using (var stream = dataEntry.Open())
        using (var writer = new StreamWriter(stream)) writer.Write(json);

        var metadata = archive.CreateEntry("backup-info.txt", CompressionLevel.Optimal);
        using var metadataStream = metadata.Open();
        using var metadataWriter = new StreamWriter(metadataStream);
        metadataWriter.WriteLine("RX Browser 3.6 — backup seletivo de perfil");
        metadataWriter.WriteLine($"Criado em UTC: {DateTime.UtcNow:O}");
        metadataWriter.WriteLine("Inclui favoritos, pastas, espaços de trabalho, personalização da Central RX e preferências não secretas.");
        metadataWriter.WriteLine("Exclui senhas, cookies, histórico, downloads, sessões, notas do Caderno RX, PINs, permissões de sites e dados WebView2.");
    }

    public static BrowserData Import(string sourcePath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourcePath);
        using var archive = ZipFile.OpenRead(sourcePath);
        var entry = archive.GetEntry(DataEntryName) ?? throw new InvalidDataException("O backup não contém os dados de perfil esperados.");
        if (entry.Length <= 0 || entry.Length > MaximumBackupEntryBytes)
            throw new InvalidDataException("O backup excede o limite permitido ou está vazio.");
        using var stream = entry.Open();
        using var reader = new StreamReader(stream);
        var restored = JsonSerializer.Deserialize<BrowserData>(reader.ReadToEnd())
            ?? throw new InvalidDataException("Não foi possível interpretar o backup.");
        Sanitize(restored);
        if (restored.Favorites.Count > 5000 || restored.FavoriteFolders.Count > 100 || restored.Workspaces.Count > 100)
            throw new InvalidDataException("O backup contém uma quantidade de itens fora dos limites aceitos.");
        return restored;
    }

    public static void WriteRestoredProfile(string destinationPath, BrowserData restored)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationPath);
        ArgumentNullException.ThrowIfNull(restored);
        var directory = Path.GetDirectoryName(destinationPath);
        if (string.IsNullOrWhiteSpace(directory)) throw new InvalidOperationException("Pasta de perfil inválida.");
        Directory.CreateDirectory(directory);
        var tempPath = destinationPath + ".restore.tmp";
        var rollbackPath = destinationPath + ".pre-restore.bak";
        File.WriteAllText(tempPath, JsonSerializer.Serialize(restored, Options));
        if (File.Exists(destinationPath)) File.Copy(destinationPath, rollbackPath, true);
        File.Move(tempPath, destinationPath, true);
    }

    private static BrowserData Clone(BrowserData source) =>
        JsonSerializer.Deserialize<BrowserData>(JsonSerializer.Serialize(source, Options))
        ?? throw new InvalidOperationException("Não foi possível preparar o backup.");

    private static void Sanitize(BrowserData data)
    {
        data.Favorites ??= new();
        data.FavoriteFolders ??= new() { "Geral" };
        data.Workspaces ??= new();
        data.FavoriteSyncRecords = new();
        data.PhishingAllowlist = new();
        data.AdBlockAllowlist = new();
        data.TrackingAllowlist = new();
        data.PopupAllowlist = new();
        data.History = new();
        data.LastSessionUrls = new();
        data.LastSessionTabs = new();
        data.SavedSessions = new();
        data.ProtectedTabs = new();
        data.DownloadHistory = new();
        data.ClosedTabUrls = new();
        data.SitePermissions = new();
        data.ExtensionInstallRecords = new();
        data.WorkspaceSyncRecords = new();
        data.PasswordAutofillEnabled = false;
        data.SessionSyncEnabled = false;
        data.SessionSyncFolder = string.Empty;
        data.SessionSyncDeviceId = Guid.NewGuid().ToString("N");
        data.SessionSnapshotUtc = DateTime.MinValue;
        data.LastActiveSessionTabIndex = 0;
        data.LastShutdownClean = true;
        data.FavoritesSyncFolder = string.Empty;
        data.PreferencesSyncFolder = string.Empty;
        data.WorkspaceSyncFolder = string.Empty;
        data.AutoSyncEnabled = false;
        data.WorkspaceSyncEnabled = false;
        data.BackupSyncEnabled = false;
        data.BackupSyncFolder = string.Empty;
        data.BackupSyncDeviceId = Guid.NewGuid().ToString("N");
        data.BackupSyncIntervalMinutes = 10;
        data.LastBackupSyncUtc = DateTime.MinValue;
    }
}
