﻿using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Caderno local com notas associadas ao site da guia ativa.</summary>
internal sealed class SiteNotesForm : Form
{
    private static readonly Color CBackground = Color.FromArgb(12, 16, 23);
    private static readonly Color CPanel = Color.FromArgb(20, 27, 37);
    private static readonly Color CPanel2 = Color.FromArgb(27, 36, 49);
    private static readonly Color CAccent = Color.FromArgb(35, 205, 230);
    private static readonly Color CText = Color.FromArgb(232, 240, 248);
    private static readonly Color CMuted = Color.FromArgb(142, 158, 178);

    private readonly List<SiteNoteRecord> _notes;
    private readonly string _currentUrl;
    private readonly string _currentTitle;
    private readonly ListBox _list = new();
    private readonly TextBox _title = new();
    private readonly RichTextBox _body = new();
    private readonly Label _siteInfo = new();
    private readonly Label _status = new();
    private readonly System.Windows.Forms.Timer _autoSaveTimer = new() { Interval = 800 };
    private SiteNoteRecord? _activeNote;
    private bool _loading;
    private bool _dirty;

    public SiteNotesForm(string? currentUrl, string? currentTitle)
    {
        _currentUrl = currentUrl ?? string.Empty;
        _currentTitle = string.IsNullOrWhiteSpace(currentTitle) ? "Página sem título" : currentTitle.Trim();
        _notes = SiteNotesStore.Load();

        Text = "Caderno RX — notas por site";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(760, 520);
        Size = new Size(980, 680);
        BackColor = CBackground;
        ForeColor = CText;
        Font = new Font("Segoe UI", 9.5F);
        KeyPreview = true;

        BuildInterface();
        RefreshNotes();
        _autoSaveTimer.Tick += (_, _) =>
        {
            _autoSaveTimer.Stop();
            CommitActiveNote();
        };
        FormClosing += (_, _) =>
        {
            _autoSaveTimer.Stop();
            CommitActiveNote();
        };
    }

    private void BuildInterface()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = CBackground,
            Padding = new Padding(18),
            ColumnCount = 1,
            RowCount = 4
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill, BackColor = CPanel, Padding = new Padding(16, 8, 14, 7) };
        var heading = new Label
        {
            Text = "CADERNO RX",
            Dock = DockStyle.Top,
            Height = 29,
            ForeColor = CAccent,
            Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold)
        };
        var subheading = new Label
        {
            Text = "Anotações rápidas relacionadas aos seus sites",
            Dock = DockStyle.Fill,
            ForeColor = CMuted,
            AutoEllipsis = true
        };
        header.Controls.Add(subheading);
        header.Controls.Add(heading);
        root.Controls.Add(header, 0, 0);

        var toolbar = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = CBackground,
            Padding = new Padding(0, 8, 0, 4),
            WrapContents = false,
            AutoScroll = true
        };
        var add = MakeButton("+ Nova nota", 104, true);
        add.Click += (_, _) => CreateNote();
        var save = MakeButton("Salvar", 78);
        save.Click += (_, _) => { _autoSaveTimer.Stop(); CommitActiveNote(force: true); };
        var delete = MakeButton("Excluir", 78);
        delete.Click += (_, _) => DeleteActiveNote();
        var export = MakeButton("Exportar .md", 108);
        export.Click += (_, _) => ExportActiveNote();
        toolbar.Controls.AddRange([add, save, delete, export]);
        root.Controls.Add(toolbar, 0, 1);

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            BackColor = CBackground,
            BorderStyle = BorderStyle.None,
            Size = new Size(900, 500),
            SplitterDistance = 300,
            FixedPanel = FixedPanel.Panel1,
            Panel1MinSize = 190,
            Panel2MinSize = 320
        };
        split.Panel1.Padding = new Padding(0, 0, 10, 0);
        split.Panel2.Padding = new Padding(10, 0, 0, 0);
        root.Controls.Add(split, 0, 2);

        var listPanel = new Panel { Dock = DockStyle.Fill, BackColor = CPanel, Padding = new Padding(10) };
        var listHeading = new Label
        {
            Text = "SUAS NOTAS",
            Dock = DockStyle.Top,
            Height = 32,
            ForeColor = CAccent,
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold)
        };
        _list.Dock = DockStyle.Fill;
        _list.BackColor = CPanel;
        _list.ForeColor = CText;
        _list.BorderStyle = BorderStyle.None;
        _list.Font = new Font("Segoe UI", 9F);
        _list.IntegralHeight = false;
        _list.SelectedIndexChanged += (_, _) =>
        {
            if (_loading) return;
            CommitActiveNote();
            if (_list.SelectedItem is SiteNoteRecord note) LoadNote(note);
        };
        listPanel.Controls.Add(_list);
        listPanel.Controls.Add(listHeading);
        split.Panel1.Controls.Add(listPanel);

        var editor = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = CPanel,
            Padding = new Padding(14),
            ColumnCount = 1,
            RowCount = 3
        };
        editor.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));
        editor.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        editor.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        split.Panel2.Controls.Add(editor);

        var titlePanel = new Panel { Dock = DockStyle.Fill, BackColor = CPanel };
        var titleLabel = new Label { Text = "TÍTULO", Dock = DockStyle.Top, Height = 22, ForeColor = CMuted, Font = new Font("Segoe UI", 8F, FontStyle.Bold) };
        _title.Dock = DockStyle.Bottom;
        _title.Height = 34;
        _title.BorderStyle = BorderStyle.FixedSingle;
        _title.BackColor = CPanel2;
        _title.ForeColor = CText;
        _title.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
        _title.TextChanged += Editor_TextChanged;
        titlePanel.Controls.Add(_title);
        titlePanel.Controls.Add(titleLabel);
        editor.Controls.Add(titlePanel, 0, 0);

        _siteInfo.Dock = DockStyle.Fill;
        _siteInfo.ForeColor = CAccent;
        _siteInfo.AutoEllipsis = true;
        _siteInfo.TextAlign = ContentAlignment.MiddleLeft;
        editor.Controls.Add(_siteInfo, 0, 1);

        _body.Dock = DockStyle.Fill;
        _body.BackColor = CPanel2;
        _body.ForeColor = CText;
        _body.BorderStyle = BorderStyle.None;
        _body.Font = new Font("Segoe UI", 10.5F);
        _body.AcceptsTab = true;
        _body.WordWrap = true;
        _body.DetectUrls = true;
        _body.ScrollBars = RichTextBoxScrollBars.Vertical;
        _body.TextChanged += Editor_TextChanged;
        editor.Controls.Add(_body, 0, 2);

        _status.Dock = DockStyle.Fill;
        _status.ForeColor = CMuted;
        _status.TextAlign = ContentAlignment.MiddleLeft;
        _status.Text = "Salvamento automático ativado · notas armazenadas neste perfil local.";
        root.Controls.Add(_status, 0, 3);
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text,
            Width = width,
            Height = 32,
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 105, 124) : CPanel2,
            ForeColor = CText,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            Margin = new Padding(0, 0, 8, 0),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderColor = accent ? CAccent : Color.FromArgb(48, 62, 79);
        button.FlatAppearance.BorderSize = 1;
        return button;
    }

    private void RefreshNotes(string? selectedId = null)
    {
        _loading = true;
        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var note in _notes.OrderByDescending(item => item.UpdatedUtc))
            _list.Items.Add(note);
        if (_list.Items.Count > 0)
        {
            var index = selectedId is null ? 0 : _notes
                .OrderByDescending(item => item.UpdatedUtc)
                .ToList()
                .FindIndex(item => item.Id == selectedId);
            _list.SelectedIndex = index >= 0 && index < _list.Items.Count ? index : 0;
        }
        _list.EndUpdate();
        _loading = false;

        if (_list.SelectedItem is SiteNoteRecord selected) LoadNote(selected);
        else ClearEditor();
    }

    private void LoadNote(SiteNoteRecord note)
    {
        _loading = true;
        _activeNote = note;
        _title.Text = note.Title;
        _body.Text = note.Body;
        _siteInfo.Text = string.IsNullOrWhiteSpace(note.Url) ? note.Site : $"{note.Site}   ·   {note.Url}";
        _body.ReadOnly = false;
        _title.ReadOnly = false;
        _dirty = false;
        _loading = false;
        _status.Text = $"Criada em {note.CreatedUtc.ToLocalTime():dd/MM/yyyy HH:mm} · alterações salvas automaticamente neste perfil.";
    }

    private void ClearEditor()
    {
        _loading = true;
        _activeNote = null;
        _title.Clear();
        _body.Clear();
        _title.ReadOnly = true;
        _body.ReadOnly = true;
        _siteInfo.Text = "Nenhuma nota selecionada";
        _dirty = false;
        _loading = false;
        _status.Text = "Clique em + Nova nota para começar.";
    }

    private void CreateNote()
    {
        if (_notes.Count >= 500)
        {
            MessageBox.Show(this, "O limite de 500 notas por perfil foi atingido. Exporte ou exclua algumas notas antes de criar outra.",
                "Caderno RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        CommitActiveNote();
        var url = SiteNotesStore.GetSafeReferenceUrl(_currentUrl);
        var note = new SiteNoteRecord
        {
            Title = _currentTitle[..Math.Min(120, _currentTitle.Length)],
            Url = url,
            Site = SiteNotesStore.GetSiteLabel(url),
            CreatedUtc = DateTime.UtcNow,
            UpdatedUtc = DateTime.UtcNow
        };
        _notes.Insert(0, note);
        SiteNotesStore.Save(_notes);
        RefreshNotes(note.Id);
        _body.Focus();
        _body.SelectionStart = _body.TextLength;
    }

    private void Editor_TextChanged(object? sender, EventArgs e)
    {
        if (_loading || _activeNote is null) return;
        _dirty = true;
        _status.Text = "Alterações pendentes · salvando automaticamente…";
        _autoSaveTimer.Stop();
        _autoSaveTimer.Start();
    }

    private void CommitActiveNote(bool force = false)
    {
        if (_activeNote is null || (!_dirty && !force)) return;
        _activeNote.Title = string.IsNullOrWhiteSpace(_title.Text) ? "Nota sem título" : _title.Text.Trim()[..Math.Min(120, _title.Text.Trim().Length)];
        _activeNote.Body = _body.Text.Length > 100_000 ? _body.Text[..100_000] : _body.Text;
        _activeNote.UpdatedUtc = DateTime.UtcNow;
        try
        {
            SiteNotesStore.Save(_notes);
            _dirty = false;
            _list.Invalidate();
            _status.Text = $"Salvo automaticamente às {_activeNote.UpdatedUtc.ToLocalTime():HH:mm:ss} · somente neste perfil.";
        }
        catch (Exception exception)
        {
            BrowserDiagnosticsLog.Write("SiteNotes.Save", exception);
            _status.Text = "Não foi possível salvar. Confira o espaço disponível e as permissões da pasta do perfil.";
        }
    }

    private void DeleteActiveNote()
    {
        if (_activeNote is null) return;
        var result = MessageBox.Show(this, $"Excluir a nota ‘{_activeNote.Title}’?", "Caderno RX", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;
        _autoSaveTimer.Stop();
        _notes.RemoveAll(note => note.Id == _activeNote.Id);
        _activeNote = null;
        SiteNotesStore.Save(_notes);
        RefreshNotes();
    }

    private void ExportActiveNote()
    {
        if (_activeNote is null) return;
        CommitActiveNote();
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar nota do Caderno RX",
            Filter = "Arquivo Markdown (*.md)|*.md|Arquivo de texto (*.txt)|*.txt",
            FileName = MakeSafeFileName(_activeNote.Title) + ".md",
            AddExtension = true,
            DefaultExt = "md"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        var markdown = new StringBuilder()
            .Append("# ").AppendLine(_activeNote.Title)
            .AppendLine()
            .Append("- Site: ").AppendLine(_activeNote.Site)
            .Append("- Endereço: ").AppendLine(string.IsNullOrWhiteSpace(_activeNote.Url) ? "(não informado)" : _activeNote.Url)
            .Append("- Atualizada em: ").AppendLine(_activeNote.UpdatedUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm"))
            .AppendLine()
            .AppendLine(_activeNote.Body)
            .ToString();
        try
        {
            File.WriteAllText(dialog.FileName, markdown, new UTF8Encoding(true));
            _status.Text = "Nota exportada: " + Path.GetFileName(dialog.FileName);
        }
        catch (Exception exception)
        {
            MessageBox.Show(this, "Não foi possível exportar a nota:\n" + exception.Message, "Caderno RX", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static string MakeSafeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var safe = new string(value.Select(character => invalid.Contains(character) ? '_' : character).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(safe) ? "nota-rx" : safe;
    }
}
