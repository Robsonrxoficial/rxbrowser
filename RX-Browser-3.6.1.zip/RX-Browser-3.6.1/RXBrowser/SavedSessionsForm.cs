﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal enum SavedSessionAction { None, Open, Rename, Delete }

/// <summary>Gerenciador de sessões com pesquisa e pré-visualização dos endereços antes de restaurar.</summary>
internal sealed class SavedSessionsForm : Form
{
    private readonly ListBox _items = new();
    private readonly TextBox _search = new();
    private readonly TextBox _preview = new();
    private readonly List<SavedSessionRecord> _all;
    public SavedSessionRecord? SelectedSession => _items.SelectedItem as SavedSessionRecord;
    public SavedSessionAction Action { get; private set; }

    public SavedSessionsForm(IReadOnlyList<SavedSessionRecord> sessions)
    {
        _all = sessions.OrderByDescending(item => item.SavedUtc).ToList();
        Text = "Sessões salvas — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.Sizable;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(760, 570);
        MinimumSize = new Size(620, 440);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);
        KeyPreview = true;

        var header = new Label
        {
            Text = "SUAS SESSÕES SALVAS",
            Dock = DockStyle.Top, Height = 48, Padding = new Padding(18, 13, 0, 0),
            ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        };
        Controls.Add(header);

        var searchPanel = new Panel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(14, 7, 14, 7), BackColor = Color.FromArgb(18, 25, 35) };
        _search.Dock = DockStyle.Fill;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = ForeColor;
        _search.PlaceholderText = "Pesquisar sessão, guia ou endereço…";
        _search.TextChanged += (_, _) => FilterSessions();
        searchPanel.Controls.Add(_search);
        Controls.Add(searchPanel);

        _items.Dock = DockStyle.Fill;
        _items.BackColor = Color.FromArgb(20, 27, 37);
        _items.ForeColor = ForeColor;
        _items.BorderStyle = BorderStyle.None;
        _items.IntegralHeight = false;
        _items.SelectedIndexChanged += (_, _) => UpdatePreview();
        _items.DoubleClick += (_, _) => Complete(SavedSessionAction.Open);
        Controls.Add(_items);

        _preview.Dock = DockStyle.Bottom;
        _preview.Height = 132;
        _preview.Multiline = true;
        _preview.ReadOnly = true;
        _preview.ScrollBars = ScrollBars.Vertical;
        _preview.BorderStyle = BorderStyle.FixedSingle;
        _preview.BackColor = Color.FromArgb(15, 21, 30);
        _preview.ForeColor = Color.FromArgb(184, 199, 215);
        _preview.Font = new Font("Consolas", 8.5F);
        _preview.Text = "Selecione uma sessão para ver os detalhes e as guias que serão abertas.";
        Controls.Add(_preview);

        var footer = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 62, FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false, Padding = new Padding(10), BackColor = Color.FromArgb(18, 25, 35)
        };
        var close = MakeButton("Fechar", 88);
        close.DialogResult = DialogResult.Cancel;
        var open = MakeButton("Abrir sessão", 112, true);
        open.Click += (_, _) => Complete(SavedSessionAction.Open);
        var rename = MakeButton("Renomear", 96);
        rename.Click += (_, _) => Complete(SavedSessionAction.Rename);
        var delete = MakeButton("Excluir", 86);
        delete.Click += (_, _) => Complete(SavedSessionAction.Delete);
        footer.Controls.Add(close);
        footer.Controls.Add(open);
        footer.Controls.Add(rename);
        footer.Controls.Add(delete);
        Controls.Add(footer);

        FilterSessions();
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter && _search.Focused) { _items.Focus(); e.Handled = true; }
            else if (e.KeyCode == Keys.Delete && _items.Focused) { Complete(SavedSessionAction.Delete); e.Handled = true; }
        };
        AcceptButton = open;
        CancelButton = close;
    }

    private void FilterSessions()
    {
        var selectedId = SelectedSession?.Id;
        var query = _search.Text.Trim();
        var filtered = _all.Where(session => query.Length == 0 ||
            session.Name.Contains(query, StringComparison.CurrentCultureIgnoreCase) ||
            session.Tabs.Any(tab => (tab.Title ?? string.Empty).Contains(query, StringComparison.CurrentCultureIgnoreCase) ||
                (tab.Url ?? string.Empty).Contains(query, StringComparison.CurrentCultureIgnoreCase)))
            .OrderByDescending(session => session.SavedUtc).ToList();
        _items.BeginUpdate();
        try
        {
            _items.Items.Clear();
            foreach (var session in filtered) _items.Items.Add(session);
            var restoreIndex = filtered.FindIndex(session => session.Id == selectedId);
            if (_items.Items.Count > 0) _items.SelectedIndex = restoreIndex >= 0 ? restoreIndex : 0;
        }
        finally { _items.EndUpdate(); }
        UpdatePreview();
    }

    private void UpdatePreview()
    {
        var session = SelectedSession;
        if (session is null)
        {
            _preview.Text = _all.Count == 0
                ? "Nenhuma sessão salva neste perfil. Use ‘Salvar sessão atual com nome’ no menu do navegador."
                : "Nenhuma sessão corresponde à pesquisa atual.";
            return;
        }
        var lines = new List<string>
        {
            session.Name,
            $"Salva em: {session.SavedUtc.ToLocalTime():dd/MM/yyyy HH:mm}   •   {session.Tabs.Count} guia(s)   •   Guia ativa: {Math.Clamp(session.ActiveIndex + 1, 1, Math.Max(1, session.Tabs.Count))}",
            new string('─', 78)
        };
        foreach (var tab in session.Tabs.Take(12))
        {
            var marker = tab.IsPinned ? "[FIXA] " : string.Empty;
            var group = string.IsNullOrWhiteSpace(tab.GroupName) ? string.Empty : $" [{tab.GroupName}]";
            lines.Add(marker + (string.IsNullOrWhiteSpace(tab.Title) ? "Sem título" : tab.Title) + group);
            lines.Add("  " + tab.Url);
        }
        if (session.Tabs.Count > 12) lines.Add($"… e mais {session.Tabs.Count - 12} guia(s)");
        _preview.Text = string.Join(Environment.NewLine, lines);
    }

    private void Complete(SavedSessionAction action)
    {
        if (SelectedSession is null) return;
        Action = action;
        DialogResult = DialogResult.OK;
        Close();
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
