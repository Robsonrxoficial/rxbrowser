﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Live, session-only dashboard for RX Browser privacy events.</summary>
internal sealed class PrivacyActivityDashboardForm : Form
{
    private static readonly Color Background = Color.FromArgb(12, 16, 23);
    private static readonly Color PanelColor = Color.FromArgb(20, 27, 37);
    private static readonly Color PanelAltColor = Color.FromArgb(27, 36, 49);
    private static readonly Color Accent = Color.FromArgb(55, 211, 235);
    private static readonly Color Foreground = Color.FromArgb(232, 240, 248);
    private static readonly Color Muted = Color.FromArgb(142, 158, 178);

    private readonly PrivacyActivityStore _store;
    private readonly string _currentHost;
    private readonly CheckBox _currentSiteOnly = new();
    private readonly Label _requests = MakeMetricLabel();
    private readonly Label _blocked = MakeMetricLabel();
    private readonly Label _ads = MakeMetricLabel();
    private readonly Label _trackers = MakeMetricLabel();
    private readonly Label _other = MakeMetricLabel();
    private readonly ListView _recent = new();
    private readonly ListBox _topDomains = new();
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 1200 };

    public PrivacyActivityDashboardForm(PrivacyActivityStore store, string? currentHost)
    {
        _store = store;
        _currentHost = (currentHost ?? string.Empty).Trim().TrimEnd('.').ToLowerInvariant();
        Text = "Painel de privacidade em tempo real — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(900, 620);
        Size = new Size(1120, 760);
        BackColor = Background;
        ForeColor = Foreground;
        Font = new Font("Segoe UI", 9.25F);

        var header = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = PanelColor, Padding = new Padding(22, 13, 18, 8) };
        header.Controls.Add(new Label
        {
            Dock = DockStyle.Top, Height = 27, Text = "RX PRIVACY MONITOR",
            ForeColor = Accent, Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold)
        });
        header.Controls.Add(new Label
        {
            Dock = DockStyle.Bottom, Height = 20,
            Text = "Atividade desta sessão · somente domínios e categorias · nenhum endereço completo é registrado",
            ForeColor = Muted, Font = new Font("Segoe UI", 8.5F)
        });
        Controls.Add(header);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 58, BackColor = PanelColor, Padding = new Padding(14, 10, 14, 10) };
        var clear = MakeButton("Limpar atividade", 136, false);
        clear.Dock = DockStyle.Left;
        clear.Click += (_, _) =>
        {
            if (MessageBox.Show(this, "Limpar as contagens e os últimos eventos desta sessão? Isso não altera as regras de proteção.",
                "Limpar atividade", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            _store.Clear();
            RefreshSnapshot();
        };
        var close = MakeButton("Fechar", 96, true);
        close.Dock = DockStyle.Right;
        close.DialogResult = DialogResult.Cancel;
        footer.Controls.Add(close);
        footer.Controls.Add(clear);
        Controls.Add(footer);

        var body = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, BackColor = Background, Padding = new Padding(16),
            ColumnCount = 1, RowCount = 3
        };
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 94));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
        body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(body);

        var metrics = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 1, BackColor = Background, Margin = new Padding(0) };
        for (var i = 0; i < 5; i++) metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        metrics.Controls.Add(MetricCard("REQUISIÇÕES EXTERNAS", _requests), 0, 0);
        metrics.Controls.Add(MetricCard("BLOQUEIOS", _blocked), 1, 0);
        metrics.Controls.Add(MetricCard("ANÚNCIOS", _ads), 2, 0);
        metrics.Controls.Add(MetricCard("RASTREADORES", _trackers), 3, 0);
        metrics.Controls.Add(MetricCard("OUTROS ALERTAS", _other), 4, 0);
        body.Controls.Add(metrics, 0, 0);

        var filterBar = new Panel { Dock = DockStyle.Fill, BackColor = Background, Margin = new Padding(0) };
        _currentSiteOnly.Text = "Mostrar apenas eventos do site atual";
        _currentSiteOnly.AutoSize = true;
        _currentSiteOnly.Checked = _currentHost.Length > 0;
        _currentSiteOnly.Enabled = _currentHost.Length > 0;
        _currentSiteOnly.ForeColor = Foreground;
        _currentSiteOnly.BackColor = Background;
        _currentSiteOnly.Left = 4;
        _currentSiteOnly.Top = 8;
        _currentSiteOnly.CheckedChanged += (_, _) => RefreshSnapshot();
        filterBar.Controls.Add(_currentSiteOnly);

        var siteInfo = new Label
        {
            Left = 350, Top = 8, Width = 500, Height = 22,
            Anchor = AnchorStyles.Left | AnchorStyles.Right,
            Text = _currentHost.Length > 0 ? "Site atual: " + _currentHost + " · contagens abrangem a sessão inteira" : "Sem site selecionado · contagens abrangem a sessão inteira",
            ForeColor = Muted, AutoEllipsis = true
        };
        filterBar.Controls.Add(siteInfo);
        body.Controls.Add(filterBar, 0, 1);

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill, Orientation = Orientation.Vertical, Size = new Size(1000, 500),
            SplitterDistance = 290, BackColor = Background, BorderStyle = BorderStyle.None,
            Panel1MinSize = 220, Panel2MinSize = 480, Margin = new Padding(0)
        };
        var domainTitle = new Label { Text = "DOMÍNIOS MAIS BLOQUEADOS", Dock = DockStyle.Top, Height = 32, ForeColor = Accent, Font = new Font("Segoe UI Semibold", 9, FontStyle.Bold), Padding = new Padding(5, 7, 0, 0) };
        _topDomains.Dock = DockStyle.Fill;
        _topDomains.BackColor = PanelColor;
        _topDomains.ForeColor = Foreground;
        _topDomains.BorderStyle = BorderStyle.FixedSingle;
        split.Panel1.Controls.Add(_topDomains);
        split.Panel1.Controls.Add(domainTitle);

        var recentTitle = new Label { Text = "EVENTOS RECENTES", Dock = DockStyle.Top, Height = 32, ForeColor = Accent, Font = new Font("Segoe UI Semibold", 9, FontStyle.Bold), Padding = new Padding(5, 7, 0, 0) };
        _recent.Dock = DockStyle.Fill;
        _recent.View = View.Details;
        _recent.FullRowSelect = true;
        _recent.GridLines = true;
        _recent.HideSelection = false;
        _recent.BackColor = PanelColor;
        _recent.ForeColor = Foreground;
        _recent.BorderStyle = BorderStyle.FixedSingle;
        _recent.Columns.Add("Horário", 78);
        _recent.Columns.Add("Site da página", 150);
        _recent.Columns.Add("Domínio", 160);
        _recent.Columns.Add("Categoria", 125);
        _recent.Columns.Add("Recurso", 110);
        _recent.Columns.Add("Detalhe", 300);
        split.Panel2.Controls.Add(_recent);
        split.Panel2.Controls.Add(recentTitle);
        body.Controls.Add(split, 0, 2);

        AcceptButton = close;
        CancelButton = close;
        _timer.Tick += (_, _) => RefreshSnapshot();
        Shown += (_, _) => _timer.Start();
        FormClosed += (_, _) => _timer.Stop();
        RefreshSnapshot();
    }

    private void RefreshSnapshot()
    {
        if (IsDisposed) return;
        var snapshot = _store.GetSnapshot();
        _requests.Text = snapshot.ExternalRequestsInspected.ToString("N0");
        _blocked.Text = snapshot.BlockedRequests.ToString("N0");
        _ads.Text = snapshot.AdsBlocked.ToString("N0");
        _trackers.Text = snapshot.TrackersBlocked.ToString("N0");
        _other.Text = (snapshot.PopupsBlocked + snapshot.PhishingWarnings).ToString("N0");

        var recent = snapshot.Recent.AsEnumerable();
        if (_currentSiteOnly.Checked && _currentHost.Length > 0)
            recent = recent.Where(entry => string.Equals(entry.PageHost, _currentHost, StringComparison.OrdinalIgnoreCase));
        var entries = recent.Take(150).ToArray();

        _topDomains.BeginUpdate();
        _topDomains.Items.Clear();
        var domainCounts = _currentSiteOnly.Checked && _currentHost.Length > 0
            ? entries.Where(entry => entry.RequestHost != "—")
                .GroupBy(entry => entry.RequestHost, StringComparer.OrdinalIgnoreCase)
                .Select(group => new KeyValuePair<string, int>(group.Key, group.Count()))
                .OrderByDescending(item => item.Value).ThenBy(item => item.Key, StringComparer.OrdinalIgnoreCase).Take(25).ToArray()
            : snapshot.TopBlockedDomains.ToArray();
        foreach (var item in domainCounts) _topDomains.Items.Add($"{item.Value,4}  {item.Key}");
        if (_topDomains.Items.Count == 0) _topDomains.Items.Add("Ainda não há domínios bloqueados.");
        _topDomains.EndUpdate();

        _recent.BeginUpdate();
        _recent.Items.Clear();
        foreach (var entry in entries)
        {
            var row = new ListViewItem(entry.TimestampUtc.ToLocalTime().ToString("HH:mm:ss"));
            row.SubItems.Add(entry.PageHost);
            row.SubItems.Add(entry.RequestHost);
            row.SubItems.Add(entry.Category);
            row.SubItems.Add(entry.ResourceType);
            row.SubItems.Add(entry.Reason);
            _recent.Items.Add(row);
        }
        _recent.EndUpdate();
    }

    private static Panel MetricCard(string caption, Label value)
    {
        var card = new Panel { Dock = DockStyle.Fill, BackColor = PanelColor, Margin = new Padding(3), Padding = new Padding(10, 8, 8, 5) };
        card.Controls.Add(new Label { Text = caption, Dock = DockStyle.Top, Height = 19, ForeColor = Muted, Font = new Font("Segoe UI", 7.5F, FontStyle.Bold), AutoEllipsis = true });
        value.Dock = DockStyle.Fill;
        value.TextAlign = ContentAlignment.MiddleLeft;
        value.ForeColor = Foreground;
        value.Font = new Font("Segoe UI Semibold", 21, FontStyle.Bold);
        card.Controls.Add(value);
        return card;
    }

    private static Label MakeMetricLabel() => new() { Text = "0", AutoEllipsis = true };

    private Button MakeButton(string text, int width, bool accent)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : PanelAltColor,
            ForeColor = accent ? Accent : Foreground,
            Cursor = Cursors.Hand, Margin = new Padding(5, 0, 0, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
