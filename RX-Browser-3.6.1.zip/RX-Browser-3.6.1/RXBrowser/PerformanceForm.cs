﻿using Microsoft.Web.WebView2.Core;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed record BrowserProcessMetric(int ProcessId, string Kind, long PrivateBytes, long WorkingSetBytes);

internal sealed class PerformanceForm : Form
{
    private readonly Func<List<BrowserProcessMetric>> _getMetrics;
    private readonly Func<(int Total, int Active, int Private)> _getTabCounts;
    private readonly Label _summary = new();
    private readonly ListView _processes = new();
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 1500 };
    private TimeSpan _lastCpu;
    private DateTime _lastSampleUtc;

    public PerformanceForm(Func<List<BrowserProcessMetric>> getMetrics, Func<(int Total, int Active, int Private)> getTabCounts)
    {
        _getMetrics = getMetrics;
        _getTabCounts = getTabCounts;
        Text = "Desempenho — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(780, 540);
        MinimumSize = new Size(620, 420);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var header = new Panel { Dock = DockStyle.Top, Height = 118, Padding = new Padding(18, 12, 18, 12), BackColor = Color.FromArgb(20, 27, 37) };
        header.Controls.Add(new Label { Text = "PAINEL DE DESEMPENHO", Dock = DockStyle.Top, Height = 27, ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold) });
        _summary.Dock = DockStyle.Fill;
        _summary.ForeColor = Color.FromArgb(232, 240, 248);
        _summary.Text = "Coletando métricas…";
        header.Controls.Add(_summary);
        Controls.Add(header);

        _processes.Dock = DockStyle.Fill;
        _processes.View = View.Details;
        _processes.FullRowSelect = true;
        _processes.HideSelection = false;
        _processes.BackColor = Color.FromArgb(20, 27, 37);
        _processes.ForeColor = Color.FromArgb(232, 240, 248);
        _processes.Columns.Add("Processo WebView2", 250);
        _processes.Columns.Add("PID", 85);
        _processes.Columns.Add("Memória privada", 155);
        _processes.Columns.Add("Memória física", 155);
        Controls.Add(_processes);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 42, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(14, 8, 14, 6) };
        footer.Controls.Add(new Label { Text = "Atualização automática a cada 1,5 s. O WebView2 compartilha processos entre guias; valores não são atribuídos com precisão a cada site.", AutoSize = true, ForeColor = Color.FromArgb(142, 158, 178) });
        Controls.Add(footer);
        Shown += (_, _) => { RefreshMetrics(); _timer.Start(); };
        FormClosed += (_, _) => { _timer.Stop(); _timer.Dispose(); };
        _timer.Tick += (_, _) => RefreshMetrics();
    }

    private void RefreshMetrics()
    {
        if (IsDisposed) return;
        try
        {
            var rows = _getMetrics();
            var counts = _getTabCounts();
            var privateTotal = rows.Sum(x => x.PrivateBytes);
            var workingSetTotal = rows.Sum(x => x.WorkingSetBytes);
            using var process = Process.GetCurrentProcess();
            process.Refresh();
            var cpuNow = process.TotalProcessorTime;
            var now = DateTime.UtcNow;
            var cpuPercent = 0d;
            if (_lastSampleUtc != DateTime.MinValue)
            {
                var elapsed = (now - _lastSampleUtc).TotalMilliseconds * Math.Max(1, Environment.ProcessorCount);
                if (elapsed > 0) cpuPercent = Math.Clamp((cpuNow - _lastCpu).TotalMilliseconds / elapsed * 100d, 0, 100);
            }
            _lastCpu = cpuNow;
            _lastSampleUtc = now;
            _summary.Text = $"Guias: {counts.Total} (ativas: {counts.Active}, privadas: {counts.Private})    •    Processos WebView2: {rows.Count}\n" +
                $"Memória privada do WebView2: {FormatBytes(privateTotal)}    •    Memória física: {FormatBytes(workingSetTotal)}\n" +
                $"RX Browser (processo da interface): {FormatBytes(process.WorkingSet64)}    •    CPU estimada da interface: {cpuPercent:F1}%";
            _processes.BeginUpdate();
            _processes.Items.Clear();
            foreach (var metric in rows.OrderByDescending(x => x.PrivateBytes))
            {
                var item = new ListViewItem(metric.Kind);
                item.SubItems.Add(metric.ProcessId.ToString());
                item.SubItems.Add(FormatBytes(metric.PrivateBytes));
                item.SubItems.Add(FormatBytes(metric.WorkingSetBytes));
                _processes.Items.Add(item);
            }
            _processes.EndUpdate();
        }
        catch (Exception ex)
        {
            _summary.Text = "Não foi possível ler as métricas do WebView2: " + ex.Message;
        }
    }

    private static string FormatBytes(long bytes)
    {
        if (bytes < 0) return "—";
        var value = (double)bytes;
        var units = new[] { "B", "KB", "MB", "GB" };
        var index = 0;
        while (value >= 1024 && index < units.Length - 1) { value /= 1024; index++; }
        return $"{value:F1} {units[index]}";
    }
}
