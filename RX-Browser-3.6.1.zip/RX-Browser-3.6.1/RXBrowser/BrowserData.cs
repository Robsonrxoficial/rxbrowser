﻿using System.Text.Json;

namespace RXBrowser;

internal sealed class BrowserData
{
    public List<FavoriteItem> Favorites { get; set; } = new();
    public List<string> FavoriteFolders { get; set; } = new() { "Geral" };
    public List<FavoriteSyncRecord> FavoriteSyncRecords { get; set; } = new();
    public List<HistoryItem> History { get; set; } = new();
    public List<string> LastSessionUrls { get; set; } = new();
    public List<SessionTabSnapshot> LastSessionTabs { get; set; } = new();
    public List<SavedSessionRecord> SavedSessions { get; set; } = new();
    public List<TabProtectionRecord> ProtectedTabs { get; set; } = new();
    public bool PasswordAutofillEnabled { get; set; } = false;
    public bool PhishingProtectionEnabled { get; set; } = true;
    public string PhishingProtectionLevel { get; set; } = "Balanced";
    public List<string> PhishingAllowlist { get; set; } = new();
    public bool SessionSyncEnabled { get; set; }
    public string SessionSyncFolder { get; set; } = string.Empty;
    public string SessionSyncDeviceId { get; set; } = Guid.NewGuid().ToString("N");
    public int LastActiveSessionTabIndex { get; set; }
    public DateTime SessionSnapshotUtc { get; set; } = DateTime.MinValue;
    public bool LastShutdownClean { get; set; } = true;
    public List<DownloadHistoryItem> DownloadHistory { get; set; } = new();
    public int BackgroundTabSuspendDelaySeconds { get; set; } = 45;
    public string SearchEngine { get; set; } = "DuckDuckGo";
    public bool RestoreLastSession { get; set; } = true;
    public bool ForceDarkMode { get; set; } = true;
    public int ZoomPercent { get; set; } = 100;
    public int UiScalePercent { get; set; } = 100;
    public bool AccessibilityHighContrast { get; set; }
    public bool AdBlockEnabled { get; set; } = true;
    public string AdBlockLevel { get; set; } = "Balanced";
    public List<string> AdBlockCustomDomains { get; set; } = new();
    public List<string> AdBlockAllowlist { get; set; } = new();
    public List<string> TrackingAllowlist { get; set; } = new();
    public List<SidebarLink> SidebarLinks { get; set; } = new();
    public bool SidebarVisible { get; set; } = true;
    public List<string> ClosedTabUrls { get; set; } = new();
    public List<string> ControlCenterVisibleActions { get; set; } = new();
    public List<string> ControlCenterActionOrder { get; set; } = new();
    public string ControlCenterAccentHex { get; set; } = string.Empty;
    public int ControlCenterColumns { get; set; } = 3;
    public List<string> ToolbarHiddenButtons { get; set; } = new();
    public bool BackupSyncEnabled { get; set; }
    public string BackupSyncFolder { get; set; } = string.Empty;
    public string BackupSyncDeviceId { get; set; } = Guid.NewGuid().ToString("N");
    public int BackupSyncIntervalMinutes { get; set; } = 10;
    public DateTime LastBackupSyncUtc { get; set; } = DateTime.MinValue;
    public string FavoritesSyncFolder { get; set; } = string.Empty;
    public string PreferencesSyncFolder { get; set; } = string.Empty;
    public bool AutoSyncEnabled { get; set; } = false;
    public string TrackingProtectionLevel { get; set; } = "Balanced";
    public bool DoNotTrack { get; set; } = true;
    public bool EcoModeEnabled { get; set; } = true;
    public string ThemeAccent { get; set; } = "Cyan";
    public string InterfaceTheme { get; set; } = "Midnight";
    public string HomePageTheme { get; set; } = "Aurora";
    public string HomePageCardStyle { get; set; } = "Glass";
    public string TranslationSourceLanguage { get; set; } = "auto";
    public string HomePageGreeting { get; set; } = "NAVEGUE DO SEU JEITO";
    public bool HomePageShowClock { get; set; } = true;
    public bool HomePageShowQuickLinks { get; set; } = true;
    public bool HomePageShowFavorites { get; set; } = true;
    public bool HomePageShowRecentSites { get; set; } = false;
    public int HomePageFavoriteCount { get; set; } = 8;
    public List<SidebarLink> HomePageQuickLinks { get; set; } = new()
    {
        new SidebarLink("Google", "https://www.google.com"),
        new SidebarLink("YouTube", "https://www.youtube.com"),
        new SidebarLink("Wikipedia", "https://www.wikipedia.org"),
        new SidebarLink("GitHub", "https://github.com")
    };
    public string PreferredTranslationLanguage { get; set; } = "pt";
    public bool CompactTabs { get; set; } = false;
    public int SidebarWidth { get; set; } = 226;
    public bool BlockPopups { get; set; } = true;
    public List<string> PopupAllowlist { get; set; } = new();
    public bool WarnDangerousDownloads { get; set; } = true;
    public string DownloadProtectionLevel { get; set; } = "Balanced";
    public List<ExtensionInstallRecord> ExtensionInstallRecords { get; set; } = new();
    public string ProfileBadge { get; set; } = "🌐";
    public string ThemeAccentHex { get; set; } = string.Empty;
    public List<SitePermissionRule> SitePermissions { get; set; } = new();
    public List<WorkspaceRecord> Workspaces { get; set; } = new();
    public string WorkspaceSyncFolder { get; set; } = string.Empty;
    public bool WorkspaceSyncEnabled { get; set; }
    public List<WorkspaceSyncRecord> WorkspaceSyncRecords { get; set; } = new();
    public Dictionary<string, string> ShortcutOverrides { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public string SpeechVoiceName { get; set; } = string.Empty;
    public string SpeechVoiceLanguage { get; set; } = string.Empty;
    public double SpeechRate { get; set; } = 1.0;
    public double SpeechPitch { get; set; } = 1.0;
    public double VideoPlaybackRate { get; set; } = 1.0;
}

internal sealed record FavoriteItem(string Title, string Url)
{
    public string GroupName { get; init; } = "Geral";
}
internal sealed class FavoriteSyncRecord
{
    public string Title { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public string GroupName { get; set; } = "Geral";
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public bool IsDeleted { get; set; }
}
internal sealed record HistoryItem(string Title, string Url, DateTime VisitedAt);

internal sealed class WorkspaceRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Novo espaço";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public List<WorkspaceTabRecord> Tabs { get; set; } = new();
}

internal sealed class WorkspaceTabRecord
{
    public string Title { get; set; } = "Nova guia";
    public string Url { get; set; } = string.Empty;
    public bool IsPinned { get; set; }
    public string? GroupName { get; set; }
}

internal sealed class WorkspaceSyncRecord
{
    public string Id { get; set; } = string.Empty;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public bool IsDeleted { get; set; }
    public WorkspaceRecord? Workspace { get; set; }
}

internal sealed class SavedSessionRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Sessão salva";
    public DateTime SavedUtc { get; set; } = DateTime.UtcNow;
    public int ActiveIndex { get; set; }
    public List<SessionTabSnapshot> Tabs { get; set; } = new();
    public override string ToString() => $"{Name}  •  {Tabs.Count} guia(s)  •  {SavedUtc.ToLocalTime():dd/MM/yyyy HH:mm}";
}

internal sealed class SessionTabSnapshot
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Url { get; set; } = string.Empty;
    public string Title { get; set; } = "Nova guia";
    public bool IsPinned { get; set; }
    public string? GroupName { get; set; }
}

internal sealed class DownloadHistoryItem
{
    public string FilePath { get; set; } = string.Empty;
    public string SourceUri { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; }
    public long BytesReceived { get; set; }
    public ulong? TotalBytesToReceive { get; set; }
    public string State { get; set; } = "Desconhecido";
    public string SecurityLevel { get; set; } = "Baixo";
    public string SecurityReason { get; set; } = string.Empty;
}
internal sealed record SidebarLink(string Title, string Url);

internal sealed class ExtensionInstallRecord
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public string SourceFolder { get; set; } = string.Empty;
    public int ManifestVersion { get; set; }
    public List<string> Permissions { get; set; } = new();
    public List<string> HostPermissions { get; set; } = new();
    public DateTime InstalledUtc { get; set; } = DateTime.UtcNow;
}

internal sealed class SitePermissionRule
{
    public string Origin { get; set; } = string.Empty;
    public string PermissionKind { get; set; } = string.Empty;
    public bool Allowed { get; set; }
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
}

internal static class BrowserStorage
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    public static readonly string Root = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RXBrowser");

    public static string CurrentProfileId { get; set; } = "default";
    public static string ProfileRoot => Path.Combine(Root, "Profiles", CurrentProfileId);
    public static string DataFile => Path.Combine(ProfileRoot, "browser-data.json");
    public static bool LastLoadRecoveredFromBackup { get; private set; }
    public static string LastLoadRecoverySource { get; private set; } = string.Empty;
    public static string UserData => Path.Combine(ProfileRoot, "WebView2");
    public static string Downloads => CurrentProfileId == "default"
        ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "RX Browser")
        : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "RX Browser", CurrentProfileId);

    public static void PrepareUserDataMigration()
    {
        if (CurrentProfileId != "default" || Directory.Exists(UserData)) return;
        var legacy = Path.Combine(Root, "WebView2");
        if (!Directory.Exists(legacy)) return;
        try
        {
            Directory.CreateDirectory(ProfileRoot);
            Directory.Move(legacy, UserData);
        }
        catch { /* Se o perfil legado estiver em uso, o WebView2 criará um perfil novo. */ }
    }

    public static BrowserData Load()
    {
        LastLoadRecoveredFromBackup = false;
        LastLoadRecoverySource = string.Empty;
        try
        {
            Directory.CreateDirectory(ProfileRoot);
            if (!File.Exists(DataFile) && CurrentProfileId == "default")
            {
                var legacyFile = Path.Combine(Root, "browser-data.json");
                if (File.Exists(legacyFile)) File.Copy(legacyFile, DataFile, false);
            }
            BrowserData? loaded = null;
            if (File.Exists(DataFile))
            {
                try { loaded = JsonSerializer.Deserialize<BrowserData>(File.ReadAllText(DataFile)); }
                catch (Exception ex) { System.Diagnostics.Trace.WriteLine("RX Browser: arquivo principal de dados inválido: " + ex.Message); }
            }
            if (loaded is null)
            {
                // Keep several known-good generations so a damaged primary and a damaged
                // latest backup do not make the profile unrecoverable.
                foreach (var backupFile in new[] { DataFile + ".bak", DataFile + ".bak.1", DataFile + ".bak.2" })
                {
                    if (!File.Exists(backupFile)) continue;
                    try
                    {
                        var candidate = JsonSerializer.Deserialize<BrowserData>(File.ReadAllText(backupFile));
                        if (candidate is null) continue;
                        loaded = candidate;
                        LastLoadRecoveredFromBackup = true;
                        LastLoadRecoverySource = Path.GetFileName(backupFile);
                        try
                        {
                            if (File.Exists(DataFile))
                            {
                                var corruptCopy = DataFile + ".corrupt-" + DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                                File.Copy(DataFile, corruptCopy, false);
                            }
                            File.Copy(backupFile, DataFile, true);
                        }
                        catch { /* A valid backup remains available even if the primary cannot be rewritten. */ }
                        break;
                    }
                    catch (Exception ex) { System.Diagnostics.Trace.WriteLine("RX Browser: backup inválido (" + Path.GetFileName(backupFile) + "): " + ex.Message); }
                }
            }
            var data = loaded ?? new BrowserData();
            data.Favorites ??= new List<FavoriteItem>();
            data.FavoriteFolders ??= new List<string> { "Geral" };
            data.FavoriteFolders = data.FavoriteFolders
                .Where(name => !string.IsNullOrWhiteSpace(name))
                .Select(name => name.Trim()[..Math.Min(name.Trim().Length, 48)])
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(100).ToList();
            if (!data.FavoriteFolders.Contains("Geral", StringComparer.OrdinalIgnoreCase)) data.FavoriteFolders.Insert(0, "Geral");
            data.Favorites = data.Favorites
                .Where(item => item is not null && !string.IsNullOrWhiteSpace(item.Url))
                .Select(item => item with
                {
                    GroupName = string.IsNullOrWhiteSpace(item.GroupName) ? "Geral" : item.GroupName.Trim()[..Math.Min(item.GroupName.Trim().Length, 48)]
                }).ToList();
            foreach (var group in data.Favorites.Select(item => item.GroupName).Distinct(StringComparer.OrdinalIgnoreCase))
                if (data.FavoriteFolders.Count < 100 && !data.FavoriteFolders.Contains(group, StringComparer.OrdinalIgnoreCase)) data.FavoriteFolders.Add(group);
            data.FavoriteSyncRecords ??= new List<FavoriteSyncRecord>();
            data.History ??= new List<HistoryItem>();
            data.LastSessionUrls ??= new List<string>();
            data.LastSessionTabs ??= new List<SessionTabSnapshot>();
            data.SavedSessions ??= new List<SavedSessionRecord>();
            data.SavedSessions = data.SavedSessions
                .Where(session => session is not null && Guid.TryParseExact(session.Id, "N", out _) && !string.IsNullOrWhiteSpace(session.Name))
                .Select(session =>
                {
                    session.Name = session.Name.Trim()[..Math.Min(session.Name.Trim().Length, 48)];
                    session.Tabs ??= new List<SessionTabSnapshot>();
                    session.Tabs = session.Tabs.Where(tab => tab is not null && Uri.TryCreate(tab.Url, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https")
                        .Take(20).ToList();
                    session.ActiveIndex = Math.Clamp(session.ActiveIndex, 0, Math.Max(0, session.Tabs.Count - 1));
                    return session;
                })
                .Where(session => session.Tabs.Count > 0)
                .OrderByDescending(session => session.SavedUtc).Take(50).ToList();
            data.ProtectedTabs ??= new List<TabProtectionRecord>();
            data.PhishingAllowlist ??= new List<string>();
            data.PhishingAllowlist = data.PhishingAllowlist.Where(host => !string.IsNullOrWhiteSpace(host) && host.Length <= 253)
                .Select(host => host.Trim().TrimStart('.').ToLowerInvariant())
                .Where(host => Uri.CheckHostName(host) != UriHostNameType.Unknown)
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(500).ToList();
            if (data.PhishingProtectionLevel is not ("Basic" or "Balanced" or "Strict")) data.PhishingProtectionLevel = "Balanced";
            if (data.HomePageCardStyle is not ("Glass" or "Solid" or "Minimal")) data.HomePageCardStyle = "Glass";
            if (data.TranslationSourceLanguage is not ("auto" or "pt" or "en" or "es" or "fr" or "de" or "it" or "ja" or "zh-CN")) data.TranslationSourceLanguage = "auto";
            data.SessionSyncFolder ??= string.Empty;
            if (!Guid.TryParseExact(data.SessionSyncDeviceId, "N", out _)) data.SessionSyncDeviceId = Guid.NewGuid().ToString("N");
            data.ProtectedTabs = data.ProtectedTabs
                .Where(item => item is not null && Guid.TryParseExact(item.TabId, "N", out _) && !string.IsNullOrWhiteSpace(item.Salt) && !string.IsNullOrWhiteSpace(item.Hash))
                .GroupBy(item => item.TabId, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.Last())
                .Take(100)
                .ToList();
            data.DownloadHistory ??= new List<DownloadHistoryItem>();
            data.ExtensionInstallRecords ??= new List<ExtensionInstallRecord>();
            data.ExtensionInstallRecords = data.ExtensionInstallRecords
                .Where(item => item is not null && !string.IsNullOrWhiteSpace(item.Id))
                .GroupBy(item => item.Id, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.OrderByDescending(item => item.InstalledUtc).First())
                .Take(200)
                .ToList();
            foreach (var extension in data.ExtensionInstallRecords)
            {
                extension.Permissions ??= new List<string>();
                extension.HostPermissions ??= new List<string>();
                extension.SourceFolder ??= string.Empty;
                extension.Name ??= string.Empty;
                extension.Version ??= string.Empty;
            }
            data.ProfileBadge ??= "🌐";
            if (data.ProfileBadge is not ("🌐" or "💼" or "🎮" or "🎨" or "📚" or "🏠" or "🚀")) data.ProfileBadge = "🌐";
            data.ThemeAccentHex ??= string.Empty;
            if (!string.IsNullOrWhiteSpace(data.ThemeAccentHex) &&
                !System.Text.RegularExpressions.Regex.IsMatch(data.ThemeAccentHex, "^#[0-9A-Fa-f]{6}$"))
                data.ThemeAccentHex = string.Empty;
            if (data.DownloadProtectionLevel is not ("Off" or "Balanced" or "Strict")) data.DownloadProtectionLevel = "Balanced";
            data.AdBlockAllowlist ??= new List<string>();
            data.AdBlockCustomDomains ??= new List<string>();
            data.AdBlockCustomDomains = data.AdBlockCustomDomains
                .Select(AdBlocker.NormalizeDomain).Where(AdBlocker.IsValidDomain)
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(5000).ToList();
            if (data.AdBlockLevel is not ("Basic" or "Balanced" or "Strict")) data.AdBlockLevel = "Balanced";
            data.TrackingAllowlist ??= new List<string>();
            data.TrackingAllowlist = data.TrackingAllowlist.Where(host => !string.IsNullOrWhiteSpace(host) && host.Length <= 253)
                .Select(host => host.Trim().TrimStart('.').ToLowerInvariant()).Distinct(StringComparer.OrdinalIgnoreCase).Take(500).ToList();
            data.SidebarLinks ??= new List<SidebarLink>();
            data.ClosedTabUrls ??= new List<string>();
            data.SitePermissions ??= new List<SitePermissionRule>();
            data.Workspaces ??= new List<WorkspaceRecord>();
            data.WorkspaceSyncFolder ??= string.Empty;
            data.WorkspaceSyncRecords ??= new List<WorkspaceSyncRecord>();
            data.WorkspaceSyncRecords = data.WorkspaceSyncRecords
                .Where(record => record is not null && Guid.TryParseExact(record.Id, "N", out _))
                .GroupBy(record => record.Id, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.OrderByDescending(record => record.UpdatedUtc).First())
                .Take(2000).ToList();
            data.Workspaces = data.Workspaces
                .Where(workspace => workspace is not null && Guid.TryParseExact(workspace.Id, "N", out _) &&
                    !string.IsNullOrWhiteSpace(workspace.Name))
                .Select(workspace =>
                {
                    workspace.Name = workspace.Name.Trim();
                    if (workspace.Name.Length > 48) workspace.Name = workspace.Name[..48];
                    workspace.Tabs ??= new List<WorkspaceTabRecord>();
                    workspace.Tabs = workspace.Tabs
                        .Where(tab => tab is not null && Uri.TryCreate(tab.Url, UriKind.Absolute, out var uri) &&
                            uri.Scheme is "http" or "https")
                        .Take(20)
                        .Select(tab => new WorkspaceTabRecord
                        {
                            Title = string.IsNullOrWhiteSpace(tab.Title) ? "Nova guia" : tab.Title[..Math.Min(tab.Title.Length, 180)],
                            Url = tab.Url,
                            IsPinned = tab.IsPinned,
                            GroupName = string.IsNullOrWhiteSpace(tab.GroupName) ? null : tab.GroupName.Trim()[..Math.Min(tab.GroupName.Trim().Length, 32)]
                        })
                        .ToList();
                    return workspace;
                })
                .Where(workspace => workspace.Tabs.Count > 0)
                .OrderByDescending(workspace => workspace.UpdatedUtc)
                .Take(30)
                .ToList();
            data.PopupAllowlist ??= new List<string>();
            data.PopupAllowlist = data.PopupAllowlist
                .Where(host => !string.IsNullOrWhiteSpace(host) && host.Length <= 253)
                .Select(host => host.Trim().TrimStart('.').ToLowerInvariant())
                .Where(host => Uri.CheckHostName(host) != UriHostNameType.Unknown)
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(500).ToList();
            data.ShortcutOverrides ??= new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            data.SpeechVoiceName ??= string.Empty;
            data.SpeechVoiceLanguage ??= string.Empty;
            data.SpeechRate = double.IsFinite(data.SpeechRate) ? Math.Clamp(data.SpeechRate, 0.5, 2.0) : 1.0;
            data.SpeechPitch = double.IsFinite(data.SpeechPitch) ? Math.Clamp(data.SpeechPitch, 0.5, 2.0) : 1.0;
            data.VideoPlaybackRate = double.IsFinite(data.VideoPlaybackRate) ? Math.Clamp(data.VideoPlaybackRate, 0.25, 2.0) : 1.0;
            data.SitePermissions = data.SitePermissions
                .Where(rule => rule is not null && !string.IsNullOrWhiteSpace(rule.Origin) && !string.IsNullOrWhiteSpace(rule.PermissionKind))
                .GroupBy(rule => rule.Origin + "|" + rule.PermissionKind, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.OrderByDescending(rule => rule.UpdatedUtc).First())
                .ToList();
            data.ControlCenterVisibleActions ??= new List<string>();
            data.ControlCenterActionOrder ??= new List<string>();
            data.ControlCenterVisibleActions = data.ControlCenterVisibleActions
                .Where(id => ControlCenterCommands.KnownIds.Contains(id))
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(30).ToList();
            data.ControlCenterActionOrder = data.ControlCenterActionOrder
                .Where(id => ControlCenterCommands.KnownIds.Contains(id))
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(30).ToList();
            data.ControlCenterAccentHex ??= string.Empty;
            if (!string.IsNullOrWhiteSpace(data.ControlCenterAccentHex) &&
                !System.Text.RegularExpressions.Regex.IsMatch(data.ControlCenterAccentHex, "^#[0-9A-Fa-f]{6}$"))
                data.ControlCenterAccentHex = string.Empty;
            data.ControlCenterColumns = Math.Clamp(data.ControlCenterColumns, 2, 4);
            data.ToolbarHiddenButtons ??= new List<string>();
            data.ToolbarHiddenButtons = data.ToolbarHiddenButtons
                .Where(id => !string.IsNullOrWhiteSpace(id) && ToolbarCatalog.Ids.Contains(id))
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(ToolbarCatalog.Options.Count).ToList();
            data.BackupSyncFolder ??= string.Empty;
            if (!Guid.TryParseExact(data.BackupSyncDeviceId, "N", out _)) data.BackupSyncDeviceId = Guid.NewGuid().ToString("N");
            data.BackupSyncIntervalMinutes = Math.Clamp(data.BackupSyncIntervalMinutes, 5, 60);
            if (string.IsNullOrWhiteSpace(data.BackupSyncFolder)) data.BackupSyncEnabled = false;
            data.FavoritesSyncFolder ??= string.Empty;
            data.PreferencesSyncFolder ??= string.Empty;
            // AutoSyncEnabled is opt-in; absent values in older profiles remain disabled.
            if (string.IsNullOrWhiteSpace(data.FavoritesSyncFolder) && string.IsNullOrWhiteSpace(data.PreferencesSyncFolder))
                data.AutoSyncEnabled = false;
            if (data.ThemeAccent is not ("Cyan" or "Violet" or "Emerald" or "Amber" or "Pink")) data.ThemeAccent = "Cyan";
            if (data.InterfaceTheme is not ("Midnight" or "Graphite" or "OLED" or "Light")) data.InterfaceTheme = "Midnight";
            if (data.HomePageTheme is not ("Aurora" or "Midnight" or "Purple" or "Forest" or "Sunset")) data.HomePageTheme = "Aurora";
            data.HomePageGreeting ??= "NAVEGUE DO SEU JEITO";
            data.HomePageGreeting = data.HomePageGreeting.Trim()[..Math.Min(data.HomePageGreeting.Trim().Length, 70)];
            data.HomePageFavoriteCount = Math.Clamp(data.HomePageFavoriteCount, 0, 16);
            data.HomePageQuickLinks ??= new List<SidebarLink>
            {
                new SidebarLink("Google", "https://www.google.com"),
                new SidebarLink("YouTube", "https://www.youtube.com"),
                new SidebarLink("Wikipedia", "https://www.wikipedia.org"),
                new SidebarLink("GitHub", "https://github.com")
            };
            data.HomePageQuickLinks = data.HomePageQuickLinks
                .Where(link => link is not null && !string.IsNullOrWhiteSpace(link.Title) &&
                    !string.IsNullOrWhiteSpace(link.Url) && link.Title.Length <= 36 && link.Url.Length <= 2048 &&
                    Uri.TryCreate(link.Url, UriKind.Absolute, out var quickUri) && (quickUri.Scheme is "http" or "https"))
                .GroupBy(link => link.Url, StringComparer.OrdinalIgnoreCase).Select(group => group.First()).Take(16).ToList();
            if (data.PreferredTranslationLanguage is not ("pt" or "en" or "es" or "fr" or "de" or "it" or "ja" or "zh-CN"))
                data.PreferredTranslationLanguage = "pt";
            data.SidebarWidth = Math.Clamp(data.SidebarWidth, 180, 360);
            data.BackgroundTabSuspendDelaySeconds = Math.Clamp(data.BackgroundTabSuspendDelaySeconds, 15, 300);
            data.LastActiveSessionTabIndex = Math.Max(0, data.LastActiveSessionTabIndex);
            data.LastSessionTabs = data.LastSessionTabs
                .Where(tab => tab is not null && !string.IsNullOrWhiteSpace(tab.Url))
                .Take(20).ToList();
            data.DownloadHistory = data.DownloadHistory
                .Where(item => item is not null && !string.IsNullOrWhiteSpace(item.FilePath))
                .OrderByDescending(item => item.StartedAt).Take(100).ToList();
            if (data.SearchEngine is not ("Google" or "DuckDuckGo" or "Bing")) data.SearchEngine = "DuckDuckGo";
            if (data.TrackingProtectionLevel is not ("Basic" or "Balanced" or "Strict" or "Off")) data.TrackingProtectionLevel = "Balanced";
            data.ZoomPercent = Math.Clamp(data.ZoomPercent, 50, 200);
            data.UiScalePercent = Math.Clamp(data.UiScalePercent, 90, 140);
            return data;
        }
        catch
        {
            return new BrowserData();
        }
    }

    public static BrowserData LoadForProfile(string profileId)
    {
        if (!ProfileStore.IsValidId(profileId)) return new BrowserData();
        var previous = CurrentProfileId;
        try
        {
            CurrentProfileId = profileId;
            return Load();
        }
        finally { CurrentProfileId = previous; }
    }

    public static void Save(BrowserData data)
    {
        try
        {
            Directory.CreateDirectory(ProfileRoot);
            var temp = DataFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                var serialized = JsonSerializer.Serialize(data, JsonOptions);
                File.WriteAllText(temp, serialized, new System.Text.UTF8Encoding(false));
                if (File.Exists(DataFile))
                {
                    // Rotate three generations, but only when the current primary is parseable.
                    try
                    {
                        using var _ = JsonDocument.Parse(File.ReadAllText(DataFile));
                        var backup0 = DataFile + ".bak";
                        var backup1 = DataFile + ".bak.1";
                        var backup2 = DataFile + ".bak.2";
                        if (File.Exists(backup1)) File.Copy(backup1, backup2, true);
                        if (File.Exists(backup0)) File.Copy(backup0, backup1, true);
                        File.Copy(DataFile, backup0, true);
                    }
                    catch { /* Never replace a known-good recovery chain with corrupt input. */ }
                }
                File.Move(temp, DataFile, true);
            }
            finally
            {
                try { if (File.Exists(temp)) File.Delete(temp); } catch { }
            }
        }
        catch (Exception ex)
        {
            // Uma falha ao salvar dados locais não deve interromper a navegação,
            // mas fica registrada para diagnóstico em vez de desaparecer silenciosamente.
            System.Diagnostics.Trace.WriteLine("RX Browser: falha ao salvar dados locais: " + ex);
        }
    }
}
