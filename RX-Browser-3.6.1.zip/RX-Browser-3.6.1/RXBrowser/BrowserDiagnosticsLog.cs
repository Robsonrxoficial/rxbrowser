﻿using System.Diagnostics;
using System.Text;

namespace RXBrowser;

internal static class BrowserDiagnosticsLog
{
    private static readonly object Sync = new();
    private static TextWriterTraceListener? _listener;
    public static string LogPath { get; private set; } = string.Empty;

    public static void Initialize(string profileRoot)
    {
        try
        {
            Directory.CreateDirectory(profileRoot);
            LogPath = Path.Combine(profileRoot, "rx-browser-diagnostics.log");
            lock (Sync)
            {
                _listener?.Flush();
                _listener?.Dispose();
                RotateIfNeeded(LogPath);
                var stream = new FileStream(LogPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true };
                _listener = new TextWriterTraceListener(writer, "RXBrowserProfileLog");
                Trace.Listeners.Add(_listener);
                Trace.AutoFlush = true;
            }
        }
        catch { /* Logging is best effort and must never prevent browser startup. */ }
    }

    public static void Write(string category, Exception exception)
    {
        try
        {
            Trace.WriteLine($"[{DateTime.UtcNow:O}] [{category}] {exception}");
            Trace.Flush();
        }
        catch { }
    }

    private static void RotateIfNeeded(string path)
    {
        const long maximumBytes = 2 * 1024 * 1024;
        try
        {
            if (!File.Exists(path) || new FileInfo(path).Length < maximumBytes) return;
            var previous = path + ".1";
            if (File.Exists(previous)) File.Delete(previous);
            File.Move(path, previous, true);
        }
        catch { }
    }
}
