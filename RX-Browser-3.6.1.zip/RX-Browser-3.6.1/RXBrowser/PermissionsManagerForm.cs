﻿namespace RXBrowser;

internal sealed class PermissionsManagerForm : Form
{
    private readonly List<SitePermissionRule> _rules;
    private readonly ListView _list = new();
    private readonly TextBox _filter = new();

    public List<SitePermissionRule> Result { get; private set; } = new();

    public PermissionsManagerForm(IEnumerable<SitePermissionRule> rules)
    {
        _rules = (rules ?? Array.Empty<SitePermissionRule>()).Select(Clone).ToList();
        Text = "Gerenciador de permissões — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.Sizable;
        MinimumSize = new Size(760, 480);
        Size = new Size(900, 610);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label
        {
            Text = "PERMISSÕES DE SITES",
            Left = 22, Top = 18, Width = 620, Height = 34,
            Font = new Font("Segoe UI Black", 16, FontStyle.Bold),
            ForeColor = Color.FromArgb(50, 211, 235)
        });
        Controls.Add(new Label
        {
            Text = "Filtrar por domínio ou tipo de permissão",
            Left = 24, Top = 61, Width = 310, Height = 24,
            ForeColor = Color.FromArgb(155, 171, 190)
        });
        _filter.SetBounds(24, 87, 560, 32);
        _filter.BackColor = Color.FromArgb(27, 36, 49);
        _filter.ForeColor = ForeColor;
        _filter.BorderStyle = BorderStyle.FixedSingle;
        _filter.PlaceholderText = "Ex.: example.com, Camera, Microphone…";
        _filter.TextChanged += (_, _) => RefreshList();
        Controls.Add(_filter);

        _list.SetBounds(24, 132, 836, 350);
        _list.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        _list.View = View.Details;
        _list.FullRowSelect = true;
        _list.GridLines = true;
        _list.HideSelection = false;
        _list.BackColor = Color.FromArgb(20, 27, 37);
        _list.ForeColor = ForeColor;
        _list.Columns.Add("Site", 340);
        _list.Columns.Add("Permissão", 190);
        _list.Columns.Add("Decisão", 120);
        _list.Columns.Add("Atualizada", 150);
        Controls.Add(_list);

        var allow = MakeButton("Permitir", 92);
        allow.SetBounds(24, 496, 92, 34);
        allow.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        allow.Click += (_, _) => SetDecision(true);
        Controls.Add(allow);
        var deny = MakeButton("Bloquear", 92);
        deny.SetBounds(124, 496, 92, 34);
        deny.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        deny.Click += (_, _) => SetDecision(false);
        Controls.Add(deny);
        var remove = MakeButton("Remover", 92);
        remove.SetBounds(224, 496, 92, 34);
        remove.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        remove.Click += (_, _) => RemoveSelected();
        Controls.Add(remove);
        var clear = MakeButton("Apagar todas", 112);
        clear.SetBounds(324, 496, 112, 34);
        clear.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        clear.Click += (_, _) => ClearAll();
        Controls.Add(clear);
        var cancel = MakeButton("Cancelar", 92);
        cancel.SetBounds(656, 496, 92, 34);
        cancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);
        var save = MakeButton("Salvar", 100, true);
        save.SetBounds(760, 496, 100, 34);
        save.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        save.Click += (_, _) => { Result = _rules.Select(Clone).ToList(); DialogResult = DialogResult.OK; Close(); };
        Controls.Add(save);
        Controls.Add(new Label
        {
            Text = "As decisões são locais a este perfil. Remover uma regra faz o site perguntar novamente na próxima solicitação.",
            Left = 24, Top = 541, Width = 836, Height = 24,
            Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            ForeColor = Color.FromArgb(140, 157, 177), Font = new Font("Segoe UI", 8.5F)
        });
        CancelButton = cancel;
        RefreshList();
    }

    private void RefreshList()
    {
        _list.BeginUpdate();
        _list.Items.Clear();
        var term = _filter.Text.Trim();
        foreach (var rule in _rules.OrderByDescending(item => item.UpdatedUtc))
        {
            if (term.Length > 0 && !rule.Origin.Contains(term, StringComparison.OrdinalIgnoreCase) &&
                !rule.PermissionKind.Contains(term, StringComparison.OrdinalIgnoreCase)) continue;
            var item = new ListViewItem(rule.Origin) { Tag = rule };
            item.SubItems.Add(rule.PermissionKind);
            item.SubItems.Add(rule.Allowed ? "Permitido" : "Bloqueado");
            item.SubItems.Add(rule.UpdatedUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm"));
            item.ForeColor = rule.Allowed ? Color.FromArgb(145, 222, 177) : Color.FromArgb(239, 163, 151);
            _list.Items.Add(item);
        }
        _list.EndUpdate();
    }

    private SitePermissionRule? SelectedRule() => _list.SelectedItems.Count > 0 ? _list.SelectedItems[0].Tag as SitePermissionRule : null;

    private void SetDecision(bool allowed)
    {
        var rule = SelectedRule();
        if (rule is null) return;
        rule.Allowed = allowed;
        rule.UpdatedUtc = DateTime.UtcNow;
        RefreshList();
    }

    private void RemoveSelected()
    {
        var rule = SelectedRule();
        if (rule is null) return;
        _rules.Remove(rule);
        RefreshList();
    }

    private void ClearAll()
    {
        if (MessageBox.Show(this, "Remover todas as decisões salvas? Os sites poderão pedir as permissões novamente.",
            "Apagar permissões", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        _rules.Clear();
        RefreshList();
    }

    private static SitePermissionRule Clone(SitePermissionRule rule) => new()
    {
        Origin = rule.Origin,
        PermissionKind = rule.PermissionKind,
        Allowed = rule.Allowed,
        UpdatedUtc = rule.UpdatedUtc
    };

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
