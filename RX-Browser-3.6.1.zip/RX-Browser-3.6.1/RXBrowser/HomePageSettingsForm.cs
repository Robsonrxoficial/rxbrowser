﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class HomePageSettingsForm : Form
{
    private readonly CheckBox _showClock = new();
    private readonly CheckBox _showQuickLinks = new();
    private readonly CheckBox _showFavorites = new();
    private readonly CheckBox _showRecent = new();
    private readonly TextBox _greeting = new();
    private readonly ComboBox _theme = new();
    private readonly ComboBox _cardStyle = new();
    private readonly NumericUpDown _favoriteCount = new();
    private readonly ListBox _links = new();
    private readonly List<SidebarLink> _workingLinks;
    private readonly BrowserData _data;

    public HomePageSettingsForm(BrowserData data)
    {
        _data = data;
        _workingLinks = data.HomePageQuickLinks.ToList();
        Text = "Personalizar página inicial — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(700, 610);
        Size = new Size(790, 690);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Label
        {
            Text = "SUA NOVA GUIA, DO SEU JEITO",
            Dock = DockStyle.Top, Height = 50, Padding = new Padding(18, 14, 0, 0),
            ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        };
        Controls.Add(header);
        var body = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(18), BackColor = Color.FromArgb(15, 21, 30) };
        Controls.Add(body);

        AddLabel(body, "Texto de boas-vindas", 16);
        _greeting.SetBounds(18, 42, 690, 32);
        _greeting.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        StyleTextBox(_greeting);
        _greeting.MaxLength = 70;
        _greeting.Text = data.HomePageGreeting;
        body.Controls.Add(_greeting);

        AddLabel(body, "Tema de fundo", 88);
        _theme.SetBounds(18, 114, 350, 32);
        _theme.DropDownStyle = ComboBoxStyle.DropDownList;
        _theme.BackColor = Color.FromArgb(27, 36, 49);
        _theme.ForeColor = ForeColor;
        _theme.Items.AddRange(new object[]
        {
            new Choice("Aurora RX", "Aurora"), new Choice("Meia-noite", "Midnight"),
            new Choice("Roxo cósmico", "Purple"), new Choice("Floresta", "Forest"),
            new Choice("Pôr do sol", "Sunset")
        });
        for (var i = 0; i < _theme.Items.Count; i++)
            if (_theme.Items[i] is Choice option && option.Value == data.HomePageTheme) _theme.SelectedIndex = i;
        if (_theme.SelectedIndex < 0) _theme.SelectedIndex = 0;
        body.Controls.Add(_theme);

        AddCheck(body, _showClock, "Mostrar relógio e data locais", 160, data.HomePageShowClock);
        AddCheck(body, _showQuickLinks, "Mostrar atalhos rápidos", 190, data.HomePageShowQuickLinks);
        AddCheck(body, _showFavorites, "Mostrar favoritos", 220, data.HomePageShowFavorites);
        AddCheck(body, _showRecent, "Mostrar sites visitados recentemente", 250, data.HomePageShowRecentSites);

        AddLabel(body, "Estilo dos cartões e atalhos", 286);
        _cardStyle.SetBounds(18, 310, 350, 32);
        _cardStyle.DropDownStyle = ComboBoxStyle.DropDownList;
        _cardStyle.BackColor = Color.FromArgb(27, 36, 49);
        _cardStyle.ForeColor = ForeColor;
        _cardStyle.Items.AddRange(new object[]
        {
            new Choice("Glass — translúcido", "Glass"),
            new Choice("Solid — sólido", "Solid"),
            new Choice("Minimal — minimalista", "Minimal")
        });
        for (var i = 0; i < _cardStyle.Items.Count; i++)
            if (_cardStyle.Items[i] is Choice option && option.Value == data.HomePageCardStyle) _cardStyle.SelectedIndex = i;
        if (_cardStyle.SelectedIndex < 0) _cardStyle.SelectedIndex = 0;
        body.Controls.Add(_cardStyle);

        AddLabel(body, "Quantidade máxima de favoritos na página inicial", 354);
        _favoriteCount.SetBounds(18, 380, 110, 30);
        _favoriteCount.Minimum = 0;
        _favoriteCount.Maximum = 16;
        _favoriteCount.Value = Math.Clamp(data.HomePageFavoriteCount, 0, 16);
        _favoriteCount.BackColor = Color.FromArgb(27, 36, 49);
        _favoriteCount.ForeColor = ForeColor;
        body.Controls.Add(_favoriteCount);

        AddLabel(body, "Seus atalhos rápidos personalizados", 426);
        _links.SetBounds(18, 453, 520, 150);
        _links.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
        _links.BackColor = Color.FromArgb(20, 27, 37);
        _links.ForeColor = ForeColor;
        _links.BorderStyle = BorderStyle.FixedSingle;
        body.Controls.Add(_links);
        RefreshLinks();

        var add = MakeButton("Adicionar", 125);
        add.SetBounds(552, 453, 156, 34);
        add.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        add.Click += (_, _) => AddLink();
        body.Controls.Add(add);
        var remove = MakeButton("Remover selecionado", 156);
        remove.SetBounds(552, 495, 156, 34);
        remove.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        remove.Click += (_, _) => RemoveLink();
        body.Controls.Add(remove);
        var reset = MakeButton("Restaurar padrão", 156);
        reset.SetBounds(552, 537, 156, 34);
        reset.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        reset.Click += (_, _) => ResetLinks();
        body.Controls.Add(reset);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 60, Padding = new Padding(14, 11, 14, 11), BackColor = Color.FromArgb(18, 25, 35) };
        var cancel = MakeButton("Cancelar", 92);
        cancel.Dock = DockStyle.Right;
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 104, true);
        save.Dock = DockStyle.Right;
        save.Click += (_, _) => SaveSettings();
        footer.Controls.Add(cancel);
        footer.Controls.Add(save);
        Controls.Add(footer);
        CancelButton = cancel;
        AcceptButton = save;
    }

    private void AddCheck(Panel parent, CheckBox checkBox, string text, int top, bool value)
    {
        checkBox.Text = text;
        checkBox.Checked = value;
        checkBox.SetBounds(18, top, 500, 25);
        checkBox.ForeColor = ForeColor;
        checkBox.BackColor = parent.BackColor;
        parent.Controls.Add(checkBox);
    }

    private static void AddLabel(Panel parent, string text, int top) =>
        parent.Controls.Add(new Label { Text = text, Left = 18, Top = top, Width = 600, Height = 22, ForeColor = Color.FromArgb(232, 240, 248) });

    private void StyleTextBox(TextBox textBox)
    {
        textBox.BorderStyle = BorderStyle.FixedSingle;
        textBox.BackColor = Color.FromArgb(27, 36, 49);
        textBox.ForeColor = ForeColor;
        textBox.Font = new Font("Segoe UI", 10F);
    }

    private void AddLink()
    {
        if (_workingLinks.Count >= 16)
        {
            MessageBox.Show(this, "Você pode manter até 16 atalhos personalizados.", "Limite de atalhos", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var title = PromptDialog.Show(this, "Novo atalho", "Nome do site:");
        if (string.IsNullOrWhiteSpace(title)) return;
        var url = PromptDialog.Show(this, "Novo atalho", "Endereço HTTP ou HTTPS:", "https://");
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
        {
            MessageBox.Show(this, "Digite um endereço HTTP ou HTTPS válido.", "Endereço inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (_workingLinks.Any(link => string.Equals(link.Url, uri.ToString(), StringComparison.OrdinalIgnoreCase))) return;
        _workingLinks.Add(new SidebarLink(title.Trim()[..Math.Min(title.Trim().Length, 36)], uri.ToString()));
        RefreshLinks();
    }

    private void RemoveLink()
    {
        if (_links.SelectedIndex < 0 || _links.SelectedIndex >= _workingLinks.Count) return;
        _workingLinks.RemoveAt(_links.SelectedIndex);
        RefreshLinks();
    }

    private void ResetLinks()
    {
        _workingLinks.Clear();
        _workingLinks.AddRange(new[]
        {
            new SidebarLink("Google", "https://www.google.com"),
            new SidebarLink("YouTube", "https://www.youtube.com"),
            new SidebarLink("Wikipedia", "https://www.wikipedia.org"),
            new SidebarLink("GitHub", "https://github.com")
        });
        RefreshLinks();
    }

    private void RefreshLinks()
    {
        _links.BeginUpdate();
        _links.Items.Clear();
        foreach (var link in _workingLinks) _links.Items.Add($"{link.Title}  —  {link.Url}");
        _links.EndUpdate();
    }

    private void SaveSettings()
    {
        _data.HomePageGreeting = _greeting.Text.Trim();
        if (_cardStyle.SelectedItem is Choice card) _data.HomePageCardStyle = card.Value;
        if (_theme.SelectedItem is Choice selected) _data.HomePageTheme = selected.Value;
        _data.HomePageShowClock = _showClock.Checked;
        _data.HomePageShowQuickLinks = _showQuickLinks.Checked;
        _data.HomePageShowFavorites = _showFavorites.Checked;
        _data.HomePageShowRecentSites = _showRecent.Checked;
        _data.HomePageFavoriteCount = decimal.ToInt32(_favoriteCount.Value);
        _data.HomePageQuickLinks = _workingLinks.ToList();
        DialogResult = DialogResult.OK;
        Close();
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private sealed record Choice(string Label, string Value)
    {
        public override string ToString() => Label;
    }
}
