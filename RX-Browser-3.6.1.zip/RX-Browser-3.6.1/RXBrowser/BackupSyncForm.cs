﻿namespace RXBrowser;

internal sealed class BackupSyncForm : Form
{
    private readonly TextBox _folder = new();
    private readonly CheckBox _enabled = new();
    private readonly ComboBox _interval = new();

    public string FolderPath => _folder.Text.Trim();
    public bool EnabledSync => _enabled.Checked;
    public int IntervalMinutes => (_interval.SelectedItem as IntervalChoice)?.Minutes ?? 10;
    public string? RequestedAction { get; private set; }

    public BackupSyncForm(string folder, bool enabled, int intervalMinutes)
    {
        Text = "Backup entre dispositivos — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(700, 420);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label
        {
            Text = "BACKUP ENTRE DISPOSITIVOS",
            Left = 24, Top = 20, Width = 640, Height = 34,
            Font = new Font("Segoe UI Black", 16, FontStyle.Bold),
            ForeColor = Color.FromArgb(50, 211, 235)
        });
        Controls.Add(new Label
        {
            Text = "Escolha uma pasta sincronizada (OneDrive, Dropbox, Google Drive ou rede local). Cada computador publica seu próprio arquivo.",
            Left = 26, Top = 66, Width = 645, Height = 42,
            ForeColor = Color.FromArgb(160, 176, 194)
        });
        _folder.SetBounds(26, 116, 500, 34);
        _folder.Text = folder;
        _folder.BackColor = Color.FromArgb(27, 36, 49);
        _folder.ForeColor = ForeColor;
        _folder.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(_folder);
        var browse = MakeButton("Escolher…", 120);
        browse.SetBounds(536, 116, 126, 34);
        browse.Click += (_, _) =>
        {
            using var picker = new FolderBrowserDialog
            {
                Description = "Selecione uma pasta que esteja sincronizada entre seus dispositivos.",
                UseDescriptionForTitle = true,
                ShowNewFolderButton = true
            };
            if (Directory.Exists(_folder.Text)) picker.SelectedPath = _folder.Text;
            if (picker.ShowDialog(this) == DialogResult.OK) _folder.Text = picker.SelectedPath;
        };
        Controls.Add(browse);

        _enabled.Text = "Publicar backups seletivos automaticamente";
        _enabled.SetBounds(28, 166, 400, 28);
        _enabled.Checked = enabled;
        _enabled.ForeColor = ForeColor;
        _enabled.BackColor = BackColor;
        Controls.Add(_enabled);
        Controls.Add(new Label { Text = "Intervalo", Left = 438, Top = 168, Width = 70, Height = 24, ForeColor = ForeColor });
        _interval.SetBounds(510, 164, 150, 30);
        _interval.DropDownStyle = ComboBoxStyle.DropDownList;
        _interval.Items.AddRange(new object[]
        {
            new IntervalChoice("5 minutos", 5), new IntervalChoice("10 minutos", 10),
            new IntervalChoice("15 minutos", 15), new IntervalChoice("30 minutos", 30),
            new IntervalChoice("60 minutos", 60)
        });
        var selectedInterval = _interval.Items.Cast<IntervalChoice>().FirstOrDefault(item => item.Minutes == intervalMinutes);
        _interval.SelectedItem = selectedInterval ?? (IntervalChoice)_interval.Items[1]!;
        Controls.Add(_interval);

        var info = new Label
        {
            Text = "O RX cria um arquivo por perfil e dispositivo na subpasta rx-browser-backups. Use o mesmo nome de perfil nos computadores que compartilharão backups. Você pode importar um backup de outro dispositivo manualmente; a importação pede confirmação e preserva uma cópia dos dados atuais.\n\nO backup inclui favoritos, pastas, espaços de trabalho, layout da Central RX e preferências não secretas. Não inclui senhas, PINs, cookies, histórico, downloads, notas do Caderno RX, permissões, extensões instaladas nem dados do WebView2. O arquivo ZIP contém JSON legível: use uma pasta compartilhada privada e confiável.",
            Left = 28, Top = 212, Width = 635, Height = 112,
            ForeColor = Color.FromArgb(145, 162, 182), Font = new Font("Segoe UI", 8.8F)
        };
        Controls.Add(info);

        var cancel = MakeButton("Cancelar", 96);
        cancel.SetBounds(246, 362, 96, 34);
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);
        var import = MakeButton("Importar de outro dispositivo…", 190);
        import.SetBounds(350, 362, 190, 34);
        import.Click += (_, _) => Complete("import");
        Controls.Add(import);
        var publish = MakeButton("Publicar agora", 120, true);
        publish.SetBounds(548, 362, 114, 34);
        publish.Click += (_, _) => Complete("publish");
        Controls.Add(publish);
        var save = MakeButton("Salvar", 86);
        save.SetBounds(26, 362, 86, 34);
        save.Click += (_, _) => Complete("save");
        Controls.Add(save);
        CancelButton = cancel;
    }

    private void Complete(string action)
    {
        if (string.IsNullOrWhiteSpace(_folder.Text))
        {
            MessageBox.Show(this, "Escolha uma pasta compartilhada primeiro.", "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        RequestedAction = action;
        DialogResult = DialogResult.OK;
        Close();
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private sealed record IntervalChoice(string Label, int Minutes)
    {
        public override string ToString() => Label;
    }
}
