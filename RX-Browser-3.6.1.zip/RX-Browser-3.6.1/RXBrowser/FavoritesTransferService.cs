﻿using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace RXBrowser;

internal sealed class FavoriteTransferResult
{
    public List<FavoriteItem> Favorites { get; init; } = new();
    public List<string> Folders { get; init; } = new() { "Geral" };
}

/// <summary>Importa e exporta favoritos em JSON RX, HTML Netscape e CSV.</summary>
internal static class FavoritesTransferService
{
    private const int MaxFavorites = 5000;
    private const int MaxFolders = 100;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    private static readonly Regex HtmlTokens = new("<H3\\b[^>]*>(?<folder>.*?)</H3>|<A\\b(?<attrs>[^>]*)>(?<title>.*?)</A>", RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);
    private static readonly Regex HrefAttribute = new("\\bHREF\\s*=\\s*(?:\"(?<double>[^\"]*)\"|'(?<single>[^']*)'|(?<plain>[^\\s>]+))", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private sealed class TransferDocument
    {
        public string Format { get; set; } = "RXBrowserFavorites";
        public int Version { get; set; } = 1;
        public List<string> Folders { get; set; } = new();
        public List<FavoriteItem> Favorites { get; set; } = new();
    }

    public static void Export(string path, IEnumerable<FavoriteItem> favorites, IEnumerable<string> folders)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        var clean = Normalize(favorites, folders);
        var extension = Path.GetExtension(path).ToLowerInvariant();
        switch (extension)
        {
            case ".html":
            case ".htm":
                File.WriteAllText(path, ToNetscapeHtml(clean), new UTF8Encoding(false));
                break;
            case ".csv":
                File.WriteAllText(path, ToCsv(clean), new UTF8Encoding(true));
                break;
            case ".json":
            default:
                var document = new TransferDocument { Folders = clean.Folders, Favorites = clean.Favorites };
                File.WriteAllText(path, JsonSerializer.Serialize(document, JsonOptions), new UTF8Encoding(false));
                break;
        }
    }

    public static FavoriteTransferResult Import(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        var info = new FileInfo(path);
        if (!info.Exists) throw new FileNotFoundException("O arquivo de favoritos não foi encontrado.", path);
        if (info.Length > 16 * 1024 * 1024) throw new InvalidDataException("O arquivo excede o limite de 16 MB.");
        var extension = Path.GetExtension(path).ToLowerInvariant();
        var text = File.ReadAllText(path, Encoding.UTF8);
        FavoriteTransferResult parsed = extension switch
        {
            ".html" or ".htm" => ParseNetscapeHtml(text),
            ".csv" => ParseCsv(text),
            ".json" => ParseJson(text),
            _ => throw new InvalidDataException("Formato não reconhecido. Use JSON, HTML de favoritos ou CSV.")
        };
        return Normalize(parsed.Favorites, parsed.Folders);
    }

    private static FavoriteTransferResult ParseJson(string text)
    {
        var document = JsonSerializer.Deserialize<TransferDocument>(text, JsonOptions)
            ?? throw new InvalidDataException("O JSON de favoritos está vazio ou inválido.");
        if (!string.Equals(document.Format, "RXBrowserFavorites", StringComparison.OrdinalIgnoreCase) || document.Version is < 1 or > 1)
            throw new InvalidDataException("O arquivo JSON não é um pacote de favoritos RX compatível.");
        return new FavoriteTransferResult { Favorites = document.Favorites ?? new(), Folders = document.Folders ?? new() };
    }

    private static FavoriteTransferResult ParseNetscapeHtml(string html)
    {
        var favorites = new List<FavoriteItem>();
        var folders = new List<string> { "Geral" };
        var currentFolder = "Geral";
        foreach (Match match in HtmlTokens.Matches(html))
        {
            if (match.Groups["folder"].Success)
            {
                var name = WebUtility.HtmlDecode(StripTags(match.Groups["folder"].Value)).Trim();
                currentFolder = CleanFolder(name);
                if (!folders.Contains(currentFolder, StringComparer.OrdinalIgnoreCase) && folders.Count < MaxFolders)
                    folders.Add(currentFolder);
                continue;
            }

            var attributes = match.Groups["attrs"].Value;
            var href = HrefAttribute.Match(attributes);
            if (!href.Success) continue;
            var url = href.Groups["double"].Success ? href.Groups["double"].Value :
                href.Groups["single"].Success ? href.Groups["single"].Value : href.Groups["plain"].Value;
            var title = WebUtility.HtmlDecode(StripTags(match.Groups["title"].Value)).Trim();
            favorites.Add(new FavoriteItem(CleanTitle(title, url), (WebUtility.HtmlDecode(url) ?? url)) { GroupName = currentFolder });
            if (favorites.Count > MaxFavorites) throw new InvalidDataException($"O arquivo excede o limite de {MaxFavorites} favoritos.");
        }
        return new FavoriteTransferResult { Favorites = favorites, Folders = folders };
    }

    private static FavoriteTransferResult ParseCsv(string csv)
    {
        var rows = ReadCsvRows(csv);
        if (rows.Count == 0) throw new InvalidDataException("O CSV não contém favoritos.");
        var header = rows[0].Select(x => x.Trim()).ToList();
        var hasHeader = header.Any(x => x.Equals("url", StringComparison.OrdinalIgnoreCase) || x.Equals("endereço", StringComparison.OrdinalIgnoreCase) || x.Equals("address", StringComparison.OrdinalIgnoreCase));
        var titleIndex = hasHeader ? FindHeader(header, "title", "titulo", "título", "name", "nome") : 0;
        var urlIndex = hasHeader ? FindHeader(header, "url", "endereço", "endereco", "address") : 1;
        var groupIndex = hasHeader ? FindHeader(header, "group", "grupo", "folder", "pasta") : 2;
        if (urlIndex < 0) throw new InvalidDataException("O CSV precisa ter uma coluna URL/Endereço ou duas colunas no formato Título,URL.");
        var favorites = new List<FavoriteItem>();
        var folders = new List<string> { "Geral" };
        foreach (var row in rows.Skip(hasHeader ? 1 : 0))
        {
            if (urlIndex >= row.Count) continue;
            var url = row[urlIndex].Trim();
            var title = titleIndex >= 0 && titleIndex < row.Count ? row[titleIndex].Trim() : string.Empty;
            var group = groupIndex >= 0 && groupIndex < row.Count ? CleanFolder(row[groupIndex]) : "Geral";
            if (!folders.Contains(group, StringComparer.OrdinalIgnoreCase) && folders.Count < MaxFolders) folders.Add(group);
            favorites.Add(new FavoriteItem(CleanTitle(title, url), url) { GroupName = group });
            if (favorites.Count > MaxFavorites) throw new InvalidDataException($"O CSV excede o limite de {MaxFavorites} favoritos.");
        }
        return new FavoriteTransferResult { Favorites = favorites, Folders = folders };
    }

    private static int FindHeader(List<string> header, params string[] names)
    {
        for (var i = 0; i < header.Count; i++)
            if (names.Contains(header[i], StringComparer.OrdinalIgnoreCase)) return i;
        return -1;
    }

    private static List<List<string>> ReadCsvRows(string input)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var field = new StringBuilder();
        var quoted = false;
        for (var i = 0; i < input.Length; i++)
        {
            var ch = input[i];
            if (ch == '"')
            {
                if (quoted && i + 1 < input.Length && input[i + 1] == '"') { field.Append('"'); i++; }
                else quoted = !quoted;
            }
            else if (ch == ',' && !quoted)
            {
                row.Add(field.ToString()); field.Clear();
            }
            else if ((ch == '\r' || ch == '\n') && !quoted)
            {
                if (ch == '\r' && i + 1 < input.Length && input[i + 1] == '\n') i++;
                row.Add(field.ToString()); field.Clear();
                if (row.Any(value => value.Length > 0)) rows.Add(row);
                row = new List<string>();
            }
            else field.Append(ch);
        }
        if (quoted) throw new InvalidDataException("O CSV contém aspas sem fechamento.");
        row.Add(field.ToString());
        if (row.Any(value => value.Length > 0)) rows.Add(row);
        return rows;
    }

    private static string ToCsv(FavoriteTransferResult data)
    {
        var builder = new StringBuilder();
        builder.AppendLine("Title,URL,Group");
        foreach (var item in data.Favorites)
            builder.Append(EscapeCsv(item.Title)).Append(',').Append(EscapeCsv(item.Url)).Append(',').Append(EscapeCsv(item.GroupName)).AppendLine();
        return builder.ToString();
    }

    private static string EscapeCsv(string value) => "\"" + (value ?? string.Empty).Replace("\"", "\"\"") + "\"";

    private static string ToNetscapeHtml(FavoriteTransferResult data)
    {
        var builder = new StringBuilder();
        builder.AppendLine("<!DOCTYPE NETSCAPE-Bookmark-file-1>");
        builder.AppendLine("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">");
        builder.AppendLine("<TITLE>RX Browser Favorites</TITLE><H1>RX Browser Favorites</H1><DL><p>");
        foreach (var folder in data.Folders)
        {
            var items = data.Favorites.Where(item => item.GroupName.Equals(folder, StringComparison.OrdinalIgnoreCase)).ToList();
            if (items.Count == 0) continue;
            builder.Append("  <DT><H3>").Append(WebUtility.HtmlEncode(folder)).AppendLine("</H3>");
            builder.AppendLine("  <DL><p>");
            foreach (var item in items)
                builder.Append("    <DT><A HREF=\"").Append(WebUtility.HtmlEncode(item.Url)).Append("\">")
                    .Append(WebUtility.HtmlEncode(item.Title)).AppendLine("</A>");
            builder.AppendLine("  </DL><p>");
        }
        builder.AppendLine("</DL><p>");
        return builder.ToString();
    }

    private static string StripTags(string value) => Regex.Replace(value, "<[^>]+>", string.Empty);
    private static string CleanTitle(string? title, string url)
    {
        var value = string.IsNullOrWhiteSpace(title) ? url : title.Trim();
        return value[..Math.Min(value.Length, 240)];
    }

    private static string CleanFolder(string? folder)
    {
        var value = string.IsNullOrWhiteSpace(folder) ? "Geral" : (WebUtility.HtmlDecode(folder) ?? folder).Trim();
        value = value.Trim();
        if (string.IsNullOrWhiteSpace(value)) return "Geral";
        value = value[..Math.Min(value.Length, 48)];
        return value.Equals("Todos", StringComparison.OrdinalIgnoreCase) ? "Geral" : value;
    }

    private static FavoriteTransferResult Normalize(IEnumerable<FavoriteItem>? favorites, IEnumerable<string>? folders)
    {
        var cleanFolders = new List<string> { "Geral" };
        foreach (var folder in folders ?? Array.Empty<string>())
        {
            var clean = CleanFolder(folder);
            if (!cleanFolders.Contains(clean, StringComparer.OrdinalIgnoreCase) && cleanFolders.Count < MaxFolders)
                cleanFolders.Add(clean);
        }
        var cleanFavorites = new List<FavoriteItem>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var favorite in favorites ?? Array.Empty<FavoriteItem>())
        {
            if (favorite is null || string.IsNullOrWhiteSpace(favorite.Url) || favorite.Url.Length > 2048) continue;
            if (!Uri.TryCreate(favorite.Url.Trim(), UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) continue;
            var url = uri.AbsoluteUri;
            if (!seen.Add(url)) continue;
            var group = CleanFolder(favorite.GroupName);
            if (!cleanFolders.Contains(group, StringComparer.OrdinalIgnoreCase) && cleanFolders.Count < MaxFolders) cleanFolders.Add(group);
            if (!cleanFolders.Contains(group, StringComparer.OrdinalIgnoreCase)) group = "Geral";
            cleanFavorites.Add(new FavoriteItem(CleanTitle(favorite.Title, url), url) { GroupName = group });
            if (cleanFavorites.Count >= MaxFavorites) break;
        }
        return new FavoriteTransferResult { Favorites = cleanFavorites, Folders = cleanFolders };
    }
}
