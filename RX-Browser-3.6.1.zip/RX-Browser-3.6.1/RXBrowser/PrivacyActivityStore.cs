﻿namespace RXBrowser;

/// <summary>
/// Session-only privacy telemetry. Stores host names and resource categories only;
/// never stores full URLs, paths, query strings, page contents, or referrers.
/// Private tabs are intentionally excluded.
/// </summary>
internal sealed class PrivacyActivityStore
{
    private const int MaximumRecentEntries = 300;
    private readonly object _gate = new();
    private readonly Queue<PrivacyActivityEntry> _recent = new();
    private readonly Dictionary<string, int> _blockedByDomain = new(StringComparer.OrdinalIgnoreCase);
    private long _externalRequestsInspected;
    private int _blockedRequests;
    private int _adsBlocked;
    private int _trackersBlocked;
    private int _popupsBlocked;
    private int _phishingWarnings;

    public void RecordExternalRequest(bool isPrivate)
    {
        if (isPrivate) return;
        lock (_gate) _externalRequestsInspected++;
    }

    public void RecordBlocked(string pageHost, string requestHost, string resourceType,
        bool blockedByAds, bool blockedByTracking, bool isPrivate)
    {
        if (isPrivate) return;
        lock (_gate)
        {
            _blockedRequests++;
            if (blockedByAds) _adsBlocked++;
            if (blockedByTracking) _trackersBlocked++;

            var host = NormalizeHost(requestHost);
            if (host.Length > 0 && (_blockedByDomain.ContainsKey(host) || _blockedByDomain.Count < 2000))
                _blockedByDomain[host] = _blockedByDomain.GetValueOrDefault(host) + 1;

            var category = blockedByAds && blockedByTracking ? "Anúncio + rastreador"
                : blockedByAds ? "Anúncio" : "Rastreador";
            AddEntry(new PrivacyActivityEntry(DateTime.UtcNow, NormalizeHost(pageHost), host,
                string.IsNullOrWhiteSpace(resourceType) ? "Outro" : resourceType, category,
                "Requisição de terceiro bloqueada pela lista local do RX"));
        }
    }

    public void RecordPopup(string pageHost, bool isPrivate)
    {
        if (isPrivate) return;
        lock (_gate)
        {
            _popupsBlocked++;
            AddEntry(new PrivacyActivityEntry(DateTime.UtcNow, NormalizeHost(pageHost), "—",
                "Janela", "Pop-up", "Nova janela automática bloqueada"));
        }
    }

    public void RecordPhishingWarning(string host, bool isPrivate)
    {
        if (isPrivate) return;
        lock (_gate)
        {
            _phishingWarnings++;
            AddEntry(new PrivacyActivityEntry(DateTime.UtcNow, NormalizeHost(host), NormalizeHost(host),
                "Navegação", "Alerta de endereço", "Sinais heurísticos de URL suspeita; confirme o domínio"));
        }
    }

    public PrivacyActivitySnapshot GetSnapshot()
    {
        lock (_gate)
        {
            return new PrivacyActivitySnapshot(
                _externalRequestsInspected, _blockedRequests, _adsBlocked, _trackersBlocked,
                _popupsBlocked, _phishingWarnings,
                _blockedByDomain.OrderByDescending(pair => pair.Value).ThenBy(pair => pair.Key, StringComparer.OrdinalIgnoreCase)
                    .Take(12).Select(pair => new KeyValuePair<string, int>(pair.Key, pair.Value)).ToArray(),
                _recent.Reverse().ToArray());
        }
    }

    public void Clear()
    {
        lock (_gate)
        {
            _externalRequestsInspected = 0;
            _blockedRequests = 0;
            _adsBlocked = 0;
            _trackersBlocked = 0;
            _popupsBlocked = 0;
            _phishingWarnings = 0;
            _blockedByDomain.Clear();
            _recent.Clear();
        }
    }

    private void AddEntry(PrivacyActivityEntry entry)
    {
        _recent.Enqueue(entry);
        while (_recent.Count > MaximumRecentEntries) _recent.Dequeue();
    }

    private static string NormalizeHost(string? host) => (host ?? string.Empty).Trim().TrimEnd('.').ToLowerInvariant();
}

internal sealed record PrivacyActivityEntry(
    DateTime TimestampUtc,
    string PageHost,
    string RequestHost,
    string ResourceType,
    string Category,
    string Reason);

internal sealed record PrivacyActivitySnapshot(
    long ExternalRequestsInspected,
    int BlockedRequests,
    int AdsBlocked,
    int TrackersBlocked,
    int PopupsBlocked,
    int PhishingWarnings,
    IReadOnlyList<KeyValuePair<string, int>> TopBlockedDomains,
    IReadOnlyList<PrivacyActivityEntry> Recent);
