﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Controles locais de privacidade e segurança do RX Browser.</summary>
internal sealed class SecurityCenterForm : Form
{
    private readonly BrowserData _data;
    private readonly CheckBox _blockPopups = new();
    private readonly CheckBox _warnDownloads = new();
    private readonly CheckBox _phishingEnabled = new();
    private readonly ComboBox _phishingLevel = new();
    private readonly CheckBox _allowManualAutofill = new();
    private readonly string _currentHost;

    public bool ClearPermissionsRequested { get; private set; }
    public bool ClearSiteExceptionsRequested { get; private set; }
    public bool ClearPhishingAllowlistRequested { get; private set; }
    public bool AddCurrentSiteToPhishingAllowlistRequested { get; private set; }

    public SecurityCenterForm(BrowserData data, string? currentUrl, int blockedRequests, int blockedPopups,
        int savedCredentialCount = 0, int autofillCredentialCount = 0, int protectedPinCount = 0)
    {
        _data = data;
        _currentHost = Uri.TryCreate(currentUrl, UriKind.Absolute, out var currentUri) && currentUri.Scheme is "http" or "https"
            ? currentUri.Host.ToLowerInvariant() : string.Empty;
        Text = "Segurança e privacidade — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(680, 720);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Label
        {
            Text = "CENTRAL DE SEGURANÇA RX",
            Dock = DockStyle.Top, Height = 52,
            Padding = new Padding(22, 13, 0, 0),
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold)
        };
        Controls.Add(header);

        var body = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = BackColor, Padding = new Padding(20, 10, 20, 12) };
        Controls.Add(body);
        var y = 12;
        var url = Uri.TryCreate(currentUrl, UriKind.Absolute, out var parsed) ? parsed : null;
        var isHttps = url?.Scheme.Equals("https", StringComparison.OrdinalIgnoreCase) == true;
        var securityText = url is null
            ? "Nenhum site selecionado."
            : isHttps
                ? $"{url.Host}\nHTTPS está ativo: a conexão usa criptografia em trânsito. Isso não garante que o conteúdo do site seja confiável."
                : url.Scheme.Equals("http", StringComparison.OrdinalIgnoreCase)
                    ? $"{url.Host}\nAtenção: HTTP não criptografa a conexão. Evite inserir dados pessoais ou senhas nesta página."
                    : $"Endereço local ou interno: {currentUrl}";
        var sitePanel = new Panel { Left = 4, Top = y, Width = 620, Height = 76, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(12) };
        sitePanel.Controls.Add(new Label
        {
            Dock = DockStyle.Fill, Text = securityText,
            ForeColor = isHttps ? Color.FromArgb(120, 220, 170) : Color.FromArgb(232, 190, 110),
            Font = new Font("Segoe UI", 9.5F), AutoEllipsis = true
        });
        body.Controls.Add(sitePanel);
        y += 92;

        body.Controls.Add(new Label
        {
            Text = "PROTEÇÕES DO NAVEGADOR", Left = 4, Top = y, Width = 600, Height = 22,
            ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold)
        });
        y += 28;

        ConfigureCheck(_blockPopups, "Bloquear pop-ups automáticos sem clique do usuário", data.BlockPopups, body, y, 570);
        y += 34;
        ConfigureCheck(_warnDownloads, "Avisar antes de baixar arquivos que podem executar código", data.WarnDangerousDownloads, body, y, 590);
        y += 34;
        ConfigureCheck(_phishingEnabled, "Ativar proteção heurística contra phishing e domínios falsificados", data.PhishingProtectionEnabled, body, y, 600);
        y += 32;

        body.Controls.Add(new Label { Text = "Sensibilidade da proteção contra phishing", Left = 22, Top = y + 5, Width = 280, Height = 24, ForeColor = ForeColor });
        _phishingLevel.SetBounds(320, y, 270, 30);
        _phishingLevel.DropDownStyle = ComboBoxStyle.DropDownList;
        _phishingLevel.BackColor = Color.FromArgb(27, 36, 49);
        _phishingLevel.ForeColor = ForeColor;
        _phishingLevel.Items.AddRange(new object[]
        {
            new Choice("Básica", "Basic"), new Choice("Equilibrada", "Balanced"), new Choice("Rigorosa", "Strict")
        });
        foreach (var item in _phishingLevel.Items)
            if (item is Choice choice && choice.Value == data.PhishingProtectionLevel) _phishingLevel.SelectedItem = item;
        if (_phishingLevel.SelectedIndex < 0) _phishingLevel.SelectedIndex = 1;
        body.Controls.Add(_phishingLevel);
        y += 38;

        var phishingListLabel = new Label
        {
            Text = $"Domínios que você escolheu ignorar: {data.PhishingAllowlist.Count}. A lista é local a este perfil.",
            Left = 22, Top = y + 5, Width = 390, Height = 25, ForeColor = ForeColor
        };
        body.Controls.Add(phishingListLabel);
        var allowCurrent = MakeButton("Confiar neste domínio", 160, y, false);
        allowCurrent.Left = 420;
        allowCurrent.Enabled = !string.IsNullOrWhiteSpace(_currentHost);
        allowCurrent.Click += (_, _) =>
        {
            AddCurrentSiteToPhishingAllowlistRequested = true;
            phishingListLabel.Text = $"{_currentHost} será adicionado à lista de confiança ao salvar.";
        };
        body.Controls.Add(allowCurrent);
        y += 36;
        var clearPhishing = MakeButton("Limpar lista de confiança", 190, y, false);
        clearPhishing.Left = 420;
        clearPhishing.Click += (_, _) =>
        {
            if (MessageBox.Show(this, "Remover todos os domínios confiados manualmente? A proteção heurística voltará a alertar nesses sites.",
                "Limpar lista de confiança", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            ClearPhishingAllowlistRequested = true;
            AddCurrentSiteToPhishingAllowlistRequested = false;
            phishingListLabel.Text = "Lista de confiança será apagada ao salvar.";
        };
        body.Controls.Add(clearPhishing);
        y += 42;

        body.Controls.Add(new Label
        {
            Text = "SmartScreen: habilitado no WebView2. Proteção contra rastreamento: " + TrackingLabel(data.TrackingProtectionLevel) +
                   $"  ·  Requisições bloqueadas: {blockedRequests}  ·  Pop-ups bloqueados: {blockedPopups}.\n" +
                   "A proteção heurística analisa padrões locais de URL; pode gerar falsos positivos e não substitui um serviço de reputação.",
            Left = 22, Top = y, Width = 590, Height = 48, ForeColor = Color.FromArgb(142, 158, 178), Font = new Font("Segoe UI", 8.5F)
        });
        y += 56;

        ConfigureCheck(_allowManualAutofill, "Permitir preenchimento manual pelo Cofre RX (origem exata e HTTPS; localhost também é permitido)", data.PasswordAutofillEnabled, body, y, 600);
        y += 34;
        body.Controls.Add(new Label
        {
            Text = $"Cofre DPAPI local: {savedCredentialCount} credencial(is) · {autofillCredentialCount} autorizada(s) para preenchimento manual · {protectedPinCount} guia(s) protegida(s) por PIN. Senhas não são sincronizadas.",
            Left = 22, Top = y, Width = 590, Height = 38, ForeColor = Color.FromArgb(142, 158, 178), Font = new Font("Segoe UI", 8.5F)
        });
        y += 48;

        var permissionsInfo = new Label { Text = $"Permissões lembradas para sites: {data.SitePermissions.Count}", Left = 22, Top = y + 5, Width = 390, Height = 24, ForeColor = ForeColor };
        body.Controls.Add(permissionsInfo);
        var clearPermissions = MakeButton("Apagar permissões", 170, y, false);
        clearPermissions.Left = 420;
        clearPermissions.Click += (_, _) =>
        {
            if (MessageBox.Show(this, "Apagar as decisões de câmera, microfone, localização e outras permissões salvas pelo RX Browser? Os sites poderão perguntar novamente.",
                "Limpar permissões", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            ClearPermissionsRequested = true;
            permissionsInfo.Text = "Permissões lembradas: 0 (serão apagadas ao salvar)";
        };
        body.Controls.Add(clearPermissions);
        y += 38;

        var exceptionsInfo = new Label
        {
            Text = $"Exceções: anúncios {data.AdBlockAllowlist.Count} · rastreamento {data.TrackingAllowlist.Count} · pop-ups {data.PopupAllowlist.Count}",
            Left = 22, Top = y + 5, Width = 390, Height = 24, ForeColor = ForeColor
        };
        body.Controls.Add(exceptionsInfo);
        var clearExceptions = MakeButton("Limpar exceções", 170, y, false);
        clearExceptions.Left = 420;
        clearExceptions.Click += (_, _) =>
        {
            if (MessageBox.Show(this, "Remover todas as exceções de anúncios, rastreamento e pop-ups? Os bloqueios serão reativados nos sites listados.",
                "Limpar exceções", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            ClearSiteExceptionsRequested = true;
            exceptionsInfo.Text = "Exceções de sites: 0 (serão apagadas ao salvar)";
        };
        body.Controls.Add(clearExceptions);
        y += 42;

        body.Controls.Add(new Label
        {
            Text = "HTTPS protege os dados em trânsito, mas não garante que um site seja legítimo. Confirme o domínio por um canal confiável antes de fornecer dados pessoais.",
            Left = 22, Top = y, Width = 590, Height = 42, ForeColor = Color.FromArgb(142, 158, 178), Font = new Font("Segoe UI", 8F)
        });

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 58, BackColor = Color.FromArgb(18, 25, 35), Padding = new Padding(12) };
        var cancel = MakeButton("Fechar", 96, 0, false);
        cancel.Dock = DockStyle.Right;
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 96, 0, true);
        save.Dock = DockStyle.Right;
        save.Click += (_, _) =>
        {
            _data.BlockPopups = _blockPopups.Checked;
            _data.WarnDangerousDownloads = _warnDownloads.Checked;
            _data.PasswordAutofillEnabled = _allowManualAutofill.Checked;
            _data.PhishingProtectionEnabled = _phishingEnabled.Checked;
            _data.PhishingProtectionLevel = (_phishingLevel.SelectedItem as Choice)?.Value ?? "Balanced";
            DialogResult = DialogResult.OK;
            Close();
        };
        footer.Controls.Add(cancel);
        footer.Controls.Add(save);
        Controls.Add(footer);
        AcceptButton = save;
        CancelButton = cancel;
    }

    private static void ConfigureCheck(CheckBox check, string text, bool value, Control parent, int top, int width)
    {
        check.Text = text;
        check.Checked = value;
        check.SetBounds(22, top, width, 26);
        check.ForeColor = Color.FromArgb(232, 240, 248);
        check.BackColor = parent.BackColor;
        parent.Controls.Add(check);
    }

    private static string TrackingLabel(string? value) => value switch
    {
        "Basic" => "Básica", "Strict" => "Rigorosa", "Off" => "Desativada", _ => "Equilibrada"
    };

    private Button MakeButton(string text, int width, int top, bool accent)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 32, Top = top,
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(20, 27, 37),
            ForeColor = accent ? Color.FromArgb(35, 205, 230) : ForeColor,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold), Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private sealed record Choice(string Label, string Value)
    {
        public override string ToString() => Label;
    }
}
