﻿using System.Security.Cryptography;

namespace RXBrowser;

internal static class TabProtection
{
    private const int Iterations = 280_000;

    public static void SetPassword(TabProtectionRecord record, string password)
    {
        if (password.Length < 8) throw new ArgumentException("Use pelo menos 8 caracteres.", nameof(password));
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        record.Salt = Convert.ToBase64String(salt);
        record.Hash = Convert.ToBase64String(hash);
        record.Iterations = Iterations;
        record.CreatedUtc = DateTime.UtcNow;
        CryptographicOperations.ZeroMemory(salt);
        CryptographicOperations.ZeroMemory(hash);
    }

    public static void SetPin(TabProtectionRecord record, string pin)
    {
        if (pin.Length is < 6 or > 12 || pin.Any(ch => ch < '0' || ch > '9'))
            throw new ArgumentException("O PIN deve conter de 6 a 12 dígitos.", nameof(pin));
        SetPassword(record, pin);
        record.CredentialKind = "PIN";
    }

    public static bool VerifyPin(TabProtectionRecord record, string pin)
    {
        return string.Equals(record.CredentialKind, "PIN", StringComparison.OrdinalIgnoreCase) &&
            pin.Length is >= 6 and <= 12 && pin.All(ch => ch >= '0' && ch <= '9') && Verify(record, pin);
    }

    public static bool Verify(TabProtectionRecord record, string password)
    {
        try
        {
            var salt = Convert.FromBase64String(record.Salt);
            var expected = Convert.FromBase64String(record.Hash);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, Math.Clamp(record.Iterations, 100_000, 1_000_000), HashAlgorithmName.SHA256, expected.Length);
            var matches = CryptographicOperations.FixedTimeEquals(expected, actual);
            CryptographicOperations.ZeroMemory(salt);
            CryptographicOperations.ZeroMemory(expected);
            CryptographicOperations.ZeroMemory(actual);
            return matches;
        }
        catch { return false; }
    }
}

internal sealed class TabProtectionRecord
{
    public string TabId { get; set; } = string.Empty;
    public string Salt { get; set; } = string.Empty;
    public string Hash { get; set; } = string.Empty;
    public int Iterations { get; set; } = 280_000;
    // Registros antigos não possuem CredentialKind e continuam sendo tratados como senha.
    public string CredentialKind { get; set; } = "Password";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}
