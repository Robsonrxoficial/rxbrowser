﻿using System.Text.Json;

namespace RXBrowser;

internal sealed class BrowserProfileInfo
{
    public string Id { get; set; } = "default";
    public string Name { get; set; } = "Pessoal";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

internal static class ProfileStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static string StoreFile => Path.Combine(BrowserStorage.Root, "profiles.json");

    public static List<BrowserProfileInfo> Load()
    {
        Directory.CreateDirectory(BrowserStorage.Root);
        List<BrowserProfileInfo>? profiles = null;
        try
        {
            if (File.Exists(StoreFile))
                profiles = JsonSerializer.Deserialize<List<BrowserProfileInfo>>(File.ReadAllText(StoreFile));
        }
        catch { }

        var changed = profiles is null;
        profiles ??= new List<BrowserProfileInfo>();
        var filtered = profiles
            .Where(p => p is not null && IsValidId(p.Id) && !string.IsNullOrWhiteSpace(p.Name))
            .GroupBy(p => p.Id, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();
        if (filtered.Count != profiles.Count) changed = true;
        if (!filtered.Any(p => p.Id == "default"))
        {
            filtered.Insert(0, new BrowserProfileInfo { Id = "default", Name = "Pessoal", CreatedAt = DateTime.UtcNow });
            changed = true;
        }
        if (filtered.Count == 0)
        {
            filtered.Add(new BrowserProfileInfo { Id = "default", Name = "Pessoal" });
            changed = true;
        }
        if (changed) Save(filtered);
        return filtered;
    }

    public static void Save(List<BrowserProfileInfo> profiles)
    {
        Directory.CreateDirectory(BrowserStorage.Root);
        var temporary = StoreFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(temporary, JsonSerializer.Serialize(profiles, JsonOptions));
            File.Move(temporary, StoreFile, true);
        }
        finally
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
        }
    }

    public static BrowserProfileInfo Create(string name)
    {
        var cleanName = string.IsNullOrWhiteSpace(name) ? "Novo perfil" : name.Trim();
        if (cleanName.Length > 32) cleanName = cleanName[..32];
        var profiles = Load();
        var profile = new BrowserProfileInfo
        {
            Id = Guid.NewGuid().ToString("N"),
            Name = cleanName,
            CreatedAt = DateTime.UtcNow
        };
        profiles.Add(profile);
        Save(profiles);
        return profile;
    }

    public static BrowserProfileInfo? Find(string id) =>
        Load().FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase));

    public static void Rename(string id, string name)
    {
        var profiles = Load();
        var profile = profiles.FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase));
        if (profile is null) return;
        var cleanName = string.IsNullOrWhiteSpace(name) ? profile.Name : name.Trim();
        if (cleanName.Length > 32) cleanName = cleanName[..32];
        profile.Name = cleanName;
        Save(profiles);
    }

    public static bool IsValidId(string? id) =>
        !string.IsNullOrWhiteSpace(id) && id.Length <= 40 && id.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_');
}
