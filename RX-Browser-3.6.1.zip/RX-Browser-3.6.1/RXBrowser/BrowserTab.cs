﻿using Microsoft.Web.WebView2.WinForms;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class BrowserTab
{
    public required WebView2 View { get; init; }
    public required Panel Header { get; init; }
    public required Label TitleLabel { get; init; }
    public required Button CloseButton { get; init; }
    public required Panel AccentLine { get; init; }
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "Nova guia";
    public string? CurrentTopLevelHost { get; set; }
    public bool IsHomePage { get; set; }
    public bool IsPrivate { get; set; }
    public bool IsPinned { get; set; }
    public string? GroupName { get; set; }
    public string? DarkModeScriptId { get; set; }
    public string? DoNotTrackScriptId { get; set; }
    public bool IsSuspended { get; set; }
    public bool IsPasswordProtected { get; set; }
    public bool IsLocked { get; set; }
    public bool IsPictureInPicture { get; set; }
    public bool HasCrashed { get; set; }
    public string? LastProcessFailure { get; set; }
    public string? PictureInPictureScriptId { get; set; }
    public DateTime LastActivatedUtc { get; set; } = DateTime.UtcNow;
}
