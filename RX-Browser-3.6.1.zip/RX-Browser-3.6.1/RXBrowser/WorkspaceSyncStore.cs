﻿using System.Text.Json;

namespace RXBrowser;

/// <summary>
/// Synchronizes workspace snapshots through a user-selected shared folder.
/// Every device writes its own file; tombstones carry deletions across devices.
/// Only workspace names and HTTP/HTTPS tab addresses are included.
/// </summary>
internal static class WorkspaceSyncStore
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };
    private const int MaximumDevices = 100;
    private const int MaximumWorkspaces = 30;
    private const int MaximumLedgerRecords = 2000;

    public static int Sync(BrowserData data)
    {
        if (string.IsNullOrWhiteSpace(data.WorkspaceSyncFolder)) return data.Workspaces.Count;
        var root = Path.GetFullPath(data.WorkspaceSyncFolder);
        var folder = Path.Combine(root, "rx-browser-workspaces-devices");
        Directory.CreateDirectory(folder);

        var oldLedger = (data.WorkspaceSyncRecords ?? new List<WorkspaceSyncRecord>())
            .Where(IsValidRecord).ToDictionary(record => record.Id, CloneRecord, StringComparer.OrdinalIgnoreCase);
        var local = (data.Workspaces ?? new List<WorkspaceRecord>())
            .Where(IsValidWorkspace)
            .GroupBy(workspace => workspace.Id, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.OrderByDescending(workspace => workspace.UpdatedUtc).First())
            .ToDictionary(workspace => workspace.Id, CloneWorkspace, StringComparer.OrdinalIgnoreCase);

        // Missing active local entries are intentional deletions because the previous ledger
        // remembers which workspace IDs were already known on this device.
        foreach (var previous in oldLedger.Values.Where(record => !record.IsDeleted))
        {
            if (!local.ContainsKey(previous.Id))
            {
                previous.IsDeleted = true;
                previous.Workspace = null;
                previous.UpdatedUtc = DateTime.UtcNow;
            }
        }

        foreach (var workspace in local.Values)
        {
            if (!oldLedger.TryGetValue(workspace.Id, out var previous) ||
                workspace.UpdatedUtc > previous.UpdatedUtc ||
                (!previous.IsDeleted && !Equivalent(previous.Workspace, workspace)))
            {
                oldLedger[workspace.Id] = new WorkspaceSyncRecord
                {
                    Id = workspace.Id,
                    UpdatedUtc = workspace.UpdatedUtc > DateTime.MinValue ? workspace.UpdatedUtc : DateTime.UtcNow,
                    IsDeleted = false,
                    Workspace = CloneWorkspace(workspace)
                };
            }
        }

        var merged = new Dictionary<string, WorkspaceSyncRecord>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in Directory.EnumerateFiles(folder, "*.json", SearchOption.TopDirectoryOnly).Take(MaximumDevices))
        {
            foreach (var record in Read(file)) Merge(merged, record);
        }
        foreach (var record in oldLedger.Values) Merge(merged, record);

        data.WorkspaceSyncRecords = merged.Values
            .OrderByDescending(record => record.UpdatedUtc)
            .Take(MaximumLedgerRecords)
            .Select(CloneRecord).ToList();
        data.Workspaces = merged.Values
            .Where(record => !record.IsDeleted && record.Workspace is not null && IsValidWorkspace(record.Workspace))
            .OrderByDescending(record => record.Workspace!.UpdatedUtc)
            .Take(MaximumWorkspaces)
            .Select(record => CloneWorkspace(record.Workspace!)).ToList();

        var deviceId = SafeId(data.SessionSyncDeviceId + "-" + Environment.MachineName);
        AtomicWrite(Path.Combine(folder, deviceId + ".json"), JsonSerializer.Serialize(data.WorkspaceSyncRecords, Options));
        return data.Workspaces.Count;
    }

    private static void Merge(Dictionary<string, WorkspaceSyncRecord> merged, WorkspaceSyncRecord candidate)
    {
        if (!IsValidRecord(candidate)) return;
        if (!merged.TryGetValue(candidate.Id, out var existing) || candidate.UpdatedUtc > existing.UpdatedUtc)
            merged[candidate.Id] = CloneRecord(candidate);
        else if (candidate.UpdatedUtc == existing.UpdatedUtc && candidate.IsDeleted && !existing.IsDeleted)
            merged[candidate.Id] = CloneRecord(candidate);
    }

    private static List<WorkspaceSyncRecord> Read(string path)
    {
        try
        {
            var info = new FileInfo(path);
            if (!info.Exists || info.Length <= 0 || info.Length > 2_000_000) return new();
            return JsonSerializer.Deserialize<List<WorkspaceSyncRecord>>(File.ReadAllText(path))?
                .Where(IsValidRecord).Take(MaximumLedgerRecords).ToList() ?? new();
        }
        catch { return new(); }
    }

    private static bool IsValidRecord(WorkspaceSyncRecord? record) => record is not null &&
        Guid.TryParseExact(record.Id, "N", out _) &&
        (record.IsDeleted || (record.Workspace is not null && IsValidWorkspace(record.Workspace)));

    private static bool IsValidWorkspace(WorkspaceRecord? workspace) => workspace is not null &&
        Guid.TryParseExact(workspace.Id, "N", out _) && !string.IsNullOrWhiteSpace(workspace.Name) &&
        workspace.Name.Length <= 48 && workspace.Tabs is not null && workspace.Tabs.Count > 0 &&
        workspace.Tabs.Count <= 20 && workspace.Tabs.All(tab => tab is not null &&
            !string.IsNullOrWhiteSpace(tab.Url) && tab.Url.Length <= 4096 &&
            Uri.TryCreate(tab.Url, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https") &&
            (tab.Title?.Length ?? 0) <= 180 && (tab.GroupName?.Length ?? 0) <= 32);

    private static bool Equivalent(WorkspaceRecord? left, WorkspaceRecord right)
    {
        if (left is null) return false;
        return string.Equals(left.Name, right.Name, StringComparison.Ordinal) &&
            left.Tabs.Count == right.Tabs.Count && left.Tabs.Zip(right.Tabs).All(pair =>
                pair.First.Url == pair.Second.Url && pair.First.Title == pair.Second.Title &&
                pair.First.IsPinned == pair.Second.IsPinned && pair.First.GroupName == pair.Second.GroupName);
    }

    private static WorkspaceRecord CloneWorkspace(WorkspaceRecord workspace) => new()
    {
        Id = workspace.Id,
        Name = workspace.Name.Trim()[..Math.Min(workspace.Name.Trim().Length, 48)],
        CreatedUtc = workspace.CreatedUtc,
        UpdatedUtc = workspace.UpdatedUtc,
        Tabs = workspace.Tabs.Select(tab => new WorkspaceTabRecord
        {
            Title = string.IsNullOrWhiteSpace(tab.Title) ? "Nova guia" : tab.Title[..Math.Min(tab.Title.Length, 180)],
            Url = tab.Url,
            IsPinned = tab.IsPinned,
            GroupName = string.IsNullOrWhiteSpace(tab.GroupName) ? null : tab.GroupName.Trim()[..Math.Min(tab.GroupName.Trim().Length, 32)]
        }).ToList()
    };

    private static WorkspaceSyncRecord CloneRecord(WorkspaceSyncRecord record) => new()
    {
        Id = record.Id,
        UpdatedUtc = record.UpdatedUtc,
        IsDeleted = record.IsDeleted,
        Workspace = record.Workspace is null ? null : CloneWorkspace(record.Workspace)
    };

    private static string SafeId(string? value)
    {
        var safe = new string((value ?? string.Empty).Where(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_').ToArray());
        return safe.Length == 0 ? Guid.NewGuid().ToString("N") : safe[..Math.Min(64, safe.Length)];
    }

    private static void AtomicWrite(string path, string contents)
    {
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { File.WriteAllText(temp, contents); File.Move(temp, path, true); }
        finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
    }
}
