﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class CustomizationForm : Form
{
    private readonly ComboBox _accent = new();
    private readonly ComboBox _homeTheme = new();
    private readonly ComboBox _interfaceTheme = new();
    private readonly CheckBox _compactTabs = new();
    private readonly NumericUpDown _sidebarWidth = new();
    private readonly ComboBox _profileBadge = new();
    private readonly Button _customAccentButton = new();
    private readonly BrowserData _data;
    private string _selectedAccentHex;

    public CustomizationForm(BrowserData data)
    {
        _data = data;
        _selectedAccentHex = data.ThemeAccentHex ?? string.Empty;
        Text = "Personalizar RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(520, 558);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var title = new Label
        {
            Text = "PERSONALIZAÇÃO AVANÇADA",
            Left = 22, Top = 18, Width = 470, Height = 30,
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        };
        Controls.Add(title);

        AddLabel("Cor de destaque da interface", 72);
        ConfigureCombo(_accent, 96, new[]
        {
            new Choice("Ciano RX", "Cyan"), new Choice("Violeta", "Violet"),
            new Choice("Verde esmeralda", "Emerald"), new Choice("Âmbar", "Amber"),
            new Choice("Rosa", "Pink")
        }, data.ThemeAccent);
        _accent.SelectedIndexChanged += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(_selectedAccentHex)) return;
            _selectedAccentHex = string.Empty;
            _customAccentButton.Text = "Escolher cor…";
            _customAccentButton.BackColor = Color.FromArgb(35, 205, 230);
            _customAccentButton.ForeColor = Color.White;
        };

        AddLabel("Tema da interface do navegador", 145);
        ConfigureCombo(_interfaceTheme, 169, new[]
        {
            new Choice("Midnight RX", "Midnight"), new Choice("Graphite", "Graphite"),
            new Choice("OLED preto", "OLED"), new Choice("Claro", "Light")
        }, data.InterfaceTheme);

        AddLabel("Tema de fundo da página inicial", 218);
        ConfigureCombo(_homeTheme, 242, new[]
        {
            new Choice("Aurora RX", "Aurora"), new Choice("Meia-noite", "Midnight"),
            new Choice("Roxo cósmico", "Purple"), new Choice("Floresta", "Forest"),
            new Choice("Pôr do sol", "Sunset")
        }, data.HomePageTheme);

        _compactTabs.Left = 22;
        _compactTabs.Top = 297;
        _compactTabs.Width = 460;
        _compactTabs.Text = "Usar guias compactas para caber mais abas na tela";
        _compactTabs.Checked = data.CompactTabs;
        _compactTabs.ForeColor = ForeColor;
        _compactTabs.BackColor = BackColor;
        Controls.Add(_compactTabs);

        AddLabel("Largura da barra lateral (pixels)", 333);
        _sidebarWidth.Left = 22;
        _sidebarWidth.Top = 357;
        _sidebarWidth.Width = 170;
        _sidebarWidth.Minimum = 180;
        _sidebarWidth.Maximum = 360;
        _sidebarWidth.Increment = 10;
        _sidebarWidth.Value = Math.Clamp(data.SidebarWidth, 180, 360);
        _sidebarWidth.BackColor = Color.FromArgb(27, 36, 49);
        _sidebarWidth.ForeColor = ForeColor;
        Controls.Add(_sidebarWidth);

        var note = new Label
        {
            Text = "A aparência e o ícone são salvos separadamente em cada perfil. Preferências não secretas também podem ser sincronizadas; senhas e dados privados não são incluídos.",
            Left = 210, Top = 351, Width = 278, Height = 58,
            ForeColor = Color.FromArgb(142, 158, 178)
        };
        Controls.Add(note);

        Controls.Add(new Label { Text = "Ícone deste perfil", Left = 22, Top = 420, Width = 180, Height = 21, ForeColor = ForeColor });
        _profileBadge.Left = 22;
        _profileBadge.Top = 444;
        _profileBadge.Width = 160;
        _profileBadge.DropDownStyle = ComboBoxStyle.DropDownList;
        _profileBadge.BackColor = Color.FromArgb(27, 36, 49);
        _profileBadge.ForeColor = ForeColor;
        foreach (var badge in new[] { "🌐", "💼", "🎮", "🎨", "📚", "🏠", "🚀" }) _profileBadge.Items.Add(badge);
        _profileBadge.SelectedItem = _profileBadge.Items.Contains(data.ProfileBadge) ? data.ProfileBadge : "🌐";
        Controls.Add(_profileBadge);

        Controls.Add(new Label { Text = "Cor personalizada do perfil", Left = 220, Top = 420, Width = 280, Height = 21, ForeColor = ForeColor });
        _customAccentButton.Left = 220;
        _customAccentButton.Top = 444;
        _customAccentButton.Width = 196;
        _customAccentButton.Height = 30;
        _customAccentButton.Text = string.IsNullOrWhiteSpace(_selectedAccentHex) ? "Escolher cor…" : _selectedAccentHex;
        _customAccentButton.FlatStyle = FlatStyle.Flat;
        _customAccentButton.BackColor = ParseAccentColor(_selectedAccentHex) ?? Color.FromArgb(35, 205, 230);
        _customAccentButton.ForeColor = Color.White;
        _customAccentButton.FlatAppearance.BorderSize = 0;
        _customAccentButton.Click += (_, _) => ChooseCustomAccent();
        Controls.Add(_customAccentButton);

        var resetAccent = MakeButton("Padrão", 78, 444, false);
        resetAccent.Left = 424;
        resetAccent.Click += (_, _) =>
        {
            _selectedAccentHex = string.Empty;
            _customAccentButton.Text = "Escolher cor…";
            _customAccentButton.BackColor = Color.FromArgb(35, 205, 230);
            _customAccentButton.ForeColor = Color.White;
        };
        Controls.Add(resetAccent);

        var cancel = MakeButton("Cancelar", 98, 510, false);
        cancel.Left = 374;
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 98, 510, true);
        save.Left = 268;
        save.Click += (_, _) => SaveSettings();
        Controls.Add(cancel);
        Controls.Add(save);
        AcceptButton = save;
        CancelButton = cancel;
    }

    private void AddLabel(string value, int top)
    {
        Controls.Add(new Label { Text = value, Left = 22, Top = top, Width = 470, Height = 21, ForeColor = ForeColor });
    }

    private void ConfigureCombo(ComboBox combo, int top, Choice[] choices, string selected)
    {
        combo.Left = 22;
        combo.Top = top;
        combo.Width = 470;
        combo.DropDownStyle = ComboBoxStyle.DropDownList;
        combo.BackColor = Color.FromArgb(27, 36, 49);
        combo.ForeColor = ForeColor;
        foreach (var choice in choices) combo.Items.Add(choice);
        for (var i = 0; i < combo.Items.Count; i++)
        {
            if (combo.Items[i] is Choice item && item.Value == selected)
            {
                combo.SelectedIndex = i;
                break;
            }
        }
        if (combo.SelectedIndex < 0 && combo.Items.Count > 0) combo.SelectedIndex = 0;
        Controls.Add(combo);
    }

    private Button MakeButton(string text, int width, int top, bool accent)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, Top = top,
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(20, 27, 37),
            ForeColor = accent ? Color.FromArgb(35, 205, 230) : ForeColor,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void ChooseCustomAccent()
    {
        using var dialog = new ColorDialog
        {
            FullOpen = true,
            Color = ParseAccentColor(_selectedAccentHex) ?? Color.FromArgb(35, 205, 230)
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        _selectedAccentHex = $"#{dialog.Color.R:X2}{dialog.Color.G:X2}{dialog.Color.B:X2}";
        _customAccentButton.Text = _selectedAccentHex;
        _customAccentButton.BackColor = dialog.Color;
        _customAccentButton.ForeColor = dialog.Color.GetBrightness() < 0.48f ? Color.White : Color.Black;
    }

    private static Color? ParseAccentColor(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        try { return ColorTranslator.FromHtml(value); }
        catch { return null; }
    }

    private void SaveSettings()
    {
        if (_accent.SelectedItem is Choice accent) _data.ThemeAccent = accent.Value;
        if (_homeTheme.SelectedItem is Choice theme) _data.HomePageTheme = theme.Value;
        if (_interfaceTheme.SelectedItem is Choice interfaceTheme) _data.InterfaceTheme = interfaceTheme.Value;
        _data.CompactTabs = _compactTabs.Checked;
        _data.SidebarWidth = decimal.ToInt32(_sidebarWidth.Value);
        _data.ProfileBadge = _profileBadge.SelectedItem?.ToString() ?? "🌐";
        _data.ThemeAccentHex = _selectedAccentHex;
        DialogResult = DialogResult.OK;
        Close();
    }

    private sealed record Choice(string Label, string Value)
    {
        public override string ToString() => Label;
    }
}
