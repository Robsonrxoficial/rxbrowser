﻿using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Histórico local com filtros por período/site e exportação CSV. Não recebe registros privados.</summary>
internal sealed class HistoryTimelineForm : Form
{
    private readonly ListView _items = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _dateFilter = new();
    private readonly ComboBox _hostFilter = new();
    private readonly Label _summary = new();
    private readonly List<HistoryItem> _all;
    private List<HistoryItem> _working;
    private List<HistoryItem> _visible = new();

    public string? OpenUrl { get; private set; }
    public List<HistoryItem> ResultHistory => _working.ToList();

    public HistoryTimelineForm(IEnumerable<HistoryItem> history)
    {
        _all = history.Where(item => item is not null).OrderByDescending(item => item.VisitedAt).ToList();
        _working = _all.ToList();
        Text = "Histórico visual — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(780, 560);
        Size = new Size(1080, 740);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);
        KeyPreview = true;

        var header = new Label
        {
            Text = "LINHA DO TEMPO DE NAVEGAÇÃO",
            Dock = DockStyle.Top,
            Height = 48,
            Padding = new Padding(18, 12, 0, 0),
            ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold)
        };
        Controls.Add(header);

        var filterPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 91,
            Padding = new Padding(18, 7, 18, 7),
            BackColor = Color.FromArgb(18, 25, 35)
        };
        _search.SetBounds(0, 0, 650, 32);
        _search.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = ForeColor;
        _search.Font = new Font("Segoe UI", 10F);
        _search.PlaceholderText = "Pesquisar por título ou endereço…  (Ctrl+F)";
        _search.TextChanged += (_, _) => RenderItems();
        filterPanel.Controls.Add(_search);

        _dateFilter.SetBounds(0, 41, 180, 32);
        _dateFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        _dateFilter.Items.AddRange(new object[] { "Todas as datas", "Hoje", "Últimos 7 dias", "Últimos 30 dias" });
        _dateFilter.SelectedIndex = 0;
        _dateFilter.BackColor = Color.FromArgb(27, 36, 49);
        _dateFilter.ForeColor = ForeColor;
        _dateFilter.SelectedIndexChanged += (_, _) => RenderItems();
        filterPanel.Controls.Add(_dateFilter);

        _hostFilter.SetBounds(190, 41, 280, 32);
        _hostFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        _hostFilter.BackColor = Color.FromArgb(27, 36, 49);
        _hostFilter.ForeColor = ForeColor;
        _hostFilter.Items.Add("Todos os sites");
        foreach (var host in _all.Select(item => GetHost(item.Url)).Where(host => host.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(host => host).Take(300))
            _hostFilter.Items.Add(host);
        _hostFilter.SelectedIndex = 0;
        _hostFilter.SelectedIndexChanged += (_, _) => RenderItems();
        filterPanel.Controls.Add(_hostFilter);
        Controls.Add(filterPanel);

        _items.Dock = DockStyle.Fill;
        _items.View = View.Details;
        _items.FullRowSelect = true;
        _items.HideSelection = false;
        _items.MultiSelect = false;
        _items.BorderStyle = BorderStyle.None;
        _items.BackColor = Color.FromArgb(15, 21, 30);
        _items.ForeColor = ForeColor;
        _items.Font = new Font("Segoe UI", 9.5F);
        _items.Columns.Add("Data e hora", 145);
        _items.Columns.Add("Página", 330);
        _items.Columns.Add("Endereço", 500);
        _items.DoubleClick += (_, _) => OpenSelected();
        _items.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Delete) { RemoveSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.Enter) { OpenSelected(); e.Handled = true; }
        };
        Controls.Add(_items);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 64, BackColor = Color.FromArgb(18, 25, 35), Padding = new Padding(16, 9, 16, 9) };
        _summary.Dock = DockStyle.Left;
        _summary.Width = 380;
        _summary.TextAlign = ContentAlignment.MiddleLeft;
        _summary.ForeColor = Color.FromArgb(142, 158, 178);
        footer.Controls.Add(_summary);

        var close = MakeButton("Fechar", 88, false);
        close.Dock = DockStyle.Right;
        close.DialogResult = DialogResult.Cancel;
        var open = MakeButton("Abrir página", 120, true);
        open.Dock = DockStyle.Right;
        open.Click += (_, _) => OpenSelected();
        var remove = MakeButton("Remover", 94, false);
        remove.Dock = DockStyle.Right;
        remove.Click += (_, _) => RemoveSelected();
        var export = MakeButton("Exportar CSV", 112, false);
        export.Dock = DockStyle.Right;
        export.Click += (_, _) => ExportCsv();
        var clear = MakeButton("Limpar tudo", 104, false);
        clear.Dock = DockStyle.Right;
        clear.Click += (_, _) => ClearAll();
        footer.Controls.Add(close);
        footer.Controls.Add(open);
        footer.Controls.Add(remove);
        footer.Controls.Add(export);
        footer.Controls.Add(clear);
        Controls.Add(footer);

        KeyDown += (_, e) =>
        {
            if (e.Control && e.KeyCode == Keys.F) { _search.Focus(); _search.SelectAll(); e.Handled = true; }
            else if (e.Control && e.KeyCode == Keys.E) { ExportCsv(); e.Handled = true; }
        };

        RenderItems();
        CancelButton = close;
        AcceptButton = open;
    }

    private Button MakeButton(string text, int width, bool accent)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 38, Margin = new Padding(4, 0, 4, 0),
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private static string GetHost(string? url)
    {
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https"
            ? uri.Host : string.Empty;
    }

    private void RenderItems()
    {
        _items.BeginUpdate();
        try
        {
            _items.Items.Clear();
            _items.Groups.Clear();
            var query = _search.Text.Trim();
            var dateMode = _dateFilter.SelectedIndex;
            var selectedHost = _hostFilter.SelectedItem?.ToString();
            var cutoff = dateMode switch
            {
                1 => DateTime.Today,
                2 => DateTime.Now.AddDays(-7),
                3 => DateTime.Now.AddDays(-30),
                _ => DateTime.MinValue
            };
            _visible = _working.Where(item =>
            {
                if (dateMode == 1 ? item.VisitedAt.Date != DateTime.Today : item.VisitedAt < cutoff) return false;
                if (!string.IsNullOrWhiteSpace(selectedHost) && selectedHost != "Todos os sites" &&
                    !string.Equals(GetHost(item.Url), selectedHost, StringComparison.OrdinalIgnoreCase)) return false;
                return query.Length == 0 ||
                    (item.Title ?? string.Empty).Contains(query, StringComparison.CurrentCultureIgnoreCase) ||
                    (item.Url ?? string.Empty).Contains(query, StringComparison.CurrentCultureIgnoreCase);
            }).OrderByDescending(item => item.VisitedAt).ToList();

            var groups = new Dictionary<DateTime, ListViewGroup>();
            foreach (var entry in _visible)
            {
                var day = entry.VisitedAt.Date;
                if (!groups.TryGetValue(day, out var group))
                {
                    var label = day == DateTime.Today ? "Hoje" : day == DateTime.Today.AddDays(-1) ? "Ontem" : day.ToString("dddd, dd/MM/yyyy");
                    group = new ListViewGroup(label, HorizontalAlignment.Left);
                    groups[day] = group;
                    _items.Groups.Add(group);
                }
                var row = new ListViewItem(entry.VisitedAt.ToString("dd/MM HH:mm:ss")) { Tag = entry, Group = group };
                row.SubItems.Add(string.IsNullOrWhiteSpace(entry.Title) ? "Sem título" : entry.Title);
                row.SubItems.Add(entry.Url ?? string.Empty);
                _items.Items.Add(row);
            }
            _summary.Text = $"{_visible.Count} visita(s) exibida(s)  ·  {_working.Count} registro(s) no perfil";
        }
        finally { _items.EndUpdate(); }
    }

    private HistoryItem? Selected => _items.SelectedItems.Count > 0 ? _items.SelectedItems[0].Tag as HistoryItem : null;

    private void OpenSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        OpenUrl = selected.Url;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void RemoveSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        _working.Remove(selected);
        RenderItems();
    }

    private void ClearAll()
    {
        if (_working.Count == 0) return;
        if (MessageBox.Show(this, "Apagar todos os registros do histórico deste perfil?", "Limpar histórico — RX Browser",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        _working.Clear();
        RenderItems();
    }

    private void ExportCsv()
    {
        if (_visible.Count == 0)
        {
            MessageBox.Show(this, "Não há registros para exportar com os filtros atuais.", "Exportar histórico", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar histórico filtrado",
            Filter = "Arquivo CSV (*.csv)|*.csv",
            FileName = $"RXBrowser-Historico-{DateTime.Now:yyyyMMdd-HHmm}.csv",
            AddExtension = true,
            DefaultExt = "csv",
            OverwritePrompt = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        static string Escape(string? value) => "\"" + (value ?? string.Empty).Replace("\"", "\"\"") + "\"";
        var output = new StringBuilder();
        output.AppendLine("DataHora;Titulo;Endereco");
        foreach (var item in _visible)
            output.AppendLine(string.Join(";", Escape(item.VisitedAt.ToString("O")), Escape(item.Title), Escape(item.Url)));
        try
        {
            File.WriteAllText(dialog.FileName, output.ToString(), new UTF8Encoding(true));
            MessageBox.Show(this, $"{_visible.Count} registro(s) exportado(s).", "Histórico exportado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível exportar o histórico.\n\n" + ex.Message, "Exportar histórico", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
