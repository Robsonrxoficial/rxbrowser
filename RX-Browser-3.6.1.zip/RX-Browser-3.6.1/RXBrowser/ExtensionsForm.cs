﻿using Microsoft.Web.WebView2.Core;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class ExtensionsForm : Form
{
    private readonly CoreWebView2Profile _profile;
    private readonly BrowserData _data;
    private readonly FlowLayoutPanel _items = new();
    private readonly Label _status = new();
    private readonly TextBox _search = new();
    private IReadOnlyList<CoreWebView2BrowserExtension> _extensions = Array.Empty<CoreWebView2BrowserExtension>();

    public bool ExtensionsChanged { get; private set; }

    public ExtensionsForm(CoreWebView2Profile profile, BrowserData data)
    {
        _profile = profile;
        _data = data;
        Text = "Extensões — RX Browser 3.6.0";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(980, 650);
        MinimumSize = new Size(850, 480);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var heading = new Panel { Dock = DockStyle.Top, Height = 132, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(18, 10, 18, 8) };
        var title = new Label { Text = "CENTRAL DE EXTENSÕES RX", Dock = DockStyle.Top, Height = 28, Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(35, 205, 230) };
        _search.Dock = DockStyle.Top;
        _search.Height = 30;
        _search.Margin = new Padding(0, 4, 0, 4);
        _search.PlaceholderText = "Pesquisar por nome, ID, versão ou permissão";
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = Color.FromArgb(232, 240, 248);
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.TextChanged += (_, _) => RenderExtensions();
        _status.Dock = DockStyle.Fill;
        _status.Text = "Revise as permissões e a origem das extensões. Instale somente componentes de fontes confiáveis.";
        _status.ForeColor = Color.FromArgb(142, 158, 178);
        heading.Controls.Add(_status);
        heading.Controls.Add(_search);
        heading.Controls.Add(title);

        _items.Dock = DockStyle.Fill;
        _items.FlowDirection = FlowDirection.TopDown;
        _items.WrapContents = false;
        _items.AutoScroll = true;
        _items.Padding = new Padding(14);

        var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 58, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(10), BackColor = Color.FromArgb(20, 27, 37) };
        footer.Controls.Add(MakeButton("Instalar extensão", async () => await InstallAsync()));
        footer.Controls.Add(MakeButton("Atualizar lista", async () => await RefreshAsync()));
        footer.Controls.Add(MakeButton("Sobre permissões", () =>
        {
            MessageBox.Show(this,
                "Extensões são componentes de terceiros e podem acessar dados dos sites conforme as permissões declaradas no manifest.json. O RX Browser mostra as permissões declaradas, mas não consegue auditar todo o código da extensão.\n\n" +
                "<all_urls>, cookies, debugger, nativeMessaging, webRequest e permissões equivalentes podem conceder acesso amplo. Nem todas as APIs da Chrome Web Store são suportadas pelo WebView2.",
                "Segurança de extensões", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return Task.CompletedTask;
        }));
        Controls.Add(_items);
        Controls.Add(footer);
        Controls.Add(heading);
        Shown += async (_, _) => await RefreshAsync();
    }

    private static Button MakeButton(string text, Func<Task> action)
    {
        var button = new Button { Text = text, AutoSize = true, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(27, 36, 49), ForeColor = Color.FromArgb(232, 240, 248), Margin = new Padding(4, 0, 4, 0), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        button.Click += async (_, _) => await action();
        return button;
    }

    private async Task InstallAsync()
    {
        using var picker = new FolderBrowserDialog { Description = "Selecione a pasta da extensão descompactada (deve conter manifest.json).", UseDescriptionForTitle = true };
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        ExtensionManifestInfo info;
        try { info = ExtensionManifestInspector.Read(picker.SelectedPath); }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Extensão inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (!ConfirmManifest(info, "Instalar extensão")) return;

        try
        {
            var extension = await _profile.AddBrowserExtensionAsync(info.FolderPath);
            SaveInstallRecord(extension.Id, info);
            ExtensionsChanged = true;
            _status.Text = $"Extensão instalada: {info.Name} · versão {info.Version}. Recarregue as páginas abertas para aplicar alterações.";
            await RefreshAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível instalar a extensão. Verifique se ela é compatível com a versão do WebView2.\n\n" + ex.Message, "Falha na instalação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private bool ConfirmManifest(ExtensionManifestInfo info, string title)
    {
        var sensitive = info.Permissions.Concat(info.HostPermissions)
            .Where(permission => permission is "<all_urls>" or "tabs" or "cookies" or "debugger" or "nativeMessaging" or "webRequest" or "webRequestBlocking" or "management" || permission.Contains("://*/*", StringComparison.OrdinalIgnoreCase) || permission.Contains("*://*/*", StringComparison.OrdinalIgnoreCase))
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var warning = sensitive.Count > 0
            ? "\n\nATENÇÃO — permissões sensíveis: " + string.Join(", ", sensitive.Take(12))
            : "\n\nRevise as permissões antes de confiar nesta extensão.";
        var text = $"Nome: {info.Name}\nVersão: {info.Version}\nManifest: V{info.ManifestVersion}\n\nPermissões: {info.PermissionSummary}\n\nDescrição: {info.Description}{warning}\n\nDeseja continuar?";
        return MessageBox.Show(this, text, title, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes;
    }

    private void SaveInstallRecord(string id, ExtensionManifestInfo info)
    {
        _data.ExtensionInstallRecords.RemoveAll(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase));
        _data.ExtensionInstallRecords.Add(new ExtensionInstallRecord
        {
            Id = id,
            Name = info.Name,
            Version = info.Version,
            SourceFolder = info.FolderPath,
            ManifestVersion = info.ManifestVersion,
            Permissions = info.Permissions.ToList(),
            HostPermissions = info.HostPermissions.ToList(),
            InstalledUtc = DateTime.UtcNow
        });
        BrowserStorage.Save(_data);
    }

    private async Task UpdateAsync(CoreWebView2BrowserExtension extension)
    {
        var record = FindRecord(extension.Id);
        var initialFolder = record?.SourceFolder;
        using var picker = new FolderBrowserDialog
        {
            Description = "Selecione a pasta atualizada da extensão. Para manter o mesmo ID, use o pacote oficial da mesma extensão.",
            UseDescriptionForTitle = true,
            SelectedPath = initialFolder is not null && Directory.Exists(initialFolder) ? initialFolder : string.Empty
        };
        if (picker.ShowDialog(this) != DialogResult.OK) return;

        ExtensionManifestInfo updatedInfo;
        try { updatedInfo = ExtensionManifestInspector.Read(picker.SelectedPath); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Pacote de atualização inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        if (!ConfirmManifest(updatedInfo, "Confirmar atualização")) return;
        if (MessageBox.Show(this,
            "O WebView2 substitui a extensão removendo a versão atual e instalando a pasta selecionada. Se a instalação falhar, o RX tentará restaurar a pasta anterior. Continuar?",
            "Atualizar extensão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

        try
        {
            await extension.RemoveAsync();
            _data.ExtensionInstallRecords.RemoveAll(item => string.Equals(item.Id, extension.Id, StringComparison.OrdinalIgnoreCase));
            BrowserStorage.Save(_data);
            try
            {
                var installed = await _profile.AddBrowserExtensionAsync(updatedInfo.FolderPath);
                if (!string.Equals(installed.Id, extension.Id, StringComparison.OrdinalIgnoreCase))
                {
                    await installed.RemoveAsync();
                    throw new InvalidDataException("A pasta selecionada corresponde a outra extensão (ID diferente). Selecione a atualização oficial da mesma extensão.");
                }
                SaveInstallRecord(installed.Id, updatedInfo);
                ExtensionsChanged = true;
                _status.Text = $"Extensão atualizada: {updatedInfo.Name} · {updatedInfo.Version}.";
            }
            catch
            {
                if (!string.IsNullOrWhiteSpace(initialFolder) && Directory.Exists(initialFolder))
                {
                    try
                    {
                        var restoredInfo = ExtensionManifestInspector.Read(initialFolder);
                        var restored = await _profile.AddBrowserExtensionAsync(initialFolder);
                        SaveInstallRecord(restored.Id, restoredInfo);
                    }
                    catch { }
                }
                throw;
            }
            await RefreshAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível atualizar a extensão. O RX tentou restaurar a versão anterior, quando a pasta original estava disponível.\n\n" + ex.Message,
                "Falha na atualização", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            await RefreshAsync();
        }
    }

    private ExtensionInstallRecord? FindRecord(string id) =>
        _data.ExtensionInstallRecords.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase));

    private async Task RefreshAsync()
    {
        try
        {
            _extensions = await _profile.GetBrowserExtensionsAsync();
            RenderExtensions();
            _status.Text = $"{_extensions.Count} extensão(ões) instalada(s). O manifesto é lido localmente para mostrar versão e permissões declaradas.";
        }
        catch (Exception ex) { _status.Text = "Não foi possível carregar extensões: " + ex.Message; }
    }

    private void RenderExtensions()
    {
        _items.SuspendLayout();
        try
        {
            foreach (Control child in _items.Controls) child.Dispose();
            _items.Controls.Clear();
            var query = _search.Text.Trim();
            var visible = _extensions.Where(extension =>
            {
                var record = FindRecord(extension.Id);
                return string.IsNullOrWhiteSpace(query) ||
                    extension.Name.Contains(query, StringComparison.CurrentCultureIgnoreCase) ||
                    extension.Id.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    (record?.Version.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false) ||
                    (record?.Permissions.Any(item => item.Contains(query, StringComparison.OrdinalIgnoreCase)) ?? false) ||
                    (record?.HostPermissions.Any(item => item.Contains(query, StringComparison.OrdinalIgnoreCase)) ?? false);
            }).ToList();

            if (_extensions.Count == 0)
            {
                _items.Controls.Add(new Label { Text = "Nenhuma extensão instalada.\n\nUse 'Instalar extensão' para adicionar uma WebExtension compatível com WebView2.", AutoSize = true, ForeColor = Color.FromArgb(142, 158, 178), Padding = new Padding(8) });
                return;
            }
            if (visible.Count == 0)
            {
                _items.Controls.Add(new Label { Text = "Nenhuma extensão corresponde à pesquisa.", AutoSize = true, ForeColor = Color.FromArgb(142, 158, 178), Padding = new Padding(8) });
                return;
            }

            foreach (var extension in visible)
            {
                var rowWidth = Math.Max(780, _items.ClientSize.Width - 42);
                var row = new Panel { Width = rowWidth, Height = 122, BackColor = Color.FromArgb(20, 27, 37), Margin = new Padding(2, 2, 2, 8), Padding = new Padding(10) };
                var record = FindRecord(extension.Id);
                var version = record?.Version ?? "versão não registrada";
                var permissions = record is null ? "Metadados do manifesto indisponíveis (extensão instalada fora do RX)." :
                    "Permissões: " + string.Join(", ", record.Permissions.Concat(record.HostPermissions).Distinct(StringComparer.OrdinalIgnoreCase).Take(9));
                var name = new Label { Text = extension.Name, Left = 10, Top = 8, Width = rowWidth - 430, Height = 22, ForeColor = Color.FromArgb(232, 240, 248), Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold), AutoEllipsis = true };
                var id = new Label { Text = $"ID: {extension.Id}  ·  {version}", Left = 10, Top = 34, Width = rowWidth - 430, Height = 18, ForeColor = Color.FromArgb(142, 158, 178), AutoEllipsis = true };
                var permissionLabel = new Label { Text = permissions, Left = 10, Top = 58, Width = rowWidth - 430, Height = 45, ForeColor = Color.FromArgb(142, 158, 178), AutoEllipsis = true };
                var enabled = new CheckBox { Text = extension.IsEnabled ? "Ativada" : "Desativada", Checked = extension.IsEnabled, Left = rowWidth - 410, Top = 12, Width = 82, ForeColor = Color.FromArgb(232, 240, 248) };
                enabled.CheckedChanged += async (_, _) =>
                {
                    try { await extension.EnableAsync(enabled.Checked); ExtensionsChanged = true; enabled.Text = enabled.Checked ? "Ativada" : "Desativada"; }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "Extensão", MessageBoxButtons.OK, MessageBoxIcon.Warning); enabled.Checked = extension.IsEnabled; }
                };
                var details = MakeRowButton("Detalhes", rowWidth - 322, 8, 72);
                details.Click += (_, _) =>
                {
                    var detailText = record is null
                        ? $"Nome: {extension.Name}\nID: {extension.Id}\nEstado: {(extension.IsEnabled ? "Ativada" : "Desativada")}\n\nO RX não possui o manifesto de origem desta extensão."
                        : $"Nome: {record.Name}\nVersão: {record.Version}\nManifest: V{record.ManifestVersion}\nID: {record.Id}\nEstado: {(extension.IsEnabled ? "Ativada" : "Desativada")}\n\nDescrição e permissões declaradas:\n{string.Join(", ", record.Permissions.Concat(record.HostPermissions))}\n\nPasta: {record.SourceFolder}\n\nO RX Browser não audita o código da extensão.";
                    MessageBox.Show(this, detailText, "Detalhes da extensão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };
                var openFolder = MakeRowButton("Pasta", rowWidth - 242, 8, 62);
                openFolder.Enabled = record is not null && Directory.Exists(record.SourceFolder);
                openFolder.Click += (_, _) =>
                {
                    if (record is null || !Directory.Exists(record.SourceFolder)) return;
                    try { Process.Start(new ProcessStartInfo(record.SourceFolder) { UseShellExecute = true }); }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "Pasta da extensão", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                };
                var update = MakeRowButton("Atualizar", rowWidth - 172, 8, 76);
                update.Enabled = record is not null && Directory.Exists(record.SourceFolder);
                update.Click += async (_, _) => await UpdateAsync(extension);
                var remove = MakeRowButton("Remover", rowWidth - 88, 8, 78);
                remove.BackColor = Color.FromArgb(70, 35, 44);
                remove.Click += async (_, _) =>
                {
                    if (MessageBox.Show(this, $"Remover a extensão '{extension.Name}'?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                    try
                    {
                        await extension.RemoveAsync();
                        _data.ExtensionInstallRecords.RemoveAll(item => string.Equals(item.Id, extension.Id, StringComparison.OrdinalIgnoreCase));
                        BrowserStorage.Save(_data);
                        ExtensionsChanged = true;
                        await RefreshAsync();
                    }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "Extensão", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                };
                row.Controls.AddRange(new Control[] { name, id, permissionLabel, enabled, details, openFolder, update, remove });
                _items.Controls.Add(row);
            }
        }
        finally { _items.ResumeLayout(); }
    }

    private static Button MakeRowButton(string text, int left, int top, int width)
    {
        var button = new Button { Text = text, Left = left, Top = top, Width = width, Height = 30, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(27, 36, 49), ForeColor = Color.White, Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
