﻿namespace RXBrowser;

/// <summary>Central de comandos personalizável do RX Browser 3.6.</summary>
internal sealed class ControlCenterForm : Form
{
    public string? SelectedAction { get; private set; }

    public ControlCenterForm(string profileName, int tabs, int privateTabs, int favorites,
        int savedSessions, int downloads, int blockedRequests,
        IEnumerable<string>? visibleActions = null, IEnumerable<string>? actionOrder = null,
        string? accentHex = null, int columns = 3)
    {
        Text = "Central RX — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.Sizable;
        MinimumSize = new Size(720, 560);
        Size = new Size(820, 660);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);
        var accent = ParseAccent(accentHex) ?? Color.FromArgb(50, 211, 235);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(22),
            BackColor = BackColor,
            ColumnCount = 1,
            RowCount = 4
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        Controls.Add(root);

        var heading = new Panel { Dock = DockStyle.Fill, BackColor = BackColor };
        var title = new Label
        {
            Text = "CENTRAL RX",
            Dock = DockStyle.Top,
            Height = 36,
            Font = new Font("Segoe UI Black", 19, FontStyle.Bold),
            ForeColor = accent
        };
        var subtitle = new Label
        {
            Text = $"Perfil: {profileName}  •  Painel de controle personalizável",
            Dock = DockStyle.Bottom,
            Height = 28,
            ForeColor = Color.FromArgb(155, 171, 190)
        };
        heading.Controls.Add(subtitle);
        heading.Controls.Add(title);
        root.Controls.Add(heading, 0, 0);

        var stats = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 5,
            RowCount = 1,
            BackColor = Color.FromArgb(20, 27, 37),
            Padding = new Padding(8),
            Margin = new Padding(0, 4, 0, 12)
        };
        for (var i = 0; i < 5; i++) stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        AddStat(stats, 0, "GUIAS", tabs.ToString(), accent);
        AddStat(stats, 1, "PRIVADAS", privateTabs.ToString(), accent);
        AddStat(stats, 2, "FAVORITOS", favorites.ToString(), accent);
        AddStat(stats, 3, "SESSÕES", savedSessions.ToString(), accent);
        AddStat(stats, 4, "DOWNLOADS", downloads.ToString(), accent);
        root.Controls.Add(stats, 0, 1);

        var commands = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = BackColor,
            Padding = new Padding(0, 2, 0, 2)
        };
        var visible = (visibleActions ?? Array.Empty<string>()).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var order = (actionOrder ?? Array.Empty<string>()).ToList();
        var catalog = ControlCenterCommands.All.ToList();
        var catalogIndexes = catalog.Select((command, index) => (command.Id, index))
            .ToDictionary(item => item.Id, item => item.index, StringComparer.OrdinalIgnoreCase);
        var ordered = catalog
            .OrderBy(command =>
            {
                var index = order.FindIndex(id => string.Equals(id, command.Id, StringComparison.OrdinalIgnoreCase));
                return index < 0 ? int.MaxValue : index;
            })
            .ThenBy(command => catalogIndexes[command.Id]);
        var selected = ordered.Where(command => visible.Count == 0 || visible.Contains(command.Id)).ToList();
        var columnCount = Math.Clamp(columns, 2, 4);
        var buttonWidth = Math.Max(150, (ClientSize.Width - 92) / columnCount - 10);
        foreach (var command in selected)
            AddCommand(commands, command, buttonWidth, accent);
        if (commands.Controls.Count == 0)
            commands.Controls.Add(new Label { Text = "Nenhum cartão selecionado. Use Personalizar Central para escolher os comandos.", AutoSize = true, ForeColor = ForeColor, Padding = new Padding(12) });
        root.Controls.Add(commands, 0, 2);

        var footer = new Panel { Dock = DockStyle.Fill, BackColor = BackColor };
        var note = new Label
        {
            Text = $"Solicitações bloqueadas nesta sessão: {blockedRequests}",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(139, 157, 178),
            TextAlign = ContentAlignment.MiddleLeft
        };
        var close = new Button
        {
            Text = "Fechar", Dock = DockStyle.Right, Width = 88,
            FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(27, 36, 49),
            ForeColor = Color.FromArgb(232, 240, 248), DialogResult = DialogResult.Cancel
        };
        close.FlatAppearance.BorderSize = 0;
        var customize = new Button
        {
            Text = "Personalizar Central", Dock = DockStyle.Right, Width = 154,
            FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(22, 53, 66),
            ForeColor = accent, Margin = new Padding(0, 0, 8, 0)
        };
        customize.FlatAppearance.BorderSize = 0;
        customize.Click += (_, _) => { SelectedAction = "customize"; DialogResult = DialogResult.OK; Close(); };
        footer.Controls.Add(note);
        footer.Controls.Add(close);
        footer.Controls.Add(customize);
        root.Controls.Add(footer, 0, 3);
        CancelButton = close;
    }

    private static Color? ParseAccent(string? hex)
    {
        if (string.IsNullOrWhiteSpace(hex) || !System.Text.RegularExpressions.Regex.IsMatch(hex, "^#[0-9A-Fa-f]{6}$")) return null;
        try { return ColorTranslator.FromHtml(hex); } catch { return null; }
    }

    private static void AddStat(TableLayoutPanel host, int column, string label, string value, Color accent)
    {
        var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(27, 36, 49), Margin = new Padding(3) };
        card.Controls.Add(new Label
        {
            Text = value, Dock = DockStyle.Top, Height = 35,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 17, FontStyle.Bold), ForeColor = accent
        });
        card.Controls.Add(new Label
        {
            Text = label, Dock = DockStyle.Bottom, Height = 22,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 7.5F, FontStyle.Bold),
            ForeColor = Color.FromArgb(155, 171, 190)
        });
        host.Controls.Add(card, column, 0);
    }

    private void AddCommand(FlowLayoutPanel host, ControlCenterCommandDefinition command, int width, Color accent)
    {
        var button = new Button
        {
            Text = $"{command.Icon}  {command.Title}" + Environment.NewLine + command.Description,
            Width = width,
            Height = 72,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 4, 8, 4),
            Margin = new Padding(0, 0, 10, 10),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(20, 27, 37),
            ForeColor = Color.FromArgb(232, 240, 248),
            Font = new Font("Segoe UI", 8.8F, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = Color.FromArgb(43, 63, 79);
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 53, 68);
        button.Click += (_, _) => { SelectedAction = command.Id; DialogResult = DialogResult.OK; Close(); };
        host.Controls.Add(button);
    }
}
