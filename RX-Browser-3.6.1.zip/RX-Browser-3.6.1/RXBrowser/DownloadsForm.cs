﻿using System.Diagnostics;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class DownloadsForm : Form
{
    private readonly IList<DownloadRecord> _downloads;
    private readonly string _downloadsFolder;
    private readonly Action _persist;
    private readonly Action<DownloadRecord> _retry;
    private readonly ListView _list = new();
    private readonly TextBox _filter = new();
    private readonly ComboBox _stateFilter = new();
    private readonly Label _summary = new();
    private readonly Button _pauseResumeButton;
    private readonly Button _retryButton;
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 1200 };

    public DownloadsForm(IList<DownloadRecord> downloads, string downloadsFolder,
        Action persist, Action<DownloadRecord> retry)
    {
        _downloads = downloads;
        _downloadsFolder = downloadsFolder;
        _persist = persist;
        _retry = retry;

        Text = "Central de downloads — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1080, 600);
        MinimumSize = new Size(900, 430);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var header = new Panel
        {
            Dock = DockStyle.Top,
            Height = 68,
            BackColor = Color.FromArgb(20, 27, 37),
            Padding = new Padding(16, 9, 16, 8)
        };
        var heading = new Label
        {
            Text = "DOWNLOADS",
            Dock = DockStyle.Top,
            Height = 23,
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold)
        };
        _summary.Dock = DockStyle.Bottom;
        _summary.Height = 23;
        _summary.ForeColor = Color.FromArgb(142, 158, 178);
        _summary.TextAlign = ContentAlignment.MiddleLeft;
        header.Controls.Add(_summary);
        header.Controls.Add(heading);

        _list.Dock = DockStyle.Fill;
        _list.View = View.Details;
        _list.OwnerDraw = true;
        _list.FullRowSelect = true;
        _list.GridLines = false;
        _list.HideSelection = false;
        _list.BackColor = Color.FromArgb(20, 27, 37);
        _list.ForeColor = Color.FromArgb(232, 240, 248);
        _list.BorderStyle = BorderStyle.None;
        _list.Columns.Add("Arquivo", 300);
        _list.Columns.Add("Estado", 130);
        _list.Columns.Add("Risco", 90);
        _list.Columns.Add("Progresso", 150);
        _list.Columns.Add("Previsão", 100);
        _list.Columns.Add("Início", 120);
        _list.DoubleClick += (_, _) => OpenSelected();
        _list.DrawColumnHeader += DrawColumnHeader;
        _list.DrawItem += (_, e) => { if (_list.View != View.Details) e.DrawDefault = true; };
        _list.DrawSubItem += DrawSubItem;
        _list.SelectedIndexChanged += (_, _) => UpdateActionButtons();
        Controls.Add(_list);

        var footer = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 58,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            Padding = new Padding(8, 11, 8, 8),
            BackColor = Color.FromArgb(20, 27, 37)
        };
        var openFolder = MakeButton("Abrir pasta", OpenFolder);
        var showFile = MakeButton("Mostrar arquivo", ShowSelected);
        var openFile = MakeButton("Abrir arquivo", OpenSelected);
        var cancel = MakeButton("Cancelar", CancelSelected);
        _retryButton = MakeButton("Baixar novamente", RetrySelected);
        _pauseResumeButton = MakeButton("Pausar", TogglePauseResumeSelected, true);
        var hash = MakeButton("SHA-256", () => _ = ComputeSelectedHashAsync());
        var clear = MakeButton("Limpar finalizados", ClearCompleted);
        footer.Controls.Add(clear);
        footer.Controls.Add(hash);
        footer.Controls.Add(openFolder);
        footer.Controls.Add(showFile);
        footer.Controls.Add(openFile);
        footer.Controls.Add(_retryButton);
        footer.Controls.Add(_pauseResumeButton);
        footer.Controls.Add(cancel);
        Controls.Add(footer);

        var filterPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 78,
            BackColor = Color.FromArgb(12, 16, 23),
            Padding = new Padding(12, 7, 12, 7)
        };
        var filterLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.FromArgb(12, 16, 23),
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        filterLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        filterLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        _filter.Dock = DockStyle.Fill;
        _filter.BackColor = Color.FromArgb(27, 36, 49);
        _filter.ForeColor = Color.FromArgb(232, 240, 248);
        _filter.BorderStyle = BorderStyle.FixedSingle;
        _filter.PlaceholderText = "Pesquisar arquivo ou endereço de origem...";
        _filter.Margin = new Padding(0, 0, 0, 4);
        _filter.TextChanged += (_, _) => RefreshRows();
        _stateFilter.Dock = DockStyle.Fill;
        _stateFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        _stateFilter.BackColor = Color.FromArgb(27, 36, 49);
        _stateFilter.ForeColor = Color.FromArgb(232, 240, 248);
        _stateFilter.Items.AddRange(new object[] { "Todos os estados", "Baixando", "Pausado", "Concluído", "Interrompido", "Interrompido (sessão anterior)", "Cancelado" });
        _stateFilter.SelectedIndex = 0;
        _stateFilter.Margin = new Padding(0, 3, 0, 0);
        _stateFilter.SelectedIndexChanged += (_, _) => RefreshRows();
        filterLayout.Controls.Add(_filter, 0, 0);
        filterLayout.Controls.Add(_stateFilter, 0, 1);
        filterPanel.Controls.Add(filterLayout);
        Controls.Add(filterPanel);
        Controls.Add(header);

        _timer.Tick += (_, _) => RefreshRows();
        Shown += (_, _) => { RefreshRows(); _timer.Start(); };
        FormClosed += (_, _) => { _timer.Stop(); _timer.Dispose(); };
    }

    private static Button MakeButton(string text, Action action, bool accent = false)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            Height = 32,
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(35, 205, 230) : Color.FromArgb(232, 240, 248),
            Margin = new Padding(4, 0, 4, 0),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 54, 70);
        button.Click += (_, _) => action();
        return button;
    }

    private void RefreshRows()
    {
        if (IsDisposed) return;
        var selectedPath = SelectedDownload?.FilePath;
        var query = _filter.Text.Trim();
        var state = _stateFilter.SelectedItem?.ToString() ?? "Todos os estados";
        var visible = _downloads
            .OrderByDescending(download => download.StartedAt)
            .Where(download => (state == "Todos os estados" || string.Equals(download.State, state, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrEmpty(query)
                    || Path.GetFileName(download.FilePath).Contains(query, StringComparison.OrdinalIgnoreCase)
                    || download.SourceUri.Contains(query, StringComparison.OrdinalIgnoreCase)))
            .ToList();

        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var download in visible)
        {
            var item = new ListViewItem(Path.GetFileName(download.FilePath));
            item.SubItems.Add(download.State);
            item.SubItems.Add(download.SecurityLevel);
            var progress = download.TotalBytesToReceive is ulong total && total > 0
                ? $"{download.ProgressText}  ·  {DownloadRecord.FormatBytes(download.BytesReceived)}/{DownloadRecord.FormatBytes(total)}"
                : download.ProgressText;
            item.SubItems.Add(progress);
            item.SubItems.Add(download.EstimatedEndTime?.ToString("HH:mm:ss") ?? "—");
            item.SubItems.Add(download.StartedAt.ToString("dd/MM HH:mm"));
            item.Tag = download;
            _list.Items.Add(item);
            if (selectedPath is not null && string.Equals(download.FilePath, selectedPath, StringComparison.OrdinalIgnoreCase))
                item.Selected = true;
        }
        _list.EndUpdate();

        var active = _downloads.Count(item => item.State == "Baixando");
        var paused = _downloads.Count(item => item.State == "Pausado");
        var completed = _downloads.Count(item => item.State == "Concluído");
        var totalBytes = _downloads.Aggregate(0UL, (total, item) => total + (ulong)Math.Max(0, item.BytesReceived));
        _summary.Text = $"{active} baixando  ·  {paused} pausado(s)  ·  {completed} concluído(s)  ·  {DownloadRecord.FormatBytes(totalBytes)} transferidos  ·  {_downloads.Count} no histórico";
        UpdateActionButtons();
    }

    private void DrawColumnHeader(object? sender, DrawListViewColumnHeaderEventArgs e)
    {
        using var background = new SolidBrush(Color.FromArgb(27, 36, 49));
        using var foreground = new SolidBrush(Color.FromArgb(145, 166, 187));
        e.Graphics.FillRectangle(background, e.Bounds);
        var headerText = e.Header?.Text ?? string.Empty;
        TextRenderer.DrawText(e.Graphics, headerText, _list.Font, e.Bounds, foreground.Color,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.LeftAndRightPadding);
    }

    private void DrawSubItem(object? sender, DrawListViewSubItemEventArgs e)
    {
        var selected = e.Item?.Selected ?? false;
        var back = selected ? Color.FromArgb(34, 63, 78) : Color.FromArgb(20, 27, 37);
        using var background = new SolidBrush(back);
        e.Graphics.FillRectangle(background, e.Bounds);
        var record = e.Item?.Tag as DownloadRecord;
        var subItemText = e.SubItem?.Text ?? string.Empty;
        if (e.ColumnIndex == 3 && record is not null)
        {
            var track = Rectangle.Inflate(e.Bounds, -8, -5);
            if (track.Width > 12 && track.Height > 4)
            {
                using var trackBrush = new SolidBrush(Color.FromArgb(44, 57, 72));
                e.Graphics.FillRectangle(trackBrush, track);
                var fillWidth = record.TotalBytesToReceive is > 0 ? (int)(track.Width * record.ProgressPercent / 100.0) : 0;
                if (fillWidth > 0)
                {
                    using var fillBrush = new SolidBrush(record.State == "Concluído" ? Color.FromArgb(65, 190, 135) : Color.FromArgb(55, 211, 235));
                    e.Graphics.FillRectangle(fillBrush, new Rectangle(track.X, track.Y, Math.Min(fillWidth, track.Width), track.Height));
                }
            }
            TextRenderer.DrawText(e.Graphics, subItemText, _list.Font, e.Bounds, Color.FromArgb(232, 240, 248),
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.LeftAndRightPadding);
            return;
        }
        if (e.ColumnIndex == 2 && record is not null)
        {
            var riskColor = record.SecurityLevel switch
            {
                "Crítico" => Color.FromArgb(255, 105, 105),
                "Alto" => Color.FromArgb(245, 166, 85),
                "Moderado" => Color.FromArgb(238, 201, 108),
                _ => Color.FromArgb(110, 205, 155)
            };
            TextRenderer.DrawText(e.Graphics, subItemText, _list.Font, e.Bounds, riskColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.LeftAndRightPadding);
            return;
        }
        var color = e.ColumnIndex == 1 ? record?.State switch
        {
            "Concluído" => Color.FromArgb(91, 220, 163),
            "Baixando" => Color.FromArgb(75, 205, 235),
            "Pausado" => Color.FromArgb(245, 196, 95),
            "Cancelado" => Color.FromArgb(155, 167, 181),
            _ => Color.FromArgb(224, 163, 110)
        } : Color.FromArgb(224, 233, 242);
        TextRenderer.DrawText(e.Graphics, subItemText, _list.Font, e.Bounds, color,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.LeftAndRightPadding);
    }

    private DownloadRecord? SelectedDownload => _list.SelectedItems.Count == 0
        ? null
        : _list.SelectedItems[0].Tag as DownloadRecord;

    private void UpdateActionButtons()
    {
        var selected = SelectedDownload;
        if (_pauseResumeButton is not null)
        {
            _pauseResumeButton.Text = selected?.State == "Pausado" || selected?.CanResume == true ? "Retomar" : "Pausar";
            _pauseResumeButton.Enabled = selected is not null &&
                (selected.CanPause || selected.CanResume);
        }
        if (_retryButton is not null)
            _retryButton.Enabled = selected is not null && selected.State is not ("Baixando" or "Pausado" or "Concluído");
    }

    private void TogglePauseResumeSelected()
    {
        var download = SelectedDownload;
        if (download?.Operation is null) return;
        try
        {
            if (download.CanPause)
            {
                download.WasPausedByUser = true;
                download.Operation.Pause();
                download.State = "Pausado";
            }
            else if (download.CanResume)
            {
                download.WasPausedByUser = false;
                download.Operation.Resume();
                download.State = "Baixando";
            }
            _persist();
            RefreshRows();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível alterar o download.\n\n" + ex.Message,
                "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void RetrySelected()
    {
        var download = SelectedDownload;
        if (download is null) return;
        if (!Uri.TryCreate(download.SourceUri, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
        {
            MessageBox.Show(this, "A origem deste download não permite uma nova tentativa automática.",
                "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        _retry(download);
    }

    private void ClearCompleted()
    {
        var completed = _downloads.Where(item => item.State is "Concluído" or "Cancelado" or "Interrompido" or "Interrompido (sessão anterior)").ToList();
        if (completed.Count == 0) return;
        foreach (var item in completed) _downloads.Remove(item);
        _persist();
        RefreshRows();
    }

    private async Task ComputeSelectedHashAsync()
    {
        var download = SelectedDownload;
        if (download is null || !File.Exists(download.FilePath) || download.State != "Concluído")
        {
            MessageBox.Show(this, "Selecione um download concluído que ainda exista no disco.", "SHA-256", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        try
        {
            _pauseResumeButton.Enabled = false;
            using var stream = new FileStream(download.FilePath, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024,
                FileOptions.Asynchronous | FileOptions.SequentialScan);
            var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream));
            var message = $"Arquivo: {Path.GetFileName(download.FilePath)}\nSHA-256: {hash}\n\nO hash permite comparar a integridade com um valor publicado por uma fonte confiável. Ele não verifica se o arquivo contém malware.";
            if (MessageBox.Show(this, message + "\n\nCopiar o hash?", "SHA-256 do download", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                Clipboard.SetText(hash);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível calcular o hash.\n\n" + ex.Message, "SHA-256", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally { UpdateActionButtons(); }
    }

    private void OpenSelected()
    {
        var download = SelectedDownload;
        if (download is null || !File.Exists(download.FilePath)) return;
        if (download.SecurityLevel is "Alto" or "Crítico")
        {
            var decision = MessageBox.Show(this,
                $"Este arquivo foi classificado com risco {download.SecurityLevel}.\n\n{download.SecurityReason}\n\nO RX Browser não substitui um antivírus. Deseja abrir mesmo assim?",
                "Confirmar abertura de arquivo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (decision != DialogResult.Yes) return;
        }
        try { Process.Start(new ProcessStartInfo(download.FilePath) { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void ShowSelected()
    {
        var download = SelectedDownload;
        if (download is null || !File.Exists(download.FilePath)) return;
        try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{download.FilePath}\"") { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void CancelSelected()
    {
        var download = SelectedDownload;
        if (download?.Operation is null || download.State is "Concluído" or "Interrompido" or "Interrompido (sessão anterior)" or "Cancelado") return;
        try
        {
            download.WasCancelledByUser = true;
            download.WasPausedByUser = false;
            download.Operation.Cancel();
            download.State = "Cancelado";
            _persist();
            RefreshRows();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void OpenFolder()
    {
        try
        {
            Directory.CreateDirectory(_downloadsFolder);
            Process.Start(new ProcessStartInfo(_downloadsFolder) { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
}
