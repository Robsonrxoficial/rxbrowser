﻿using Microsoft.Web.WebView2.Core;
using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Searchable visual tab manager with privacy and state filters.</summary>
internal sealed class TabManagerForm : Form
{
    private readonly List<BrowserTab> _tabs;
    private readonly BrowserTab? _active;
    private readonly Action<BrowserTab> _activate;
    private readonly Func<BrowserTab, Task> _close;
    private readonly FlowLayoutPanel _cards = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _filter = new();
    private readonly ComboBox _sort = new();
    private readonly Label _summary = new();
    private bool _building;

    public TabManagerForm(IReadOnlyList<BrowserTab> tabs, BrowserTab? active,
        Action<BrowserTab> activate, Func<BrowserTab, Task> close)
    {
        _tabs = tabs.ToList();
        _active = active;
        _activate = activate;
        _close = close;
        Text = "RX Tab Manager 2.0 — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1060, 720);
        MinimumSize = new Size(760, 520);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var header = new Panel { Dock = DockStyle.Top, Height = 66, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(20, 10, 18, 8) };
        header.Controls.Add(new Label
        {
            Text = "RX TAB MANAGER 2.0", Dock = DockStyle.Top, Height = 26,
            ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        });
        _summary.Dock = DockStyle.Bottom;
        _summary.Height = 20;
        _summary.ForeColor = Color.FromArgb(142, 158, 178);
        header.Controls.Add(_summary);
        Controls.Add(header);

        var filterBar = new TableLayoutPanel
        {
            Dock = DockStyle.Top, Height = 56, Padding = new Padding(14, 8, 14, 8),
            ColumnCount = 4, RowCount = 1, BackColor = Color.FromArgb(16, 22, 31)
        };
        filterBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        filterBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        filterBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
        filterBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 148));
        _search.Dock = DockStyle.Fill;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = Color.FromArgb(232, 240, 248);
        _search.Font = new Font("Segoe UI", 10F);
        _search.PlaceholderText = "Pesquisar título, endereço ou grupo…";
        _search.TextChanged += (_, _) => RefreshCards();
        ConfigureCombo(_filter, ["Todas", "Normais", "Privadas", "Fixadas", "Agrupadas", "Suspensas"]);
        ConfigureCombo(_sort, ["Atividade recente", "Título A–Z", "Grupo A–Z"]);
        _filter.SelectedIndexChanged += (_, _) => RefreshCards();
        _sort.SelectedIndexChanged += (_, _) => RefreshCards();
        var closeUnpinned = MakeButton("Fechar não fixadas", 142);
        closeUnpinned.Click += async (_, _) => await CloseUnpinnedAsync(closeUnpinned);
        filterBar.Controls.Add(_search, 0, 0);
        filterBar.Controls.Add(_filter, 1, 0);
        filterBar.Controls.Add(_sort, 2, 0);
        filterBar.Controls.Add(closeUnpinned, 3, 0);
        Controls.Add(filterBar);

        _cards.Dock = DockStyle.Fill;
        _cards.AutoScroll = true;
        _cards.WrapContents = true;
        _cards.FlowDirection = FlowDirection.LeftToRight;
        _cards.Padding = new Padding(16);
        _cards.BackColor = Color.FromArgb(12, 16, 23);
        Controls.Add(_cards);
        Shown += async (_, _) => await BuildCardsAsync();
    }

    private static void ConfigureCombo(ComboBox combo, IEnumerable<string> values)
    {
        combo.Dock = DockStyle.Fill;
        combo.DropDownStyle = ComboBoxStyle.DropDownList;
        combo.BackColor = Color.FromArgb(27, 36, 49);
        combo.ForeColor = Color.FromArgb(232, 240, 248);
        combo.FlatStyle = FlatStyle.Flat;
        combo.Items.AddRange(values.Cast<object>().ToArray());
        combo.SelectedIndex = 0;
    }

    private void RefreshCards()
    {
        if (IsDisposed || !IsHandleCreated || _building) return;
        _ = BuildCardsAsync();
    }

    private List<BrowserTab> GetVisibleTabs()
    {
        IEnumerable<BrowserTab> result = _tabs.Where(tab => !tab.View.IsDisposed);
        var query = _search.Text.Trim();
        if (query.Length > 0)
        {
            result = result.Where(tab => tab.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                (tab.View.Source?.ToString() ?? string.Empty).Contains(query, StringComparison.OrdinalIgnoreCase) ||
                (tab.GroupName ?? string.Empty).Contains(query, StringComparison.OrdinalIgnoreCase));
        }

        result = _filter.SelectedItem?.ToString() switch
        {
            "Normais" => result.Where(tab => !tab.IsPrivate),
            "Privadas" => result.Where(tab => tab.IsPrivate),
            "Fixadas" => result.Where(tab => tab.IsPinned),
            "Agrupadas" => result.Where(tab => !string.IsNullOrWhiteSpace(tab.GroupName)),
            "Suspensas" => result.Where(tab => tab.IsSuspended),
            _ => result
        };

        return (_sort.SelectedItem?.ToString() switch
        {
            "Título A–Z" => result.OrderBy(tab => tab.Title, StringComparer.CurrentCultureIgnoreCase),
            "Grupo A–Z" => result.OrderBy(tab => tab.GroupName ?? "~", StringComparer.CurrentCultureIgnoreCase).ThenBy(tab => tab.Title, StringComparer.CurrentCultureIgnoreCase),
            _ => result.OrderByDescending(tab => tab.LastActivatedUtc)
        }).ToList();
    }

    private async Task BuildCardsAsync()
    {
        if (IsDisposed || _building) return;
        _building = true;
        _cards.SuspendLayout();
        try
        {
            foreach (Control oldCard in _cards.Controls)
            {
                foreach (var picture in FindPictures(oldCard))
                {
                    var oldImage = picture.Image;
                    picture.Image = null;
                    oldImage?.Dispose();
                }
                oldCard.Dispose();
            }
            _cards.Controls.Clear();

            var visible = GetVisibleTabs();
            _summary.Text = $"{_tabs.Count} guia(s) abertas  •  {visible.Count} exibida(s)  •  {_tabs.Count(tab => tab.IsPrivate)} privada(s)  •  {_tabs.Count(tab => tab.IsPinned)} fixada(s)";
            foreach (var tab in visible)
            {
                if (IsDisposed) return;
                var card = new Panel
                {
                    Width = 310, Height = 252, Margin = new Padding(8), Padding = new Padding(10),
                    BackColor = ReferenceEquals(tab, _active) ? Color.FromArgb(30, 49, 63) : Color.FromArgb(20, 27, 37)
                };
                var preview = new PictureBox
                {
                    Dock = DockStyle.Top, Height = 132, BackColor = Color.FromArgb(27, 36, 49),
                    SizeMode = PictureBoxSizeMode.Zoom
                };
                var title = new Label
                {
                    Dock = DockStyle.Top, Height = 27,
                    Text = (tab.IsPrivate ? "◉ Privada · " : "") + (tab.IsPinned ? "◆ " : "") + (tab.IsPasswordProtected ? "🔒 " : "") + tab.Title,
                    ForeColor = Color.FromArgb(232, 240, 248), AutoEllipsis = true,
                    Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
                };
                var host = Uri.TryCreate(tab.View.Source?.ToString(), UriKind.Absolute, out var uri) ? uri.Host : "Página inicial";
                var state = new List<string> { host };
                if (!string.IsNullOrWhiteSpace(tab.GroupName)) state.Add("Grupo: " + tab.GroupName);
                if (tab.IsSuspended) state.Add("Suspensa");
                if (ReferenceEquals(tab, _active)) state.Add("Ativa");
                var details = new Label
                {
                    Dock = DockStyle.Top, Height = 24, Text = string.Join("  •  ", state),
                    ForeColor = Color.FromArgb(142, 158, 178), AutoEllipsis = true,
                    Font = new Font("Segoe UI", 7.5F), TextAlign = ContentAlignment.MiddleLeft
                };
                var actions = new FlowLayoutPanel
                {
                    Dock = DockStyle.Bottom, Height = 36, WrapContents = false,
                    FlowDirection = FlowDirection.RightToLeft, BackColor = card.BackColor
                };
                var close = MakeButton("Fechar", 72);
                close.Click += async (_, _) =>
                {
                    close.Enabled = false;
                    await _close(tab);
                    _tabs.Remove(tab);
                    if (!IsDisposed) await BuildCardsAsync();
                };
                var activate = MakeButton("Abrir guia", 92, true);
                activate.Click += (_, _) => { _activate(tab); Close(); };
                actions.Controls.Add(close);
                actions.Controls.Add(activate);
                card.Controls.Add(actions);
                card.Controls.Add(details);
                card.Controls.Add(title);
                card.Controls.Add(preview);
                _cards.Controls.Add(card);
                if (tab.IsPasswordProtected)
                {
                    preview.SizeMode = PictureBoxSizeMode.CenterImage;
                    var lockedLabel = new Label
                    {
                        Dock = DockStyle.Fill, Text = "🔒\nCONTEÚDO PROTEGIDO", TextAlign = ContentAlignment.MiddleCenter,
                        ForeColor = Color.FromArgb(35, 205, 230), BackColor = Color.FromArgb(27, 36, 49),
                        Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold)
                    };
                    preview.Controls.Add(lockedLabel);
                }
                else if (!tab.IsSuspended) _ = CapturePreviewAsync(tab, preview);
                else
                {
                    preview.SizeMode = PictureBoxSizeMode.CenterImage;
                    preview.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "GUIA SUSPENSA\nAbra para retomar", TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.FromArgb(142, 158, 178), BackColor = preview.BackColor });
                }
            }

            if (visible.Count == 0)
                _cards.Controls.Add(new Label
                {
                    AutoSize = false, Width = 700, Height = 80, Margin = new Padding(20),
                    Text = "Nenhuma guia corresponde à pesquisa ou ao filtro selecionado.",
                    ForeColor = Color.FromArgb(142, 158, 178), TextAlign = ContentAlignment.MiddleLeft
                });
        }
        finally
        {
            _cards.ResumeLayout();
            _building = false;
        }
    }

    private async Task CloseUnpinnedAsync(Button button)
    {
        var targets = _tabs.Where(tab => !tab.IsPinned).ToList();
        if (targets.Count == 0)
        {
            MessageBox.Show(this, "Não há guias não fixadas para fechar.", "RX Tab Manager", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var keepOne = !_tabs.Any(tab => tab.IsPinned) && targets.Count == _tabs.Count;
        if (keepOne)
        {
            var preserved = _active is not null && targets.Contains(_active) ? _active : targets[0];
            targets.Remove(preserved);
        }
        if (targets.Count == 0)
        {
            MessageBox.Show(this, "A única guia aberta será preservada para manter o navegador pronto para uso.", "RX Tab Manager", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var note = keepOne ? "Uma guia será preservada para manter o navegador aberto. " : string.Empty;
        var answer = MessageBox.Show(this,
            $"{note}Fechar {targets.Count} guia(s) não fixadas?\n\nIsso inclui guias privadas. As guias fixadas serão preservadas.",
            "Fechar guias não fixadas", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes) return;
        button.Enabled = false;
        foreach (var tab in targets)
        {
            if (IsDisposed) return;
            await _close(tab);
            _tabs.Remove(tab);
        }
        if (!IsDisposed) await BuildCardsAsync();
        if (!button.IsDisposed) button.Enabled = true;
    }

    private static IEnumerable<PictureBox> FindPictures(Control parent)
    {
        foreach (Control child in parent.Controls)
        {
            if (child is PictureBox picture) yield return picture;
            foreach (var nested in FindPictures(child)) yield return nested;
        }
    }

    private static Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 30, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(35, 205, 230) : Color.FromArgb(205, 216, 229),
            Margin = new Padding(4, 2, 0, 0), Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private async Task CapturePreviewAsync(BrowserTab tab, PictureBox target)
    {
        try
        {
            var core = tab.View.CoreWebView2;
            if (core is null || target.IsDisposed) return;
            using var stream = new MemoryStream();
            await core.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Jpeg, stream);
            if (target.IsDisposed || IsDisposed || stream.Length == 0) return;
            stream.Position = 0;
            using var image = Image.FromStream(stream);
            var copy = new Bitmap(image);
            if (target.IsDisposed) { copy.Dispose(); return; }
            var old = target.Image;
            target.Image = copy;
            old?.Dispose();
        }
        catch
        {
            if (!target.IsDisposed)
            {
                target.SizeMode = PictureBoxSizeMode.CenterImage;
                target.BackColor = Color.FromArgb(27, 36, 49);
            }
        }
    }
}
