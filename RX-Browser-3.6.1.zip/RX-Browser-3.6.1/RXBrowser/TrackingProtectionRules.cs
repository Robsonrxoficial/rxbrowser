﻿namespace RXBrowser;

/// <summary>
/// Extra host-based anti-tracking rules complementing WebView2's built-in tracking prevention.
/// This is a curated list, not a complete filter-list engine and not a replacement for antivirus.
/// </summary>
internal static class TrackingProtectionRules
{
    private static readonly string[] BalancedDomains =
    [
        "google-analytics.com", "googletagmanager.com", "connect.facebook.net",
        "pixel.facebook.com", "analytics.tiktok.com", "bat.bing.com",
        "static.hotjar.com", "script.hotjar.com", "clarity.ms", "scorecardresearch.com",
        "segment.io", "api.segment.io", "mixpanel.com", "api.mixpanel.com",
        "amplitude.com", "api.amplitude.com", "nr-data.net", "newrelic.com",
        "demdex.net", "bluekai.com", "quantserve.com", "quantcount.com"
    ];

    private static readonly string[] StrictDomains =
    [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "amazon-adsystem.com", "adsrvr.org", "adroll.com", "criteo.com", "criteo.net",
        "taboola.com", "outbrain.com", "pubmatic.com", "openx.net", "rubiconproject.com",
        "adnxs.com", "sharethrough.com", "casalemedia.com", "33across.com", "advertising.com",
        "yieldmo.com", "lijit.com", "smartadserver.com", "teads.tv", "zemanta.com", "pippio.com",
        "rlcdn.com", "analytics.twitter.com", "ads-twitter.com", "tr.snapchat.com",
        "sc-static.net", "analytics.pinterest.com", "px.ads.linkedin.com", "snap.licdn.com",
        "hotjar.com", "clarity.ms", "mouseflow.com", "fullstory.com", "logrocket.io",
        "segment.com", "segment.io", "mixpanel.com", "amplitude.com", "heap.io", "kissmetrics.com"
    ];

    public static bool ShouldBlock(Uri requestUri, string pageHost, string level, IReadOnlyCollection<string> allowList)
    {
        if (level is not ("Balanced" or "Strict") || requestUri.Scheme is not ("http" or "https")) return false;
        var host = requestUri.Host.TrimEnd('.').ToLowerInvariant();
        var firstParty = (pageHost ?? string.Empty).TrimEnd('.').ToLowerInvariant();
        if (host.Length == 0 || host == firstParty || AdBlocker.HostMatches(host, firstParty) || AdBlocker.HostMatches(firstParty, host) ||
            allowList.Any(allowed => AdBlocker.HostMatches(firstParty, allowed))) return false;

        var domains = level == "Strict" ? StrictDomains : BalancedDomains;
        return domains.Any(domain => AdBlocker.HostMatches(host, domain));
    }
}
