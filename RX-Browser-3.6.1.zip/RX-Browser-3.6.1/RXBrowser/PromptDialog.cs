﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal static class PromptDialog
{
    public static string? Show(IWin32Window owner, string title, string prompt, string initialValue = "", bool multiline = false)
    {
        using var dialog = new Form
        {
            Text = title,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MinimizeBox = false,
            MaximizeBox = false,
            ShowInTaskbar = false,
            ClientSize = new Size(440, multiline ? 250 : 142),
            BackColor = Color.FromArgb(20, 27, 37),
            ForeColor = Color.FromArgb(232, 240, 248),
            Font = new Font("Segoe UI", 9F)
        };
        var label = new Label { Text = prompt, Left = 16, Top = 14, Width = 405, Height = 25, ForeColor = dialog.ForeColor };
        var input = new TextBox
        {
            Left = 16, Top = 43, Width = 405, Height = multiline ? 145 : 25, Text = initialValue,
            Multiline = multiline, AcceptsReturn = multiline, ScrollBars = multiline ? ScrollBars.Vertical : ScrollBars.None,
            BackColor = Color.FromArgb(27, 36, 49), ForeColor = dialog.ForeColor,
            BorderStyle = BorderStyle.FixedSingle
        };
        var ok = new Button { Text = "Salvar", Left = 250, Top = multiline ? 204 : 91, Width = 82, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Cancelar", Left = 339, Top = multiline ? 204 : 91, Width = 82, DialogResult = DialogResult.Cancel };
        foreach (var button in new[] { ok, cancel })
        {
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = Color.FromArgb(35, 53, 68);
            button.ForeColor = dialog.ForeColor;
        }
        dialog.Controls.AddRange(new Control[] { label, input, ok, cancel });
        dialog.AcceptButton = ok;
        dialog.CancelButton = cancel;
        dialog.Shown += (_, _) => { input.Focus(); input.SelectAll(); };
        return dialog.ShowDialog(owner) == DialogResult.OK ? input.Text.Trim() : null;
    }
}
