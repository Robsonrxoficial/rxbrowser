﻿using System.Drawing;
using System.Text.Json;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Manages named, local collections of tabs. Private/protected tabs are excluded by the caller.</summary>
internal sealed class WorkspaceManagerForm : Form
{
    private static readonly Color Bg = Color.FromArgb(12, 16, 23);
    private static readonly Color Panel = Color.FromArgb(20, 27, 37);
    private static readonly Color PanelAlt = Color.FromArgb(27, 36, 49);
    private static readonly Color Accent = Color.FromArgb(55, 211, 235);
    private readonly ListBox _items = new();
    private readonly TextBox _search = new();
    private readonly Label _details = new();
    private readonly List<WorkspaceRecord> _workspaces;
    private readonly Func<List<WorkspaceTabRecord>> _captureCurrent;
    private readonly Func<WorkspaceRecord, Task<bool>> _openWorkspace;

    public List<WorkspaceRecord> ResultWorkspaces => _workspaces;
    public string SyncFolder { get; private set; }

    public WorkspaceManagerForm(IEnumerable<WorkspaceRecord> workspaces,
        Func<List<WorkspaceTabRecord>> captureCurrent,
        Func<WorkspaceRecord, Task<bool>> openWorkspace, string syncFolder)
    {
        _workspaces = workspaces.Select(Clone).ToList();
        SyncFolder = syncFolder ?? string.Empty;
        _captureCurrent = captureCurrent;
        _openWorkspace = openWorkspace;

        Text = "Espaços de trabalho — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1030, 610);
        MinimumSize = new Size(900, 480);
        BackColor = Bg;
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Panel { Dock = DockStyle.Top, Height = 74, BackColor = Panel, Padding = new Padding(20, 12, 18, 8) };
        header.Controls.Add(new Label
        {
            Text = "ESPAÇOS DE TRABALHO RX", Dock = DockStyle.Top, Height = 30,
            ForeColor = Accent, Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold)
        });
        header.Controls.Add(new Label
        {
            Text = string.IsNullOrWhiteSpace(SyncFolder) ? "Salve conjuntos de guias. Use Pasta sync para sincronizar entre computadores." : $"Sincronização configurada: {Path.GetFileName(SyncFolder)}  •  use Pasta sync para alterar.", Dock = DockStyle.Bottom,
            Height = 22, ForeColor = Color.FromArgb(142, 158, 178)
        });
        Controls.Add(header);

        var searchPanel = new Panel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(18, 7, 18, 7), BackColor = Bg };
        _search.Dock = DockStyle.Fill;
        _search.PlaceholderText = "Pesquisar espaços de trabalho…";
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = PanelAlt;
        _search.ForeColor = ForeColor;
        _search.TextChanged += (_, _) => RenderList();
        searchPanel.Controls.Add(_search);
        Controls.Add(searchPanel);

        var body = new SplitContainer
        {
            Dock = DockStyle.Fill, SplitterDistance = 330, FixedPanel = FixedPanel.Panel2,
            BackColor = Bg, BorderStyle = BorderStyle.None, Panel1MinSize = 230, Panel2MinSize = 270
        };
        _items.Dock = DockStyle.Fill;
        _items.BorderStyle = BorderStyle.None;
        _items.BackColor = Panel;
        _items.ForeColor = ForeColor;
        _items.Font = new Font("Segoe UI", 10F);
        _items.IntegralHeight = false;
        _items.SelectedIndexChanged += (_, _) => RefreshDetails();
        _items.DoubleClick += async (_, _) => await OpenSelectedAsync();
        body.Panel1.Padding = new Padding(18, 2, 8, 12);
        body.Panel1.Controls.Add(_items);

        var detailPanel = new Panel { Dock = DockStyle.Fill, BackColor = Panel, Padding = new Padding(18) };
        var detailTitle = new Label { Text = "DETALHES", Dock = DockStyle.Top, Height = 32, ForeColor = Accent, Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold) };
        _details.Dock = DockStyle.Fill;
        _details.ForeColor = Color.FromArgb(205, 216, 229);
        _details.TextAlign = ContentAlignment.TopLeft;
        _details.Padding = new Padding(0, 8, 0, 0);
        _details.AutoEllipsis = true;
        detailPanel.Controls.Add(_details);
        detailPanel.Controls.Add(detailTitle);
        body.Panel2.Padding = new Padding(8, 2, 18, 12);
        body.Panel2.Controls.Add(detailPanel);
        Controls.Add(body);

        var footer = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 58, FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false, AutoScroll = true, Padding = new Padding(14, 9, 14, 8), BackColor = Panel
        };
        footer.Controls.Add(MakeButton("Salvar guias atuais", 132, true, (_, _) => SaveCurrent()));
        footer.Controls.Add(MakeButton("Abrir espaço", 104, true, async (_, _) => await OpenSelectedAsync()));
        footer.Controls.Add(MakeButton("Renomear", 88, false, (_, _) => RenameSelected()));
        footer.Controls.Add(MakeButton("Excluir", 76, false, (_, _) => DeleteSelected()));
        footer.Controls.Add(MakeButton("Importar", 82, false, (_, _) => ImportWorkspace()));
        footer.Controls.Add(MakeButton("Exportar", 82, false, (_, _) => ExportSelected()));
        footer.Controls.Add(MakeButton("Pasta sync", 94, false, (_, _) => ConfigureSyncFolder()));
        footer.Controls.Add(MakeButton("Desativar sync", 104, false, (_, _) => DisableSync()));
        var close = MakeButton("Fechar", 78, false, (_, _) => Close());
        footer.Controls.Add(close);
        Controls.Add(footer);

        RenderList();
        if (_items.Items.Count > 0) _items.SelectedIndex = 0;
        AcceptButton = null;
    }

    private void ConfigureSyncFolder()
    {
        using var picker = new FolderBrowserDialog
        {
            Description = "Escolha uma pasta compartilhada/sincronizada entre computadores. O RX Browser criará nela rx-browser-workspaces-devices.",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };
        if (!string.IsNullOrWhiteSpace(SyncFolder) && Directory.Exists(SyncFolder)) picker.SelectedPath = SyncFolder;
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        SyncFolder = picker.SelectedPath;
        MessageBox.Show(this, "A pasta foi selecionada. A sincronização dos espaços será executada ao fechar este painel e também quando ele for aberto novamente.",
            "Sincronização de espaços — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void DisableSync()
    {
        if (string.IsNullOrWhiteSpace(SyncFolder)) return;
        if (MessageBox.Show(this, "Desativar a sincronização automática de espaços neste computador? Os arquivos já enviados à pasta compartilhada não serão apagados.",
            "Desativar sincronização", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        SyncFolder = string.Empty;
        MessageBox.Show(this, "Sincronização desativada neste perfil. Os espaços salvos localmente serão mantidos.",
            "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private static Button MakeButton(string text, int width, bool accent, EventHandler click)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : PanelAlt,
            ForeColor = accent ? Accent : Color.FromArgb(205, 216, 229),
            Margin = new Padding(3, 0, 3, 0), Cursor = Cursors.Hand,
            Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold)
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += click;
        return button;
    }

    private WorkspaceRecord? Selected => _items.SelectedItem as WorkspaceRecord;

    private void RenderList()
    {
        var currentId = Selected?.Id;
        var query = _search.Text.Trim();
        var visible = _workspaces
            .Where(x => query.Length == 0 || x.Name.Contains(query, StringComparison.CurrentCultureIgnoreCase) ||
                x.Tabs.Any(tab => tab.Title.Contains(query, StringComparison.CurrentCultureIgnoreCase) || tab.Url.Contains(query, StringComparison.CurrentCultureIgnoreCase)))
            .OrderByDescending(x => x.UpdatedUtc)
            .ToList();
        _items.BeginUpdate();
        _items.Items.Clear();
        _items.DisplayMember = nameof(WorkspaceRecord.Name);
        foreach (var workspace in visible) _items.Items.Add(workspace);
        var index = currentId is null ? -1 : visible.FindIndex(x => x.Id == currentId);
        if (index >= 0) _items.SelectedIndex = index;
        else if (_items.Items.Count > 0) _items.SelectedIndex = 0;
        _items.EndUpdate();
        RefreshDetails();
    }

    private void RefreshDetails()
    {
        var item = Selected;
        if (item is null)
        {
            _details.Text = "Nenhum espaço selecionado.\n\nUse ‘Salvar guias atuais’ para criar seu primeiro espaço.";
            return;
        }
        var lines = item.Tabs.Select((tab, index) =>
            $"{index + 1:00}. {(tab.IsPinned ? "◆ " : "")}{(string.IsNullOrWhiteSpace(tab.GroupName) ? "" : "[" + tab.GroupName + "] ")}{tab.Title}\n    {tab.Url}");
        _details.Text = $"{item.Name}\n\n{item.Tabs.Count} guia(s)\nCriado: {item.CreatedUtc.ToLocalTime():dd/MM/yyyy HH:mm}\nAtualizado: {item.UpdatedUtc.ToLocalTime():dd/MM/yyyy HH:mm}\n\n" + string.Join("\n\n", lines);
    }

    private void SaveCurrent()
    {
        var tabs = _captureCurrent();
        if (tabs.Count == 0)
        {
            MessageBox.Show(this, "Não há guias normais com endereços HTTP ou HTTPS para salvar. Guias privadas e protegidas são excluídas.",
                "Espaços de trabalho — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (_workspaces.Count >= 30)
        {
            MessageBox.Show(this, "O limite local é de 30 espaços de trabalho. Exclua um espaço antigo antes de criar outro.",
                "Limite atingido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var name = PromptDialog.Show(this, "Novo espaço de trabalho", "Nome para este conjunto de guias:", "Meu projeto");
        if (string.IsNullOrWhiteSpace(name)) return;
        name = name.Trim();
        if (name.Length > 48) name = name[..48];
        _workspaces.Insert(0, new WorkspaceRecord { Name = name, Tabs = tabs, CreatedUtc = DateTime.UtcNow, UpdatedUtc = DateTime.UtcNow });
        RenderList();
        _items.SelectedIndex = 0;
    }

    private async Task OpenSelectedAsync()
    {
        var selected = Selected;
        if (selected is null) return;
        var opened = await _openWorkspace(Clone(selected));
        if (opened) Close();
    }

    private void RenameSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        var name = PromptDialog.Show(this, "Renomear espaço", "Novo nome:", selected.Name);
        if (string.IsNullOrWhiteSpace(name)) return;
        selected.Name = name.Trim()[..Math.Min(name.Trim().Length, 48)];
        selected.UpdatedUtc = DateTime.UtcNow;
        RenderList();
    }

    private void DeleteSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        if (MessageBox.Show(this, $"Excluir o espaço ‘{selected.Name}’? As guias salvas não serão fechadas.", "Excluir espaço",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        _workspaces.RemoveAll(x => x.Id == selected.Id);
        RenderList();
    }

    private void ExportSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        using var dialog = new SaveFileDialog { Filter = "Espaço RX (*.rxspace.json)|*.rxspace.json|JSON (*.json)|*.json", FileName = SafeFileName(selected.Name) + ".rxspace.json" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var json = JsonSerializer.Serialize(Clone(selected), new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(dialog.FileName, json);
            MessageBox.Show(this, "Espaço exportado. O arquivo contém somente nomes, títulos, endereços e organização das guias; não contém cookies, senhas ou dados de sessão.",
                "Exportação concluída", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Falha ao exportar", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void ImportWorkspace()
    {
        if (_workspaces.Count >= 30)
        {
            MessageBox.Show(this, "O limite local é de 30 espaços de trabalho.", "Limite atingido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new OpenFileDialog { Filter = "Espaços RX (*.rxspace.json;*.json)|*.rxspace.json;*.json|Todos os arquivos (*.*)|*.*" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var info = new FileInfo(dialog.FileName);
            if (info.Length > 1_000_000) throw new InvalidDataException("O arquivo selecionado é maior que 1 MB.");
            var imported = JsonSerializer.Deserialize<WorkspaceRecord>(File.ReadAllText(dialog.FileName));
            if (imported is null) throw new InvalidDataException("O arquivo não contém um espaço válido.");
            imported.Tabs = (imported.Tabs ?? new List<WorkspaceTabRecord>())
                .Where(tab => tab is not null && Uri.TryCreate(tab.Url, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https")
                .Take(20)
                .Select(tab => new WorkspaceTabRecord
                {
                    Title = string.IsNullOrWhiteSpace(tab.Title) ? "Nova guia" : tab.Title[..Math.Min(tab.Title.Length, 180)],
                    Url = tab.Url,
                    IsPinned = tab.IsPinned,
                    GroupName = string.IsNullOrWhiteSpace(tab.GroupName) ? null : tab.GroupName.Trim()[..Math.Min(tab.GroupName.Trim().Length, 32)]
                }).ToList();
            if (imported.Tabs.Count == 0) throw new InvalidDataException("O arquivo não contém nenhuma guia HTTP/HTTPS válida.");
            var name = string.IsNullOrWhiteSpace(imported.Name) ? "Espaço importado" : imported.Name.Trim();
            if (name.Length > 48) name = name[..48];
            if (_workspaces.Any(x => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase)))
                name = (name.Length > 36 ? name[..36] : name) + " (importado)";
            imported.Id = Guid.NewGuid().ToString("N");
            imported.Name = name;
            imported.CreatedUtc = DateTime.UtcNow;
            imported.UpdatedUtc = DateTime.UtcNow;
            _workspaces.Insert(0, imported);
            RenderList();
            _items.SelectedIndex = 0;
        }
        catch (Exception ex) { MessageBox.Show(this, "Não foi possível importar o espaço.\n\n" + ex.Message, "Importação inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private static WorkspaceRecord Clone(WorkspaceRecord item) => new()
    {
        Id = Guid.TryParseExact(item.Id, "N", out _) ? item.Id : Guid.NewGuid().ToString("N"),
        Name = item.Name,
        CreatedUtc = item.CreatedUtc,
        UpdatedUtc = item.UpdatedUtc,
        Tabs = (item.Tabs ?? new List<WorkspaceTabRecord>()).Select(tab => new WorkspaceTabRecord
        {
            Title = tab.Title,
            Url = tab.Url,
            IsPinned = tab.IsPinned,
            GroupName = tab.GroupName
        }).ToList()
    };

    private static string SafeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var safe = new string(value.Select(c => invalid.Contains(c) ? '_' : c).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(safe) ? "Espaco-RX" : safe;
    }
}
