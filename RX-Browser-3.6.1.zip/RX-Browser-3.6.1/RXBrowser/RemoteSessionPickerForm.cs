﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class RemoteSessionPickerForm : Form
{
    private readonly ListBox _sessions = new();
    public RemoteSessionSnapshot? SelectedSession => _sessions.SelectedItem as RemoteSessionSnapshot;

    public RemoteSessionPickerForm(IReadOnlyList<RemoteSessionSnapshot> sessions)
    {
        Text = "Sessões sincronizadas — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.Sizable;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(610, 390);
        MinimumSize = new Size(520, 310);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);
        Controls.Add(new Label
        {
            Text = "ESCOLHA UMA SESSÃO DE OUTRO DISPOSITIVO",
            Dock = DockStyle.Top, Height = 48, TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(16, 0, 0, 0), ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold)
        });
        _sessions.Dock = DockStyle.Fill;
        _sessions.BackColor = Color.FromArgb(20, 27, 37);
        _sessions.ForeColor = ForeColor;
        _sessions.BorderStyle = BorderStyle.None;
        foreach (var item in sessions) _sessions.Items.Add(item);
        if (_sessions.Items.Count > 0) _sessions.SelectedIndex = 0;
        _sessions.DoubleClick += (_, _) => AcceptSelection();
        Controls.Add(_sessions);
        var footer = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 56, FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(10), BackColor = Color.FromArgb(20, 27, 37), WrapContents = false
        };
        var cancel = new Button { Text = "Cancelar", Width = 90, Height = 32, DialogResult = DialogResult.Cancel };
        var open = new Button { Text = "Abrir sessão", Width = 112, Height = 32, BackColor = Color.FromArgb(22, 53, 66), ForeColor = Color.FromArgb(35, 205, 230), FlatStyle = FlatStyle.Flat };
        open.FlatAppearance.BorderSize = 0;
        open.Click += (_, _) => AcceptSelection();
        footer.Controls.Add(cancel);
        footer.Controls.Add(open);
        Controls.Add(footer);
        AcceptButton = open;
        CancelButton = cancel;
    }

    private void AcceptSelection()
    {
        if (SelectedSession is null) return;
        DialogResult = DialogResult.OK;
        Close();
    }
}
