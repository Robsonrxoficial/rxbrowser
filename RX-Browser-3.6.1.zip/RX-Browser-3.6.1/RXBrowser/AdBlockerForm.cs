﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class AdBlockerForm : Form
{
    private readonly CheckBox _enabled = new();
    private readonly ComboBox _level = new();
    private readonly ListBox _customDomains = new();
    private readonly List<string> _domains;

    public bool IsEnabled => _enabled.Checked;
    public string Level => (_level.SelectedItem as Choice)?.Value ?? "Balanced";
    public List<string> CustomDomains => _domains.ToList();

    public AdBlockerForm(bool enabled, string level, IEnumerable<string> customDomains)
    {
        _domains = customDomains.Select(AdBlocker.NormalizeDomain)
            .Where(AdBlocker.IsValidDomain).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

        Text = "Bloqueador de anúncios RX";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(640, 500);
        Size = new Size(760, 590);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Label
        {
            Text = "PROTEÇÃO CONTRA ANÚNCIOS E DOMÍNIOS INDESEJADOS",
            Dock = DockStyle.Top, Height = 48, Padding = new Padding(18, 13, 0, 0),
            ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 11.5F, FontStyle.Bold)
        };
        Controls.Add(header);

        var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18), BackColor = Color.FromArgb(15, 21, 30), AutoScroll = true };
        Controls.Add(body);

        _enabled.Text = "Ativar bloqueador RX";
        _enabled.Checked = enabled;
        _enabled.SetBounds(18, 17, 300, 26);
        _enabled.ForeColor = ForeColor;
        _enabled.BackColor = body.BackColor;
        body.Controls.Add(_enabled);

        body.Controls.Add(new Label { Text = "Intensidade dos filtros locais", Left = 18, Top = 58, Width = 360, Height = 22, ForeColor = ForeColor });
        _level.SetBounds(18, 83, 340, 32);
        _level.DropDownStyle = ComboBoxStyle.DropDownList;
        _level.BackColor = Color.FromArgb(27, 36, 49);
        _level.ForeColor = ForeColor;
        _level.Items.AddRange(new object[]
        {
            new Choice("Básica — bloqueia redes de anúncios conhecidas", "Basic"),
            new Choice("Equilibrada — recomendada para uso diário", "Balanced"),
            new Choice("Rigorosa — lista ampliada; pode quebrar sites", "Strict")
        });
        _level.SelectedIndex = level switch { "Basic" => 0, "Strict" => 2, _ => 1 };
        body.Controls.Add(_level);

        var count = new Label
        {
            Text = $"Lista local selecionada: {AdBlocker.BuiltInRuleCount(level)} domínios conhecidos. Não é compatível com todas as regras EasyList/uBlock.",
            Left = 18, Top = 127, Width = 690, Height = 38, ForeColor = Color.FromArgb(142, 158, 178)
        };
        body.Controls.Add(count);
        _level.SelectedIndexChanged += (_, _) =>
        {
            var selected = (_level.SelectedItem as Choice)?.Value ?? "Balanced";
            count.Text = $"Lista local selecionada: {AdBlocker.BuiltInRuleCount(selected)} domínios conhecidos. Não é compatível com todas as regras EasyList/uBlock.";
        };

        body.Controls.Add(new Label { Text = "Sua lista personalizada de domínios para bloquear", Left = 18, Top = 177, Width = 500, Height = 22, ForeColor = ForeColor });
        _customDomains.SetBounds(18, 205, 555, 190);
        _customDomains.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
        _customDomains.BackColor = Color.FromArgb(20, 27, 37);
        _customDomains.ForeColor = ForeColor;
        _customDomains.BorderStyle = BorderStyle.FixedSingle;
        body.Controls.Add(_customDomains);
        RefreshDomains();

        var add = MakeButton("Adicionar domínio", 132);
        add.SetBounds(585, 205, 132, 34);
        add.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        add.Click += (_, _) => AddDomain();
        body.Controls.Add(add);
        var remove = MakeButton("Remover", 132);
        remove.SetBounds(585, 246, 132, 34);
        remove.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        remove.Click += (_, _) => RemoveDomain();
        body.Controls.Add(remove);
        var import = MakeButton("Importar lista", 132);
        import.SetBounds(585, 287, 132, 34);
        import.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        import.Click += (_, _) => ImportDomainList();
        body.Controls.Add(import);
        var export = MakeButton("Exportar lista", 132);
        export.SetBounds(585, 328, 132, 34);
        export.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        export.Click += (_, _) => ExportDomainList();
        body.Controls.Add(export);

        var note = new Label
        {
            Text = "O RX bloqueia requisições de terceiros por domínio. Importe ou exporte listas simples (um domínio por linha; comentários com # e linhas ||dominio^ são aceitas). Não é um mecanismo completo EasyList/uBlock. Sites que dependem de serviços externos podem deixar de funcionar; use exceções por site e recarregue a página.",
            Left = 18, Top = 414, Width = 690, Height = 64, ForeColor = Color.FromArgb(142, 158, 178),
            Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
        };
        body.Controls.Add(note);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 58, Padding = new Padding(14, 10, 14, 10), BackColor = Color.FromArgb(18, 25, 35) };
        var cancel = MakeButton("Cancelar", 92);
        cancel.Dock = DockStyle.Right;
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 104, true);
        save.Dock = DockStyle.Right;
        save.Click += (_, _) => { DialogResult = DialogResult.OK; Close(); };
        footer.Controls.Add(cancel);
        footer.Controls.Add(save);
        Controls.Add(footer);
        CancelButton = cancel;
        AcceptButton = save;
    }

    private void AddDomain()
    {
        var raw = PromptDialog.Show(this, "Adicionar domínio", "Digite apenas o domínio, por exemplo: ads.exemplo.com");
        if (string.IsNullOrWhiteSpace(raw)) return;
        var domain = AdBlocker.NormalizeDomain(raw);
        if (!AdBlocker.IsValidDomain(domain))
        {
            MessageBox.Show(this, "Digite um domínio DNS válido, sem protocolo, caminho ou porta.", "Domínio inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (_domains.Contains(domain, StringComparer.OrdinalIgnoreCase)) return;
        if (_domains.Count >= 5000)
        {
            MessageBox.Show(this, "A lista personalizada já atingiu o limite de 5.000 domínios.", "Limite da lista", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        _domains.Add(domain);
        RefreshDomains();
    }

    private void RemoveDomain()
    {
        if (_customDomains.SelectedItem is not string selected) return;
        _domains.Remove(selected);
        RefreshDomains();
    }

    private void ImportDomainList()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Importar lista de bloqueio RX",
            Filter = "Listas de texto (*.txt;*.list;*.hosts)|*.txt;*.list;*.hosts|Todos os arquivos (*.*)|*.*",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            var imported = new HashSet<string>(_domains, StringComparer.OrdinalIgnoreCase);
            var invalid = 0;
            foreach (var rawLine in File.ReadLines(dialog.FileName).Take(20000))
            {
                var line = rawLine.Trim();
                if (line.Length == 0 || line.StartsWith('#') || line.StartsWith('!')) continue;
                // Accept plain host lines and the simple ||host^ notation only.
                if (line.StartsWith("||", StringComparison.Ordinal)) line = line[2..];
                if (line.EndsWith('^')) line = line[..^1];
                if (line.Contains('$') || line.Contains('*') || line.Contains('/') || line.Contains('^'))
                {
                    // A full filter-list rule is deliberately not interpreted as a domain.
                    invalid++;
                    continue;
                }
                var domain = AdBlocker.NormalizeDomain(line);
                if (AdBlocker.IsValidDomain(domain)) imported.Add(domain);
                else invalid++;
                if (imported.Count >= 5000) break;
            }

            var before = _domains.Count;
            _domains.Clear();
            _domains.AddRange(imported.OrderBy(value => value, StringComparer.OrdinalIgnoreCase).Take(5000));
            RefreshDomains();
            MessageBox.Show(this,
                $"Importação concluída. Novos domínios: {_domains.Count - before}. Total na lista: {_domains.Count}. Linhas ignoradas ou não reconhecidas: {invalid}.",
                "Lista RX importada", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível importar a lista.\n\n" + ex.Message, "Falha na importação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void ExportDomainList()
    {
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar lista de bloqueio RX",
            Filter = "Lista de domínios (*.txt)|*.txt",
            FileName = "rx-dominios-bloqueados.txt",
            AddExtension = true,
            DefaultExt = "txt"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var lines = new[] { "# RX Browser — lista personalizada de domínios", "# Um domínio por linha; não contém histórico de navegação." }
                .Concat(_domains.OrderBy(value => value, StringComparer.OrdinalIgnoreCase));
            File.WriteAllLines(dialog.FileName, lines);
            MessageBox.Show(this, $"Lista exportada com {_domains.Count} domínio(s).", "Exportação concluída", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível exportar a lista.\n\n" + ex.Message, "Falha na exportação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void RefreshDomains()
    {
        _customDomains.BeginUpdate();
        _customDomains.Items.Clear();
        foreach (var domain in _domains.OrderBy(value => value, StringComparer.OrdinalIgnoreCase))
            _customDomains.Items.Add(domain);
        _customDomains.EndUpdate();
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand, Margin = new Padding(5, 0, 0, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private sealed record Choice(string Label, string Value)
    {
        public override string ToString() => Label;
    }
}
