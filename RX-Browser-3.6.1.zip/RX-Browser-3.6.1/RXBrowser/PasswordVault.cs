﻿using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace RXBrowser;

/// <summary>
/// Cofre local por perfil. O conteúdo do arquivo é protegido pelo DPAPI do Windows
/// no escopo do usuário atual; não é sincronizado nem exportado em texto puro.
/// </summary>
internal static class PasswordVault
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("RXBrowser.PasswordVault.v1");
    private static string VaultFile => Path.Combine(BrowserStorage.ProfileRoot, "password-vault.dat");

    public static List<SavedCredential> Load()
    {
        Directory.CreateDirectory(BrowserStorage.ProfileRoot);
        if (!File.Exists(VaultFile)) return new List<SavedCredential>();

        var encrypted = File.ReadAllBytes(VaultFile);
        var plain = Unprotect(encrypted);
        try
        {
            var entries = JsonSerializer.Deserialize<List<SavedCredential>>(plain, JsonOptions) ?? new List<SavedCredential>();
            entries = entries.Where(x => x is not null).ToList();
            foreach (var entry in entries)
            {
                entry.Id ??= Guid.NewGuid().ToString("N");
                entry.Site ??= string.Empty;
                entry.Username ??= string.Empty;
                entry.Password ??= string.Empty;
                entry.Notes ??= string.Empty;
            }
            return entries
                .Where(x => x is not null && !string.IsNullOrWhiteSpace(x.Id) && !string.IsNullOrWhiteSpace(x.Site))
                .OrderBy(x => x.Site, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        finally
        {
            CryptographicOperations.ZeroMemory(plain);
            CryptographicOperations.ZeroMemory(encrypted);
        }
    }

    /// <summary>Retorna apenas credenciais que o usuário habilitou para preenchimento manual
    /// e cuja origem (esquema, host e porta) corresponde exatamente ao site atual.</summary>
    public static List<SavedCredential> FindForExactOrigin(string origin)
    {
        var normalized = NormalizeOrigin(origin);
        if (string.IsNullOrWhiteSpace(normalized)) return new List<SavedCredential>();
        return Load().Where(entry => entry.AutofillEnabled &&
            string.Equals(NormalizeOrigin(entry.Site), normalized, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public static (int Total, int AutofillEnabled) GetSummary()
    {
        try
        {
            var entries = Load();
            return (entries.Count, entries.Count(entry => entry.AutofillEnabled));
        }
        catch { return (0, 0); }
    }

    public static bool IsSecureHttpUrl(string? value, out Uri? uri)
    {
        uri = null;
        if (!Uri.TryCreate(value, UriKind.Absolute, out var parsed)) return false;
        if (parsed.Scheme.Equals(Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase))
        {
            uri = parsed;
            return true;
        }
        if (parsed.Scheme.Equals(Uri.UriSchemeHttp, StringComparison.OrdinalIgnoreCase) &&
            (parsed.IsLoopback || parsed.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase)))
        {
            uri = parsed;
            return true;
        }
        return false;
    }

    public static string NormalizeHost(string? site)
    {
        if (string.IsNullOrWhiteSpace(site)) return string.Empty;
        var candidate = site.Trim();
        if (!candidate.Contains("://", StringComparison.Ordinal)) candidate = "https://" + candidate;
        if (!Uri.TryCreate(candidate, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp)) return string.Empty;
        return uri.IdnHost.TrimEnd('.').ToLowerInvariant();
    }

    public static string NormalizeOrigin(string? site)
    {
        if (string.IsNullOrWhiteSpace(site)) return string.Empty;
        var candidate = site.Trim();
        if (!candidate.Contains("://", StringComparison.Ordinal)) candidate = "https://" + candidate;
        if (!Uri.TryCreate(candidate, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp)) return string.Empty;
        return uri.GetLeftPart(UriPartial.Authority).TrimEnd('/').ToLowerInvariant();
    }

    public static bool MatchesExactOrigin(string? site, string? origin)
    {
        var siteOrigin = NormalizeOrigin(site);
        var targetOrigin = NormalizeOrigin(origin);
        return siteOrigin.Length > 0 && targetOrigin.Length > 0 &&
            string.Equals(siteOrigin, targetOrigin, StringComparison.OrdinalIgnoreCase);
    }

    public static void Save(List<SavedCredential> entries)
    {
        Directory.CreateDirectory(BrowserStorage.ProfileRoot);
        var plain = JsonSerializer.SerializeToUtf8Bytes(entries, JsonOptions);
        byte[]? encrypted = null;
        var temporary = VaultFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            encrypted = Protect(plain);
            File.WriteAllBytes(temporary, encrypted);
            File.Move(temporary, VaultFile, true);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(plain);
            if (encrypted is not null) CryptographicOperations.ZeroMemory(encrypted);
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
        }
    }

    private static byte[] Protect(byte[] input) => Transform(input, protect: true);
    private static byte[] Unprotect(byte[] input) => Transform(input, protect: false);

    private static byte[] Transform(byte[] input, bool protect)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("O cofre local usa a proteção DPAPI do Windows.");

        var inputBlob = BlobFromBytes(input);
        var entropyBlob = BlobFromBytes(Entropy);
        DataBlob outputBlob = default;
        try
        {
            var ok = protect
                ? CryptProtectData(ref inputBlob, "RX Browser Password Vault", ref entropyBlob,
                    IntPtr.Zero, IntPtr.Zero, CryptProtectUiForbidden, out outputBlob)
                : CryptUnprotectData(ref inputBlob, IntPtr.Zero, ref entropyBlob,
                    IntPtr.Zero, IntPtr.Zero, CryptProtectUiForbidden, out outputBlob);

            if (!ok) throw new Win32Exception(Marshal.GetLastWin32Error(), "O Windows não conseguiu proteger ou abrir o cofre de senhas.");
            var result = new byte[outputBlob.cbData];
            if (result.Length > 0) Marshal.Copy(outputBlob.pbData, result, 0, result.Length);
            return result;
        }
        finally
        {
            FreeBlob(ref inputBlob);
            FreeBlob(ref entropyBlob);
            if (outputBlob.pbData != IntPtr.Zero)
            {
                // O buffer de saída contém texto puro durante a descriptografia.
                if (!protect && outputBlob.cbData > 0)
                {
                    var zeros = new byte[outputBlob.cbData];
                    Marshal.Copy(zeros, 0, outputBlob.pbData, zeros.Length);
                }
                LocalFree(outputBlob.pbData);
            }
        }
    }

    private static DataBlob BlobFromBytes(byte[] bytes)
    {
        var ptr = Marshal.AllocHGlobal(Math.Max(1, bytes.Length));
        if (bytes.Length > 0) Marshal.Copy(bytes, 0, ptr, bytes.Length);
        return new DataBlob { cbData = bytes.Length, pbData = ptr };
    }

    private static void FreeBlob(ref DataBlob blob)
    {
        if (blob.pbData != IntPtr.Zero)
        {
            if (blob.cbData > 0)
            {
                var zeros = new byte[blob.cbData];
                Marshal.Copy(zeros, 0, blob.pbData, zeros.Length);
            }
            Marshal.FreeHGlobal(blob.pbData);
        }
        blob = default;
    }

    private const int CryptProtectUiForbidden = 0x1;

    [StructLayout(LayoutKind.Sequential)]
    private struct DataBlob
    {
        public int cbData;
        public IntPtr pbData;
    }

    [DllImport("Crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CryptProtectData(
        ref DataBlob pDataIn, string? description, ref DataBlob optionalEntropy,
        IntPtr reserved, IntPtr prompt, int flags, out DataBlob pDataOut);

    [DllImport("Crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CryptUnprotectData(
        ref DataBlob pDataIn, IntPtr description, ref DataBlob optionalEntropy,
        IntPtr reserved, IntPtr prompt, int flags, out DataBlob pDataOut);

    [DllImport("Kernel32.dll", SetLastError = true)]
    private static extern IntPtr LocalFree(IntPtr hMem);
}

internal sealed class SavedCredential
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Site { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    /// <summary>Opt-in individual para preenchimento manual, sempre por host exato.</summary>
    public bool AutofillEnabled { get; set; } = false;
}
