﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;

namespace RXBrowser;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        var profileArg = args.FirstOrDefault(a => a.StartsWith("--profile=", StringComparison.OrdinalIgnoreCase));
        var profileId = profileArg is null ? "default" : profileArg["--profile=".Length..];
        BrowserProfileStore.EnsureDefault();
        var selectedProfile = ProfileStore.IsValidId(profileId) ? ProfileStore.Find(profileId) : null;
        BrowserStorage.CurrentProfileId = selectedProfile?.Id ?? "default";
        BrowserDiagnosticsLog.Initialize(BrowserStorage.ProfileRoot);
        Application.ThreadException += (_, eventArgs) => BrowserDiagnosticsLog.Write("WinForms", eventArgs.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, eventArgs) =>
        {
            if (eventArgs.ExceptionObject is Exception exception)
                BrowserDiagnosticsLog.Write("AppDomain", exception);
        };
        TaskScheduler.UnobservedTaskException += (_, eventArgs) =>
        {
            BrowserDiagnosticsLog.Write("TaskScheduler", eventArgs.Exception);
            eventArgs.SetObserved();
        };
        Application.Run(new MainForm());
        Trace.Flush();
    }
}

internal static class BrowserProfileStore
{
    public static void EnsureDefault() => _ = ProfileStore.Load();
}
