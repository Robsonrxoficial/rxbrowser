﻿using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using System.Diagnostics;
using System.IO;
using System.Drawing;
using System.Text.Json;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class MainForm : Form
{
    private static Color CBackground = Color.FromArgb(12, 16, 23);
    private static Color CPanel = Color.FromArgb(20, 27, 37);
    private static Color CPanel2 = Color.FromArgb(27, 36, 49);
    private static Color CAccent = Color.FromArgb(35, 205, 230);
    private static Color CText = Color.FromArgb(232, 240, 248);
    private static Color CMuted = Color.FromArgb(142, 158, 178);

    // Runs before page scripts. Pages that already have a dark background are left untouched;
    // light pages get an algorithmic inversion with media restored to its original colors.
    private const string ForceDarkModeScript = """
        (() => {
          try {
            if (window.top !== window) return;
            const styleId = '__rx_browser_forced_dark_v1';
            const ensureStyle = () => {
              if (document.getElementById(styleId)) return;
              const host = document.head || document.documentElement;
              if (!host) return;
              const style = document.createElement('style');
              style.id = styleId;
              style.textContent = `
                :root { color-scheme: dark !important; }
                body.rx-force-dark-active {
                  filter: invert(1) hue-rotate(180deg) !important;
                  background-color: #fff !important;
                }
                body.rx-force-dark-active img,
                body.rx-force-dark-active video,
                body.rx-force-dark-active canvas,
                body.rx-force-dark-active svg,
                body.rx-force-dark-active input[type="image"] {
                  filter: invert(1) hue-rotate(180deg) !important;
                }
                body.rx-force-dark-active ::selection {
                  background: #276b91 !important;
                  color: #fff !important;
                }
              `;
              host.appendChild(style);
            };
            const readColor = (value) => {
              if (!value || value === 'transparent') return null;
              const parts = value.match(/[\d.]+/g);
              if (!parts || parts.length < 3) return null;
              const rgb = parts.slice(0, 3).map(Number);
              const alpha = parts.length >= 4 ? Number(parts[3]) : 1;
              if (alpha < 0.05) return null;
              return rgb;
            };
            let timer = 0;
            const update = () => {
              const body = document.body;
              if (!body) return;
              ensureStyle();
              let rgb = readColor(getComputedStyle(body).backgroundColor);
              if (!rgb) rgb = readColor(getComputedStyle(document.documentElement).backgroundColor);
              if (!rgb) rgb = [255, 255, 255];
              const luminance = (0.2126 * rgb[0]) + (0.7152 * rgb[1]) + (0.0722 * rgb[2]);
              const shouldInvert = luminance >= 158;
              body.classList.toggle('rx-force-dark-active', shouldInvert);
            };
            const schedule = () => {
              if (timer) clearTimeout(timer);
              timer = setTimeout(update, 140);
            };
            if (document.readyState === 'loading')
              document.addEventListener('DOMContentLoaded', schedule, { once: true });
            schedule();
            const observer = new MutationObserver(schedule);
            observer.observe(document, {
              subtree: true, childList: true, attributes: true,
              attributeFilter: ['style', 'class']
            });
            window.addEventListener('pageshow', schedule, { passive: true });
          } catch (_) { /* Dark mode must never prevent a page from loading. */ }
        })();
        """;

    private const string DisableForceDarkModeScript = """
        (() => {
          try {
            document.body?.classList.remove('rx-force-dark-active');
            document.getElementById('__rx_browser_forced_dark_v1')?.remove();
          } catch (_) { }
        })();
        """;

    // The in-page control invokes the standard HTML Picture-in-Picture API from a real
    // pointer click, preserving the transient user activation required by Chromium.
    private const string PictureInPictureScript = """
        (() => {
          try {
            if (window.__rxBrowserPipInstalled) return;
            window.__rxBrowserPipInstalled = true;
            let target = null;
            let hideTimer = 0;
            let button = null;
            const post = (state, detail = '') => {
              try { window.chrome?.webview?.postMessage({ action: 'rx-pip', state, detail }); } catch (_) { }
            };
            const ensureButton = () => {
              if (button && button.isConnected) return button;
              button = document.createElement('button');
              button.type = 'button';
              button.textContent = 'RX  PiP';
              button.setAttribute('aria-label', 'Abrir vídeo em janela flutuante RX');
              button.style.cssText = 'position:fixed;z-index:2147483647;display:none;padding:8px 12px;border:1px solid #45d8ed;border-radius:9px;background:#101a28;color:#e8f8fc;font:600 12px Segoe UI,Arial;box-shadow:0 5px 18px #0009;cursor:pointer;';
              button.addEventListener('pointerenter', () => { if (hideTimer) clearTimeout(hideTimer); });
              button.addEventListener('pointerleave', scheduleHide);
              button.addEventListener('click', async event => {
                event.preventDefault(); event.stopPropagation();
                const video = target;
                if (!video || !video.isConnected) return;
                try {
                  if (document.pictureInPictureElement === video) await document.exitPictureInPicture();
                  else if (document.pictureInPictureEnabled && typeof video.requestPictureInPicture === 'function') await video.requestPictureInPicture();
                  else throw new Error('Este site ou vídeo não permite Picture-in-Picture.');
                } catch (error) { post('error', String(error?.message || error)); }
              });
              (document.body || document.documentElement).appendChild(button);
              return button;
            };
            const placeButton = video => {
              if (!video || !video.isConnected) return;
              target = video;
              const rect = video.getBoundingClientRect();
              const b = ensureButton();
              b.style.left = Math.max(6, Math.min(window.innerWidth - 100, rect.right - 96)) + 'px';
              b.style.top = Math.max(6, Math.min(window.innerHeight - 46, rect.top + 8)) + 'px';
              b.style.display = 'block';
              if (hideTimer) clearTimeout(hideTimer);
            };
            function scheduleHide() {
              if (hideTimer) clearTimeout(hideTimer);
              hideTimer = setTimeout(() => { if (button) button.style.display = 'none'; target = null; }, 650);
            }
            document.addEventListener('pointerover', event => {
              const video = event.target?.closest?.('video');
              if (video && !video.disablePictureInPicture) placeButton(video);
            }, true);
            document.addEventListener('pointermove', event => {
              const video = event.target?.closest?.('video');
              if (video && target === video && button?.style.display !== 'none') placeButton(video);
            }, true);
            document.addEventListener('pointerout', event => {
              if (target && (event.target === target || event.target?.closest?.('video') === target)) scheduleHide();
            }, true);
            document.addEventListener('enterpictureinpicture', () => post('started'), true);
            document.addEventListener('leavepictureinpicture', () => post('stopped'), true);
            window.addEventListener('scroll', () => { if (target && button?.style.display !== 'none') placeButton(target); }, true);
            window.addEventListener('resize', () => { if (target && button?.style.display !== 'none') placeButton(target); }, { passive: true });
          } catch (_) { /* PiP enhancement must never prevent page loading. */ }
        })();
        """;

    private readonly Stopwatch _startupStopwatch = Stopwatch.StartNew();
    private readonly List<BrowserTab> _tabs = new();
    private readonly List<DownloadRecord> _downloads = new();
    private readonly System.Windows.Forms.Timer _sessionSnapshotTimer = new() { Interval = 30000 };
    private readonly System.Windows.Forms.Timer _resourceSweepTimer = new() { Interval = 60000 };
    private readonly System.Windows.Forms.Timer _syncMaintenanceTimer = new() { Interval = 60000 };
    private bool _syncMaintenanceRunning;
    private readonly BrowserData _data = BrowserStorage.Load();
    private readonly FlowLayoutPanel _tabStrip = new();
    private readonly Panel _contentHost = new();
    private readonly Panel _sidebarPanel = new();
    private readonly FlowLayoutPanel _sidebarItems = new();
    private readonly ToolTip _tabToolTips = new();
    private int _blockedRequestsCount;
    private int _blockedAdRequestsCount;
    private readonly PrivacyActivityStore _privacyActivity = new();
    private int _blockedPopupsCount;
    private int _warnedDownloadsCount;
    private readonly TextBox _addressBox = new();
    private readonly Button _translateButton = new();
    private readonly HashSet<string> _approvedRiskyUrls = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, (int Failures, DateTime LockoutUntil)> _tabPinAttempts = new(StringComparer.OrdinalIgnoreCase);
    private bool _regionCaptureActive;
    private readonly Label _statusText = new();
    private readonly Panel _findPanel = new();
    private readonly TextBox _findBox = new();
    private readonly Label _findResult = new();
    private readonly Button _backButton;
    private readonly Button _forwardButton;
    private readonly Button _reloadButton;
    private readonly Button _homeButton;
    private readonly Button _goButton;
    private readonly Button _favoriteButton;
    private readonly Button _favoritesMenuButton;
    private readonly Button _historyButton;
    private readonly Button _downloadsButton;
    private readonly Button _moreButton;
    private readonly Button _securityButton;
    private readonly Button _tabManagerButton;
    private readonly Button _performanceButton;
    private CoreWebView2Environment? _environment;
    private CoreWebView2Environment? _privateEnvironment;
    private CoreWebView2Profile? _privateProfile;
    private string? _privateDataPath;
    private BrowserTab? _activeTab;
    private DownloadsForm? _downloadsForm;
    private bool _initializing;
    private bool _closing;
    private bool _preserveRestoredDataOnClose;
    private bool _resourceSweepRunning;
    private string? _sessionSyncPassphrase;
    private string? _lastSessionSyncFingerprint;
    private readonly IMessageFilter _browserShortcutFilter;
    private bool _fullscreen;
    private FormBorderStyle _borderBeforeFullscreen;
    private FormWindowState _stateBeforeFullscreen;
    private Rectangle _boundsBeforeFullscreen;

    public MainForm()
    {
        CAccent = _data.AccessibilityHighContrast ? Color.FromArgb(255, 230, 0) : AccentFromData(_data);
        SetInterfaceThemeColors(_data.InterfaceTheme, _data.AccessibilityHighContrast);
        var activeProfile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        LoadPersistedDownloads();
        Text = $"{_data.ProfileBadge} RX Browser 3.6.0" + (activeProfile is null || activeProfile.Id == "default" ? string.Empty : " — " + activeProfile.Name);
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1440, 900);
        MinimumSize = new Size(960, 620);
        BackColor = CBackground;
        ForeColor = CText;
        Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
        KeyPreview = true;
        // WebView2 1.0.4314.35 does not expose AcceleratorKeyPressed on its WinForms control.
        // A WinForms message filter catches browser accelerators before they reach WebView2.
        _browserShortcutFilter = new BrowserShortcutMessageFilter(this);
        Application.AddMessageFilter(_browserShortcutFilter);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = CBackground,
            ColumnCount = 1,
            RowCount = 4,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));
        Controls.Add(root);

        root.Controls.Add(BuildTabBar(), 0, 0);
        root.Controls.Add(BuildToolbar(out _backButton, out _forwardButton, out _reloadButton,
            out _homeButton, out _goButton, out _favoriteButton, out _favoritesMenuButton,
            out _historyButton, out _downloadsButton, out _moreButton, out _securityButton,
            out _tabManagerButton, out _performanceButton), 0, 1);

        var workArea = new Panel { Dock = DockStyle.Fill, BackColor = CBackground, Margin = Padding.Empty };
        _sidebarPanel.Dock = DockStyle.Left;
        _sidebarPanel.Width = Math.Clamp(_data.SidebarWidth, 180, 360);
        _sidebarPanel.Visible = _data.SidebarVisible;
        _sidebarPanel.BackColor = CPanel;
        _sidebarPanel.Padding = new Padding(0);
        _contentHost.Dock = DockStyle.Fill;
        _contentHost.BackColor = CBackground;
        _contentHost.Margin = Padding.Empty;
        workArea.Controls.Add(_contentHost);
        workArea.Controls.Add(_sidebarPanel);
        root.Controls.Add(workArea, 0, 2);
        BuildSidebar();
        BuildFindBar();

        var status = new Panel { Dock = DockStyle.Fill, BackColor = CPanel, Padding = new Padding(14, 0, 12, 0) };
        _statusText.Dock = DockStyle.Fill;
        _statusText.TextAlign = ContentAlignment.MiddleLeft;
        _statusText.ForeColor = CMuted;
        _statusText.Font = new Font("Segoe UI", 8.5F);
        _statusText.Text = "RX Browser 3.6.0  •  pronto";
        status.Controls.Add(_statusText);
        root.Controls.Add(status, 0, 3);

        _addressBox.KeyDown += AddressBox_KeyDown;
        _addressBox.Enter += (_, _) => _addressBox.SelectAll();
        _goButton.Click += (_, _) => NavigateFromAddress();
        _translateButton.Click += (_, _) => ShowTranslateTargetMenu(_translateButton);
        _backButton.Click += (_, _) => { if (_activeTab?.View.CoreWebView2?.CanGoBack == true) _activeTab.View.CoreWebView2.GoBack(); };
        _forwardButton.Click += (_, _) => { if (_activeTab?.View.CoreWebView2?.CanGoForward == true) _activeTab.View.CoreWebView2.GoForward(); };
        _reloadButton.Click += (_, _) => _activeTab?.View.CoreWebView2?.Reload();
        _homeButton.Click += (_, _) => ShowHomePage(_activeTab);
        _favoriteButton.Click += (_, _) => ToggleCurrentFavorite();
        _favoritesMenuButton.Click += (_, _) => ShowFavoritesMenu(_favoritesMenuButton);
        _historyButton.Click += (_, _) => ShowHistoryMenu(_historyButton);
        _downloadsButton.Click += (_, _) => OpenDownloadsCenter();
        _moreButton.Click += (_, _) => ShowMoreMenu(_moreButton);
        _securityButton.Click += (_, _) => OpenSecurityCenter();
        _tabManagerButton.Click += (_, _) => OpenTabManager();
        _performanceButton.Click += (_, _) => OpenPerformancePanel();
        KeyDown += MainForm_KeyDown;
        Shown += MainForm_Shown;
        FormClosing += MainForm_FormClosing;
        SizeChanged += MainForm_SizeChanged;
        _sessionSnapshotTimer.Tick += (_, _) =>
        {
            SaveSessionSnapshot();
            PersistDownloadHistory(false);
            SyncSessionSnapshot(false);
        };
        _resourceSweepTimer.Tick += async (_, _) =>
        {
            if (!_closing && _data.EcoModeEnabled && _tabs.Count >= 3 && WindowState != FormWindowState.Minimized && _activeTab is not null)
                await SuspendInactiveTabsAsync(_activeTab);
        };
        _syncMaintenanceTimer.Tick += (_, _) => RunPeriodicSync();
        UiScaleManager.Apply(this, _data.UiScalePercent);
        UpdateNavigationButtons();
    }

    private async void MainForm_SizeChanged(object? sender, EventArgs e)
    {
        if (!_data.EcoModeEnabled || _tabs.Count == 0) return;
        if (WindowState == FormWindowState.Minimized)
        {
            foreach (var tab in _tabs.ToList())
            {
                try
                {
                    var core = tab.View.CoreWebView2;
                    if (core is not null && !tab.IsSuspended && !tab.IsPictureInPicture && !core.IsDocumentPlayingAudio)
                        tab.IsSuspended = await core.TrySuspendAsync();
                }
                catch { }
            }
        }
        else if (_activeTab is not null)
        {
            SelectTab(_activeTab);
        }
    }

    private Control BuildTabBar()
    {
        var bar = new Panel { Dock = DockStyle.Fill, BackColor = CPanel, Padding = new Padding(12, 5, 12, 4) };
        var brand = new Panel { Dock = DockStyle.Left, Width = 126, BackColor = CPanel };
        var rx = new Label
        {
            Text = "RX", Dock = DockStyle.Left, Width = 44, ForeColor = CAccent,
            Font = new Font("Segoe UI Black", 18F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
        };
        var name = new Label
        {
            Text = "BROWSER 3.6.0", Dock = DockStyle.Fill, ForeColor = CText,
            Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
        };
        brand.Controls.Add(name);
        brand.Controls.Add(rx);

        var newTab = MakeButton("+", "Nova guia (Ctrl+T)", 38, 34, accent: true);
        newTab.Dock = DockStyle.Right;
        newTab.Click += async (_, _) => await CreateTabAsync(null, true);

        _tabStrip.Dock = DockStyle.Fill;
        _tabStrip.WrapContents = false;
        _tabStrip.AutoScroll = true;
        _tabStrip.FlowDirection = FlowDirection.LeftToRight;
        _tabStrip.BackColor = CPanel;
        _tabStrip.Margin = Padding.Empty;
        _tabStrip.Padding = new Padding(10, 1, 8, 0);
        bar.Controls.Add(_tabStrip);
        bar.Controls.Add(newTab);
        bar.Controls.Add(brand);
        return bar;
    }

    private Control BuildToolbar(out Button back, out Button forward, out Button reload,
        out Button home, out Button go, out Button favorite, out Button favorites,
        out Button history, out Button downloads, out Button more, out Button security,
        out Button tabManager, out Button performance)
    {
        var bar = new Panel { Dock = DockStyle.Fill, BackColor = CBackground, Padding = new Padding(12, 9, 12, 8) };
        var left = new FlowLayoutPanel
        {
            Dock = DockStyle.Left, Width = 188, WrapContents = false,
            BackColor = CBackground, Margin = Padding.Empty, Padding = Padding.Empty
        };
        back = MakeButton("‹", "Voltar", 38, 38); back.Name = "rx-toolbar-back";
        forward = MakeButton("›", "Avançar", 38, 38); forward.Name = "rx-toolbar-forward";
        reload = MakeButton("⟳", "Recarregar", 38, 38); reload.Name = "rx-toolbar-reload";
        home = MakeButton("⌂", "Página inicial", 38, 38); home.Name = "rx-toolbar-home";
        left.Controls.AddRange(new Control[] { back, forward, reload, home });

        var right = new FlowLayoutPanel
        {
            Dock = DockStyle.Right, Width = 610, WrapContents = false,
            FlowDirection = FlowDirection.RightToLeft, BackColor = CBackground,
            Margin = Padding.Empty, Padding = Padding.Empty
        };
        more = MakeButton("•••", "Mais opções e configurações", 42, 38); more.Name = "rx-toolbar-more";
        security = MakeButton("Segurança", "Abrir a Central de Segurança e privacidade (Ctrl+Shift+S)", 82, 38, accent: true); security.Name = "rx-toolbar-security";
        tabManager = MakeButton("▦", "Gerenciador de guias com pré-visualização (Ctrl+Shift+A)", 38, 38); tabManager.Name = "rx-toolbar-tabs";
        performance = MakeButton("◴", "Painel de desempenho (Ctrl+Shift+Y)", 38, 38); performance.Name = "rx-toolbar-performance";
        downloads = MakeButton("↓", "Central de downloads (Ctrl+J)", 38, 38); downloads.Name = "rx-toolbar-downloads";
        history = MakeButton("Histórico", "Histórico de navegação (Ctrl+H)", 82, 38); history.Name = "rx-toolbar-history";
        favorites = MakeButton("Favoritos", "Abrir favoritos salvos", 86, 38); favorites.Name = "rx-toolbar-favorites";
        favorite = MakeButton("☆", "Adicionar ou remover favorito (Ctrl+D)", 38, 38, accent: true); favorite.Name = "rx-toolbar-favorite";
        var workspaces = MakeButton("Espaços", "Salvar e reabrir conjuntos de guias (Ctrl+Shift+W)", 82, 38); workspaces.Name = "rx-toolbar-workspaces";
        workspaces.Click += (_, _) => OpenWorkspaceManager();
        right.Controls.AddRange(new Control[] { more, security, performance, tabManager, downloads, history, favorites, favorite, workspaces });

        var addressPanel = new Panel
        {
            Dock = DockStyle.Fill, BackColor = CPanel2,
            Padding = new Padding(13, 0, 7, 0), Margin = new Padding(8, 0, 8, 0)
        };
        _addressBox.Dock = DockStyle.Fill;
        _addressBox.BorderStyle = BorderStyle.None;
        _addressBox.BackColor = CPanel2;
        _addressBox.ForeColor = CText;
        _addressBox.Font = new Font("Segoe UI", 10F);
        _addressBox.PlaceholderText = "Pesquisar na web ou digitar endereço";
        _addressBox.Margin = Padding.Empty;
        go = MakeButton("Ir", "Abrir endereço", 45, 34, accent: true);
        go.Dock = DockStyle.Right;
        go.Margin = new Padding(0, 2, 0, 2);
        _translateButton.Name = "rx-toolbar-translate";
        _translateButton.Text = "文";
        _translateButton.Width = 38;
        _translateButton.Height = 34;
        _translateButton.Dock = DockStyle.Right;
        _translateButton.Margin = new Padding(3, 2, 4, 2);
        _translateButton.FlatStyle = FlatStyle.Flat;
        _translateButton.FlatAppearance.BorderSize = 0;
        _translateButton.BackColor = Color.FromArgb(35, 69, 84);
        _translateButton.ForeColor = CText;
        _translateButton.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
        _translateButton.Cursor = Cursors.Hand;
        _translateButton.AccessibleName = "Traduzir página";
        _translateButton.AccessibleDescription = "Traduzir para " + TranslationLanguageName(_data.PreferredTranslationLanguage);
        _translateButton.TabStop = false;
        addressPanel.Controls.Add(_addressBox);
        addressPanel.Controls.Add(_translateButton);
        addressPanel.Controls.Add(go);
        bar.Controls.Add(addressPanel);
        bar.Controls.Add(left);
        bar.Controls.Add(right);
        ApplyToolbarVisibility(bar);
        return bar;
    }

    private void ApplyToolbarVisibility(Control parent)
    {
        var hidden = _data.ToolbarHiddenButtons.ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (Control child in parent.Controls)
        {
            if (child.Name.StartsWith("rx-toolbar-", StringComparison.OrdinalIgnoreCase))
            {
                var id = child.Name["rx-toolbar-".Length..];
                child.Visible = id == "more" || !hidden.Contains(id);
            }
            if (child.HasChildren) ApplyToolbarVisibility(child);
        }
    }

    private void OpenToolbarSettings()
    {
        using var form = new ToolbarSettingsForm(_data.ToolbarHiddenButtons);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.ToolbarHiddenButtons = form.HiddenIds;
        BrowserStorage.Save(_data);
        foreach (Control control in Controls) ApplyToolbarVisibility(control);
        SetStatus("Barra de ferramentas personalizada neste perfil.");
    }

    private void BuildSidebar()
    {
        var heading = new Panel { Dock = DockStyle.Top, Height = 48, BackColor = CPanel, Padding = new Padding(14, 7, 9, 5) };
        var title = new Label { Text = "BARRA LATERAL", Dock = DockStyle.Fill, ForeColor = CAccent, Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        var add = MakeButton("+", "Adicionar site à barra lateral", 34, 32, accent: true);
        add.Dock = DockStyle.Right;
        add.Click += (_, _) => AddCurrentPageToSidebar();
        heading.Controls.Add(title);
        heading.Controls.Add(add);
        _sidebarItems.Dock = DockStyle.Fill;
        _sidebarItems.FlowDirection = FlowDirection.TopDown;
        _sidebarItems.WrapContents = false;
        _sidebarItems.AutoScroll = true;
        _sidebarItems.Padding = new Padding(10, 8, 10, 10);
        _sidebarItems.BackColor = CPanel;
        _sidebarPanel.Controls.Add(_sidebarItems);
        _sidebarPanel.Controls.Add(heading);
        RefreshSidebar();
    }

    private void RefreshSidebar()
    {
        if (_sidebarItems.IsDisposed) return;
        _sidebarItems.SuspendLayout();
        foreach (Control child in _sidebarItems.Controls) child.Dispose();
        _sidebarItems.Controls.Clear();
        foreach (var link in _data.SidebarLinks)
        {
            var button = MakeButton("◈  " + link.Title, link.Url, 194, 38);
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.Margin = new Padding(0, 0, 0, 6);
            button.Click += async (_, _) => await NavigateOrNewTabAsync(link.Url);
            var menu = new WheelScrollableContextMenuStrip();
            menu.Items.Add("Abrir em nova guia", null, async (_, _) => await CreateTabAsync(link.Url, true));
            menu.Items.Add("Remover da barra lateral", null, (_, _) =>
            {
                _data.SidebarLinks.Remove(link);
                BrowserStorage.Save(_data);
                RefreshSidebar();
            });
            button.ContextMenuStrip = menu;
            _sidebarItems.Controls.Add(button);
        }
        if (_data.SidebarLinks.Count == 0)
            _sidebarItems.Controls.Add(new Label { Text = "Adicione seus sites favoritos aqui para acessá-los rapidamente.", AutoSize = false, Width = 192, Height = 74, ForeColor = CMuted, Padding = new Padding(8) });
        UiScaleManager.Apply(_sidebarPanel, _data.UiScalePercent);
        _sidebarItems.ResumeLayout();
    }

    private void AddCurrentPageToSidebar()
    {
        var url = _activeTab?.View.Source?.ToString();
        if (!IsHttpUrl(url))
        {
            SetStatus("Abra um site antes de adicioná-lo à barra lateral.");
            return;
        }
        var title = _activeTab?.View.CoreWebView2?.DocumentTitle;
        var name = PromptDialog.Show(this, "Adicionar à barra lateral", "Nome do atalho:", string.IsNullOrWhiteSpace(title) ? url! : title);
        if (string.IsNullOrWhiteSpace(name)) return;
        _data.SidebarLinks.RemoveAll(x => string.Equals(x.Url, url, StringComparison.OrdinalIgnoreCase));
        _data.SidebarLinks.Insert(0, new SidebarLink(name, url!));
        _sidebarPanel.Visible = true;
        _data.SidebarVisible = true;
        BrowserStorage.Save(_data);
        RefreshSidebar();
        SetStatus("Atalho adicionado à barra lateral.");
    }

    private void ToggleSidebar()
    {
        _sidebarPanel.Visible = !_sidebarPanel.Visible;
        _data.SidebarVisible = _sidebarPanel.Visible;
        BrowserStorage.Save(_data);
        SetStatus(_sidebarPanel.Visible ? "Barra lateral aberta." : "Barra lateral oculta.");
    }

    private ContextMenuStrip BuildTabContextMenu(BrowserTab tab)
    {
        var menu = new WheelScrollableContextMenuStrip();
        var pin = new ToolStripMenuItem(tab.IsPinned ? "Desafixar guia" : "Fixar guia");
        menu.Opening += (_, _) => pin.Text = tab.IsPinned ? "Desafixar guia" : "Fixar guia";
        pin.Click += (_, _) =>
        {
            tab.IsPinned = !tab.IsPinned;
            _tabs.Remove(tab);
            var firstUnpinned = _tabs.TakeWhile(existing => existing.IsPinned).Count();
            _tabs.Insert(firstUnpinned, tab);
            _tabStrip.Controls.SetChildIndex(tab.Header, firstUnpinned);
            pin.Text = tab.IsPinned ? "Desafixar guia" : "Fixar guia";
            ApplyTabHeaderStyle(tab);
        };
        menu.Items.Add(pin);
        menu.Items.Add("Duplicar guia", null, async (_, _) =>
        {
            var url = tab.View.Source?.ToString();
            await CreateTabAsync(IsHttpUrl(url) ? url : null, true, tab.IsPrivate);
        });
        menu.Items.Add("Agrupar guia…", null, (_, _) =>
        {
            var group = PromptDialog.Show(this, "Grupo de guias", "Nome do grupo:", tab.GroupName ?? "Trabalho");
            if (string.IsNullOrWhiteSpace(group)) return;
            tab.GroupName = group;
            ApplyTabHeaderStyle(tab);
        });
        menu.Items.Add("Remover do grupo", null, (_, _) => { tab.GroupName = null; ApplyTabHeaderStyle(tab); });
        var protectTab = new ToolStripMenuItem("Proteger guia com PIN…");
        protectTab.Click += (_, _) => ProtectTabWithPassword(tab);
        var removeProtection = new ToolStripMenuItem("Remover proteção da guia…");
        removeProtection.Click += (_, _) => RemoveTabProtection(tab);
        menu.Opening += (_, _) =>
        {
            protectTab.Visible = !tab.IsPrivate && !tab.IsPasswordProtected;
            removeProtection.Visible = !tab.IsPrivate && tab.IsPasswordProtected;
        };
        menu.Items.Add(protectTab);
        menu.Items.Add(removeProtection);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Fechar outras guias", null, async (_, _) => await CloseOtherTabsAsync(tab));
        menu.Items.Add("Fechar guias à direita", null, async (_, _) => await CloseTabsToRightAsync(tab));
        menu.Items.Add("Fechar guia", null, async (_, _) => await CloseTabAsync(tab));
        return menu;
    }

    private void ApplyTabHeaderStyle(BrowserTab tab)
    {
        var selected = ReferenceEquals(_activeTab, tab);
        var groupColor = tab.GroupName switch
        {
            null or "" => CPanel2,
            _ => GroupColor(tab.GroupName)
        };
        tab.Header.Width = tab.IsPinned ? 104 : (_data.CompactTabs ? 148 : 190);
        tab.Header.BackColor = selected ? Color.FromArgb(35, 53, 68) : groupColor;
        tab.CloseButton.BackColor = selected ? Color.FromArgb(35, 53, 68) : groupColor;
        tab.TitleLabel.ForeColor = selected ? CAccent : CText;
        tab.AccentLine.Visible = selected;
        tab.AccentLine.BackColor = CAccent;
        tab.TitleLabel.Text = (tab.IsPinned ? "◆ " : "") + (tab.IsPasswordProtected ? "🔒 " : "") + (string.IsNullOrWhiteSpace(tab.GroupName) ? tab.Title : "[" + tab.GroupName + "] " + tab.Title);
        _tabToolTips.SetToolTip(tab.TitleLabel, tab.Title + (tab.IsPasswordProtected ? " · Protegida por senha" : "") + (string.IsNullOrWhiteSpace(tab.GroupName) ? "" : " · Grupo: " + tab.GroupName));
    }

    private static Color GroupColor(string? group)
    {
        if (string.IsNullOrWhiteSpace(group)) return CPanel2;
        Color[] palette = [Color.FromArgb(45, 48, 78), Color.FromArgb(35, 63, 69), Color.FromArgb(70, 47, 58), Color.FromArgb(62, 57, 39), Color.FromArgb(45, 55, 76)];
        return palette[(int)((uint)group.GetHashCode() % (uint)palette.Length)];
    }

    private async Task CloseOtherTabsAsync(BrowserTab keep)
    {
        foreach (var tab in _tabs.Where(t => !ReferenceEquals(t, keep)).ToList()) await CloseTabAsync(tab);
        if (_tabs.Contains(keep)) SelectTab(keep);
    }

    private async Task CloseTabsToRightAsync(BrowserTab tab)
    {
        var index = _tabs.IndexOf(tab);
        if (index < 0) return;
        foreach (var item in _tabs.Skip(index + 1).ToList()) await CloseTabAsync(item);
        if (_tabs.Contains(tab)) SelectTab(tab);
    }

    private async Task ReopenClosedTabAsync()
    {
        var url = _data.ClosedTabUrls.FirstOrDefault();
        if (string.IsNullOrWhiteSpace(url)) { SetStatus("Não há guias fechadas recentemente."); return; }
        _data.ClosedTabUrls.RemoveAt(0);
        BrowserStorage.Save(_data);
        await CreateTabAsync(url, true);
    }

    private async Task ManageExtensionsAsync()
    {
        var profile = _tabs.FirstOrDefault(t => !t.IsPrivate)?.View.CoreWebView2?.Profile;
        if (profile is null)
        {
            MessageBox.Show(this, "Abra uma guia normal para gerenciar extensões.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var form = new ExtensionsForm(profile, _data);
        form.ShowDialog(this);
        if (form.ExtensionsChanged && MessageBox.Show(this,
            "As extensões foram alteradas. Deseja recarregar as páginas abertas para aplicar as alterações?",
            "Atualizar páginas", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
            foreach (var tab in _tabs.Where(t => !t.IsPrivate && t.View.CoreWebView2 is not null).ToList())
            {
                try { tab.View.CoreWebView2!.Reload(); } catch { }
            }
        }
    }

    private void ToggleAdBlockForCurrentSite()
    {
        var host = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var uri) ? uri.Host : null;
        if (string.IsNullOrWhiteSpace(host)) { SetStatus("Abra um site para configurar a exceção do bloqueador."); return; }
        var existing = _data.AdBlockAllowlist.FirstOrDefault(x => AdBlocker.HostMatches(host, x));
        if (existing is not null)
        {
            _data.AdBlockAllowlist.Remove(existing);
            SetStatus("Bloqueador reativado neste site.");
        }
        else
        {
            _data.AdBlockAllowlist.Add(host);
            SetStatus("Bloqueador desativado para " + host);
        }
        BrowserStorage.Save(_data);
    }

    private void ToggleTrackingProtectionForCurrentSite()
    {
        var host = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var uri) ? uri.Host : null;
        if (string.IsNullOrWhiteSpace(host)) { SetStatus("Abra um site para configurar uma exceção de rastreamento."); return; }
        var existing = _data.TrackingAllowlist.FirstOrDefault(x => AdBlocker.HostMatches(host, x));
        if (existing is not null)
        {
            _data.TrackingAllowlist.Remove(existing);
            SetStatus("Proteção extra contra rastreamento reativada neste site.");
        }
        else
        {
            _data.TrackingAllowlist.Add(host);
            SetStatus("Proteção extra contra rastreamento dispensada para " + host + ".");
        }
        BrowserStorage.Save(_data);
    }

    private void BuildFindBar()
    {
        _findPanel.Dock = DockStyle.Top;
        _findPanel.Height = 46;
        _findPanel.Visible = false;
        _findPanel.BackColor = CPanel;
        _findPanel.Padding = new Padding(12, 6, 12, 6);

        var label = new Label { Text = "LOCALIZAR", ForeColor = CMuted, Dock = DockStyle.Left, Width = 78, TextAlign = ContentAlignment.MiddleLeft };
        _findBox.Dock = DockStyle.Fill;
        _findBox.BackColor = CPanel2;
        _findBox.ForeColor = CText;
        _findBox.BorderStyle = BorderStyle.FixedSingle;
        _findBox.PlaceholderText = "Texto nesta página";
        _findBox.Margin = new Padding(0, 2, 0, 2);
        _findBox.KeyDown += async (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                await FindInPageAsync(e.Shift);
            }
            else if (e.KeyCode == Keys.Escape) HideFindBar();
        };
        _findResult.Dock = DockStyle.Right;
        _findResult.Width = 110;
        _findResult.ForeColor = CMuted;
        _findResult.TextAlign = ContentAlignment.MiddleCenter;
        var close = MakeButton("×", "Fechar localizar", 32, 30);
        close.Dock = DockStyle.Right;
        close.Click += (_, _) => HideFindBar();
        var next = MakeButton("↓", "Próxima ocorrência", 32, 30);
        next.Dock = DockStyle.Right;
        next.Click += async (_, _) => await FindInPageAsync(false);
        var previous = MakeButton("↑", "Ocorrência anterior", 32, 30);
        previous.Dock = DockStyle.Right;
        previous.Click += async (_, _) => await FindInPageAsync(true);
        _findPanel.Controls.Add(_findBox);
        _findPanel.Controls.Add(_findResult);
        _findPanel.Controls.Add(close);
        _findPanel.Controls.Add(next);
        _findPanel.Controls.Add(previous);
        _findPanel.Controls.Add(label);
        _contentHost.Controls.Add(_findPanel);
    }

    private static Button MakeButton(string text, string tooltip, int width, int height, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = height, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : CPanel,
            ForeColor = accent ? CAccent : CText,
            Font = new Font("Segoe UI Semibold", text.Length > 2 ? 8.5F : 15F, FontStyle.Bold),
            Cursor = Cursors.Hand, Margin = new Padding(2, 0, 2, 0), TabStop = false
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 54, 70);
        button.FlatAppearance.MouseDownBackColor = CAccent;
        var tips = new ToolTip();
        tips.SetToolTip(button, tooltip);
        return button;
    }

    private async void MainForm_Shown(object? sender, EventArgs e)
    {
        if (_initializing) return;
        _initializing = true;
        try
        {
            BrowserStorage.PrepareUserDataMigration();
            Directory.CreateDirectory(BrowserStorage.UserData);
            Directory.CreateDirectory(BrowserStorage.Downloads);
            var environmentOptions = new CoreWebView2EnvironmentOptions { AreBrowserExtensionsEnabled = true };
            _environment = await CoreWebView2Environment.CreateAsync(null, BrowserStorage.UserData, environmentOptions);
            if (!string.IsNullOrWhiteSpace(_data.FavoritesSyncFolder))
            {
                try
                {
                    var synced = BookmarkSync.Sync(_data);
                    BrowserStorage.Save(_data);
                    SetStatus($"Favoritos sincronizados: {synced}");
                }
                catch (Exception syncEx) { SetStatus("Sincronização de favoritos indisponível: " + syncEx.Message); }
            }
            if (!string.IsNullOrWhiteSpace(_data.WorkspaceSyncFolder) && Directory.Exists(_data.WorkspaceSyncFolder))
            {
                try
                {
                    var syncedWorkspaces = WorkspaceSyncStore.Sync(_data);
                    BrowserStorage.Save(_data);
                    SetStatus($"Espaços de trabalho sincronizados: {syncedWorkspaces}");
                }
                catch (Exception syncEx) { SetStatus("Sincronização de espaços indisponível: " + syncEx.Message); }
            }

            // Marca a sessão como aberta depois que o WebView2 inicializou. Se o processo
            // terminar sem FormClosing, a próxima inicialização oferecerá recuperação.
            var previousSessionWasInterrupted = !_data.LastShutdownClean;
            _data.LastShutdownClean = false;
            BrowserStorage.Save(_data);

            var restoreItems = _data.RestoreLastSession
                ? _data.LastSessionTabs.Where(item => IsHttpUrl(item.Url)).Take(20).ToList()
                : new List<SessionTabSnapshot>();
            if (restoreItems.Count == 0 && _data.RestoreLastSession)
            {
                restoreItems = _data.LastSessionUrls.Where(IsHttpUrl).Take(20)
                    .Select(url => new SessionTabSnapshot { Url = url, Title = "Guia restaurada" }).ToList();
            }

            var shouldRestore = _data.RestoreLastSession && restoreItems.Count > 0;
            if (shouldRestore && previousSessionWasInterrupted)
            {
                var answer = MessageBox.Show(this,
                    $"O RX Browser percebeu que a última sessão não foi encerrada normalmente.\n\n" +
                    $"Deseja recuperar as {restoreItems.Count} guia(s) da sessão anterior?",
                    "Recuperação de sessão — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button1);
                shouldRestore = answer == DialogResult.Yes;
            }

            if (shouldRestore)
            {
                // Abre primeiro uma guia utilizável e deixa as demais serem restauradas
                // em segundo plano, em sequência, para que a janela fique responsiva mais cedo.
                var preferredIndex = Math.Clamp(_data.LastActiveSessionTabIndex, 0, restoreItems.Count - 1);
                var firstIndex = preferredIndex;
                if (restoreItems.Count > 0 && _data.ProtectedTabs.Any(p =>
                    string.Equals(p.TabId, restoreItems[firstIndex].Id, StringComparison.OrdinalIgnoreCase)))
                {
                    var unlockedIndex = restoreItems.FindIndex(item => !_data.ProtectedTabs.Any(p =>
                        string.Equals(p.TabId, item.Id, StringComparison.OrdinalIgnoreCase)));
                    firstIndex = unlockedIndex;
                }

                if (firstIndex >= 0)
                {
                    var first = restoreItems[firstIndex];
                    var firstTab = await CreateTabAsync(first.Url, true, false, first.Id);
                    ApplyRestoredTabMetadata(firstTab, first);
                }
                else
                {
                    await CreateTabAsync(null, true);
                }

                _ = RestoreRemainingTabsAsync(restoreItems, firstIndex);
                SetStatus($"Sessão recuperada  •  carregando até {restoreItems.Count} guia(s) em segundo plano");
            }
            else
            {
                await CreateTabAsync(null, true);
                if (previousSessionWasInterrupted && restoreItems.Count > 0)
                    SetStatus("Sessão anterior não restaurada. Nova sessão iniciada.");
            }

            if (_data.SessionSyncEnabled && !string.IsNullOrWhiteSpace(_data.SessionSyncFolder) && Directory.Exists(_data.SessionSyncFolder))
            {
                var syncPassword = PasswordPromptDialog.Show(this, "Desbloquear sincronização RX",
                    "Digite a senha compartilhada usada nos outros computadores. Ela fica somente na memória enquanto o RX Browser estiver aberto.");
                if (!string.IsNullOrEmpty(syncPassword) && syncPassword.Length >= 10)
                {
                    _sessionSyncPassphrase = syncPassword;
                    try
                    {
                        var remoteSessions = SessionSyncStore.ReadOtherDevices(_data.SessionSyncFolder, _data.SessionSyncDeviceId, _sessionSyncPassphrase);
                        if (remoteSessions.Count > 0 && MessageBox.Show(this,
                            $"Foram encontradas {remoteSessions.Count} sessão(ões) de outros dispositivos. Deseja escolher uma agora?",
                            "Sincronização de sessões — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            await OpenRemoteSessionPickerAsync(remoteSessions);
                    }
                    catch (Exception syncEx)
                    {
                        _sessionSyncPassphrase = null;
                        SetStatus("Sincronização de sessões indisponível: " + syncEx.Message);
                    }
                }
            }
            _sessionSnapshotTimer.Start();
            _resourceSweepTimer.Start();
            if (_data.AutoSyncEnabled) PublishPreferencesNow(false);
            RefreshSyncMaintenanceTimer();
            _startupStopwatch.Stop();
            SetStatus(BrowserStorage.LastLoadRecoveredFromBackup
                ? $"Dados recuperados de {BrowserStorage.LastLoadRecoverySource}  •  RX Browser 3.6.0  •  {_startupStopwatch.ElapsedMilliseconds} ms"
                : $"RX Browser 3.6.0 pronto  •  interface iniciada em {_startupStopwatch.ElapsedMilliseconds} ms");
        }
        catch (Exception ex)
        {
            var answer = MessageBox.Show(
                "O RX Browser não conseguiu iniciar o WebView2.\n\n" +
                "Instale o Microsoft Edge WebView2 Runtime e abra o RX Browser novamente.\n\n" +
                "Detalhe: " + ex.Message + "\n\nAbrir a página oficial de instalação?",
                "Componente WebView2 não encontrado", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer == DialogResult.Yes)
                Process.Start(new ProcessStartInfo("https://developer.microsoft.com/microsoft-edge/webview2/") { UseShellExecute = true });
            Close();
        }
    }

    private async Task<BrowserTab> CreateTabAsync(string? address, bool select, bool privateMode = false, string? persistedTabId = null)
    {
        var environment = _environment ?? throw new InvalidOperationException("O motor WebView2 ainda não foi inicializado.");
        if (privateMode)
        {
            if (_privateEnvironment is null)
            {
                _privateDataPath = Path.Combine(Path.GetTempPath(), "RXBrowser-Private-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(_privateDataPath);
                var privateOptions = new CoreWebView2EnvironmentOptions { AreBrowserExtensionsEnabled = true };
                _privateEnvironment = await CoreWebView2Environment.CreateAsync(null, _privateDataPath, privateOptions);
            }
            environment = _privateEnvironment;
        }

        var view = new WebView2 { Dock = DockStyle.Fill, BackColor = CBackground, Visible = false };
        var header = new Panel
        {
            Width = 190, Height = 34, BackColor = CPanel2,
            Margin = new Padding(3, 1, 3, 1), Padding = new Padding(9, 0, 3, 0)
        };
        var title = new Label
        {
            Dock = DockStyle.Fill, Text = privateMode ? "Privado · Nova guia" : "Nova guia",
            ForeColor = CText, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true,
            Cursor = Cursors.Hand, Font = new Font("Segoe UI", 8.5F)
        };
        var close = new Button
        {
            Text = "×", Dock = DockStyle.Right, Width = 25, FlatStyle = FlatStyle.Flat,
            BackColor = CPanel2, ForeColor = CMuted, Font = new Font("Segoe UI", 11F),
            Cursor = Cursors.Hand, TabStop = false
        };
        close.FlatAppearance.BorderSize = 0;
        close.FlatAppearance.MouseOverBackColor = Color.FromArgb(130, 45, 55);
        header.Controls.Add(title);
        header.Controls.Add(close);
        var accentLine = new Panel { Dock = DockStyle.Bottom, Height = 2, BackColor = CAccent, Visible = false };
        header.Controls.Add(accentLine);
        UiScaleManager.Apply(header, _data.UiScalePercent);

        var safeTabId = Guid.TryParseExact(persistedTabId, "N", out _) ? persistedTabId! : Guid.NewGuid().ToString("N");
        var protection = privateMode ? null : _data.ProtectedTabs.FirstOrDefault(item => string.Equals(item.TabId, safeTabId, StringComparison.OrdinalIgnoreCase));
        var tab = new BrowserTab
        {
            Id = safeTabId, View = view, Header = header, TitleLabel = title, CloseButton = close,
            AccentLine = accentLine, IsPrivate = privateMode, LastActivatedUtc = DateTime.UtcNow,
            IsPasswordProtected = protection is not null, IsLocked = protection is not null
        };
        _tabs.Add(tab);
        _contentHost.Controls.Add(view);
        view.SendToBack();
        _tabStrip.Controls.Add(header);
        title.Click += (_, _) => SelectTab(tab);
        header.Click += (_, _) => SelectTab(tab);
        close.Click += async (_, _) => await CloseTabAsync(tab);
        var tabMenu = BuildTabContextMenu(tab);
        header.ContextMenuStrip = tabMenu;
        title.ContextMenuStrip = tabMenu;

        try
        {
            await view.EnsureCoreWebView2Async(environment);
            view.ZoomFactor = _data.ZoomPercent / 100d;
            if (tab.IsPrivate) _privateProfile ??= view.CoreWebView2.Profile;
            await ConfigureTabAsync(tab);
            if (select) SelectTab(tab);
            if (string.IsNullOrWhiteSpace(address)) ShowHomePage(tab);
            else view.CoreWebView2.Navigate(NormalizeAddress(address));
            return tab;
        }
        catch
        {
            _tabs.Remove(tab);
            _tabStrip.Controls.Remove(header);
            _contentHost.Controls.Remove(view);
            view.Dispose();
            header.Dispose();
            throw;
        }
    }

    private async Task ConfigureTabAsync(BrowserTab tab)
    {
        var core = tab.View.CoreWebView2;
        core.Settings.AreDefaultContextMenusEnabled = true;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = true;
        core.Settings.IsPasswordAutosaveEnabled = false;
        core.Settings.IsGeneralAutofillEnabled = false;
        core.Settings.IsSwipeNavigationEnabled = true;
        core.Settings.IsPinchZoomEnabled = true;
        core.Settings.IsBuiltInErrorPageEnabled = true;
        core.Settings.AreBrowserAcceleratorKeysEnabled = true;
        // The RX password vault is separate; avoid creating a second browser-managed vault.
        // Some WebView2 .NET projections omit IsPasswordAutofillEnabled even when the
        // underlying runtime supports it, so use reflection instead of a hard API dependency.
        try
        {
            var passwordAutofill = core.Settings.GetType().GetProperty("IsPasswordAutofillEnabled");
            if (passwordAutofill?.CanWrite == true && passwordAutofill.PropertyType == typeof(bool))
                passwordAutofill.SetValue(core.Settings, false);
        }
        catch { /* Password autosave and general autofill are already disabled above. */ }
        // SmartScreen reputation checks are provided by the installed Edge WebView2 Runtime.
        // RX does not inject host objects into arbitrary pages.
        core.Settings.IsReputationCheckingRequired = true;
        core.Settings.AreHostObjectsAllowed = false;
        await ApplyTrackingProtectionAsync(tab);
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        try { tab.PictureInPictureScriptId = await core.AddScriptToExecuteOnDocumentCreatedAsync(PictureInPictureScript); }
        catch { tab.PictureInPictureScriptId = null; }
        if (Math.Abs(_data.VideoPlaybackRate - 1.0) > 0.001)
        {
            try { await core.AddScriptToExecuteOnDocumentCreatedAsync(BuildMediaPlaybackRateScript(_data.VideoPlaybackRate)); }
            catch { /* A preferência não deve impedir a criação da guia. */ }
        }
        core.ProcessFailed += (_, e) =>
        {
            tab.HasCrashed = true;
            tab.LastProcessFailure = e.ProcessFailedKind.ToString();
            if (ReferenceEquals(_activeTab, tab))
                SetStatus($"Uma guia apresentou falha no processo WebView2 ({tab.LastProcessFailure}). Abra o Gerenciador de tarefas para recarregar ou fechar a guia.");
        };
        core.WebResourceRequested += (_, e) =>
        {
            if (_data.DoNotTrack)
            {
                try { e.Request.Headers.SetHeader("DNT", "1"); } catch { }
            }
            if (e.ResourceContext == CoreWebView2WebResourceContext.Document) return;
            if (!Uri.TryCreate(e.Request.Uri, UriKind.Absolute, out var requestUri)) return;
            var pageHost = !string.IsNullOrWhiteSpace(tab.CurrentTopLevelHost)
                ? tab.CurrentTopLevelHost!
                : Uri.TryCreate(tab.View.Source?.ToString(), UriKind.Absolute, out var pageUri) ? pageUri.Host : string.Empty;
            var isThirdParty = !string.IsNullOrWhiteSpace(pageHost) &&
                !AdBlocker.HostMatches(requestUri.Host, pageHost) && !AdBlocker.HostMatches(pageHost, requestUri.Host);
            if (isThirdParty) _privacyActivity.RecordExternalRequest(tab.IsPrivate);
            var blockedByAds = _data.AdBlockEnabled && AdBlocker.ShouldBlock(requestUri, pageHost, _data.AdBlockAllowlist, _data.AdBlockCustomDomains, _data.AdBlockLevel);
            var blockedByTracking = TrackingProtectionRules.ShouldBlock(requestUri, pageHost, _data.TrackingProtectionLevel, _data.TrackingAllowlist);
            if (!blockedByAds && !blockedByTracking) return;
            try
            {
                e.Response = core.Environment.CreateWebResourceResponse(Stream.Null, 204, "Blocked by RX Browser", "Content-Length: 0\r\n");
                _blockedRequestsCount++;
                if (blockedByAds) _blockedAdRequestsCount++;
                _privacyActivity.RecordBlocked(pageHost, requestUri.Host, e.ResourceContext.ToString(), blockedByAds, blockedByTracking, tab.IsPrivate);
                if (ReferenceEquals(_activeTab, tab) && _blockedRequestsCount % 8 == 0)
                    SetStatus($"Proteção RX ativa  •  {_blockedRequestsCount} requisições bloqueadas ({_blockedAdRequestsCount} anúncios) nesta sessão");
            }
            catch { /* Um bloqueio que falhar não deve interromper a página. */ }
        };

        core.NavigationStarting += (_, e) =>
        {
            if (!IsAllowedWebScheme(e.Uri))
            {
                e.Cancel = true;
                PromptExternalProtocol(e.Uri);
                return;
            }

            var warning = _data.PhishingProtectionEnabled
                ? UrlSafetyAssessment.GetWarning(e.Uri, _data.PhishingProtectionLevel, _data.PhishingAllowlist)
                : null;
            var safetyKey = NormalizeSafetyKey(e.Uri);
            if (warning is not null && !_approvedRiskyUrls.Remove(safetyKey))
            {
                e.Cancel = true;
                if (Uri.TryCreate(e.Uri, UriKind.Absolute, out var warningUri))
                    _privacyActivity.RecordPhishingWarning(warningUri.Host, tab.IsPrivate);
                var targetUrl = e.Uri;
                BeginInvoke(new Action(() =>
                {
                    if (_closing || IsDisposed) return;
                    var answer = MessageBox.Show(this,
                        warning + "\n\nO SmartScreen do Microsoft Defender continua habilitado, mas nenhum filtro garante detectar todos os sites maliciosos.\n\nDeseja continuar mesmo assim?",
                        "Verificação de endereço — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (answer == DialogResult.Yes && !_closing)
                    {
                        _approvedRiskyUrls.Add(NormalizeSafetyKey(targetUrl));
                        try { core.Navigate(targetUrl); } catch { }
                    }
                }));
                return;
            }

            tab.CurrentTopLevelHost = Uri.TryCreate(e.Uri, UriKind.Absolute, out var navigationUri) && navigationUri.Scheme is "http" or "https"
                ? navigationUri.Host : string.Empty;
            if (e.Uri != "about:blank") tab.IsHomePage = false;
            if (ReferenceEquals(_activeTab, tab)) SetStatus("Carregando página…");
        };
        core.SourceChanged += (_, _) =>
        {
            if (ReferenceEquals(_activeTab, tab) && !tab.IsHomePage) UpdateAddressFromTab(tab);
            if (ReferenceEquals(_activeTab, tab)) UpdateSecurityStatus(tab);
            UpdateNavigationButtons();
        };
        core.DocumentTitleChanged += (_, _) => UpdateTabTitle(tab);
        core.NavigationCompleted += (_, e) =>
        {
            if (e.IsSuccess)
            {
                tab.HasCrashed = false;
                tab.LastProcessFailure = null;
                var currentUrl = tab.View.Source?.ToString() ?? string.Empty;
                var isInternalHome = tab.IsHomePage || currentUrl == "about:blank";
                if (isInternalHome)
                {
                    tab.IsHomePage = true;
                    tab.Title = tab.IsPrivate ? "Privado · Nova guia" : "Nova guia";
                    ApplyTabHeaderStyle(tab);
                }
                else
                {
                    tab.IsHomePage = false;
                    UpdateTabTitle(tab);
                    SaveHistory(tab);
                }
                if (ReferenceEquals(_activeTab, tab))
                {
                    if (!isInternalHome) UpdateAddressFromTab(tab);
                    else _addressBox.Text = string.Empty;
                    UpdateSecurityStatus(tab);
                }
            }
            else if (ReferenceEquals(_activeTab, tab))
                SetStatus("Não foi possível concluir a navegação: " + e.WebErrorStatus);
            UpdateNavigationButtons();
        };
        core.NewWindowRequested += async (_, e) =>
        {
            var sourceHost = Uri.TryCreate(tab.View.Source?.ToString(), UriKind.Absolute, out var sourcePage)
                ? sourcePage.Host : string.Empty;
            var popupSiteAllowed = IsPopupHostAllowed(sourceHost);
            if (_data.BlockPopups && !e.IsUserInitiated && !popupSiteAllowed)
            {
                e.Handled = true;
                _blockedPopupsCount++;
                _privacyActivity.RecordPopup(sourceHost, tab.IsPrivate);
                if (ReferenceEquals(_activeTab, tab)) SetStatus($"Pop-up automático bloqueado  •  {_blockedPopupsCount} nesta sessão");
                return;
            }

            if (!IsAllowedWebScheme(e.Uri))
            {
                e.Handled = true;
                PromptExternalProtocol(e.Uri);
                return;
            }

            var deferral = e.GetDeferral();
            try
            {
                var newTab = await CreateTabAsync(null, true, tab.IsPrivate);
                e.NewWindow = newTab.View.CoreWebView2;
            }
            catch { e.Handled = true; }
            finally { deferral.Complete(); }
        };
        core.DownloadStarting += (_, e) => ConfigureDownload(e);
        core.PermissionRequested += (_, e) =>
        {
            var origin = GetPermissionOrigin(e.Uri);
            var permissionName = e.PermissionKind.ToString();
            var savedRule = tab.IsPrivate ? null : _data.SitePermissions.FirstOrDefault(rule =>
                string.Equals(rule.Origin, origin, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(rule.PermissionKind, permissionName, StringComparison.OrdinalIgnoreCase));

            bool allow;
            if (savedRule is not null)
            {
                allow = savedRule.Allowed;
            }
            else
            {
                var response = MessageBox.Show(this,
                    $"O site {origin} está solicitando a permissão: {permissionName}.\n\n" +
                    "Sua decisão será lembrada neste perfil do RX Browser. Você pode apagar permissões na Central de Segurança.",
                    "Permissão do site — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                allow = response == DialogResult.Yes;
                if (!tab.IsPrivate)
                {
                    _data.SitePermissions.RemoveAll(rule =>
                        string.Equals(rule.Origin, origin, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(rule.PermissionKind, permissionName, StringComparison.OrdinalIgnoreCase));
                    _data.SitePermissions.Add(new SitePermissionRule
                    {
                        Origin = origin,
                        PermissionKind = permissionName,
                        Allowed = allow,
                        UpdatedUtc = DateTime.UtcNow
                    });
                    BrowserStorage.Save(_data);
                }
            }
            e.State = allow ? CoreWebView2PermissionState.Allow : CoreWebView2PermissionState.Deny;
            // RX owns the decision store so it can be reviewed and cleared in the Security Center.
            e.SavesInProfile = false;
        };
        core.WebMessageReceived += (_, e) =>
        {
            try
            {
                using var json = JsonDocument.Parse(e.WebMessageAsJson);
                var root = json.RootElement;
                if (!root.TryGetProperty("action", out var actionElement)) return;
                var action = actionElement.GetString();
                if (action == "search" && tab.IsHomePage && root.TryGetProperty("query", out var query))
                {
                    var value = query.GetString();
                    if (!string.IsNullOrWhiteSpace(value)) core.Navigate(NormalizeAddress(value));
                }
                else if (action == "home-settings" && tab.IsHomePage && ReferenceEquals(_activeTab, tab))
                {
                    BeginInvoke(new Action(OpenHomePageSettings));
                }
                else if (action == "rx-region-capture")
                {
                    // A page can post WebView messages. Accept region data only while the
                    // user explicitly started capture and only from the active tab.
                    if (!_regionCaptureActive || !ReferenceEquals(_activeTab, tab)) return;
                    _regionCaptureActive = false;
                    if (root.TryGetProperty("cancelled", out var cancelled) && cancelled.ValueKind == JsonValueKind.True)
                    {
                        SetStatus("Captura de região cancelada.");
                    }
                    else if (root.TryGetProperty("x", out var xElement) && root.TryGetProperty("y", out var yElement) &&
                             root.TryGetProperty("width", out var widthElement) && root.TryGetProperty("height", out var heightElement))
                    {
                        var rect = new RectangleF((float)xElement.GetDouble(), (float)yElement.GetDouble(),
                            (float)widthElement.GetDouble(), (float)heightElement.GetDouble());
                        _ = CaptureRegionAsync(tab, rect);
                    }
                }
                else if (action == "rx-pip" && root.TryGetProperty("state", out var stateElement))
                {
                    var state = stateElement.GetString();
                    if (state == "started")
                    {
                        tab.IsPictureInPicture = true;
                        if (ReferenceEquals(_activeTab, tab)) SetStatus("Vídeo em janela flutuante Picture-in-Picture.");
                    }
                    else if (state == "stopped")
                    {
                        tab.IsPictureInPicture = false;
                        if (ReferenceEquals(_activeTab, tab)) SetStatus("Picture-in-Picture encerrado.");
                    }
                    else if (state == "error" && root.TryGetProperty("detail", out var detail) && ReferenceEquals(_activeTab, tab))
                        SetStatus("PiP indisponível: " + detail.GetString());
                }
            }
            catch { /* Mensagens inválidas não afetam a navegação. */ }
        };

        await ApplyForcedDarkModeToTabAsync(tab);
    }

    private async Task ApplyTrackingProtectionAsync(BrowserTab tab)
    {
        try
        {
            var core = tab.View.CoreWebView2;
            var level = _data.TrackingProtectionLevel switch
            {
                "Basic" => CoreWebView2TrackingPreventionLevel.Basic,
                "Strict" => CoreWebView2TrackingPreventionLevel.Strict,
                "Off" => CoreWebView2TrackingPreventionLevel.None,
                _ => CoreWebView2TrackingPreventionLevel.Balanced
            };
            core.Profile.PreferredTrackingPreventionLevel = level;

            if (!string.IsNullOrWhiteSpace(tab.DoNotTrackScriptId))
            {
                try { core.RemoveScriptToExecuteOnDocumentCreated(tab.DoNotTrackScriptId); } catch { }
                tab.DoNotTrackScriptId = null;
            }
            if (_data.DoNotTrack)
            {
                tab.DoNotTrackScriptId = await core.AddScriptToExecuteOnDocumentCreatedAsync(
                    "try { Object.defineProperty(Navigator.prototype, 'doNotTrack', { configurable: true, get: () => '1' }); } catch (_) {};");
            }
        }
        catch (Exception ex)
        {
            SetStatus("Proteção contra rastreamento não disponível neste runtime: " + ex.Message);
        }
    }

    private async Task SetTrackingProtectionLevelAsync(string level)
    {
        if (level is not ("Basic" or "Balanced" or "Strict" or "Off")) return;
        _data.TrackingProtectionLevel = level;
        BrowserStorage.Save(_data);
        foreach (var tab in _tabs) await ApplyTrackingProtectionAsync(tab);
        SetStatus("Proteção contra rastreamento: " + (level == "Off" ? "desativada" : level));
    }

    private void SyncFavoritesNow(bool showFeedback)
    {
        if (string.IsNullOrWhiteSpace(_data.FavoritesSyncFolder))
        {
            if (showFeedback) SetStatus("Configure primeiro uma pasta de sincronização de favoritos.");
            return;
        }
        try
        {
            var count = BookmarkSync.Sync(_data);
            BrowserStorage.Save(_data);
            RefreshFavoriteButton();
            if (showFeedback) SetStatus($"Sincronização concluída: {count} favorito(s).");
        }
        catch (Exception ex)
        {
            if (showFeedback) MessageBox.Show(this, "Não foi possível sincronizar favoritos. Verifique a pasta selecionada.\n\n" + ex.Message,
                "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenSyncCenter()
    {
        var currentFolder = !string.IsNullOrWhiteSpace(_data.FavoritesSyncFolder)
            ? _data.FavoritesSyncFolder : _data.PreferencesSyncFolder;
        using var form = new SyncCenterForm(currentFolder, _data.AutoSyncEnabled);
        if (form.ShowDialog(this) != DialogResult.OK) return;

        var folder = form.FolderPath;
        if (!string.IsNullOrWhiteSpace(folder))
        {
            try { Directory.CreateDirectory(folder); }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Não foi possível acessar a pasta escolhida.\n\n" + ex.Message,
                    "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        // The 2.3 sync center uses one selected folder for bookmarks and preferences.
        _data.FavoritesSyncFolder = folder;
        _data.PreferencesSyncFolder = folder;
        _data.AutoSyncEnabled = form.AutoSyncEnabled && !string.IsNullOrWhiteSpace(folder);
        BrowserStorage.Save(_data);
        RefreshSyncMaintenanceTimer();

        if (form.SyncNowRequested)
        {
            SyncFavoritesNow(true);
            PublishPreferencesNow(true);
        }
        if (form.ImportRequested) ImportPreferencesNow();
        SetStatus(_data.AutoSyncEnabled
            ? "Sincronização automática ativada para favoritos e publicação de preferências."
            : "Central de sincronização salva. A sincronização automática está desativada.");
    }

    private void RunPeriodicSync()
    {
        if (_closing || (!_data.AutoSyncEnabled && !_data.WorkspaceSyncEnabled && !_data.BackupSyncEnabled) || _syncMaintenanceRunning) return;
        _syncMaintenanceRunning = true;
        try
        {
            if (_data.AutoSyncEnabled)
            {
                if (!string.IsNullOrWhiteSpace(_data.FavoritesSyncFolder) && Directory.Exists(_data.FavoritesSyncFolder))
                {
                    BookmarkSync.Sync(_data);
                    BrowserStorage.Save(_data);
                    RefreshFavoriteButton();
                }
                if (!string.IsNullOrWhiteSpace(_data.PreferencesSyncFolder) && Directory.Exists(_data.PreferencesSyncFolder))
                    PublishPreferencesNow(false);
            }
            if (_data.WorkspaceSyncEnabled && !string.IsNullOrWhiteSpace(_data.WorkspaceSyncFolder) && Directory.Exists(_data.WorkspaceSyncFolder))
            {
                WorkspaceSyncStore.Sync(_data);
                BrowserStorage.Save(_data);
            }
            var syncProfileName = ProfileStore.Find(BrowserStorage.CurrentProfileId)?.Name ?? "Pessoal";
            if (_data.BackupSyncEnabled && BackupSyncStore.PublishIfDue(_data, syncProfileName))
                BrowserStorage.Save(_data);
        }
        catch (Exception ex)
        {
            SetStatus("Sincronização automática indisponível: " + ex.Message);
        }
        finally { _syncMaintenanceRunning = false; }
    }

    private void ConfigureFavoritesSync()
    {
        using var picker = new FolderBrowserDialog
        {
            Description = "Selecione uma pasta sincronizada entre seus dispositivos (por exemplo, OneDrive). O RX Browser guardará nela apenas os favoritos.",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };
        if (!string.IsNullOrWhiteSpace(_data.FavoritesSyncFolder) && Directory.Exists(_data.FavoritesSyncFolder))
            picker.SelectedPath = _data.FavoritesSyncFolder;
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        _data.FavoritesSyncFolder = picker.SelectedPath;
        BrowserStorage.Save(_data);
        SyncFavoritesNow(true);
    }

    private void ConfigurePreferencesSync()
    {
        using var picker = new FolderBrowserDialog
        {
            Description = "Selecione a pasta compartilhada entre seus dispositivos (por exemplo, uma pasta do OneDrive). Somente preferências não secretas serão gravadas em rx-browser-settings.",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };
        if (!string.IsNullOrWhiteSpace(_data.PreferencesSyncFolder) && Directory.Exists(_data.PreferencesSyncFolder))
            picker.SelectedPath = _data.PreferencesSyncFolder;
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        _data.PreferencesSyncFolder = picker.SelectedPath;
        BrowserStorage.Save(_data);
        PublishPreferencesNow(true);
    }

    private void PublishPreferencesNow(bool showFeedback)
    {
        if (string.IsNullOrWhiteSpace(_data.PreferencesSyncFolder))
        {
            if (showFeedback) SetStatus("Configure primeiro uma pasta de sincronização de preferências.");
            return;
        }
        try
        {
            var path = PreferencesSyncStore.Publish(_data, _data.PreferencesSyncFolder,
                _data.SessionSyncDeviceId, Environment.MachineName);
            if (showFeedback) SetStatus("Preferências enviadas para a pasta compartilhada: " + Path.GetFileName(path));
        }
        catch (Exception ex)
        {
            if (showFeedback) MessageBox.Show(this, "Não foi possível enviar as preferências. Verifique o acesso à pasta.\n\n" + ex.Message,
                "Sincronização de preferências", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async void ImportPreferencesNow()
    {
        if (string.IsNullOrWhiteSpace(_data.PreferencesSyncFolder))
        {
            SetStatus("Configure primeiro uma pasta de sincronização de preferências.");
            return;
        }
        try
        {
            var remote = PreferencesSyncStore.FindLatestOtherDevice(_data.PreferencesSyncFolder, _data.SessionSyncDeviceId);
            if (remote is null)
            {
                SetStatus("Nenhuma configuração de outro dispositivo foi encontrada.");
                return;
            }
            var updated = remote.UpdatedUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm");
            var decision = MessageBox.Show(this,
                $"Aplicar as preferências publicadas por '{remote.DeviceName}' em {updated}?\n\nIsso substituirá tema, busca, zoom, bloqueio de anúncios e opções de privacidade deste perfil. Senhas, cookies, histórico, extensões e sessões não serão alterados.",
                "Importar preferências RX", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (decision != DialogResult.Yes) return;

            var oldPalette = UiThemePalette.For(_currentInterfaceTheme, CAccent, _data.AccessibilityHighContrast);
            PreferencesSyncStore.Apply(_data, remote);
            CAccent = _data.AccessibilityHighContrast ? Color.FromArgb(255, 230, 0) : AccentFromData(_data);
            SetInterfaceThemeColors(_data.InterfaceTheme, _data.AccessibilityHighContrast);
            var newPalette = UiThemePalette.For(_data.InterfaceTheme, CAccent, _data.AccessibilityHighContrast);
            ApplyThemePaletteToControls(this, oldPalette, newPalette);
            UiScaleManager.Apply(this, _data.UiScalePercent);
            _sidebarPanel.Width = Math.Clamp(_data.SidebarWidth, 180, 360);
            _sidebarPanel.Visible = _data.SidebarVisible;
            SetZoom(_data.ZoomPercent);
            foreach (var tab in _tabs.ToList())
            {
                await ApplyTrackingProtectionAsync(tab);
                await ApplyForcedDarkModeToTabAsync(tab);
                ApplyTabHeaderStyle(tab);
            }
            if (_activeTab is not null && _data.EcoModeEnabled) await SuspendInactiveTabsAsync(_activeTab);
            if (_activeTab?.IsHomePage == true) ShowHomePage(_activeTab);
            BrowserStorage.Save(_data);
            var activeProfile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
            Text = $"{_data.ProfileBadge} RX Browser 3.6.0" + (activeProfile is null || activeProfile.Id == "default" ? string.Empty : " — " + activeProfile.Name);
            SetStatus("Preferências de " + remote.DeviceName + " aplicadas com sucesso.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível importar as preferências.\n\n" + ex.Message,
                "Sincronização de preferências", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void ProtectTabWithPassword(BrowserTab tab)
    {
        if (tab.IsPrivate || tab.IsPasswordProtected) return;
        var pin = PasswordPromptDialog.Show(this, "Proteger guia com PIN — RX Browser",
            "Crie um PIN numérico de 6 a 12 dígitos. Ele será armazenado somente como hash derivado.",
            "Confirme o PIN:", numericOnly: true);
        if (pin is null) return;
        var record = new TabProtectionRecord { TabId = tab.Id };
        try { TabProtection.SetPin(record, pin); }
        catch (ArgumentException ex)
        {
            MessageBox.Show(this, ex.Message, "PIN inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        _data.ProtectedTabs.RemoveAll(item => string.Equals(item.TabId, tab.Id, StringComparison.OrdinalIgnoreCase));
        _data.ProtectedTabs.Add(record);
        tab.IsPasswordProtected = true;
        tab.IsLocked = false;
        ApplyTabHeaderStyle(tab);
        BrowserStorage.Save(_data);
        SetStatus("Guia protegida por PIN. O PIN será solicitado quando você voltar a ela.");
    }

    private void RemoveTabProtection(BrowserTab tab)
    {
        if (!tab.IsPasswordProtected) return;
        var record = _data.ProtectedTabs.FirstOrDefault(item => string.Equals(item.TabId, tab.Id, StringComparison.OrdinalIgnoreCase));
        if (record is null) { tab.IsPasswordProtected = false; tab.IsLocked = false; return; }
        var isPin = string.Equals(record.CredentialKind, "PIN", StringComparison.OrdinalIgnoreCase);
        var password = PasswordPromptDialog.Show(this, "Remover proteção — RX Browser",
            isPin ? "Digite o PIN atual desta guia." : "Digite a senha atual desta guia.", numericOnly: isPin);
        if (password is null) return;
        if (!VerifyTabProtectionCredential(tab, record, password)) return;
        _data.ProtectedTabs.Remove(record);
        tab.IsPasswordProtected = false;
        tab.IsLocked = false;
        ApplyTabHeaderStyle(tab);
        BrowserStorage.Save(_data);
        SetStatus("Proteção removida desta guia.");
    }

    private bool VerifyTabProtectionCredential(BrowserTab tab, TabProtectionRecord record, string supplied)
    {
        var now = DateTime.UtcNow;
        if (_tabPinAttempts.TryGetValue(tab.Id, out var state) && state.LockoutUntil > now)
        {
            var seconds = Math.Max(1, (int)Math.Ceiling((state.LockoutUntil - now).TotalSeconds));
            MessageBox.Show(this, $"Muitas tentativas incorretas. Tente novamente em {seconds} segundo(s).",
                "Guia protegida — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        var isPin = string.Equals(record.CredentialKind, "PIN", StringComparison.OrdinalIgnoreCase);
        var valid = isPin ? TabProtection.VerifyPin(record, supplied) : TabProtection.Verify(record, supplied);
        if (valid)
        {
            _tabPinAttempts.Remove(tab.Id);
            return true;
        }

        var failures = state.LockoutUntil <= now ? state.Failures + 1 : 1;
        if (failures >= 5)
        {
            _tabPinAttempts[tab.Id] = (0, now.AddSeconds(30));
            MessageBox.Show(this, "Cinco tentativas incorretas. Esta guia ficará bloqueada por 30 segundos.",
                "Guia protegida — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        else
        {
            _tabPinAttempts[tab.Id] = (failures, DateTime.MinValue);
            MessageBox.Show(this, $"PIN ou senha incorreto(a). Restam {5 - failures} tentativa(s) antes de uma pausa de segurança.",
                "Guia protegida — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        return false;
    }

    private void ConfigureSessionSync()
    {
        using var picker = new FolderBrowserDialog
        {
            Description = "Escolha uma pasta compartilhada entre seus computadores (por exemplo, uma pasta do OneDrive). As sessões serão gravadas criptografadas com uma senha que você define.",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };
        if (!string.IsNullOrWhiteSpace(_data.SessionSyncFolder) && Directory.Exists(_data.SessionSyncFolder))
            picker.SelectedPath = _data.SessionSyncFolder;
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        var password = PasswordPromptDialog.Show(this, "Senha de sincronização RX",
            "Crie uma senha de pelo menos 10 caracteres. Use exatamente a mesma senha nos outros computadores.",
            "Confirme a senha:");
        if (password is null) return;
        if (password.Length < 10)
        {
            MessageBox.Show(this, "A senha de sincronização precisa ter pelo menos 10 caracteres.", "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        _data.SessionSyncFolder = picker.SelectedPath;
        _data.SessionSyncEnabled = true;
        if (!Guid.TryParseExact(_data.SessionSyncDeviceId, "N", out _)) _data.SessionSyncDeviceId = Guid.NewGuid().ToString("N");
        _sessionSyncPassphrase = password;
        BrowserStorage.Save(_data);
        SyncSessionSnapshot(true, forceWrite: true);
        OpenRemoteSessions();
    }

    private List<SessionTabSnapshot> BuildSessionSnapshots(bool excludeProtected)
    {
        var snapshots = new List<SessionTabSnapshot>();
        foreach (var tab in _tabs.Where(item => !item.IsPrivate))
        {
            if (snapshots.Count >= 20) break;
            if (excludeProtected && tab.IsPasswordProtected) continue;
            var url = tab.View.Source?.ToString() ?? string.Empty;
            if (!IsHttpUrl(url)) continue;
            snapshots.Add(new SessionTabSnapshot
            {
                Id = tab.Id,
                Url = url,
                Title = tab.Title,
                IsPinned = tab.IsPinned,
                GroupName = tab.GroupName
            });
        }
        return snapshots;
    }

    private int GetSessionActiveIndex(IReadOnlyList<SessionTabSnapshot> snapshots)
    {
        if (_activeTab is null || _activeTab.IsPrivate || _activeTab.IsPasswordProtected) return 0;
        // Match by tab identity rather than URL: two tabs may intentionally show the same page.
        var index = snapshots.ToList().FindIndex(item => string.Equals(item.Id, _activeTab.Id, StringComparison.OrdinalIgnoreCase));
        return Math.Max(0, index);
    }

    private void SyncSessionSnapshot(bool showFeedback, bool allowPrompt = false, bool forceWrite = false)
    {
        if (!_data.SessionSyncEnabled || string.IsNullOrWhiteSpace(_data.SessionSyncFolder))
        {
            if (showFeedback) SetStatus("Configure primeiro a sincronização de sessões.");
            return;
        }
        if (string.IsNullOrWhiteSpace(_sessionSyncPassphrase))
        {
            // The periodic timer and shutdown path must never surprise the user with a
            // password dialog. Only an explicit menu action may request the passphrase.
            if (!allowPrompt) return;
            var password = PasswordPromptDialog.Show(this, "Desbloquear sincronização RX",
                "Digite a senha compartilhada definida nos outros computadores.");
            if (password is null) return;
            try { _ = SessionSyncStore.ReadOtherDevices(_data.SessionSyncFolder, _data.SessionSyncDeviceId, password); }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Não foi possível validar a senha de sincronização. Nenhuma sessão foi sobrescrita.\n\n" + ex.Message,
                    "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _sessionSyncPassphrase = password;
        }
        try
        {
            var snapshots = BuildSessionSnapshots(excludeProtected: true);
            var activeIndex = GetSessionActiveIndex(snapshots);
            var fingerprintPayload = JsonSerializer.SerializeToUtf8Bytes(new { Tabs = snapshots, ActiveIndex = activeIndex });
            var fingerprint = Convert.ToHexString(SHA256.HashData(fingerprintPayload));
            CryptographicOperations.ZeroMemory(fingerprintPayload);
            if (!forceWrite && string.Equals(fingerprint, _lastSessionSyncFingerprint, StringComparison.Ordinal))
            {
                if (showFeedback) SetStatus("Sessão já está sincronizada; nenhuma alteração encontrada.");
                return;
            }
            SessionSyncStore.Save(_data.SessionSyncFolder, _data.SessionSyncDeviceId, Environment.MachineName,
                snapshots, activeIndex, _sessionSyncPassphrase);
            _lastSessionSyncFingerprint = fingerprint;
            if (showFeedback) SetStatus($"Sessão sincronizada com segurança: {snapshots.Count} guia(s) compartilhadas.");
        }
        catch (Exception ex)
        {
            if (showFeedback) MessageBox.Show(this, "Não foi possível sincronizar a sessão. Verifique a pasta e a senha de sincronização.\n\n" + ex.Message,
                "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async void OpenRemoteSessions()
    {
        if (!_data.SessionSyncEnabled || string.IsNullOrWhiteSpace(_data.SessionSyncFolder))
        {
            SetStatus("Configure primeiro a sincronização de sessões.");
            return;
        }
        if (string.IsNullOrWhiteSpace(_sessionSyncPassphrase))
        {
            var password = PasswordPromptDialog.Show(this, "Desbloquear sincronização RX",
                "Digite a senha compartilhada definida nos outros computadores.");
            if (password is null) return;
            _sessionSyncPassphrase = password;
        }
        try
        {
            var sessions = SessionSyncStore.ReadOtherDevices(_data.SessionSyncFolder, _data.SessionSyncDeviceId, _sessionSyncPassphrase);
            await OpenRemoteSessionPickerAsync(sessions);
        }
        catch (Exception ex)
        {
            _sessionSyncPassphrase = null;
            MessageBox.Show(this, "Não foi possível abrir as sessões compartilhadas. Confira a senha e a pasta.\n\n" + ex.Message,
                "Sincronização RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task OpenRemoteSessionPickerAsync(IReadOnlyList<RemoteSessionSnapshot> sessions)
    {
        if (sessions.Count == 0)
        {
            SetStatus("Nenhuma sessão de outro dispositivo foi encontrada.");
            return;
        }
        using var picker = new RemoteSessionPickerForm(sessions);
        if (picker.ShowDialog(this) != DialogResult.OK || picker.SelectedSession is null) return;
        await OpenRemoteSessionAsync(picker.SelectedSession);
    }

    private async Task OpenRemoteSessionAsync(RemoteSessionSnapshot remote)
    {
        var opened = new List<BrowserTab>();
        foreach (var item in remote.Tabs.Take(Math.Max(0, 20 - _tabs.Count)))
        {
            var tab = await CreateTabAsync(item.Url, false);
            tab.IsPinned = item.IsPinned;
            tab.GroupName = item.GroupName;
            if (!string.IsNullOrWhiteSpace(item.Title)) tab.Title = item.Title;
            ApplyTabHeaderStyle(tab);
            opened.Add(tab);
        }
        if (opened.Count > 0)
        {
            SelectTab(opened[Math.Clamp(remote.ActiveIndex, 0, opened.Count - 1)]);
            SetStatus($"Sessão de {remote.DeviceName} aberta: {opened.Count} guia(s). As guias atuais foram mantidas.");
        }
        else SetStatus("Não foi possível importar guias: limite de 20 guias atingido.");
    }

    private void SaveCurrentSessionAs()
    {
        var snapshots = BuildSessionSnapshots(excludeProtected: true);
        if (snapshots.Count == 0)
        {
            SetStatus("Não há guias HTTP/HTTPS abertas para salvar. Guias privadas e protegidas são excluídas.");
            return;
        }
        var name = PromptDialog.Show(this, "Salvar sessão RX", "Nome para esta sessão:", "Minha sessão");
        if (string.IsNullOrWhiteSpace(name)) return;
        name = name.Trim();
        if (name.Length > 48) name = name[..48];
        var record = new SavedSessionRecord
        {
            Name = name,
            SavedUtc = DateTime.UtcNow,
            ActiveIndex = GetSessionActiveIndex(snapshots),
            Tabs = snapshots.Select(item => new SessionTabSnapshot
            {
                Id = Guid.NewGuid().ToString("N"), Url = item.Url, Title = item.Title,
                IsPinned = item.IsPinned, GroupName = item.GroupName
            }).ToList()
        };
        _data.SavedSessions.Insert(0, record);
        _data.SavedSessions = _data.SavedSessions.OrderByDescending(item => item.SavedUtc).Take(50).ToList();
        BrowserStorage.Save(_data);
        SetStatus($"Sessão '{name}' salva localmente com {record.Tabs.Count} guia(s). Não inclui guias privadas, protegidas, cookies ou senhas.");
    }

    private async void ManageSavedSessions()
    {
        while (!_closing && !IsDisposed)
        {
            using var form = new SavedSessionsForm(_data.SavedSessions);
            if (form.ShowDialog(this) != DialogResult.OK || form.SelectedSession is null) return;
            var selected = _data.SavedSessions.FirstOrDefault(item => item.Id == form.SelectedSession.Id);
            if (selected is null) continue;
            switch (form.Action)
            {
                case SavedSessionAction.Open:
                    await OpenSavedSessionAsync(selected);
                    return;
                case SavedSessionAction.Rename:
                {
                    var newName = PromptDialog.Show(this, "Renomear sessão", "Novo nome:", selected.Name);
                    if (string.IsNullOrWhiteSpace(newName)) continue;
                    selected.Name = newName.Trim()[..Math.Min(newName.Trim().Length, 48)];
                    BrowserStorage.Save(_data);
                    break;
                }
                case SavedSessionAction.Delete:
                    if (MessageBox.Show(this, $"Excluir a sessão '{selected.Name}' salva neste perfil?", "Excluir sessão",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        _data.SavedSessions.RemoveAll(item => item.Id == selected.Id);
                        BrowserStorage.Save(_data);
                    }
                    break;
            }
        }
    }

    private async Task OpenSavedSessionAsync(SavedSessionRecord session)
    {
        var capacity = Math.Max(0, 20 - _tabs.Count);
        var items = session.Tabs.Where(item => IsHttpUrl(item.Url)).Take(capacity).ToList();
        if (items.Count == 0)
        {
            SetStatus("Não há espaço para abrir novas guias. Feche algumas guias e tente novamente.");
            return;
        }
        if (_tabs.Count > 0 && MessageBox.Show(this,
            $"Abrir '{session.Name}' com {items.Count} guia(s)? As guias atuais serão mantidas.",
            "Abrir sessão salva", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

        var opened = new List<BrowserTab>();
        try
        {
            foreach (var item in items)
            {
                var tab = await CreateTabAsync(item.Url, false);
                tab.IsPinned = item.IsPinned;
                tab.GroupName = item.GroupName;
                if (!string.IsNullOrWhiteSpace(item.Title)) tab.Title = item.Title;
                ApplyTabHeaderStyle(tab);
                opened.Add(tab);
            }
            if (opened.Count > 0)
            {
                SelectTab(opened[Math.Clamp(session.ActiveIndex, 0, opened.Count - 1)]);
                SetStatus($"Sessão '{session.Name}' aberta: {opened.Count} guia(s). As guias atuais foram mantidas.");
            }
        }
        catch (Exception ex)
        {
            if (opened.Count > 0) SelectTab(opened[0]);
            MessageBox.Show(this, "Não foi possível abrir todas as guias da sessão salva.\n\n" + ex.Message,
                "RX Browser — sessão salva", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenProfile(string profileId)
    {
        if (!ProfileStore.IsValidId(profileId) || ProfileStore.Find(profileId) is null) return;
        if (string.Equals(profileId, BrowserStorage.CurrentProfileId, StringComparison.OrdinalIgnoreCase)) return;
        try
        {
            var start = new ProcessStartInfo(Application.ExecutablePath)
            {
                UseShellExecute = true,
                WorkingDirectory = AppContext.BaseDirectory
            };
            start.Arguments = "--profile=" + profileId;
            Process.Start(start);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível abrir o perfil.\n\n" + ex.Message, "Perfis RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void CreateProfile()
    {
        var name = PromptDialog.Show(this, "Novo perfil", "Nome do novo perfil:", "Trabalho");
        if (string.IsNullOrWhiteSpace(name)) return;
        var profile = ProfileStore.Create(name);
        OpenProfile(profile.Id);
    }

    private void RenameCurrentProfile()
    {
        var profile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        if (profile is null) return;
        var name = PromptDialog.Show(this, "Renomear perfil", "Novo nome:", profile.Name);
        if (string.IsNullOrWhiteSpace(name)) return;
        ProfileStore.Rename(profile.Id, name);
        var updated = ProfileStore.Find(profile.Id);
        Text = $"{_data.ProfileBadge} RX Browser 3.6.0" + (updated is null || updated.Id == "default" ? string.Empty : " — " + updated.Name);
        SetStatus("Perfil renomeado.");
    }

    private async Task SuspendInactiveTabsAsync(BrowserTab active)
    {
        if (_resourceSweepRunning || _closing || _tabs.Count < 3 || WindowState == FormWindowState.Minimized) return;
        _resourceSweepRunning = true;
        try
        {
            var configuredDelay = Math.Clamp(_data.BackgroundTabSuspendDelaySeconds, 15, 300);
            var availableRamPercent = SystemMemoryStatus.AvailablePhysicalPercent;
            // Under memory pressure, shorten the idle grace period without changing the
            // WebView2 memory-target API. This app consistently uses TrySuspendAsync/Resume.
            var adaptiveDelay = availableRamPercent < 12 ? 15 : availableRamPercent < 22 ? Math.Min(configuredDelay, 30) : configuredDelay;
            var delay = TimeSpan.FromSeconds(adaptiveDelay);
            var now = DateTime.UtcNow;
            foreach (var tab in _tabs.Where(t => !ReferenceEquals(t, active)).ToList())
            {
                try
                {
                    var core = tab.View.CoreWebView2;
                    if (core is null || tab.View.Visible) continue;
                    if (!_data.EcoModeEnabled && tab.IsSuspended)
                    {
                        core.Resume();
                        tab.IsSuspended = false;
                        continue;
                    }
                    if (tab.IsPinned || tab.IsPictureInPicture || core.IsDocumentPlayingAudio) continue;
                    if (_data.EcoModeEnabled && !tab.IsSuspended && now - tab.LastActivatedUtc >= delay)
                        tab.IsSuspended = await core.TrySuspendAsync();
                }
                catch { /* Suspensão é best-effort; a guia será retomada ao ser selecionada. */ }
            }
        }
        finally { _resourceSweepRunning = false; }
    }

    private async Task ApplyForcedDarkModeToTabAsync(BrowserTab tab)
    {
        var core = tab.View.CoreWebView2;
        if (core is null) return;
        try
        {
            core.Profile.PreferredColorScheme = _data.ForceDarkMode
                ? CoreWebView2PreferredColorScheme.Dark
                : CoreWebView2PreferredColorScheme.Auto;

            if (!string.IsNullOrWhiteSpace(tab.DarkModeScriptId))
            {
                try { core.RemoveScriptToExecuteOnDocumentCreated(tab.DarkModeScriptId); } catch { }
                tab.DarkModeScriptId = null;
            }

            if (_data.ForceDarkMode)
            {
                tab.DarkModeScriptId = await core.AddScriptToExecuteOnDocumentCreatedAsync(ForceDarkModeScript);
                await core.ExecuteScriptAsync(ForceDarkModeScript);
            }
            else
            {
                await core.ExecuteScriptAsync(DisableForceDarkModeScript);
            }
        }
        catch (Exception ex)
        {
            SetStatus("Não foi possível aplicar o tema escuro nesta página: " + ex.Message);
        }
    }

    private async Task SetForcedDarkModeAsync(bool enabled)
    {
        _data.ForceDarkMode = enabled;
        BrowserStorage.Save(_data);
        foreach (var tab in _tabs.ToList())
            await ApplyForcedDarkModeToTabAsync(tab);
        SetStatus(enabled
            ? "Tema escuro forçado ativado para as páginas. Alguns sites podem apresentar cores diferentes."
            : "Tema escuro forçado desativado.");
    }

    private async Task ToggleForcedDarkModeAsync()
    {
        await SetForcedDarkModeAsync(!_data.ForceDarkMode);
    }

    private void ConfigureDownload(CoreWebView2DownloadStartingEventArgs e)
    {
        try
        {
            var proposedName = SanitizeDownloadFileName(Path.GetFileName(e.ResultFilePath));
            var safety = DownloadSafety.Assess(proposedName, e.DownloadOperation.Uri);
            var protectionLevel = _data.WarnDangerousDownloads ? _data.DownloadProtectionLevel : "Off";
            if (protectionLevel == "Strict" && safety.Risk == DownloadRisk.Critical)
            {
                e.Cancel = true;
                _warnedDownloadsCount++;
                SetStatus($"Download bloqueado pelo modo rigoroso: {proposedName} · {safety.Reason}");
                MessageBox.Show(this,
                    $"O RX Browser bloqueou este download no modo de proteção rigorosa.\n\nArquivo: {proposedName}\nMotivo: {safety.Reason}\n\nMude o nível de proteção somente se entender o risco.",
                    "Download bloqueado — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            var requiresConfirmation = protectionLevel == "Strict"
                ? safety.Risk >= DownloadRisk.Moderate
                : protectionLevel == "Balanced" && safety.Risk >= DownloadRisk.High;
            if (requiresConfirmation)
            {
                _warnedDownloadsCount++;
                var sourceHost = Uri.TryCreate(e.DownloadOperation.Uri, UriKind.Absolute, out var sourceUri)
                    ? sourceUri.Host : "origem desconhecida";
                var decision = MessageBox.Show(this,
                    $"Arquivo: {proposedName}\nOrigem: {sourceHost}\nRisco estimado: {safety.Label}\n\n{ safety.Reason }\n\nO RX Browser não substitui um antivírus. Deseja continuar o download?",
                    "Aviso de segurança de download — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (decision != DialogResult.Yes)
                {
                    e.Cancel = true;
                    SetStatus("Download recusado pelo usuário após aviso de segurança.");
                    return;
                }
            }

            Directory.CreateDirectory(BrowserStorage.Downloads);
            var suggested = proposedName;
            if (string.IsNullOrWhiteSpace(suggested)) suggested = "download";
            var target = Path.Combine(BrowserStorage.Downloads, suggested);
            var suffix = 2;
            while (File.Exists(target) || _downloads.Any(d => string.Equals(d.FilePath, target, StringComparison.OrdinalIgnoreCase)))
            {
                var name = Path.GetFileNameWithoutExtension(suggested);
                var ext = Path.GetExtension(suggested);
                target = Path.Combine(BrowserStorage.Downloads, $"{name} ({suffix++}){ext}");
            }
            e.ResultFilePath = target;
            var operation = e.DownloadOperation;
            var record = new DownloadRecord
            {
                FilePath = target,
                SourceUri = operation.Uri,
                StartedAt = DateTime.Now,
                Operation = operation,
                BytesReceived = operation.BytesReceived,
                TotalBytesToReceive = operation.TotalBytesToReceive,
                State = "Baixando",
                EstimatedEndTime = ParseEstimatedEndTime(operation.EstimatedEndTime),
                SecurityLevel = safety.Label,
                SecurityReason = safety.Reason
            };
            _downloads.Insert(0, record);
            SetStatus("Baixando: " + Path.GetFileName(target));
            operation.BytesReceivedChanged += (_, _) =>
            {
                record.BytesReceived = operation.BytesReceived;
                record.TotalBytesToReceive = operation.TotalBytesToReceive;
                record.EstimatedEndTime = ParseEstimatedEndTime(operation.EstimatedEndTime);
            };
            operation.EstimatedEndTimeChanged += (_, _) =>
            {
                record.EstimatedEndTime = ParseEstimatedEndTime(operation.EstimatedEndTime);
            };
            operation.StateChanged += (_, _) =>
            {
                record.BytesReceived = operation.BytesReceived;
                record.TotalBytesToReceive = operation.TotalBytesToReceive;
                record.EstimatedEndTime = ParseEstimatedEndTime(operation.EstimatedEndTime);
                record.State = operation.State switch
                {
                    CoreWebView2DownloadState.Completed => "Concluído",
                    CoreWebView2DownloadState.Interrupted => record.WasCancelledByUser ? "Cancelado" : record.WasPausedByUser ? "Pausado" : "Interrompido",
                    CoreWebView2DownloadState.InProgress => "Baixando",
                    _ => operation.State.ToString()
                };
                if (!_closing) PersistDownloadHistory(false);
                if (record.State == "Concluído") SetStatus("Download concluído: " + Path.GetFileName(target));
                else if (record.State == "Interrompido") SetStatus("Download interrompido: " + Path.GetFileName(target));
            };
            PersistDownloadHistory(false);
        }
        catch (Exception ex) { SetStatus("Não foi possível preparar o download: " + ex.Message); }
    }

    private static bool IsAllowedWebScheme(string value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme is "http" or "https" or "data" or "about" or "blob" or "chrome-extension") return true;
        // Local top-level file navigation is limited to real PDF documents opened by the user.
        return uri.IsFile && Path.GetExtension(uri.LocalPath).Equals(".pdf", StringComparison.OrdinalIgnoreCase)
            && File.Exists(uri.LocalPath);
    }

    private void PromptExternalProtocol(string value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri))
        {
            SetStatus("Link externo bloqueado por segurança.");
            return;
        }
        var answer = MessageBox.Show(this,
            $"Este link solicita abrir outro aplicativo usando o protocolo {uri.Scheme}:.\n\nEndereço: {value}\n\nDeseja permitir que o Windows abra o aplicativo associado?",
            "Abrir aplicativo externo? — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes) { SetStatus("Abertura de aplicativo externo cancelada."); return; }
        try { Process.Start(new ProcessStartInfo(value) { UseShellExecute = true }); }
        catch (Exception ex) { SetStatus("Não foi possível abrir o aplicativo externo: " + ex.Message); }
    }

    private static string SanitizeDownloadFileName(string? value)
    {
        var name = string.IsNullOrWhiteSpace(value) ? "download" : Path.GetFileName(value.Trim());
        foreach (var invalid in Path.GetInvalidFileNameChars()) name = name.Replace(invalid, '_');
        name = name.Trim().TrimEnd('.');
        return string.IsNullOrWhiteSpace(name) ? "download" : name;
    }

    private static bool IsExecutableLikeExtension(string? extension) =>
        new[] { ".exe", ".msi", ".msix", ".appx", ".bat", ".cmd", ".com", ".scr", ".ps1", ".vbs", ".js", ".hta", ".reg", ".dll" }
            .Contains(extension ?? string.Empty, StringComparer.OrdinalIgnoreCase);

    private static string GetPermissionOrigin(string value)
    {
        if (Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https")
            return uri.GetLeftPart(UriPartial.Authority);
        return value;
    }

    private static bool IsPdfDocument(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        var path = uri.IsFile ? uri.LocalPath : uri.AbsolutePath;
        return Path.GetExtension(path).Equals(".pdf", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsHttpUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";

    private void SelectTab(BrowserTab tab)
    {
        if (!_tabs.Contains(tab)) return;
        if (_activeTab is not null && !ReferenceEquals(_activeTab, tab)) _regionCaptureActive = false;
        if (_activeTab is not null && !ReferenceEquals(_activeTab, tab))
        {
            try { _ = _activeTab.View.CoreWebView2?.ExecuteScriptAsync("window.speechSynthesis?.cancel();"); }
            catch { /* A troca de guia não deve depender do mecanismo de voz. */ }
        }
        if (tab.IsPasswordProtected && tab.IsLocked)
        {
            var record = _data.ProtectedTabs.FirstOrDefault(item => string.Equals(item.TabId, tab.Id, StringComparison.OrdinalIgnoreCase));
            if (record is null)
            {
                tab.IsPasswordProtected = false;
                tab.IsLocked = false;
            }
            else
            {
                var isPin = string.Equals(record.CredentialKind, "PIN", StringComparison.OrdinalIgnoreCase);
                var password = PasswordPromptDialog.Show(this, "Guia protegida — RX Browser",
                    isPin ? "Digite o PIN desta guia para continuar." : "Digite a senha desta guia para continuar.", numericOnly: isPin);
                if (password is null) return;
                if (!VerifyTabProtectionCredential(tab, record, password))
                {
                    SetStatus("Credencial incorreta ou limite temporário de tentativas. A guia continua bloqueada.");
                    return;
                }
                tab.IsLocked = false;
            }
        }
        if (_activeTab is not null && !ReferenceEquals(_activeTab, tab) && _activeTab.IsPasswordProtected)
            _activeTab.IsLocked = true;
        _activeTab = tab;
        tab.LastActivatedUtc = DateTime.UtcNow;
        try
        {
            if (tab.IsSuspended && tab.View.CoreWebView2 is not null)
            {
                tab.View.CoreWebView2.Resume();
                tab.IsSuspended = false;
            }
        }
        catch { tab.IsSuspended = false; }
        foreach (var item in _tabs)
        {
            var selected = ReferenceEquals(item, tab);
            item.View.Visible = selected;
            item.Header.BackColor = selected ? Color.FromArgb(35, 53, 68) : CPanel2;
            item.TitleLabel.ForeColor = selected ? CAccent : CText;
            item.CloseButton.BackColor = selected ? Color.FromArgb(35, 53, 68) : CPanel2;
            ApplyTabHeaderStyle(item);
        }
        tab.View.BringToFront();
        _ = SuspendInactiveTabsAsync(tab);
        if (_findPanel.Visible) _findPanel.BringToFront();
        if (tab.IsHomePage) _addressBox.Text = string.Empty;
        else UpdateAddressFromTab(tab);
        UpdateNavigationButtons();
        UpdateWindowCaption();
        UpdateSecurityStatus(tab);
    }

    private async Task CloseTabAsync(BrowserTab tab)
    {
        var index = _tabs.IndexOf(tab);
        if (index < 0) return;
        var wasActive = ReferenceEquals(_activeTab, tab);
        var closedUrl = tab.View.Source?.ToString();
        if (!tab.IsPrivate && !tab.IsPasswordProtected && IsHttpUrl(closedUrl))
        {
            _data.ClosedTabUrls.Insert(0, closedUrl!);
            _data.ClosedTabUrls = _data.ClosedTabUrls.Distinct(StringComparer.OrdinalIgnoreCase).Take(12).ToList();
            BrowserStorage.Save(_data);
        }
        _tabs.Remove(tab);
        _data.ProtectedTabs.RemoveAll(item => string.Equals(item.TabId, tab.Id, StringComparison.OrdinalIgnoreCase));
        _contentHost.Controls.Remove(tab.View);
        _tabStrip.Controls.Remove(tab.Header);
        tab.View.Dispose();
        tab.Header.ContextMenuStrip?.Dispose();
        tab.Header.Dispose();
        if (tab.IsPrivate && !_tabs.Any(t => t.IsPrivate)) CleanupPrivateSession();
        if (wasActive)
        {
            _activeTab = null;
            if (_tabs.Count > 0) SelectTab(_tabs[Math.Clamp(index - 1, 0, _tabs.Count - 1)]);
            else await CreateTabAsync(null, true);
        }
        SaveSessionSnapshot();
        UpdateNavigationButtons();
    }

    private void ShowHomePage(BrowserTab? tab)
    {
        if (tab?.View.CoreWebView2 is null) return;
        HideFindBar();
        tab.IsHomePage = true;
        tab.Title = tab.IsPrivate ? "Privado · Nova guia" : "Nova guia";
        tab.TitleLabel.Text = tab.Title;
        tab.View.CoreWebView2.NavigateToString(BuildHomePage(tab.IsPrivate));
        if (ReferenceEquals(_activeTab, tab))
        {
            _addressBox.Text = string.Empty;
            SetStatus(tab.IsPrivate ? "Navegação privada  •  perfil temporário separado" : "Nova guia  •  RX Browser");
        }
        UpdateWindowCaption();
    }

    private string BuildHomePage(bool privateMode)
    {
        static string Encode(string value) => System.Net.WebUtility.HtmlEncode(value ?? string.Empty);
        var favorites = _data.Favorites.Take(Math.Clamp(_data.HomePageFavoriteCount, 0, 16)).ToList();
        var favoriteMarkup = favorites.Count == 0
            ? "<div class='empty'>Adicione páginas aos favoritos para encontrá-las rapidamente.</div>"
            : string.Join("", favorites.Select(f => $"<a class='tile' href='{Encode(f.Url)}'><b>★</b><span>{Encode(f.Title)}</span></a>"));
        var quickLinks = _data.HomePageQuickLinks ?? new List<SidebarLink>();
        var quickMarkup = quickLinks.Count == 0
            ? "<div class='empty'>Adicione atalhos nas configurações da página inicial.</div>"
            : string.Join("", quickLinks.Select((link, index) => $"<a class='tile' href='{Encode(link.Url)}'><b>{(index % 2 == 0 ? "↗" : "✦")}</b><span>{Encode(link.Title)}</span></a>"));
        var recent = privateMode ? new List<HistoryItem>() : _data.History
            .Where(item => Uri.TryCreate(item.Url, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https"))
            .OrderByDescending(item => item.VisitedAt).GroupBy(item => item.Url, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.First()).Take(6).ToList();
        var recentMarkup = recent.Count == 0
            ? "<div class='empty'>As páginas visitadas recentemente aparecerão aqui.</div>"
            : string.Join("", recent.Select(item => $"<a class='recent' href='{Encode(item.Url)}'><span>{Encode(item.Title)}</span><small>{Encode(new Uri(item.Url).Host)}</small></a>"));
        var privateBadge = privateMode ? "<div class='private'>◉ MODO PRIVADO — perfil temporário separado; histórico e sincronização não são compartilhados.</div>" : "";
        var clockMarkup = _data.HomePageShowClock ? "<div class='clockbox'><div id='rx-clock'></div><small id='rx-date'></small></div>" : "";
        var quickSection = _data.HomePageShowQuickLinks ? "<section><h2>ATALHOS RÁPIDOS</h2><div class='tiles'>__QUICK_LINKS__</div></section>" : "";
        var favoriteSection = _data.HomePageShowFavorites ? "<section><h2>SEUS FAVORITOS</h2><div class='tiles'>__FAVORITES__</div></section>" : "";
        var recentSection = !privateMode && _data.HomePageShowRecentSites ? "<section><h2>VISITADOS RECENTEMENTE</h2><div class='recent-grid'>__RECENT__</div></section>" : "";
        var greeting = Encode(string.IsNullOrWhiteSpace(_data.HomePageGreeting) ? "NAVEGUE DO SEU JEITO" : _data.HomePageGreeting);
        return """
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nova guia — RX Browser</title>
<style>
:root{color-scheme:dark;--cyan:#23cde6;--text:#e8f0f8;--muted:#8e9eb2}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 50% 18%,__GLOW__ 0%,__MID__ 40%,__BASE__ 80%);font-family:Segoe UI,Arial,sans-serif;color:var(--text);display:flex;align-items:center;justify-content:center}main{width:min(1050px,94vw);padding:32px 24px 48px;text-align:center}.top{display:flex;align-items:center;justify-content:center;gap:24px}.brand{font-size:66px;font-weight:900;letter-spacing:-7px;color:var(--cyan);text-shadow:0 0 36px #23cde655}.brand span{color:white}.clockbox{text-align:left}.clockbox div{font-size:24px;font-weight:700}.clockbox small{font-size:11px;color:var(--muted)}.tag{margin:10px 0 25px;color:var(--muted);font-size:11px;letter-spacing:4px}.private{max-width:700px;margin:0 auto 15px;padding:10px;border:1px solid #7d5cff66;background:#34245a55;color:#c9bfff;border-radius:10px;font-size:12px}.search{display:flex;max-width:760px;margin:0 auto 32px;padding:8px;background:#141e2b;border:1px solid #314457;border-radius:17px}.search input{flex:1;min-width:0;background:transparent;border:0;outline:0;color:white;padding:12px 14px;font-size:16px}.search button{border:0;border-radius:11px;background:linear-gradient(120deg,var(--cyan),#5c9cff);color:#06131b;padding:0 24px;font-weight:800;cursor:pointer}.sections{display:flex;flex-direction:column;gap:24px}section{max-width:760px;width:100%;margin:auto;text-align:left}h2{font-size:10px;letter-spacing:2px;color:var(--muted);margin:0 0 12px 5px}.tiles{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px}.tile{min-height:76px;padding:12px;background:#182332;border:1px solid #293b4e;border-radius:14px;color:var(--text);text-decoration:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:7px;font-size:12px;overflow:hidden}.tile:hover,.recent:hover{border-color:var(--cyan);background:#203247}.tile b{font-size:20px;color:var(--cyan)}.empty{padding:16px;color:var(--muted);background:#141e2b;border:1px dashed #33475b;border-radius:12px;text-align:center;font-size:12px;grid-column:1/-1}.recent-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.recent{display:flex;flex-direction:column;gap:5px;padding:12px 14px;background:#182332;border:1px solid #293b4e;border-radius:12px;color:var(--text);text-decoration:none}.recent span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12px}.recent small{font-size:10px;color:var(--muted)}.home-actions{margin-top:24px}.home-actions button{background:transparent;border:1px solid #314457;border-radius:20px;color:var(--muted);padding:7px 15px;cursor:pointer}.home-actions button:hover{color:var(--cyan);border-color:var(--cyan)}.footer{margin-top:20px;color:#63778d;font-size:10px;letter-spacing:1px}@media(max-width:680px){.top{flex-direction:column;gap:8px}.brand{font-size:54px}.clockbox{text-align:center}.tiles{grid-template-columns:repeat(2,minmax(0,1fr))}.recent-grid{grid-template-columns:1fr}}
</style></head><body><main><div class="top"><div class="brand">R<span>X</span></div>__CLOCK__</div><div class="tag">__GREETING__</div>__PRIVATE__
<div class="search"><input id="q" autocomplete="off" placeholder="O que você quer encontrar hoje?" autofocus><button id="go">PESQUISAR</button></div>
<div class="sections">__QUICK_SECTION____FAVORITE_SECTION____RECENT_SECTION__</div><div class="home-actions"><button id="customize">⚙ Personalizar página inicial</button></div><div class="footer">RX BROWSER · INTERFACE ORIGINAL · WEBVIEW2</div></main>
<script>
function search(){const q=document.getElementById('q').value.trim();if(q)window.chrome.webview.postMessage({action:'search',query:q})}document.getElementById('go').addEventListener('click',search);document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')search()});document.getElementById('customize').addEventListener('click',()=>window.chrome.webview.postMessage({action:'home-settings'}));const tick=()=>{const n=new Date(),c=document.getElementById('rx-clock'),d=document.getElementById('rx-date');if(c)c.textContent=new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(n);if(d)d.textContent=new Intl.DateTimeFormat('pt-BR',{weekday:'long',day:'2-digit',month:'long'}).format(n)};tick();setInterval(tick,30000);
</script></body></html>
"""
            .Replace("__PRIVATE__", privateBadge)
            .Replace("__CLOCK__", clockMarkup)
            .Replace("__GREETING__", greeting)
            .Replace("__QUICK_SECTION__", quickSection)
            .Replace("__FAVORITE_SECTION__", favoriteSection)
            .Replace("__RECENT_SECTION__", recentSection)
            .Replace("__QUICK_LINKS__", quickMarkup)
            .Replace("__FAVORITES__", favoriteMarkup)
            .Replace("__RECENT__", recentMarkup)
            .Replace("__GLOW__", HomePagePalette(_data.HomePageTheme).Glow)
            .Replace("__MID__", HomePagePalette(_data.HomePageTheme).Mid)
            .Replace("__BASE__", HomePagePalette(_data.HomePageTheme).Base)
            .Replace("</style>", HomePageCardStyleCss(_data.HomePageCardStyle) + "</style>")
            .Replace("--cyan:#23cde6", "--cyan:" + ColorTranslator.ToHtml(CAccent));
    }

    private static string HomePageCardStyleCss(string? style) => style switch
    {
        "Solid" => ".tile,.recent{background:#202b3b;border-color:#35485e;box-shadow:0 8px 22px #0004}.tile:hover,.recent:hover{background:#2a3b50}",
        "Minimal" => ".tile,.recent{background:transparent;border-color:#405064;border-radius:7px;box-shadow:none}.tile:hover,.recent:hover{background:#ffffff0c}",
        _ => ".tile,.recent{background:#182332cc;border-color:#71849a55;backdrop-filter:blur(12px);box-shadow:0 10px 28px #0003}"
    };

    private void NavigateFromAddress()
    {
        var value = _addressBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(value) || _activeTab?.View.CoreWebView2 is null) return;
        try
        {
            HideFindBar();
            _activeTab.IsHomePage = false;
            _activeTab.View.CoreWebView2.Navigate(NormalizeAddress(value));
            _activeTab.View.Focus();
        }
        catch (Exception ex) { SetStatus("Endereço inválido: " + ex.Message); }
    }

    private string NormalizeAddress(string input)
    {
        var value = input.Trim();
        if (Uri.TryCreate(value, UriKind.Absolute, out var absolute) &&
            absolute.Scheme is "http" or "https" or "file") return absolute.ToString();
        if (value.Contains(' ') || !value.Contains('.')) return BuildSearchUrl(value);
        if (Uri.TryCreate("https://" + value, UriKind.Absolute, out var withHttps)) return withHttps.ToString();
        return BuildSearchUrl(value);
    }

    private string BuildSearchUrl(string query)
    {
        var q = Uri.EscapeDataString(query);
        return _data.SearchEngine switch
        {
            "Google" => "https://www.google.com/search?q=" + q,
            "Bing" => "https://www.bing.com/search?q=" + q,
            _ => "https://duckduckgo.com/?q=" + q
        };
    }

    private void AddressBox_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            NavigateFromAddress();
        }
    }

    private async void MainForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && !e.Shift && !e.Alt && ((e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D8) || (e.KeyCode >= Keys.NumPad1 && e.KeyCode <= Keys.NumPad8)))
        {
            e.SuppressKeyPress = true;
            var index = e.KeyCode >= Keys.NumPad1 ? (int)e.KeyCode - (int)Keys.NumPad1 : (int)e.KeyCode - (int)Keys.D1;
            SelectTabByIndex(index);
        }
        else if (e.Control && !e.Shift && !e.Alt && (e.KeyCode == Keys.D9 || e.KeyCode == Keys.NumPad9))
        {
            e.SuppressKeyPress = true;
            SelectTabByIndex(_tabs.Count - 1);
        }
        else if (MatchesShortcut("PreviousTab", "Ctrl+Shift+Tab", e) || (e.Control && e.KeyCode == Keys.PageUp))
        {
            e.SuppressKeyPress = true;
            SelectRelativeTab(-1);
        }
        else if (MatchesShortcut("NextTab", "Ctrl+Tab", e) || (e.Control && e.KeyCode == Keys.PageDown))
        {
            e.SuppressKeyPress = true;
            SelectRelativeTab(1);
        }
        else if (e.KeyCode == Keys.F6)
        {
            e.SuppressKeyPress = true;
            ToggleAddressFocus();
        }
        else if (e.Alt && !e.Control && !e.Shift && e.KeyCode == Keys.Left)
        {
            e.SuppressKeyPress = true;
            if (_activeTab?.View.CoreWebView2?.CanGoBack == true) _activeTab.View.CoreWebView2.GoBack();
        }
        else if (e.Alt && !e.Control && !e.Shift && e.KeyCode == Keys.Right)
        {
            e.SuppressKeyPress = true;
            if (_activeTab?.View.CoreWebView2?.CanGoForward == true) _activeTab.View.CoreWebView2.GoForward();
        }
        else if (MatchesShortcut("NewTab", "Ctrl+T", e))
        {
            e.SuppressKeyPress = true;
            await CreateTabAsync(null, true);
        }
        else if (MatchesShortcut("CloseTab", "Ctrl+W", e))
        {
            e.SuppressKeyPress = true;
            if (_activeTab is not null) await CloseTabAsync(_activeTab);
        }
        else if (MatchesShortcut("TabManager", "Ctrl+Shift+A", e))
        {
            e.SuppressKeyPress = true;
            OpenTabManager();
        }
        else if (MatchesShortcut("TabSearch", "Ctrl+Shift+Q", e))
        {
            e.SuppressKeyPress = true;
            OpenTabSearch();
        }
        else if (MatchesShortcut("Workspaces", "Ctrl+Shift+W", e))
        {
            e.SuppressKeyPress = true;
            OpenWorkspaceManager();
        }
        else if (MatchesShortcut("Performance", "Ctrl+Shift+Y", e))
        {
            e.SuppressKeyPress = true;
            OpenPerformancePanel();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.U)
        {
            e.SuppressKeyPress = true;
            OpenAccessibilitySettings();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.O)
        {
            e.SuppressKeyPress = true;
            OpenControlCenter();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.Space)
        {
            e.SuppressKeyPress = true;
            OpenCommandPalette();
        }
        else if (MatchesShortcut("PdfTools", "Ctrl+Shift+M", e))
        {
            e.SuppressKeyPress = true;
            OpenPdfReaderTools();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.F)
        {
            e.SuppressKeyPress = true;
            OpenTaskManager();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.G)
        {
            e.SuppressKeyPress = true;
            await TranslateCurrentPageAsync("pt", "Português (Brasil)");
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.K)
        {
            e.SuppressKeyPress = true;
            await CaptureFullPageAsync();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.V)
        {
            e.SuppressKeyPress = true;
            await ReadActivePageAloudAsync();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.R)
        {
            e.SuppressKeyPress = true;
            await StartRegionCaptureAsync();
        }
        else if (MatchesShortcut("ReaderMode", "Ctrl+Shift+E", e))
        {
            e.SuppressKeyPress = true;
            await OpenReaderModeAsync();
        }
        else if (MatchesShortcut("TranslateSelection", "Ctrl+Shift+X", e))
        {
            e.SuppressKeyPress = true;
            await TranslateSelectedTextAsync("pt", "Português (Brasil)");
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.N)
        {
            e.SuppressKeyPress = true;
            await CreateTabAsync(null, true, true);
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.T)
        {
            e.SuppressKeyPress = true;
            await ReopenClosedTabAsync();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.B)
        {
            e.SuppressKeyPress = true;
            ToggleSidebar();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.D)
        {
            e.SuppressKeyPress = true;
            await ToggleForcedDarkModeAsync();
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.P)
        {
            e.SuppressKeyPress = true;
            OpenPasswordManager();
        }
        else if (e.Control && e.KeyCode == Keys.O)
        {
            e.SuppressKeyPress = true;
            await OpenPdfDocumentAsync();
        }
        else if (MatchesShortcut("Security", "Ctrl+Shift+S", e))
        {
            e.SuppressKeyPress = true;
            OpenSecurityCenter();
        }
        else if (e.Control && e.KeyCode == Keys.P)
        {
            e.SuppressKeyPress = true;
            await PrintActiveDocumentAsync();
        }
        else if (MatchesShortcut("FocusAddress", "Ctrl+L", e))
        {
            e.SuppressKeyPress = true;
            _addressBox.Focus();
            _addressBox.SelectAll();
        }
        else if (e.Control && e.KeyCode == Keys.F)
        {
            e.SuppressKeyPress = true;
            ShowFindBar();
        }
        else if (e.Control && e.KeyCode == Keys.D)
        {
            e.SuppressKeyPress = true;
            ToggleCurrentFavorite();
        }
        else if (MatchesShortcut("Downloads", "Ctrl+J", e))
        {
            e.SuppressKeyPress = true;
            OpenDownloadsCenter();
        }
        else if (e.Control && e.KeyCode == Keys.H)
        {
            e.SuppressKeyPress = true;
            ShowHistoryMenu(_historyButton);
        }
        else if (e.Control && e.Shift && e.KeyCode == Keys.Delete)
        {
            e.SuppressKeyPress = true;
            await ClearBrowsingDataAsync();
        }
        else if (e.Control && (e.KeyCode == Keys.Add || e.KeyCode == Keys.Oemplus))
        {
            e.SuppressKeyPress = true;
            ChangeZoom(10);
        }
        else if (e.Control && e.KeyCode == Keys.Subtract || e.Control && e.KeyCode == Keys.OemMinus)
        {
            e.SuppressKeyPress = true;
            ChangeZoom(-10);
        }
        else if (e.Control && e.KeyCode == Keys.D0)
        {
            e.SuppressKeyPress = true;
            SetZoom(100);
        }
        else if (e.KeyCode == Keys.F11)
        {
            e.SuppressKeyPress = true;
            ToggleFullscreen();
        }
        else if (e.Alt && e.KeyCode == Keys.Home)
        {
            e.SuppressKeyPress = true;
            ShowHomePage(_activeTab);
        }
        else if (e.KeyCode == Keys.Escape && _findPanel.Visible) HideFindBar();
        else if (e.Control && e.KeyCode == Keys.R || e.KeyCode == Keys.F5)
        {
            e.SuppressKeyPress = true;
            _activeTab?.View.CoreWebView2?.Reload();
        }
        else if (e.Alt && e.KeyCode == Keys.Left)
        {
            e.SuppressKeyPress = true;
            if (_activeTab?.View.CoreWebView2?.CanGoBack == true) _activeTab.View.CoreWebView2.GoBack();
        }
        else if (e.Alt && e.KeyCode == Keys.Right)
        {
            e.SuppressKeyPress = true;
            if (_activeTab?.View.CoreWebView2?.CanGoForward == true) _activeTab.View.CoreWebView2.GoForward();
        }
    }

    private void ShowFindBar()
    {
        if (_activeTab?.View.CoreWebView2 is null) return;
        _findPanel.Visible = true;
        _findPanel.BringToFront();
        _findBox.Focus();
        _findBox.SelectAll();
    }

    private void HideFindBar()
    {
        if (!_findPanel.Visible) return;
        _findPanel.Visible = false;
        _findResult.Text = string.Empty;
        _ = _activeTab?.View.CoreWebView2?.ExecuteScriptAsync("window.getSelection()?.removeAllRanges();");
        _activeTab?.View.Focus();
    }

    private async Task FindInPageAsync(bool backwards)
    {
        if (_activeTab?.View.CoreWebView2 is null || string.IsNullOrWhiteSpace(_findBox.Text))
        {
            _findResult.Text = "Digite um texto";
            return;
        }
        try
        {
            var query = JsonSerializer.Serialize(_findBox.Text);
            var result = await _activeTab.View.CoreWebView2.ExecuteScriptAsync(
                $"window.find({query}, false, {(backwards ? "true" : "false")}, true, false, false, false);");
            _findResult.Text = result == "true" ? "Encontrado" : "Não encontrado";
        }
        catch { _findResult.Text = "Indisponível"; }
    }

    private void SelectTabByIndex(int index)
    {
        if (_tabs.Count == 0) return;
        var clamped = Math.Clamp(index, 0, _tabs.Count - 1);
        SelectTab(_tabs[clamped]);
    }

    private void ToggleAddressFocus()
    {
        if (_addressBox.Focused)
        {
            _activeTab?.View.Focus();
            return;
        }
        _addressBox.Focus();
        _addressBox.SelectAll();
    }

    private void SelectRelativeTab(int direction)
    {
        if (_tabs.Count < 2 || _activeTab is null) return;
        var index = _tabs.IndexOf(_activeTab);
        var next = (index + direction + _tabs.Count) % _tabs.Count;
        SelectTab(_tabs[next]);
    }

    private void ChangeZoom(int delta) => SetZoom(_data.ZoomPercent + delta);

    private void SetZoom(int percent)
    {
        _data.ZoomPercent = Math.Clamp(percent, 50, 200);
        foreach (var tab in _tabs)
        {
            try { tab.View.ZoomFactor = _data.ZoomPercent / 100d; } catch { }
        }
        BrowserStorage.Save(_data);
        SetStatus("Zoom: " + _data.ZoomPercent + "%");
    }

    private void ToggleFullscreen()
    {
        if (!_fullscreen)
        {
            _borderBeforeFullscreen = FormBorderStyle;
            _stateBeforeFullscreen = WindowState;
            _boundsBeforeFullscreen = Bounds;
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            _fullscreen = true;
        }
        else
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = _borderBeforeFullscreen;
            Bounds = _boundsBeforeFullscreen;
            WindowState = _stateBeforeFullscreen;
            _fullscreen = false;
        }
    }

    private void UpdateAddressFromTab(BrowserTab tab)
    {
        var source = tab.View.Source?.ToString() ?? string.Empty;
        if (!string.IsNullOrWhiteSpace(source) && source != "about:blank") _addressBox.Text = source;
    }

    private void UpdateTabTitle(BrowserTab tab)
    {
        if (tab.View.CoreWebView2 is null) return;
        var title = tab.View.CoreWebView2.DocumentTitle;
        if (string.IsNullOrWhiteSpace(title)) title = "Nova guia";
        tab.Title = tab.IsPrivate ? "Privado · " + title : title;
        ApplyTabHeaderStyle(tab);
        if (ReferenceEquals(_activeTab, tab)) UpdateWindowCaption();
    }

    private void UpdateWindowCaption()
    {
        Text = _activeTab is null || string.IsNullOrWhiteSpace(_activeTab.Title)
            ? "RX Browser"
            : _activeTab.Title + " — RX Browser";
    }

    private void UpdateSecurityStatus(BrowserTab? tab)
    {
        if (tab is null) return;
        var url = tab.View.Source?.ToString() ?? string.Empty;
        if (tab.IsPrivate)
            SetStatus("Modo privado ativo  •  perfil temporário separado");
        else if (url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            SetStatus("Conexão HTTPS  •  transporte criptografado");
        else if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
            SetStatus("Atenção: esta página usa HTTP sem criptografia");
        else
            SetStatus("RX Browser  •  nova guia");
    }

    private void UpdateNavigationButtons()
    {
        var core = _activeTab?.View.CoreWebView2;
        _backButton.Enabled = core?.CanGoBack == true;
        _forwardButton.Enabled = core?.CanGoForward == true;
        _reloadButton.Enabled = core is not null;
        _homeButton.Enabled = core is not null;
        _favoriteButton.Enabled = core is not null && IsHttpUrl(_activeTab?.View.Source?.ToString());
        RefreshFavoriteButton();
    }

    private void RefreshFavoriteButton()
    {
        var url = _activeTab?.View.Source?.ToString();
        var isFavorite = !string.IsNullOrWhiteSpace(url) && _data.Favorites.Any(f =>
            string.Equals(f.Url, url, StringComparison.OrdinalIgnoreCase));
        _favoriteButton.Text = isFavorite ? "★" : "☆";
        _favoriteButton.ForeColor = isFavorite ? CAccent : CText;
    }

    private void ToggleCurrentFavorite()
    {
        if (_activeTab?.View.CoreWebView2 is null) return;
        var url = _activeTab.View.Source?.ToString();
        if (!IsHttpUrl(url))
        {
            SetStatus("Abra um site para adicioná-lo aos favoritos.");
            return;
        }
        var existing = _data.Favorites.FirstOrDefault(f => string.Equals(f.Url, url, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            _data.Favorites.Remove(existing);
            BookmarkSync.Mark(_data, existing.Title, existing.Url, deleted: true, groupName: existing.GroupName);
            SetStatus("Favorito removido.");
        }
        else
        {
            var title = _activeTab.View.CoreWebView2.DocumentTitle ?? url!;
            _data.Favorites.Insert(0, new FavoriteItem(title, url!) { GroupName = "Geral" });
            BookmarkSync.Mark(_data, title, url!, deleted: false, groupName: "Geral");
            SetStatus("Adicionado aos favoritos.");
        }
        BrowserStorage.Save(_data);
        SyncFavoritesNow(false);
        RefreshFavoriteButton();
    }

    private void ShowFavoritesMenu(Control anchor)
    {
        var menu = new WheelScrollableContextMenuStrip();
        menu.Items.Add("Gerenciar favoritos e grupos…", null, (_, _) => OpenFavoritesManager());
        menu.Items.Add(new ToolStripSeparator());
        if (_data.Favorites.Count == 0)
            menu.Items.Add(new ToolStripMenuItem("Nenhum favorito salvo") { Enabled = false });

        foreach (var group in _data.Favorites
            .GroupBy(favorite => string.IsNullOrWhiteSpace(favorite.GroupName) ? "Geral" : favorite.GroupName)
            .OrderBy(item => item.Key, StringComparer.CurrentCultureIgnoreCase))
        {
            var groupItem = new ToolStripMenuItem(group.Key);
            foreach (var favorite in group.OrderBy(item => item.Title, StringComparer.CurrentCultureIgnoreCase).Take(80))
            {
                var item = new ToolStripMenuItem(favorite.Title) { ToolTipText = favorite.Url };
                item.Click += async (_, _) => await NavigateOrNewTabAsync(favorite.Url);
                var remove = new ToolStripMenuItem("Remover favorito");
                remove.Click += (_, _) =>
                {
                    _data.Favorites.Remove(favorite);
                    BookmarkSync.Mark(_data, favorite.Title, favorite.Url, deleted: true, groupName: favorite.GroupName);
                    BrowserStorage.Save(_data);
                    SyncFavoritesNow(false);
                    RefreshFavoriteButton();
                    SetStatus("Favorito removido.");
                };
                item.DropDownItems.Add(remove);
                groupItem.DropDownItems.Add(item);
            }
            menu.Items.Add(groupItem);
        }
        menu.Show(anchor, new Point(0, anchor.Height));
    }

    private void OpenFavoritesManager()
    {
        var before = _data.Favorites.ToList();
        using var form = new FavoritesManagerForm(_data.Favorites, _data.FavoriteFolders, url => _ = NavigateOrNewTabAsync(url));
        form.ShowDialog(this);
        _data.Favorites = form.ResultFavorites;
        _data.FavoriteFolders = form.ResultFolders;
        var currentUrls = _data.Favorites.Select(item => item.Url).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var removed in before.Where(item => !currentUrls.Contains(item.Url)))
            BookmarkSync.Mark(_data, removed.Title, removed.Url, deleted: true, groupName: removed.GroupName);
        foreach (var favorite in _data.Favorites)
            BookmarkSync.Mark(_data, favorite.Title, favorite.Url, deleted: false, groupName: favorite.GroupName);
        BrowserStorage.Save(_data);
        SyncFavoritesNow(false);
        RefreshFavoriteButton();
        SetStatus($"Favoritos organizados: {_data.Favorites.Count} em {_data.FavoriteFolders.Count} pasta(s).");
    }

    private void OpenSiteNotes()
    {
        if (_activeTab is null)
        {
            SetStatus("Abra uma guia para usar o Caderno RX.");
            return;
        }
        if (_activeTab.IsPrivate)
        {
            MessageBox.Show(this,
                "O Caderno RX não é aberto em guias privadas para evitar que anotações dessa sessão sejam gravadas no perfil normal.",
                "Caderno RX — privacidade", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var form = new SiteNotesForm(_activeTab.View.Source?.ToString(), _activeTab.Title);
        form.ShowDialog(this);
    }

    private void ShowHistoryMenu(Control anchor)
    {
        using var form = new HistoryTimelineForm(_data.History);
        form.ShowDialog(this);
        _data.History = form.ResultHistory;
        BrowserStorage.Save(_data);
        if (!string.IsNullOrWhiteSpace(form.OpenUrl))
            _ = NavigateOrNewTabAsync(form.OpenUrl);
        SetStatus($"Histórico atualizado  •  {_data.History.Count} registro(s)");
    }

    private void ShowMoreMenu(Control anchor)
    {
        var menu = new WheelScrollableContextMenuStrip();
        menu.Items.Add("Central RX — painel de controle  ·  Ctrl+Shift+O", null, (_, _) => OpenControlCenter());
        menu.Items.Add("Paleta de comandos  ·  Ctrl+Shift+Espaço", null, (_, _) => OpenCommandPalette());
        menu.Items.Add("Personalizar barra de ferramentas…", null, (_, _) => OpenToolbarSettings());
        menu.Items.Add("Painel visual de sincronização…", null, (_, _) => OpenSyncDashboard());
        menu.Items.Add("Diagnóstico e backup do perfil…", null, (_, _) => OpenDiagnostics());
        menu.Items.Add("Caderno RX — notas por site…", null, (_, _) => OpenSiteNotes());
        menu.Items.Add(new ToolStripSeparator());
        var forceDark = new ToolStripMenuItem("Forçar tema escuro nas páginas  ·  Ctrl+Shift+D")
        {
            Checked = _data.ForceDarkMode,
            CheckOnClick = true
        };
        forceDark.CheckedChanged += async (_, _) => await SetForcedDarkModeAsync(forceDark.Checked);
        menu.Items.Add(forceDark);
        menu.Items.Add("Personalizar aparência…", null, (_, _) => OpenCustomization());
        menu.Items.Add("Personalizar página inicial…", null, (_, _) => OpenHomePageSettings());
        menu.Items.Add("Acessibilidade e tamanho da interface…", null, (_, _) => OpenAccessibilitySettings());
        menu.Items.Add("Atalhos personalizáveis…", null, (_, _) => OpenShortcutSettings());
        menu.Items.Add("Gerenciador de guias com pré-visualização…  ·  Ctrl+Shift+A", null, (_, _) => OpenTabManager());
        menu.Items.Add("Localizar guia aberta…  ·  Ctrl+Shift+Q", null, (_, _) => OpenTabSearch());
        menu.Items.Add("Espaços de trabalho…  ·  Ctrl+Shift+W", null, (_, _) => OpenWorkspaceManager());
        menu.Items.Add("Painel de desempenho…  ·  Ctrl+Shift+Y", null, (_, _) => OpenPerformancePanel());
        menu.Items.Add("Cofre de senhas local…  ·  Ctrl+Shift+P", null, (_, _) => OpenPasswordManager());
        menu.Items.Add("Abrir PDF local…  ·  Ctrl+O", null, async (_, _) => await OpenPdfDocumentAsync());
        var pdfTools = new ToolStripMenuItem("Ferramentas de PDF") { Enabled = IsPdfDocument(_activeTab?.View.Source?.ToString()) };
        pdfTools.DropDownItems.Add("Imprimir PDF…", null, async (_, _) => await PrintActiveDocumentAsync());
        pdfTools.DropDownItems.Add("Salvar cópia do documento…", null, async (_, _) => await SaveActiveDocumentAsAsync());
        pdfTools.DropDownItems.Add("Aumentar zoom", null, (_, _) => ChangeZoom(10));
        pdfTools.DropDownItems.Add("Diminuir zoom", null, (_, _) => ChangeZoom(-10));
        pdfTools.DropDownItems.Add("Restaurar zoom", null, (_, _) => SetZoom(100));
        pdfTools.DropDownItems.Add("Marcadores e anotações…  ·  Ctrl+Shift+M", null, (_, _) => OpenPdfReaderTools());
        pdfTools.DropDownItems.Add("Abrir PDF local no aplicativo padrão", null, (_, _) => OpenLocalPdfExternally());
        menu.Items.Add(pdfTools);
        menu.Items.Add("Salvar página atual como PDF…", null, async (_, _) => await SaveCurrentPageAsPdfAsync());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Segurança e privacidade…  ·  Ctrl+Shift+S", null, (_, _) => OpenSecurityCenter());
        menu.Items.Add("Painel de privacidade em tempo real…", null, (_, _) => OpenPrivacyActivityDashboard());
        menu.Items.Add("Verificar endereço atual…", null, (_, _) => CheckCurrentAddressSafety());
        menu.Items.Add(new ToolStripSeparator());

        var tracking = new ToolStripMenuItem("Proteção contra rastreamento");
        foreach (var level in new[] { "Basic", "Balanced", "Strict", "Off" })
        {
            var label = level switch { "Basic" => "Básica", "Balanced" => "Equilibrada", "Strict" => "Rigorosa", _ => "Desativada" };
            var choice = new ToolStripMenuItem(label) { Checked = _data.TrackingProtectionLevel == level };
            choice.Click += async (_, _) => await SetTrackingProtectionLevelAsync(level);
            tracking.DropDownItems.Add(choice);
        }
        menu.Items.Add(tracking);
        var downloadProtection = new ToolStripMenuItem("Proteção de downloads");
        var currentDownloadProtection = _data.WarnDangerousDownloads ? _data.DownloadProtectionLevel : "Off";
        foreach (var level in new[] { "Off", "Balanced", "Strict" })
        {
            var label = level switch { "Off" => "Desativada", "Balanced" => "Equilibrada", _ => "Rigorosa" };
            var choice = new ToolStripMenuItem(label) { Checked = currentDownloadProtection == level };
            choice.Click += (_, _) =>
            {
                _data.DownloadProtectionLevel = level;
                _data.WarnDangerousDownloads = level != "Off";
                BrowserStorage.Save(_data);
                SetStatus("Proteção de downloads: " + label + ".");
            };
            downloadProtection.DropDownItems.Add(choice);
        }
        menu.Items.Add(downloadProtection);
        menu.Items.Add("Privacidade deste site…", null, (_, _) => OpenCurrentSitePrivacySettings());
        menu.Items.Add("Dispensar filtros extras de rastreamento neste site", null, (_, _) => ToggleTrackingProtectionForCurrentSite());
        var dnt = new ToolStripMenuItem("Enviar sinal Não Rastrear (DNT)") { Checked = _data.DoNotTrack, CheckOnClick = true };
        dnt.CheckedChanged += (_, _) =>
        {
            _data.DoNotTrack = dnt.Checked;
            BrowserStorage.Save(_data);
            foreach (var tab in _tabs) _ = ApplyTrackingProtectionAsync(tab);
            SetStatus(dnt.Checked ? "Sinal DNT ativado para novas requisições." : "Sinal DNT desativado.");
        };
        menu.Items.Add(dnt);
        var eco = new ToolStripMenuItem("Suspender guias inativas para economizar memória") { Checked = _data.EcoModeEnabled, CheckOnClick = true };
        eco.CheckedChanged += (_, _) =>
        {
            _data.EcoModeEnabled = eco.Checked;
            BrowserStorage.Save(_data);
            if (_activeTab is not null) _ = SuspendInactiveTabsAsync(_activeTab);
            SetStatus(eco.Checked ? "Modo econômico ativado." : "Modo econômico desativado.");
        };
        menu.Items.Add(eco);
        var suspendDelay = new ToolStripMenuItem($"Aguardar antes de suspender guias  ·  {_data.BackgroundTabSuspendDelaySeconds}s");
        foreach (var seconds in new[] { 30, 45, 60, 120, 300 })
        {
            var delayItem = new ToolStripMenuItem(seconds < 60 ? $"{seconds} segundos" : $"{seconds / 60} minuto(s)")
            {
                Checked = _data.BackgroundTabSuspendDelaySeconds == seconds
            };
            delayItem.Click += (_, _) =>
            {
                _data.BackgroundTabSuspendDelaySeconds = seconds;
                BrowserStorage.Save(_data);
                SetStatus($"Suspensão de guias configurada para após {seconds} segundos sem uso.");
            };
            suspendDelay.DropDownItems.Add(delayItem);
        }
        menu.Items.Add(suspendDelay);
        menu.Items.Add(new ToolStripSeparator());

        var profiles = new ToolStripMenuItem("Perfis de usuário");
        var currentProfile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        profiles.Text = $"{_data.ProfileBadge} Perfil: " + (currentProfile?.Name ?? "Pessoal");
        foreach (var profile in ProfileStore.Load())
        {
            var profileData = string.Equals(profile.Id, BrowserStorage.CurrentProfileId, StringComparison.OrdinalIgnoreCase) ? _data : BrowserStorage.LoadForProfile(profile.Id);
            var profileItem = new ToolStripMenuItem($"{profileData.ProfileBadge} {profile.Name}")
            {
                Checked = profile.Id == BrowserStorage.CurrentProfileId,
                CheckOnClick = false
            };
            profileItem.Click += (_, _) => OpenProfile(profile.Id);
            profiles.DropDownItems.Add(profileItem);
        }
        profiles.DropDownItems.Add(new ToolStripSeparator());
        profiles.DropDownItems.Add("Criar perfil…", null, (_, _) => CreateProfile());
        profiles.DropDownItems.Add("Renomear perfil atual…", null, (_, _) => RenameCurrentProfile());
        menu.Items.Add(profiles);
        menu.Items.Add("Central de sincronização RX…", null, (_, _) => OpenSyncCenter());
        menu.Items.Add("Configurar sincronização de favoritos…", null, (_, _) => ConfigureFavoritesSync());
        menu.Items.Add("Sincronizar favoritos agora", null, (_, _) => SyncFavoritesNow(true));
        menu.Items.Add("Configurar sincronização de preferências…", null, (_, _) => ConfigurePreferencesSync());
        menu.Items.Add("Enviar preferências deste computador", null, (_, _) => PublishPreferencesNow(true));
        menu.Items.Add("Aplicar preferências de outro computador…", null, (_, _) => ImportPreferencesNow());
        var disablePreferencesSync = new ToolStripMenuItem("Desativar sincronização de preferências") { Enabled = !string.IsNullOrWhiteSpace(_data.PreferencesSyncFolder) };
        disablePreferencesSync.Click += (_, _) =>
        {
            _data.PreferencesSyncFolder = string.Empty;
            BrowserStorage.Save(_data);
            SetStatus("Sincronização de preferências desativada neste perfil. Os arquivos compartilhados não foram apagados.");
        };
        menu.Items.Add(disablePreferencesSync);
        menu.Items.Add("Salvar sessão atual com nome…", null, (_, _) => SaveCurrentSessionAs());
        menu.Items.Add("Gerenciar sessões salvas…", null, (_, _) => ManageSavedSessions());
        menu.Items.Add("Configurar sincronização de sessões…", null, (_, _) => ConfigureSessionSync());
        menu.Items.Add("Abrir sessão de outro dispositivo…", null, (_, _) => OpenRemoteSessions());
        var syncSessionNow = new ToolStripMenuItem("Sincronizar sessão deste dispositivo agora");
        syncSessionNow.Click += (_, _) => SyncSessionSnapshot(true, allowPrompt: true, forceWrite: true);
        menu.Items.Add(syncSessionNow);
        var disableSessionSync = new ToolStripMenuItem("Desativar sincronização de sessões") { Enabled = _data.SessionSyncEnabled };
        disableSessionSync.Click += (_, _) =>
        {
            _data.SessionSyncEnabled = false;
            _data.SessionSyncFolder = string.Empty;
            _sessionSyncPassphrase = null;
            BrowserStorage.Save(_data);
            SetStatus("Sincronização de sessões desativada neste perfil. Os arquivos compartilhados não foram apagados.");
        };
        menu.Items.Add(disableSessionSync);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Nova guia privada  ·  Ctrl+Shift+N", null, async (_, _) => await CreateTabAsync(null, true, true));
        menu.Items.Add("Localizar na página  ·  Ctrl+F", null, (_, _) => ShowFindBar());
        menu.Items.Add("Central de downloads  ·  Ctrl+J", null, (_, _) => OpenDownloadsCenter());
        var translate = new ToolStripMenuItem("RX Translate — traduzir página");
        translate.DropDownItems.Add("Escolher idiomas e preparar tradução…", null, async (_, _) => await TranslateCurrentPageAsync(_data.PreferredTranslationLanguage, TranslationLanguageName(_data.PreferredTranslationLanguage)));
        translate.DropDownItems.Add("Para português (Brasil)  ·  Ctrl+Shift+G", null, async (_, _) => await TranslateCurrentPageAsync("pt", "Português (Brasil)"));
        translate.DropDownItems.Add("Para inglês", null, async (_, _) => await TranslateCurrentPageAsync("en", "Inglês"));
        translate.DropDownItems.Add("Para espanhol", null, async (_, _) => await TranslateCurrentPageAsync("es", "Espanhol"));
        translate.DropDownItems.Add("Traduzir texto selecionado para português", null, async (_, _) => await TranslateSelectedTextAsync("pt", "Português (Brasil)"));
        translate.DropDownItems.Add("Traduzir texto selecionado para inglês", null, async (_, _) => await TranslateSelectedTextAsync("en", "Inglês"));
        menu.Items.Add(translate);
        menu.Items.Add("Modo leitor sem distrações…  ·  Ctrl+Shift+E", null, async (_, _) => await OpenReaderModeAsync());
        menu.Items.Add("Capturar página inteira  ·  Ctrl+Shift+K", null, async (_, _) => await CaptureFullPageAsync());
        menu.Items.Add("Capturar região da página…", null, async (_, _) => await StartRegionCaptureAsync());
        var readAloud = new ToolStripMenuItem("Leitura em voz alta");
        readAloud.DropDownItems.Add("Ler página atual  ·  Ctrl+Shift+V", null, async (_, _) => await ReadActivePageAloudAsync());
        readAloud.DropDownItems.Add("Configurar voz e velocidade…", null, async (_, _) => await OpenSpeechSettingsAsync());
        readAloud.DropDownItems.Add("Pausar leitura", null, async (_, _) => await ControlSpeechAsync("pause"));
        readAloud.DropDownItems.Add("Continuar leitura", null, async (_, _) => await ControlSpeechAsync("resume"));
        readAloud.DropDownItems.Add("Parar leitura", null, async (_, _) => await ControlSpeechAsync("stop"));
        menu.Items.Add(readAloud);
        var media = new ToolStripMenuItem("Controles de vídeo e áudio");
        media.DropDownItems.Add("Reproduzir vídeos", null, async (_, _) => await ControlPageMediaAsync("play"));
        media.DropDownItems.Add("Pausar vídeos", null, async (_, _) => await ControlPageMediaAsync("pause"));
        media.DropDownItems.Add("Alternar mudo", null, async (_, _) => await ControlPageMediaAsync("mute"));
        var speed = new ToolStripMenuItem("Velocidade de reprodução");
        foreach (var rate in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0 })
        {
            var rateItem = new ToolStripMenuItem(rate.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "×") { Checked = Math.Abs(_data.VideoPlaybackRate - rate) < 0.001 };
            rateItem.Click += async (_, _) => await SetPageMediaRateAsync(rate);
            speed.DropDownItems.Add(rateItem);
        }
        media.DropDownItems.Add(speed);
        menu.Items.Add(media);
        menu.Items.Add("Gerenciador de vídeos desta página…", null, async (_, _) => await OpenVideoManagerAsync());
        menu.Items.Add("Gerenciador de tarefas  ·  Ctrl+Shift+F", null, (_, _) => OpenTaskManager());
        menu.Items.Add("Gerenciador de processos WebView2…", null, (_, _) => OpenProcessManager());
        menu.Items.Add("Gerenciar extensões…", null, async (_, _) => await ManageExtensionsAsync());
        menu.Items.Add("Como usar Picture-in-Picture…", null, (_, _) => MessageBox.Show(this,
            "Passe o mouse sobre um vídeo compatível. Um botão RX PiP aparecerá sobre o vídeo; clique nele para abrir a janela flutuante.\n\nO recurso depende do suporte HTML Picture-in-Picture do site, das permissões da página e do WebView2 Runtime. Alguns players incorporados ou protegidos podem não permitir a janela flutuante.",
            "Picture-in-Picture — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information));
        menu.Items.Add("Adicionar página à barra lateral…", null, (_, _) => AddCurrentPageToSidebar());
        var sidebar = new ToolStripMenuItem("Mostrar barra lateral") { Checked = _sidebarPanel.Visible, CheckOnClick = true };
        sidebar.CheckedChanged += (_, _) =>
        {
            _sidebarPanel.Visible = sidebar.Checked;
            _data.SidebarVisible = sidebar.Checked;
            BrowserStorage.Save(_data);
        };
        menu.Items.Add(sidebar);
        var adBlock = new ToolStripMenuItem("Bloqueador de anúncios RX") { Checked = _data.AdBlockEnabled, CheckOnClick = true };
        adBlock.CheckedChanged += (_, _) => { _data.AdBlockEnabled = adBlock.Checked; BrowserStorage.Save(_data); SetStatus(adBlock.Checked ? $"Bloqueador RX ativado · {_data.AdBlockLevel}" : "Bloqueador de anúncios desativado."); };
        menu.Items.Add(adBlock);
        menu.Items.Add($"Configurar filtros de anúncios… · {_data.AdBlockLevel}", null, (_, _) => OpenAdBlockerSettings());
        menu.Items.Add("Abrir monitor de privacidade…", null, (_, _) => OpenPrivacyActivityDashboard());
        menu.Items.Add($"Anúncios bloqueados nesta sessão: {_blockedAdRequestsCount}", null, (_, _) => SetStatus($"O RX Browser bloqueou {_blockedAdRequestsCount} requisições de anúncios nesta sessão."));
        menu.Items.Add("Ativar/desativar bloqueio de anúncios neste site", null, (_, _) => ToggleAdBlockForCurrentSite());
        var popupBlock = new ToolStripMenuItem("Bloquear pop-ups automáticos") { Checked = _data.BlockPopups, CheckOnClick = true };
        popupBlock.CheckedChanged += (_, _) =>
        {
            _data.BlockPopups = popupBlock.Checked;
            BrowserStorage.Save(_data);
            SetStatus(popupBlock.Checked ? "Bloqueio inteligente de pop-ups ativado." : "Bloqueio de pop-ups desativado.");
        };
        menu.Items.Add(popupBlock);
        menu.Items.Add(IsCurrentSitePopupAllowed() ? "Remover exceção de pop-ups deste site" : "Permitir pop-ups neste site", null, (_, _) => TogglePopupAllowlistForCurrentSite());
        menu.Items.Add($"Pop-ups bloqueados nesta sessão: {_blockedPopupsCount}", null, (_, _) => SetStatus($"RX bloqueou {_blockedPopupsCount} pop-up(s) automático(s) nesta sessão."));
        menu.Items.Add($"Requisições bloqueadas nesta sessão: {_blockedRequestsCount}", null, (_, _) => SetStatus($"Bloqueador RX: {_blockedRequestsCount} requisições bloqueadas nesta sessão."));
        menu.Items.Add("Reabrir guia fechada  ·  Ctrl+Shift+T", null, async (_, _) => await ReopenClosedTabAsync());
        menu.Items.Add(new ToolStripSeparator());

        var search = new ToolStripMenuItem("Mecanismo de busca");
        foreach (var engine in new[] { "DuckDuckGo", "Google", "Bing" })
        {
            var choice = new ToolStripMenuItem(engine) { Checked = _data.SearchEngine == engine, CheckOnClick = false };
            choice.Click += (_, _) =>
            {
                _data.SearchEngine = engine;
                BrowserStorage.Save(_data);
                SetStatus("Mecanismo de busca: " + engine);
            };
            search.DropDownItems.Add(choice);
        }
        menu.Items.Add(search);

        var restore = new ToolStripMenuItem("Restaurar guias ao iniciar")
        {
            Checked = _data.RestoreLastSession,
            CheckOnClick = true
        };
        restore.CheckedChanged += (_, _) =>
        {
            _data.RestoreLastSession = restore.Checked;
            BrowserStorage.Save(_data);
        };
        menu.Items.Add(restore);

        var zoom = new ToolStripMenuItem($"Zoom  ·  {_data.ZoomPercent}%");
        zoom.DropDownItems.Add("Aumentar", null, (_, _) => ChangeZoom(10));
        zoom.DropDownItems.Add("Diminuir", null, (_, _) => ChangeZoom(-10));
        zoom.DropDownItems.Add("Restaurar 100%", null, (_, _) => SetZoom(100));
        menu.Items.Add(zoom);

        menu.Items.Add("Limpar dados de navegação…", null, async (_, _) => await ClearBrowsingDataAsync());
        menu.Items.Add("Abrir pasta de downloads", null, (_, _) => OpenDownloadsFolder());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Sobre o RX Browser", null, (_, _) => MessageBox.Show(this,
            "RX Browser 3.6.0\n\nNovidades: RX Privacy Monitor com contagens e eventos temporários de bloqueios; RX AdBlock com importação e exportação de listas simples de domínios; alertas heurísticos de phishing registrados no painel; padrões de falsificação ampliados para serviços conhecidos, incluindo marcas brasileiras.\n\nRecursos mantidos: RX Translate, RX Reader Intelligence, RX Tab Manager 2.0, Caderno RX e sincronização seletiva. A interface é própria em C# WinForms e a renderização web utiliza Microsoft Edge WebView2 (Chromium). O SmartScreen do WebView2 continua solicitado para verificação de reputação.",
            "Sobre", MessageBoxButtons.OK, MessageBoxIcon.Information));
        menu.Show(anchor, new Point(0, anchor.Height));
    }

    private void ApplyRestoredTabMetadata(BrowserTab tab, SessionTabSnapshot item)
    {
        tab.IsPinned = item.IsPinned;
        tab.GroupName = item.GroupName;
        if (!string.IsNullOrWhiteSpace(item.Title)) tab.Title = item.Title;
        ApplyTabHeaderStyle(tab);
    }

    private async Task RestoreRemainingTabsAsync(List<SessionTabSnapshot> items, int firstIndex)
    {
        var restored = firstIndex >= 0 ? 1 : 0;
        for (var i = 0; i < items.Count; i++)
        {
            if (i == firstIndex) continue;
            if (_closing || IsDisposed || !IsHandleCreated) return;
            try
            {
                // Pequenas pausas evitam criar vários controles WebView2 no mesmo instante.
                await Task.Delay(110);
                if (_closing || IsDisposed) return;
                var item = items[i];
                var tab = await CreateTabAsync(item.Url, false, false, item.Id);
                ApplyRestoredTabMetadata(tab, item);
                restored++;
            }
            catch (Exception ex)
            {
                if (!_closing) SetStatus("Uma guia da sessão não pôde ser restaurada: " + ex.Message);
            }
        }
        if (_closing || IsDisposed) return;
        SaveSessionSnapshot();
        SetStatus($"Sessão restaurada  •  {restored} guia(s) recuperada(s)");
    }

    private static string NormalizeSafetyKey(string value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return value;
        try { return uri.GetComponents(UriComponents.AbsoluteUri, UriFormat.SafeUnescaped); }
        catch { return uri.ToString(); }
    }

    private void ShowTranslateTargetMenu(Control anchor)
    {
        var menu = new WheelScrollableContextMenuStrip();
        var preferred = _data.PreferredTranslationLanguage;
        var preferredName = TranslationLanguageName(preferred);
        menu.Items.Add($"Traduzir página para {preferredName} · padrão", null,
            async (_, _) => await TranslateCurrentPageAsync(preferred, preferredName));
        menu.Items.Add("Definir idioma de destino…", null, (_, _) => ShowTranslationLanguageMenu(anchor));
        menu.Items.Add("Idioma de origem: " + TranslationSourceLanguageName(_data.TranslationSourceLanguage), null,
            (_, _) => ShowTranslationSourceLanguageMenu(anchor));
        menu.Items.Add(new ToolStripSeparator());
        foreach (var choice in TranslationLanguages())
        {
            var item = new ToolStripMenuItem(choice.Name) { Checked = preferred == choice.Code };
            item.Click += async (_, _) => await TranslateCurrentPageAsync(choice.Code, choice.Name);
            menu.Items.Add(item);
        }
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add($"Traduzir seleção para {preferredName}", null,
            async (_, _) => await TranslateSelectedTextAsync(preferred, preferredName));
        menu.Items.Add("Traduzir seleção para inglês", null, async (_, _) => await TranslateSelectedTextAsync("en", "Inglês"));
        menu.Show(anchor, new Point(0, anchor.Height));
    }

    private void ShowTranslationLanguageMenu(Control anchor)
    {
        var menu = new WheelScrollableContextMenuStrip();
        foreach (var choice in TranslationLanguages())
        {
            var item = new ToolStripMenuItem(choice.Name) { Checked = _data.PreferredTranslationLanguage == choice.Code };
            item.Click += (_, _) =>
            {
                _data.PreferredTranslationLanguage = choice.Code;
                _translateButton.AccessibleDescription = "Traduzir para " + choice.Name;
                BrowserStorage.Save(_data);
                SetStatus("Idioma padrão de tradução definido: " + choice.Name + ".");
            };
            menu.Items.Add(item);
        }
        menu.Show(anchor, new Point(0, anchor.Height));
    }

    private void ShowTranslationSourceLanguageMenu(Control anchor)
    {
        var menu = new WheelScrollableContextMenuStrip();
        var choices = new[] { ("auto", "Detectar automaticamente") }.Concat(TranslationLanguages()).ToArray();
        foreach (var choice in choices)
        {
            var item = new ToolStripMenuItem(choice.Item2) { Checked = _data.TranslationSourceLanguage == choice.Item1 };
            item.Click += (_, _) =>
            {
                _data.TranslationSourceLanguage = choice.Item1;
                BrowserStorage.Save(_data);
                SetStatus("Idioma de origem da tradução: " + choice.Item2 + ".");
            };
            menu.Items.Add(item);
        }
        menu.Show(anchor, new Point(0, anchor.Height));
    }

    private static string TranslationSourceLanguageName(string code) => code == "auto"
        ? "detecção automática"
        : TranslationLanguageName(code);

    private static (string Code, string Name)[] TranslationLanguages() =>
    [
        ("pt", "Português (Brasil)"), ("en", "Inglês"), ("es", "Espanhol"),
        ("fr", "Francês"), ("de", "Alemão"), ("it", "Italiano"),
        ("ja", "Japonês"), ("zh-CN", "Chinês simplificado")
    ];

    private static string TranslationLanguageName(string code) =>
        TranslationLanguages().FirstOrDefault(item => item.Code == code).Name ?? "Português (Brasil)";

    private async Task OpenReaderModeAsync()
    {
        var tab = _activeTab;
        var core = tab?.View.CoreWebView2;
        if (tab is null || core is null || !IsHttpUrl(tab.View.Source?.ToString()))
        {
            SetStatus("Abra um artigo ou página web antes de ativar o modo leitor.");
            return;
        }

        const string script = """
            (() => {
              const hidden = node => {
                if (!node || node.nodeType !== 1) return false;
                const style = getComputedStyle(node);
                return style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0 ||
                  node.getAttribute('aria-hidden') === 'true';
              };
              const unwanted = 'script,style,noscript,nav,header,footer,aside,form,button,iframe,svg,canvas,video,audio,dialog,[role="navigation"],[role="complementary"],[aria-hidden="true"]';
              const noisePattern = /(cookie|consent|newsletter|subscribe|advert|ad-slot|social|share|breadcrumb|related|recommend|outbrain|taboola|popup|modal|paywall)/i;
              const prepare = root => {
                const clone = root.cloneNode(true);
                clone.querySelectorAll(unwanted).forEach(node => node.remove());
                clone.querySelectorAll('*').forEach(node => {
                  const marker = (node.id || '') + ' ' + (typeof node.className === 'string' ? node.className : '') + ' ' + (node.getAttribute('role') || '');
                  if (noisePattern.test(marker) || hidden(node)) node.remove();
                });
                return clone;
              };
              const textOf = node => (node.innerText || node.textContent || '')
                .replace(/\u00a0/g, ' ').replace(/[\t ]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
              const candidates = Array.from(document.querySelectorAll('article, main, [role="main"], .article, .post-content, .entry-content, .story-body, .article-body'));
              let best = null, bestScore = -1;
              for (const node of candidates) {
                if (hidden(node)) continue;
                const clone = prepare(node);
                const text = textOf(clone);
                const words = text.split(/\s+/).filter(Boolean).length;
                const paragraphs = clone.querySelectorAll('p').length;
                const links = Array.from(clone.querySelectorAll('a')).reduce((sum, a) => sum + textOf(a).length, 0);
                const linkDensity = text.length ? links / text.length : 1;
                const score = Math.min(words, 5000) + paragraphs * 24 - linkDensity * 900 + (node.matches('article,main,[role="main"]') ? 180 : 0);
                if (text.length >= 180 && score > bestScore) { best = clone; bestScore = score; }
              }
              if (!best) best = prepare(document.body || document.documentElement);
              const blocks = [];
              const blockNodes = Array.from(best.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,pre'));
              for (const node of blockNodes) {
                const text = textOf(node);
                if (text.length < (node.matches('h1,h2,h3,h4') ? 2 : 28)) continue;
                const links = Array.from(node.querySelectorAll('a')).reduce((sum, a) => sum + textOf(a).length, 0);
                if (text.length && links / text.length > 0.65) continue;
                const type = /^H[1-4]$/.test(node.tagName) ? 'heading' : node.tagName === 'LI' ? 'list' : node.tagName === 'BLOCKQUOTE' ? 'quote' : 'paragraph';
                blocks.push({ type, level: Number(node.tagName.slice(1)) || 0, text });
              }
              let articleText = blocks.map(block => block.text).join('\n\n');
              if (articleText.length < 180) articleText = textOf(best);
              const title = document.querySelector('meta[property="og:title"]')?.content || document.querySelector('h1')?.innerText || document.title || 'Leitura';
              const author = document.querySelector('meta[name="author"]')?.content || document.querySelector('[rel="author"]')?.innerText || document.querySelector('[class*="author"], [itemprop="author"]')?.innerText || '';
              const words = articleText.split(/\s+/).filter(Boolean).length;
              return JSON.stringify({ title: title.trim(), author: author.trim().slice(0, 180), url: location.href,
                text: articleText.slice(0, 120000), words, readingMinutes: Math.max(1, Math.ceil(words / 220)) });
            })()
            """;
        try
        {
            var raw = await core.ExecuteScriptAsync(script);
            var payload = JsonSerializer.Deserialize<string>(raw);
            if (string.IsNullOrWhiteSpace(payload)) throw new InvalidOperationException("A página não retornou texto para leitura.");
            using var document = JsonDocument.Parse(payload);
            var root = document.RootElement;
            var title = root.TryGetProperty("title", out var titleValue) ? titleValue.GetString() ?? "Leitura" : "Leitura";
            var url = root.TryGetProperty("url", out var urlValue) ? urlValue.GetString() ?? string.Empty : string.Empty;
            var text = root.TryGetProperty("text", out var textValue) ? textValue.GetString() ?? string.Empty : string.Empty;
            var author = root.TryGetProperty("author", out var authorValue) ? authorValue.GetString() ?? string.Empty : string.Empty;
            var readingMinutes = root.TryGetProperty("readingMinutes", out var minutesValue) && minutesValue.TryGetInt32(out var minutes) ? minutes : Math.Max(1, (int)Math.Ceiling(text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries).Length / 220d));
            if (text.Length < 80) throw new InvalidOperationException("Não foi possível identificar um artigo com texto suficiente nesta página.");
            using var reader = new ReaderModeForm(title, url, text, author, readingMinutes);
            reader.ShowDialog(this);
            SetStatus("Modo leitor fechado. A página original permaneceu aberta.");
        }
        catch (Exception ex) { SetStatus("Não foi possível ativar o modo leitor: " + ex.Message); }
    }

    private async Task TranslateSelectedTextAsync(string targetLanguage, string languageName)
    {
        var sourceTab = _activeTab;
        var core = sourceTab?.View.CoreWebView2;
        if (core is null) return;
        try
        {
            var raw = await core.ExecuteScriptAsync("String(window.getSelection ? window.getSelection().toString() : '').slice(0, 4000)");
            var selected = JsonSerializer.Deserialize<string>(raw)?.Trim();
            if (string.IsNullOrWhiteSpace(selected))
            {
                SetStatus("Selecione um trecho de texto na página antes de traduzir.");
                return;
            }
            var consent = MessageBox.Show(this,
                $"O texto selecionado será enviado ao Google Tradutor para tradução em {languageName}. Não envie senhas, informações privadas ou conteúdo confidencial.\n\nDeseja continuar?",
                "Traduzir seleção — serviço externo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (consent != DialogResult.Yes) return;
            var url = "https://translate.google.com/?sl=" + Uri.EscapeDataString(_data.TranslationSourceLanguage) +
                "&tl=" + Uri.EscapeDataString(targetLanguage) + "&text=" + Uri.EscapeDataString(selected) + "&op=translate";
            await CreateTabAsync(url, true, sourceTab?.IsPrivate == true);
            SetStatus("Texto selecionado enviado ao Google Tradutor em uma nova guia.");
        }
        catch (Exception ex) { SetStatus("Não foi possível preparar a tradução do trecho: " + ex.Message); }
    }

    private async Task TranslateCurrentPageAsync(string targetLanguage, string languageName)
    {
        var sourceTab = _activeTab;
        var typedAddress = _addressBox.Text.Trim();
        string? typedCandidate = null;
        if (Uri.TryCreate(typedAddress, UriKind.Absolute, out var typedUri) && typedUri.Scheme is "http" or "https")
            typedCandidate = typedUri.ToString();
        else if (!string.IsNullOrWhiteSpace(typedAddress) && !typedAddress.Contains(' ') && typedAddress.Contains('.') &&
                 Uri.TryCreate("https://" + typedAddress, UriKind.Absolute, out var typedHost) && typedHost.Scheme == "https")
            typedCandidate = typedHost.ToString();
        var sourceUrl = IsHttpUrl(typedCandidate) ? typedCandidate : sourceTab?.View.Source?.ToString();
        if (sourceTab is null || !IsHttpUrl(sourceUrl))
        {
            SetStatus("Abra uma página HTTP ou HTTPS para traduzir.");
            return;
        }

        using var setup = new TranslationSetupForm(sourceUrl!, _data.TranslationSourceLanguage,
            targetLanguage, TranslationLanguages());
        if (setup.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            // Google Translate's current website workflow asks the user to paste the URL in its Websites tab.
            // The source URL is copied only after the user accepts the disclosure in TranslationSetupForm.
            Clipboard.SetText(sourceUrl!);
            _data.TranslationSourceLanguage = setup.SourceLanguageCode;
            _data.PreferredTranslationLanguage = setup.TargetLanguageCode;
            BrowserStorage.Save(_data);
            _translateButton.AccessibleDescription = "Traduzir para " + setup.TargetLanguageName;

            var translateUrl = "https://translate.google.com/?hl=pt-BR&sl=" + Uri.EscapeDataString(setup.SourceLanguageCode) +
                "&tl=" + Uri.EscapeDataString(setup.TargetLanguageCode) + "&op=websites";
            await CreateTabAsync(translateUrl, true, sourceTab.IsPrivate);
            SetStatus($"Endereço copiado. No Google Tradutor, abra Sites, cole o endereço e inicie a tradução para {setup.TargetLanguageName}.");
        }
        catch (Exception ex)
        {
            SetStatus("Não foi possível preparar a tradução: " + ex.Message);
        }
    }

    private async Task CaptureFullPageAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        using var dialog = new SaveFileDialog
        {
            Title = "Capturar página inteira — RX Browser",
            Filter = "Imagem PNG (*.png)|*.png",
            FileName = "RX-Captura-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".png",
            AddExtension = true,
            DefaultExt = "png"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            await core.CallDevToolsProtocolMethodAsync("Page.enable", "{}");
            var metricsJson = await core.CallDevToolsProtocolMethodAsync("Page.getLayoutMetrics", "{}");
            using var metrics = JsonDocument.Parse(metricsJson);
            var root = metrics.RootElement;
            var content = root.TryGetProperty("cssContentSize", out var cssSize)
                ? cssSize : root.GetProperty("contentSize");
            var width = Math.Ceiling(content.GetProperty("width").GetDouble());
            var height = Math.Ceiling(content.GetProperty("height").GetDouble());
            if (width < 1 || height < 1 || width > 12000 || height > 30000 || width * height > 100_000_000)
                throw new InvalidOperationException("A página é muito grande para uma única imagem. Tente capturar uma parte menor ou usar a captura normal do Windows.");

            var request = new Dictionary<string, object>
            {
                ["format"] = "png",
                ["fromSurface"] = true,
                ["captureBeyondViewport"] = true,
                ["clip"] = new Dictionary<string, object>
                {
                    ["x"] = 0,
                    ["y"] = 0,
                    ["width"] = width,
                    ["height"] = height,
                    ["scale"] = 1
                }
            };
            var captureJson = await core.CallDevToolsProtocolMethodAsync("Page.captureScreenshot", JsonSerializer.Serialize(request));
            using var capture = JsonDocument.Parse(captureJson);
            var base64 = capture.RootElement.GetProperty("data").GetString();
            if (string.IsNullOrWhiteSpace(base64)) throw new InvalidOperationException("O Chromium não retornou os dados da captura.");
            var bytes = Convert.FromBase64String(base64);
            await File.WriteAllBytesAsync(dialog.FileName, bytes);
            SetStatus($"Página inteira capturada: {Path.GetFileName(dialog.FileName)} ({width:0} × {height:0}).");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this,
                "Não foi possível capturar a página inteira. Alguns conteúdos protegidos, páginas extensas ou versões do WebView2 podem limitar a captura.\n\nDetalhe: " + ex.Message,
                "Captura de página — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task OpenSpeechSettingsAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        var voices = new List<SpeechVoiceOption>();
        try
        {
            for (var attempt = 0; attempt < 4 && voices.Count == 0; attempt++)
            {
                await Task.Delay(250);
                var raw = await core.ExecuteScriptAsync("JSON.stringify((window.speechSynthesis?.getVoices?.() || []).map(v => ({name:v.name,language:v.lang})))");
                var json = JsonSerializer.Deserialize<string>(raw) ?? "[]";
                using var parsed = JsonDocument.Parse(json);
                foreach (var item in parsed.RootElement.EnumerateArray())
                {
                    var name = item.TryGetProperty("name", out var n) ? n.GetString() ?? string.Empty : string.Empty;
                    var lang = item.TryGetProperty("language", out var l) ? l.GetString() ?? string.Empty : string.Empty;
                    if (!string.IsNullOrWhiteSpace(name) && voices.All(v => !string.Equals(v.Name, name, StringComparison.OrdinalIgnoreCase)))
                        voices.Add(new SpeechVoiceOption(name, lang));
                }
            }
        }
        catch { /* A voz padrão ainda pode funcionar se o WebView2 não listar as vozes. */ }

        using var form = new SpeechSettingsForm(voices, _data.SpeechVoiceName, _data.SpeechRate, _data.SpeechPitch);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.SpeechVoiceName = form.VoiceName;
        _data.SpeechVoiceLanguage = form.VoiceLanguage;
        _data.SpeechRate = form.Rate;
        _data.SpeechPitch = form.Pitch;
        BrowserStorage.Save(_data);
        SetStatus("Preferências de voz e velocidade salvas neste perfil.");
    }

    private async Task ReadActivePageAloudAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        var configJson = JsonSerializer.Serialize(new
        {
            voiceName = _data.SpeechVoiceName,
            voiceLanguage = _data.SpeechVoiceLanguage,
            rate = _data.SpeechRate,
            pitch = _data.SpeechPitch
        });
        var script = """
            (() => {
              try {
                if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') return 'unsupported';
                const config = __RX_SPEECH_CONFIG__;
                const root = document.querySelector('main, article, [role="main"]') || document.body;
                const text = (root?.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 80000);
                if (!text) return 'empty';
                window.speechSynthesis.cancel();
                const voices = window.speechSynthesis.getVoices() || [];
                const voice = voices.find(v => v.name === config.voiceName) ||
                  (config.voiceLanguage ? voices.find(v => v.lang.toLowerCase() === config.voiceLanguage.toLowerCase()) : null);
                const language = config.voiceLanguage || document.documentElement.lang || 'pt-BR';
                const chunks = text.match(/[\s\S]{1,3200}(?:\s|$)/g) || [text];
                for (const chunk of chunks) {
                  const utterance = new SpeechSynthesisUtterance(chunk);
                  utterance.lang = language;
                  utterance.rate = config.rate;
                  utterance.pitch = config.pitch;
                  if (voice) utterance.voice = voice;
                  window.speechSynthesis.speak(utterance);
                }
                return voice ? 'started:' + voice.name : 'started:default';
              } catch (_) { return 'error'; }
            })();
            """.Replace("__RX_SPEECH_CONFIG__", configJson);
        try
        {
            var result = await core.ExecuteScriptAsync(script);
            if (result.Contains("unsupported", StringComparison.OrdinalIgnoreCase))
                SetStatus("A leitura em voz alta não está disponível neste WebView2.");
            else if (result.Contains("empty", StringComparison.OrdinalIgnoreCase))
                SetStatus("Não encontrei texto legível nesta página.");
            else if (result.Contains("error", StringComparison.OrdinalIgnoreCase))
                SetStatus("O mecanismo de voz não conseguiu iniciar a leitura.");
            else
                SetStatus("Leitura iniciada com as preferências de voz RX. Use o menu Mais para pausar ou parar.");
        }
        catch (Exception ex) { SetStatus("Não foi possível iniciar a leitura: " + ex.Message); }
    }

    private async Task ControlSpeechAsync(string action)
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        var command = action switch
        {
            "pause" => "window.speechSynthesis?.pause();",
            "resume" => "window.speechSynthesis?.resume();",
            _ => "window.speechSynthesis?.cancel();"
        };
        try
        {
            await core.ExecuteScriptAsync(command);
            SetStatus(action switch
            {
                "pause" => "Leitura pausada.",
                "resume" => "Leitura retomada.",
                _ => "Leitura interrompida."
            });
        }
        catch (Exception ex) { SetStatus("Controle de voz indisponível: " + ex.Message); }
    }

    private const string RegionCaptureOverlayScript = """
        (() => {
          try {
            document.getElementById('__rx_region_capture_overlay')?.remove();
            const overlay = document.createElement('div');
            overlay.id = '__rx_region_capture_overlay';
            overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(5,12,20,.28);cursor:crosshair;touch-action:none;user-select:none;';
            const box = document.createElement('div');
            box.style.cssText = 'position:absolute;border:2px solid #23cde6;background:rgba(35,205,230,.12);box-shadow:0 0 0 99999px rgba(0,0,0,.22);display:none;pointer-events:none;';
            const hint = document.createElement('div');
            hint.textContent = 'Arraste para selecionar uma região  •  Esc para cancelar';
            hint.style.cssText = 'position:absolute;top:14px;left:50%;transform:translateX(-50%);padding:9px 13px;border-radius:9px;background:#111d2b;color:#eaf8ff;border:1px solid #23cde6;font:600 12px Segoe UI,Arial;white-space:nowrap;';
            overlay.append(box, hint);
            (document.body || document.documentElement).appendChild(overlay);
            let startX = 0, startY = 0, active = false;
            const cleanup = () => { overlay.remove(); window.removeEventListener('keydown', onKey, true); };
            const post = data => { try { window.chrome?.webview?.postMessage({action:'rx-region-capture', ...data}); } catch (_) {} };
            const onKey = event => { if (event.key === 'Escape') { event.preventDefault(); cleanup(); post({cancelled:true}); } };
            window.addEventListener('keydown', onKey, true);
            overlay.addEventListener('pointerdown', event => {
              if (event.target === hint) return;
              event.preventDefault(); event.stopPropagation();
              active = true; startX = event.clientX; startY = event.clientY;
              box.style.display = 'block'; box.style.left = startX + 'px'; box.style.top = startY + 'px'; box.style.width = '0'; box.style.height = '0';
              overlay.setPointerCapture?.(event.pointerId);
            }, true);
            overlay.addEventListener('pointermove', event => {
              if (!active) return;
              event.preventDefault(); event.stopPropagation();
              const left = Math.min(startX,event.clientX), top = Math.min(startY,event.clientY);
              box.style.left = left + 'px'; box.style.top = top + 'px';
              box.style.width = Math.abs(event.clientX-startX) + 'px'; box.style.height = Math.abs(event.clientY-startY) + 'px';
            }, true);
            overlay.addEventListener('pointerup', event => {
              if (!active) return;
              event.preventDefault(); event.stopPropagation(); active = false;
              const x = Math.min(startX,event.clientX), y = Math.min(startY,event.clientY);
              const width = Math.abs(event.clientX-startX), height = Math.abs(event.clientY-startY);
              cleanup();
              if (width < 8 || height < 8) post({cancelled:true});
              else post({x,y,width,height,devicePixelRatio:window.devicePixelRatio || 1});
            }, true);
          } catch (_) { try { window.chrome?.webview?.postMessage({action:'rx-region-capture',cancelled:true}); } catch (_) {} }
        })();
        """;

    private async Task StartRegionCaptureAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        try
        {
            _regionCaptureActive = true;
            await core.ExecuteScriptAsync(RegionCaptureOverlayScript);
            SetStatus("Selecione a área da página arrastando o mouse. Pressione Esc para cancelar.");
        }
        catch (Exception ex)
        {
            _regionCaptureActive = false;
            SetStatus("Não foi possível iniciar a captura de região: " + ex.Message);
        }
    }

    private async Task CaptureRegionAsync(BrowserTab tab, RectangleF rect)
    {
        var core = tab.View.CoreWebView2;
        if (core is null || rect.Width < 8 || rect.Height < 8) return;
        using var dialog = new SaveFileDialog
        {
            Title = "Salvar região capturada — RX Browser",
            Filter = "Imagem PNG (*.png)|*.png",
            FileName = "RX-Regiao-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".png",
            AddExtension = true,
            DefaultExt = "png"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            await core.CallDevToolsProtocolMethodAsync("Page.enable", "{}");
            var metricsJson = await core.CallDevToolsProtocolMethodAsync("Page.getLayoutMetrics", "{}");
            using var metrics = JsonDocument.Parse(metricsJson);
            var viewport = metrics.RootElement.TryGetProperty("cssVisualViewport", out var visual)
                ? visual : metrics.RootElement.GetProperty("cssLayoutViewport");
            var offsetX = viewport.TryGetProperty("pageX", out var px) ? px.GetDouble() : 0d;
            var offsetY = viewport.TryGetProperty("pageY", out var py) ? py.GetDouble() : 0d;
            var x = Math.Max(0, rect.X + offsetX);
            var y = Math.Max(0, rect.Y + offsetY);
            var width = Math.Max(1, rect.Width);
            var height = Math.Max(1, rect.Height);
            if (width > 8000 || height > 8000 || width * height > 30_000_000)
                throw new InvalidOperationException("A região selecionada é muito grande. Selecione uma área menor.");
            var request = new Dictionary<string, object>
            {
                ["format"] = "png", ["fromSurface"] = true, ["captureBeyondViewport"] = false,
                ["clip"] = new Dictionary<string, object> { ["x"] = x, ["y"] = y, ["width"] = width, ["height"] = height, ["scale"] = 1 }
            };
            var resultJson = await core.CallDevToolsProtocolMethodAsync("Page.captureScreenshot", JsonSerializer.Serialize(request));
            using var result = JsonDocument.Parse(resultJson);
            var base64 = result.RootElement.GetProperty("data").GetString();
            if (string.IsNullOrWhiteSpace(base64)) throw new InvalidOperationException("O WebView2 não retornou a imagem.");
            await File.WriteAllBytesAsync(dialog.FileName, Convert.FromBase64String(base64));
            SetStatus("Região capturada: " + Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível capturar esta região. Páginas protegidas ou certas superfícies de mídia podem limitar capturas.\n\n" + ex.Message,
                "Captura de região — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private static string BuildMediaPlaybackRateScript(double rate)
    {
        var rateJson = JsonSerializer.Serialize(Math.Clamp(rate, 0.25, 2.0));
        return """
            (() => {
              try {
                const preferredRate = __RX_RATE__;
                const applyRate = root => {
                  (root || document).querySelectorAll?.('video,audio').forEach(media => {
                    try { media.playbackRate = preferredRate; } catch (_) { }
                  });
                };
                document.addEventListener('loadedmetadata', event => {
                  if (event.target instanceof HTMLMediaElement) {
                    try { event.target.playbackRate = preferredRate; } catch (_) { }
                  }
                }, true);
                const observer = new MutationObserver(records => {
                  for (const record of records) for (const node of record.addedNodes) {
                    if (node.nodeType === 1) {
                      if (node.matches?.('video,audio')) { try { node.playbackRate = preferredRate; } catch (_) { } }
                      applyRate(node);
                    }
                  }
                });
                observer.observe(document.documentElement, {subtree:true, childList:true});
                applyRate(document);
              } catch (_) { }
            })();
            """.Replace("__RX_RATE__", rateJson);
    }

    private async Task ControlPageMediaAsync(string action)
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        var script = """
            (() => {
              const media = [...document.querySelectorAll('video,audio')];
              if (!media.length) return 'none';
              if ('__ACTION__' === 'pause') media.forEach(m => m.pause());
              else if ('__ACTION__' === 'play') media.forEach(m => { const p=m.play(); if (p?.catch) p.catch(()=>{}); });
              else if ('__ACTION__' === 'mute') { const next = !media.every(m => m.muted); media.forEach(m => m.muted = next); }
              return String(media.length);
            })();
            """.Replace("__ACTION__", action);
        try
        {
            var result = await core.ExecuteScriptAsync(script);
            if (result.Contains("none", StringComparison.OrdinalIgnoreCase)) SetStatus("Nenhum elemento de áudio ou vídeo foi encontrado nesta página.");
            else SetStatus(action switch
            {
                "play" => "Comando de reprodução enviado. Alguns sites exigem clicar no próprio player.",
                "pause" => "Reprodução pausada nos elementos de mídia desta página.",
                _ => "Estado de áudio alternado nos elementos de mídia desta página."
            });
        }
        catch (Exception ex) { SetStatus("Não foi possível controlar a mídia: " + ex.Message); }
    }

    private async Task SetPageMediaRateAsync(double rate)
    {
        rate = Math.Clamp(rate, 0.25, 2.0);
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        try
        {
            var rateJson = JsonSerializer.Serialize(rate);
            var result = await core.ExecuteScriptAsync("(() => { const list=[...document.querySelectorAll('video,audio')]; list.forEach(m=>m.playbackRate=" + rateJson + "); return String(list.length); })()");
            var countText = JsonSerializer.Deserialize<string>(result) ?? "0";
            int.TryParse(countText, out var mediaCount);
            _data.VideoPlaybackRate = rate;
            BrowserStorage.Save(_data);
            SetStatus(mediaCount == 0 ? $"Velocidade {rate:0.##}× salva; nenhum player de mídia foi localizado." : $"Velocidade de reprodução ajustada para {rate:0.##}× em {mediaCount} elemento(s) de mídia.");
        }
        catch (Exception ex) { SetStatus("Não foi possível ajustar a velocidade: " + ex.Message); }
    }

    private List<BrowserProcessMetric> ReadWebViewProcessMetrics()
    {
        var environments = new[] { _environment, _privateEnvironment }.Where(x => x is not null).Cast<CoreWebView2Environment>().ToList();
        var results = new Dictionary<int, BrowserProcessMetric>();
        foreach (var environment in environments)
        {
            try
            {
                foreach (var info in environment.GetProcessInfos())
                {
                    try
                    {
                        using var process = Process.GetProcessById(info.ProcessId);
                        process.Refresh();
                        results[info.ProcessId] = new BrowserProcessMetric(info.ProcessId, info.Kind.ToString(), process.PrivateMemorySize64, process.WorkingSet64);
                    }
                    catch { }
                }
            }
            catch { }
        }
        return results.Values.ToList();
    }

    private void OpenProcessManager()
    {
        using var form = new ProcessManagerForm(ReadWebViewProcessMetrics, TerminateWebViewProcess);
        form.ShowDialog(this);
    }

    private void TerminateWebViewProcess(int processId)
    {
        try
        {
            var metric = ReadWebViewProcessMetrics().FirstOrDefault(p => p.ProcessId == processId);
            if (metric is null || string.Equals(metric.Kind, "Browser", StringComparison.OrdinalIgnoreCase))
            {
                SetStatus("O processo principal do WebView2 é protegido contra encerramento neste painel.");
                return;
            }
            using var process = Process.GetProcessById(processId);
            if (!process.ProcessName.Contains("msedgewebview2", StringComparison.OrdinalIgnoreCase))
            {
                SetStatus("O processo selecionado não foi reconhecido como um processo WebView2.");
                return;
            }
            process.Kill();
            SetStatus($"Solicitado encerramento do processo WebView2 PID {processId}. Algumas guias podem precisar ser recarregadas.");
        }
        catch (Exception ex) { SetStatus("Não foi possível encerrar o processo: " + ex.Message); }
    }

    private void CheckCurrentAddressSafety()
    {
        var address = _activeTab?.View.Source?.ToString();
        var warning = _data.PhishingProtectionEnabled ? UrlSafetyAssessment.GetWarning(address ?? string.Empty, _data.PhishingProtectionLevel, _data.PhishingAllowlist) : null;
        if (warning is null)
        {
            MessageBox.Show(this,
                "Nenhum dos padrões locais de URL suspeita foi identificado. Isso não significa que o site seja seguro. O Microsoft Defender SmartScreen permanece habilitado no WebView2 e pode exibir alertas de reputação.",
                "Verificação de endereço — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        MessageBox.Show(this, warning + "\n\nEsta é uma análise local de formato do endereço, não uma verificação antivírus nem uma lista atualizada de sites maliciosos. O SmartScreen é a verificação de reputação principal.",
            "Verificação de endereço — RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    private void OpenTaskManager()
    {
        using var form = new TaskManagerForm(
            () => _tabs.ToList(),
            _activeTab,
            SelectTab,
            CloseTabAsync,
            tab =>
            {
                tab.HasCrashed = false;
                tab.LastProcessFailure = null;
                tab.View.CoreWebView2?.Reload();
            });
        form.ShowDialog(this);
    }

    private bool IsPopupHostAllowed(string host)
    {
        if (string.IsNullOrWhiteSpace(host)) return false;
        return _data.PopupAllowlist.Any(allowed =>
            string.Equals(host, allowed, StringComparison.OrdinalIgnoreCase) ||
            host.EndsWith("." + allowed, StringComparison.OrdinalIgnoreCase));
    }

    private bool IsCurrentSitePopupAllowed()
    {
        var host = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var uri) ? uri.Host : string.Empty;
        return IsPopupHostAllowed(host);
    }

    private void TogglePopupAllowlistForCurrentSite()
    {
        var host = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var uri) ? uri.Host.ToLowerInvariant() : string.Empty;
        if (string.IsNullOrWhiteSpace(host) || Uri.CheckHostName(host) == UriHostNameType.Unknown)
        {
            SetStatus("Abra primeiro um site para configurar a exceção de pop-ups.");
            return;
        }
        var matchingRule = _data.PopupAllowlist
            .Where(item => string.Equals(host, item, StringComparison.OrdinalIgnoreCase) || host.EndsWith("." + item, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(item => item.Length)
            .FirstOrDefault();
        if (matchingRule is not null)
        {
            _data.PopupAllowlist.Remove(matchingRule);
            SetStatus("Exceção de pop-ups removida: " + matchingRule + ". Sites subordinados também podem ser afetados.");
        }
        else
        {
            _data.PopupAllowlist.Add(host);
            _data.PopupAllowlist = _data.PopupAllowlist.Distinct(StringComparer.OrdinalIgnoreCase).Take(500).ToList();
            SetStatus("Pop-ups permitidos para " + host + " e seus subdomínios.");
        }
        BrowserStorage.Save(_data);
    }

    private void OpenTabManager()
    {
        if (_tabs.Count == 0) return;
        using var form = new TabManagerForm(_tabs.ToList(), _activeTab, SelectTab, CloseTabAsync);
        form.ShowDialog(this);
    }

    private void OpenTabSearch()
    {
        if (_tabs.Count == 0) return;
        using var form = new TabSearchForm(_tabs.ToList(), _activeTab, SelectTab);
        form.ShowDialog(this);
    }

    private void OpenWorkspaceManager()
    {
        if (!string.IsNullOrWhiteSpace(_data.WorkspaceSyncFolder) && Directory.Exists(_data.WorkspaceSyncFolder))
        {
            try
            {
                WorkspaceSyncStore.Sync(_data);
                BrowserStorage.Save(_data);
            }
            catch (Exception ex) { SetStatus("Não foi possível sincronizar espaços: " + ex.Message); }
        }

        using var form = new WorkspaceManagerForm(_data.Workspaces, CaptureWorkspaceTabs, OpenWorkspaceAsync, _data.WorkspaceSyncFolder);
        form.ShowDialog(this);
        _data.Workspaces = form.ResultWorkspaces
            .Where(workspace => workspace.Tabs.Count > 0)
            .OrderByDescending(workspace => workspace.UpdatedUtc)
            .Take(30)
            .ToList();
        _data.WorkspaceSyncFolder = form.SyncFolder;
        _data.WorkspaceSyncEnabled = !string.IsNullOrWhiteSpace(form.SyncFolder);
        RefreshSyncMaintenanceTimer();
        try
        {
            if (!string.IsNullOrWhiteSpace(_data.WorkspaceSyncFolder))
            {
                Directory.CreateDirectory(_data.WorkspaceSyncFolder);
                var synced = WorkspaceSyncStore.Sync(_data);
                SetStatus($"Espaços de trabalho salvos e sincronizados: {synced}.");
            }
            else SetStatus($"Espaços de trabalho salvos: {_data.Workspaces.Count}.");
        }
        catch (Exception ex) { SetStatus("Espaços salvos localmente; sincronização indisponível: " + ex.Message); }
        BrowserStorage.Save(_data);
    }

    private List<WorkspaceTabRecord> CaptureWorkspaceTabs()
    {
        return _tabs
            .Where(tab => !tab.IsPrivate && !tab.IsPasswordProtected && !tab.View.IsDisposed)
            .Select(tab => new WorkspaceTabRecord
            {
                Url = tab.View.Source?.ToString() ?? string.Empty,
                Title = string.IsNullOrWhiteSpace(tab.Title) ? "Nova guia" : tab.Title,
                IsPinned = tab.IsPinned,
                GroupName = tab.GroupName
            })
            .Where(item => IsHttpUrl(item.Url))
            .Take(20)
            .ToList();
    }

    private async Task<bool> OpenWorkspaceAsync(WorkspaceRecord workspace)
    {
        var validTabs = workspace.Tabs
            .Where(item => item is not null && IsHttpUrl(item.Url))
            .Take(20)
            .ToList();
        if (validTabs.Count == 0)
        {
            MessageBox.Show(this, "Este espaço não contém endereços HTTP ou HTTPS válidos.",
                "Espaço de trabalho", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return false;
        }

        var answer = MessageBox.Show(this,
            $"Abrir o espaço ‘{workspace.Name}’ com {validTabs.Count} guia(s)?\n\nAs guias que já estão abertas serão mantidas.",
            "Abrir espaço de trabalho — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (answer != DialogResult.Yes) return false;

        var opened = new List<BrowserTab>();
        try
        {
            foreach (var item in validTabs)
            {
                var tab = await CreateTabAsync(item.Url, false);
                tab.IsPinned = item.IsPinned;
                tab.GroupName = string.IsNullOrWhiteSpace(item.GroupName) ? null : item.GroupName;
                if (!string.IsNullOrWhiteSpace(item.Title)) tab.Title = item.Title;
                ApplyTabHeaderStyle(tab);
                opened.Add(tab);
            }
            if (opened.Count == 0) return false;
            var orderedTabs = _tabs.OrderByDescending(tab => tab.IsPinned).ToList();
            _tabs.Clear();
            _tabs.AddRange(orderedTabs);
            for (var index = 0; index < _tabs.Count; index++)
            {
                _tabStrip.Controls.SetChildIndex(_tabs[index].Header, index);
                ApplyTabHeaderStyle(_tabs[index]);
            }
            SelectTab(opened[0]);
            SaveSessionSnapshot();
            SetStatus($"Espaço ‘{workspace.Name}’ aberto  •  {opened.Count} guia(s)");
            return true;
        }
        catch (Exception ex)
        {
            if (opened.Count > 0) SelectTab(opened[0]);
            MessageBox.Show(this, "Não foi possível abrir todas as guias do espaço.\n\n" + ex.Message,
                "Falha ao abrir espaço", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return opened.Count > 0;
        }
    }

    private void OpenControlCenter()
    {
        var profile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        using var form = new ControlCenterForm(
            profile?.Name ?? "Pessoal",
            _tabs.Count,
            _tabs.Count(tab => tab.IsPrivate),
            _data.Favorites.Count,
            _data.SavedSessions.Count,
            _downloads.Count,
            _blockedRequestsCount + _blockedAdRequestsCount + _blockedPopupsCount,
            _data.ControlCenterVisibleActions,
            _data.ControlCenterActionOrder,
            _data.ControlCenterAccentHex,
            _data.ControlCenterColumns);
        if (form.ShowDialog(this) == DialogResult.OK && !string.IsNullOrWhiteSpace(form.SelectedAction))
            RunControlCenterAction(form.SelectedAction);
    }

    private void RunControlCenterAction(string action)
    {
        switch (action)
        {
            case "tabs": OpenTabManager(); break;
            case "workspaces": OpenWorkspaceManager(); break;
            case "favorites": OpenFavoritesManager(); break;
            case "history": ShowHistoryMenu(_historyButton); break;
            case "site-notes": OpenSiteNotes(); break;
            case "downloads": OpenDownloadsCenter(); break;
            case "passwords": OpenPasswordManager(); break;
            case "extensions": _ = ManageExtensionsAsync(); break;
            case "security": OpenSecurityCenter(); break;
            case "privacy-activity": OpenPrivacyActivityDashboard(); break;
            case "performance": OpenPerformancePanel(); break;
            case "appearance": OpenCustomization(); break;
            case "homepage": OpenHomePageSettings(); break;
            case "diagnostics": OpenDiagnostics(); break;
            case "accessibility": OpenAccessibilitySettings(); break;
            case "permissions": OpenPermissionsManager(); break;
            case "backup-sync": OpenBackupSyncCenter(); break;
            case "sync-dashboard": OpenSyncDashboard(); break;
            case "toolbar": OpenToolbarSettings(); break;
            case "customize": OpenControlCenterSettings(); break;
        }
    }

    private void OpenCommandPalette()
    {
        var commands = new List<BrowserCommand>
        {
            new("control-center", "Central RX", "Abrir o painel de controle do navegador", "Sistema"),
            new("control-center-settings", "Personalizar Central RX", "Escolher cartões, ordem, cor e colunas", "Personalização"),
            new("new-tab", "Nova guia", "Abrir uma nova guia", "Navegação"),
            new("private-tab", "Nova guia privada", "Abrir uma sessão privada", "Privacidade"),
            new("focus-address", "Focar barra de endereço", "Pesquisar ou digitar um endereço", "Navegação"),
            new("reload", "Recarregar página", "Atualizar a página atual", "Navegação"),
            new("close-tab", "Fechar guia atual", "Fechar a guia selecionada", "Guias"),
            new("tabs", "Gerenciar guias", "Pesquisar, visualizar e organizar guias", "Guias"),
            new("tab-search", "Localizar guia aberta", "Pesquisar entre as guias abertas", "Guias"),
            new("workspaces", "Espaços de trabalho", "Salvar e abrir conjuntos de guias", "Guias"),
            new("favorites", "Gerenciar favoritos", "Organizar favoritos e pastas", "Organização"),
            new("history", "Abrir histórico", "Consultar a linha do tempo local", "Organização"),
            new("site-notes", "Caderno RX — notas por site", "Criar, editar e exportar notas locais associadas a sites", "Organização"),
            new("downloads", "Central de downloads", "Ver transferências e arquivos", "Arquivos"),
            new("passwords", "Cofre de senhas", "Gerenciar credenciais protegidas", "Privacidade"),
            new("security", "Central de Segurança", "Revisar proteção e permissões", "Privacidade"),
            new("privacy-activity", "Monitor de privacidade RX", "Ver requisições, anúncios, rastreadores e alertas bloqueados nesta sessão", "Privacidade"),
            new("permissions", "Gerenciar permissões de sites", "Revisar, permitir, bloquear ou remover permissões lembradas", "Privacidade"),
            new("backup-sync", "Configurar backup entre dispositivos", "Publicar ou importar backup seletivo por pasta compartilhada", "Sistema"),
            new("sync-dashboard", "Painel visual de sincronização", "Ver estado, dispositivos, tamanho e última publicação", "Sistema"),
            new("toolbar", "Personalizar barra de ferramentas", "Mostrar ou ocultar botões da barra superior", "Personalização"),
            new("extensions", "Gerenciar extensões", "Ver e configurar extensões", "Ferramentas"),
            new("performance", "Desempenho", "Ver processos e uso de recursos", "Ferramentas"),
            new("diagnostics", "Diagnóstico e backup", "Verificar perfil, exportar logs e backup seletivo", "Sistema"),
            new("accessibility", "Acessibilidade", "Ajustar tamanho da interface e alto contraste", "Personalização"),
            new("appearance", "Personalizar aparência", "Mudar tema e cores", "Personalização"),
            new("homepage", "Personalizar página inicial", "Configurar cartões e atalhos", "Personalização"),
            new("reader", "RX Reader Intelligence", "Extrair o artigo principal, estimar a leitura e exportar", "Leitura"),
            new("translate", "RX Translate", "Escolher idiomas e preparar a tradução do site", "Leitura"),
            new("pdf", "Ferramentas PDF", "Marcadores, anotações e impressão", "Documentos")
        };
        using var form = new CommandPaletteForm(commands);
        if (form.ShowDialog(this) == DialogResult.OK && form.SelectedCommandId is { } selected)
            RunCommandPaletteAction(selected);
    }

    private void RunCommandPaletteAction(string action)
    {
        switch (action)
        {
            case "control-center": OpenControlCenter(); break;
            case "control-center-settings": OpenControlCenterSettings(); break;
            case "new-tab": _ = CreateTabAsync(null, true); break;
            case "private-tab": _ = CreateTabAsync(null, true, true); break;
            case "focus-address": _addressBox.Focus(); _addressBox.SelectAll(); break;
            case "reload": _activeTab?.View.CoreWebView2?.Reload(); break;
            case "close-tab": if (_activeTab is not null) _ = CloseTabAsync(_activeTab); break;
            case "tabs": OpenTabManager(); break;
            case "tab-search": OpenTabSearch(); break;
            case "workspaces": OpenWorkspaceManager(); break;
            case "favorites": OpenFavoritesManager(); break;
            case "history": ShowHistoryMenu(_historyButton); break;
            case "site-notes": OpenSiteNotes(); break;
            case "downloads": OpenDownloadsCenter(); break;
            case "passwords": OpenPasswordManager(); break;
            case "security": OpenSecurityCenter(); break;
            case "privacy-activity": OpenPrivacyActivityDashboard(); break;
            case "permissions": OpenPermissionsManager(); break;
            case "backup-sync": OpenBackupSyncCenter(); break;
            case "sync-dashboard": OpenSyncDashboard(); break;
            case "toolbar": OpenToolbarSettings(); break;
            case "extensions": _ = ManageExtensionsAsync(); break;
            case "performance": OpenPerformancePanel(); break;
            case "diagnostics": OpenDiagnostics(); break;
            case "accessibility": OpenAccessibilitySettings(); break;
            case "appearance": OpenCustomization(); break;
            case "homepage": OpenHomePageSettings(); break;
            case "reader": _ = OpenReaderModeAsync(); break;
            case "translate": _ = TranslateCurrentPageAsync("pt", "Português (Brasil)"); break;
            case "pdf": OpenPdfReaderTools(); break;
        }
    }

    private void OpenControlCenterSettings()
    {
        using var form = new ControlCenterSettingsForm(_data.ControlCenterVisibleActions,
            _data.ControlCenterActionOrder, _data.ControlCenterAccentHex, _data.ControlCenterColumns);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.ControlCenterVisibleActions = form.VisibleActions;
        _data.ControlCenterActionOrder = form.ActionOrder;
        _data.ControlCenterAccentHex = form.AccentHex;
        _data.ControlCenterColumns = form.Columns;
        BrowserStorage.Save(_data);
        SetStatus("A Central RX foi personalizada neste perfil.");
    }

    private void OpenPermissionsManager()
    {
        using var form = new PermissionsManagerForm(_data.SitePermissions);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.SitePermissions = form.Result;
        BrowserStorage.Save(_data);
        SetStatus($"Gerenciador de permissões salvo: {_data.SitePermissions.Count} regra(s) mantida(s).");
    }

    private void OpenSyncDashboard()
    {
        var profileName = ProfileStore.Find(BrowserStorage.CurrentProfileId)?.Name ?? "Pessoal";
        BackupSyncDashboardSummary summary;
        try { summary = BackupSyncStore.GetDashboardSummary(_data.BackupSyncFolder, profileName, _data.BackupSyncDeviceId); }
        catch { summary = new BackupSyncDashboardSummary(0, 0, null, false, null, 0); }
        using var form = new SyncDashboardForm(profileName, _data.BackupSyncEnabled, _data.BackupSyncFolder,
            _data.BackupSyncIntervalMinutes, _data.LastBackupSyncUtc, summary);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        switch (form.RequestedAction)
        {
            case "settings": OpenBackupSyncCenter(); break;
            case "publish": PublishBackupNow(true); break;
            case "import": ImportBackupFromAnotherDevice(); break;
        }
    }

    private void OpenBackupSyncCenter()
    {
        using var form = new BackupSyncForm(_data.BackupSyncFolder, _data.BackupSyncEnabled, _data.BackupSyncIntervalMinutes);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        var folder = form.FolderPath;
        try
        {
            if (!string.IsNullOrWhiteSpace(folder))
            {
                Directory.CreateDirectory(folder);
                Directory.CreateDirectory(BackupSyncStore.GetStorageFolder(folder));
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível acessar a pasta compartilhada.\n\n" + ex.Message,
                "Backup entre dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _data.BackupSyncFolder = folder;
        _data.BackupSyncEnabled = form.EnabledSync && !string.IsNullOrWhiteSpace(folder);
        _data.BackupSyncIntervalMinutes = form.IntervalMinutes;
        if (!Guid.TryParseExact(_data.BackupSyncDeviceId, "N", out _)) _data.BackupSyncDeviceId = Guid.NewGuid().ToString("N");
        BrowserStorage.Save(_data);
        RefreshSyncMaintenanceTimer();

        if (form.RequestedAction == "publish") PublishBackupNow(true);
        else if (form.RequestedAction == "import") ImportBackupFromAnotherDevice();
        else SetStatus(_data.BackupSyncEnabled
            ? $"Backup entre dispositivos ativado. Publicação automática a cada {_data.BackupSyncIntervalMinutes} minutos."
            : "Configurações do backup entre dispositivos salvas; publicação automática desativada.");
    }

    private void PublishBackupNow(bool showFeedback)
    {
        if (string.IsNullOrWhiteSpace(_data.BackupSyncFolder))
        {
            if (showFeedback) SetStatus("Configure uma pasta compartilhada na Central de Backup primeiro.");
            return;
        }
        try
        {
            var syncProfileName = ProfileStore.Find(BrowserStorage.CurrentProfileId)?.Name ?? "Pessoal";
            var path = BackupSyncStore.Publish(_data.BackupSyncFolder, syncProfileName,
                _data.BackupSyncDeviceId, _data);
            _data.LastBackupSyncUtc = DateTime.UtcNow;
            BrowserStorage.Save(_data);
            if (showFeedback)
                MessageBox.Show(this, "Backup seletivo publicado com sucesso.\n\n" + path +
                    "\n\nSenhas, PINs, cookies, histórico, downloads, permissões e dados WebView2 não foram incluídos.",
                    "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            SetStatus("Backup seletivo publicado na pasta compartilhada.");
        }
        catch (Exception ex)
        {
            if (showFeedback) MessageBox.Show(this, "Não foi possível publicar o backup.\n\n" + ex.Message,
                "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else SetStatus("Backup automático indisponível: " + ex.Message);
        }
    }

    private void ImportBackupFromAnotherDevice()
    {
        if (string.IsNullOrWhiteSpace(_data.BackupSyncFolder)) return;
        var sharedFolder = BackupSyncStore.GetStorageFolder(_data.BackupSyncFolder);
        var syncProfileName = ProfileStore.Find(BrowserStorage.CurrentProfileId)?.Name ?? "Pessoal";
        List<BackupSyncCandidate> candidates;
        try
        {
            candidates = BackupSyncStore.ListOtherDevices(_data.BackupSyncFolder,
                syncProfileName, _data.BackupSyncDeviceId);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível consultar a pasta de backups compartilhada. Verifique se ela está disponível e se você tem permissão de leitura.\n\n" + ex.Message,
                "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (candidates.Count == 0)
        {
            MessageBox.Show(this, "Não foram encontrados backups de outros dispositivos para este perfil na pasta compartilhada.",
                "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new OpenFileDialog
        {
            Title = "Importar backup de outro dispositivo",
            InitialDirectory = sharedFolder,
            Filter = "Backup RX Browser (*.rxbackup)|*.rxbackup",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        if (!BackupSyncStore.IsOtherDeviceBackup(dialog.FileName, syncProfileName, _data.BackupSyncDeviceId))
        {
            MessageBox.Show(this, "Selecione um backup de outro dispositivo publicado para este perfil.",
                "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        try
        {
            var restored = ProfileBackupService.Import(dialog.FileName);
            var answer = MessageBox.Show(this,
                $"O backup selecionado contém {restored.Favorites.Count} favorito(s), {restored.FavoriteFolders.Count} pasta(s) e {restored.Workspaces.Count} espaço(s) de trabalho.\n\nDeseja substituir os itens organizacionais e preferências deste perfil? O RX será fechado para aplicar os dados.\n\nSenhas, PINs, cookies, histórico, downloads, permissões e extensões não são importados.",
                "Confirmar importação de backup", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes) return;
            PreserveLocalBackupSyncSettings(restored);
            ApplyImportedBackup(restored);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "O backup não pôde ser importado. Os dados atuais foram mantidos.\n\n" + ex.Message,
                "Backup RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void PreserveLocalBackupSyncSettings(BrowserData restored)
    {
        restored.BackupSyncEnabled = _data.BackupSyncEnabled;
        restored.BackupSyncFolder = _data.BackupSyncFolder;
        restored.BackupSyncDeviceId = _data.BackupSyncDeviceId;
        restored.BackupSyncIntervalMinutes = _data.BackupSyncIntervalMinutes;
        restored.LastBackupSyncUtc = _data.LastBackupSyncUtc;
    }

    private void ApplyImportedBackup(BrowserData restored)
    {
        BrowserStorage.Save(_data);
        ProfileBackupService.WriteRestoredProfile(BrowserStorage.DataFile, restored);
        _preserveRestoredDataOnClose = true;
        _sessionSnapshotTimer.Stop();
        _resourceSweepTimer.Stop();
        _syncMaintenanceTimer.Stop();
        MessageBox.Show(this, "Backup importado. O RX Browser será fechado agora. Abra-o novamente para carregar os dados do outro dispositivo.",
            "Restauração concluída", MessageBoxButtons.OK, MessageBoxIcon.Information);
        Close();
    }

    private void RefreshSyncMaintenanceTimer()
    {
        if (_data.AutoSyncEnabled || _data.WorkspaceSyncEnabled || _data.BackupSyncEnabled)
            _syncMaintenanceTimer.Start();
        else
            _syncMaintenanceTimer.Stop();
    }

    private void OpenAccessibilitySettings()
    {
        using var form = new AccessibilitySettingsForm(_data.UiScalePercent, _data.AccessibilityHighContrast);
        if (form.ShowDialog(this) != DialogResult.OK) return;

        var oldPalette = UiThemePalette.For(_currentInterfaceTheme, CAccent, _data.AccessibilityHighContrast);
        _data.UiScalePercent = Math.Clamp(form.ScalePercent, 90, 140);
        _data.AccessibilityHighContrast = form.HighContrast;
        CAccent = _data.AccessibilityHighContrast ? Color.FromArgb(255, 230, 0) : AccentFromData(_data);
        SetInterfaceThemeColors(_data.InterfaceTheme, _data.AccessibilityHighContrast);
        var newPalette = UiThemePalette.For(_data.InterfaceTheme, CAccent, _data.AccessibilityHighContrast);
        ApplyThemePaletteToControls(this, oldPalette, newPalette);
        UiScaleManager.Apply(this, _data.UiScalePercent);
        BrowserStorage.Save(_data);
        foreach (var tab in _tabs) ApplyTabHeaderStyle(tab);
        SetStatus($"Acessibilidade aplicada: interface em {_data.UiScalePercent}%" + (_data.AccessibilityHighContrast ? " · alto contraste" : string.Empty));
    }

    private void ExportDiagnosticLogs()
    {
        var logPath = BrowserDiagnosticsLog.LogPath;
        if (string.IsNullOrWhiteSpace(logPath) || !File.Exists(logPath))
        {
            MessageBox.Show(this, "Ainda não há logs de diagnóstico neste perfil.", "Exportar logs", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar logs de diagnóstico do RX Browser",
            Filter = "Log de texto (*.log)|*.log|Arquivo de texto (*.txt)|*.txt",
            FileName = $"RXBrowser-Log-{DateTime.Now:yyyyMMdd-HHmm}.log",
            AddExtension = true,
            OverwritePrompt = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            Trace.Flush();
            File.Copy(logPath, dialog.FileName, true);
            MessageBox.Show(this, "Log exportado. Ele pode conter mensagens de erro e caminhos locais; revise antes de compartilhar.",
                "Logs exportados", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível exportar o log.\n\n" + ex.Message, "Exportar logs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenDiagnostics()
    {
        var profile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        var metrics = ReadWebViewProcessMetrics();
        var memoryBytes = metrics.Sum(item => Math.Max(0, item.PrivateBytes));
        var runtimeVersion = "Não detectado";
        try
        {
            var method = typeof(CoreWebView2Environment).GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static)
                .FirstOrDefault(candidate => candidate.Name == "GetAvailableBrowserVersionString" && candidate.GetParameters().Length == 1);
            runtimeVersion = method?.Invoke(null, new object?[] { null }) as string ?? "Método de detecção indisponível";
        }
        catch (Exception ex) { runtimeVersion = "Indisponível: " + ex.GetBaseException().Message; }

        using var form = new DiagnosticsForm(profile?.Name ?? "Pessoal", BrowserStorage.ProfileRoot,
            BrowserStorage.DataFile, runtimeVersion, _tabs.Count, memoryBytes, BrowserDiagnosticsLog.LogPath);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        switch (form.RequestedAction)
        {
            case "logs": ExportDiagnosticLogs(); break;
            case "folder":
                try
                {
                    Directory.CreateDirectory(BrowserStorage.ProfileRoot);
                    var explorer = new ProcessStartInfo("explorer.exe") { UseShellExecute = true };
                    explorer.ArgumentList.Add(BrowserStorage.ProfileRoot);
                    Process.Start(explorer);
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Abrir pasta", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                break;
            case "export": ExportSafeProfileBackup(); break;
            case "restore": RestoreSafeProfileBackup(); break;
        }
    }

    private void ExportSafeProfileBackup()
    {
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar backup seletivo do RX Browser",
            Filter = "Backup RX Browser (*.rxbackup)|*.rxbackup",
            FileName = $"RXBrowser-{BrowserStorage.CurrentProfileId}-{DateTime.Now:yyyyMMdd-HHmm}.rxbackup",
            AddExtension = true,
            DefaultExt = "rxbackup"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            ProfileBackupService.Export(dialog.FileName, _data);
            SetStatus("Backup seletivo exportado. Senhas, cookies e histórico foram excluídos.");
            MessageBox.Show(this,
                "O backup foi criado. Ele inclui favoritos, espaços de trabalho e preferências não secretas.\n\nSenhas, PINs, cookies, histórico, sessões abertas e dados do WebView2 não foram incluídos.",
                "Backup RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível criar o backup.\n\n" + ex.Message, "Backup RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void RestoreSafeProfileBackup()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Restaurar backup seletivo do RX Browser",
            Filter = "Backup RX Browser (*.rxbackup)|*.rxbackup|Arquivo ZIP (*.zip)|*.zip",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var restored = ProfileBackupService.Import(dialog.FileName);
            var answer = MessageBox.Show(this,
                $"O backup contém {restored.Favorites.Count} favorito(s), {restored.FavoriteFolders.Count} pasta(s) e {restored.Workspaces.Count} espaço(s) de trabalho.\n\nDeseja substituir os dados organizacionais e preferências deste perfil? O navegador será fechado para aplicar as alterações.\n\nSenhas, cookies, histórico, PINs e permissões não são importados.",
                "Confirmar restauração", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes) return;

            PreserveLocalBackupSyncSettings(restored);
            ApplyImportedBackup(restored);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "O backup não pôde ser restaurado. Os dados atuais foram mantidos.\n\n" + ex.Message,
                "Restauração RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenPerformancePanel()
    {
        (int Total, int Active, int Private) ReadTabs() =>
            (_tabs.Count, _tabs.Count(t => ReferenceEquals(t, _activeTab)), _tabs.Count(t => t.IsPrivate));
        using var form = new PerformanceForm(ReadWebViewProcessMetrics, ReadTabs);
        form.ShowDialog(this);
    }

    private void OpenShortcutSettings()
    {
        using var form = new ShortcutSettingsForm(_data.ShortcutOverrides);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.ShortcutOverrides = form.Result;
        BrowserStorage.Save(_data);
        SetStatus("Atalhos personalizados salvos neste perfil.");
    }

    private void OpenPdfReaderTools()
    {
        var tab = _activeTab;
        var path = GetActivePdfPath();
        if (tab is null || path is null)
        {
            SetStatus("Abra um PDF local para usar marcadores e anotações.");
            return;
        }
        try
        {
            var notes = PdfNotesStore.Load(path);
            using var form = new PdfReaderToolsForm(notes, page =>
            {
                if (_tabs.Contains(tab) && tab.View.CoreWebView2 is not null)
                {
                    SelectTab(tab);
                    tab.View.CoreWebView2.Navigate(new Uri(path).AbsoluteUri + "#page=" + Math.Max(1, page));
                }
            });
            form.ShowDialog(this);
            SetStatus("Marcadores e anotações PDF salvos localmente.");
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Ferramentas PDF", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private string? GetActivePdfPath()
    {
        var source = _activeTab?.View.Source?.ToString();
        if (!Uri.TryCreate(source, UriKind.Absolute, out var uri) || !uri.IsFile || !Path.GetExtension(uri.LocalPath).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            return null;
        return File.Exists(uri.LocalPath) ? uri.LocalPath : null;
    }

    private bool MatchesShortcut(string id, string defaultGesture, KeyEventArgs e)
    {
        var gesture = _data.ShortcutOverrides.TryGetValue(id, out var custom) && !string.IsNullOrWhiteSpace(custom)
            ? custom : defaultGesture;
        return ShortcutMatcher.Matches(gesture, e);
    }

    private bool IsBrowserShortcut(KeyEventArgs e)
    {
        var key = e.KeyCode;
        return MatchesShortcut("NewTab", "Ctrl+T", e) ||
            MatchesShortcut("CloseTab", "Ctrl+W", e) ||
            MatchesShortcut("TabManager", "Ctrl+Shift+A", e) ||
            MatchesShortcut("TabSearch", "Ctrl+Shift+Q", e) ||
            MatchesShortcut("Workspaces", "Ctrl+Shift+W", e) ||
            MatchesShortcut("Performance", "Ctrl+Shift+Y", e) ||
            MatchesShortcut("PdfTools", "Ctrl+Shift+M", e) ||
            MatchesShortcut("Downloads", "Ctrl+J", e) ||
            MatchesShortcut("Security", "Ctrl+Shift+S", e) ||
            MatchesShortcut("ReaderMode", "Ctrl+Shift+E", e) ||
            MatchesShortcut("TranslateSelection", "Ctrl+Shift+X", e) ||
            MatchesShortcut("NextTab", "Ctrl+Tab", e) ||
            MatchesShortcut("PreviousTab", "Ctrl+Shift+Tab", e) ||
            MatchesShortcut("FocusAddress", "Ctrl+L", e) ||
            (e.Control && !e.Shift && ((key >= Keys.D1 && key <= Keys.D9) || (key >= Keys.NumPad1 && key <= Keys.NumPad9))) ||
            (e.Control && (key == Keys.PageUp || key == Keys.PageDown)) ||
            (e.Alt && (key == Keys.Left || key == Keys.Right)) ||
            key == Keys.F6 ||
            (e.Control && e.Shift && (key == Keys.N || key == Keys.T || key == Keys.B || key == Keys.D || key == Keys.P || key == Keys.Delete || key == Keys.F || key == Keys.G || key == Keys.K || key == Keys.V || key == Keys.O || key == Keys.U || key == Keys.Space)) ||
            (e.Control && (key == Keys.O || key == Keys.P || key == Keys.F || key == Keys.D || key == Keys.H)) ||
            (e.Control && (key == Keys.Add || key == Keys.Oemplus || key == Keys.Subtract || key == Keys.OemMinus || key == Keys.D0)) ||
            key == Keys.F11;
    }

    private void OpenCurrentSitePrivacySettings()
    {
        var host = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https"
            ? uri.Host.ToLowerInvariant() : string.Empty;
        if (string.IsNullOrWhiteSpace(host))
        {
            SetStatus("Abra um site HTTP ou HTTPS para configurar a privacidade por site.");
            return;
        }
        var blockAds = !_data.AdBlockAllowlist.Any(item => AdBlocker.HostMatches(host, item));
        var blockTracking = !_data.TrackingAllowlist.Any(item => AdBlocker.HostMatches(host, item));
        using var form = new SitePrivacyForm(host, blockAds, blockTracking);
        if (form.ShowDialog(this) != DialogResult.OK) return;

        _data.AdBlockAllowlist.RemoveAll(item => AdBlocker.HostMatches(host, item));
        _data.TrackingAllowlist.RemoveAll(item => AdBlocker.HostMatches(host, item));
        if (!form.BlockAds) _data.AdBlockAllowlist.Add(host);
        if (!form.BlockTracking) _data.TrackingAllowlist.Add(host);
        BrowserStorage.Save(_data);
        SetStatus("Privacidade atualizada para " + host + ". Recarregue a página para aplicar os filtros.");
    }

    private void OpenPrivacyActivityDashboard()
    {
        var currentHost = Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var currentUri) && currentUri.Scheme is "http" or "https"
            ? currentUri.Host : string.Empty;
        using var form = new PrivacyActivityDashboardForm(_privacyActivity, currentHost);
        form.ShowDialog(this);
    }

    private void OpenSecurityCenter()
    {
        var vaultSummary = PasswordVault.GetSummary();
        using var form = new SecurityCenterForm(_data, _activeTab?.View.Source?.ToString(), _blockedRequestsCount,
            _blockedPopupsCount, vaultSummary.Total, vaultSummary.AutofillEnabled,
            _data.ProtectedTabs.Count(record => string.Equals(record.CredentialKind, "PIN", StringComparison.OrdinalIgnoreCase)));
        if (form.ShowDialog(this) != DialogResult.OK) return;
        if (form.ClearPermissionsRequested) _data.SitePermissions.Clear();
        if (form.ClearSiteExceptionsRequested)
        {
            _data.AdBlockAllowlist.Clear();
            _data.TrackingAllowlist.Clear();
            _data.PopupAllowlist.Clear();
        }
        if (form.ClearPhishingAllowlistRequested) _data.PhishingAllowlist.Clear();
        if (form.AddCurrentSiteToPhishingAllowlistRequested &&
            Uri.TryCreate(_activeTab?.View.Source?.ToString(), UriKind.Absolute, out var trustedUri) && trustedUri.Scheme is "http" or "https")
        {
            var trustedHost = trustedUri.Host.ToLowerInvariant();
            if (!_data.PhishingAllowlist.Contains(trustedHost, StringComparer.OrdinalIgnoreCase)) _data.PhishingAllowlist.Add(trustedHost);
        }
        BrowserStorage.Save(_data);
        SetStatus("Configurações de segurança e privacidade salvas para este perfil.");
    }

    private async Task PrintActiveDocumentAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        try
        {
            core.ShowPrintUI();
            SetStatus("Pré-visualização de impressão aberta.");
        }
        catch (Exception ex) { SetStatus("Não foi possível abrir a impressão: " + ex.Message); }
        await Task.CompletedTask;
    }

    private async Task SaveActiveDocumentAsAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        try
        {
            await core.ShowSaveAsUIAsync();
            SetStatus("Salvar como solicitado.");
        }
        catch (Exception ex) { SetStatus("Não foi possível abrir Salvar como: " + ex.Message); }
    }

    private async Task SaveCurrentPageAsPdfAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        using var dialog = new SaveFileDialog
        {
            Title = "Salvar página como PDF",
            Filter = "Documento PDF (*.pdf)|*.pdf",
            DefaultExt = "pdf",
            AddExtension = true,
            FileName = MakeSafeFileName(core.DocumentTitle) + ".pdf",
            OverwritePrompt = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var created = await core.PrintToPdfAsync(dialog.FileName, null);
            if (created)
            {
                SetStatus("PDF criado: " + Path.GetFileName(dialog.FileName));
                if (MessageBox.Show(this, "PDF salvo com sucesso. Deseja abrir a pasta?", "RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    Process.Start(new ProcessStartInfo(Path.GetDirectoryName(dialog.FileName)!) { UseShellExecute = true });
            }
            else SetStatus("O WebView2 não conseguiu gerar o PDF desta página.");
        }
        catch (Exception ex) { SetStatus("Falha ao gerar PDF: " + ex.Message); }
    }

    private static string MakeSafeFileName(string? value)
    {
        var name = string.IsNullOrWhiteSpace(value) ? "pagina-rx" : value.Trim();
        foreach (var invalid in Path.GetInvalidFileNameChars()) name = name.Replace(invalid, '_');
        return name.Length > 80 ? name[..80] : name;
    }

    private void OpenLocalPdfExternally()
    {
        var source = _activeTab?.View.Source?.ToString();
        if (!Uri.TryCreate(source, UriKind.Absolute, out var uri) || !uri.IsFile || !File.Exists(uri.LocalPath))
        {
            SetStatus("Somente PDFs locais podem ser abertos diretamente no aplicativo padrão.");
            return;
        }
        try { Process.Start(new ProcessStartInfo(uri.LocalPath) { UseShellExecute = true }); }
        catch (Exception ex) { SetStatus("Não foi possível abrir o leitor externo: " + ex.Message); }
    }

    private void OpenPasswordManager()
    {
        try
        {
            var currentUrl = _activeTab?.View.Source?.ToString();
            Action<string, string>? fillCallback = null;
            if (_data.PasswordAutofillEnabled && PasswordVault.IsSecureHttpUrl(currentUrl, out _))
            {
                var capturedUrl = currentUrl;
                fillCallback = (username, password) => _ = FillCredentialIntoActivePageAsync(capturedUrl, username, password);
            }
            using var form = new PasswordManagerForm(currentUrl, _data.PasswordAutofillEnabled, fillCallback);
            form.ShowDialog(this);
            SetStatus("Cofre de senhas local fechado.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível abrir o cofre de senhas.\n\n" + ex.Message,
                "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task FillCredentialIntoActivePageAsync(string? expectedUrl, string username, string password)
    {
        var tab = _activeTab;
        var core = tab?.View.CoreWebView2;
        var currentUrl = tab?.View.Source?.ToString();
        if (core is null || tab is null || !PasswordVault.IsSecureHttpUrl(currentUrl, out var currentUri) ||
            !PasswordVault.IsSecureHttpUrl(expectedUrl, out var expectedUri) ||
            !string.Equals(currentUri!.IdnHost, expectedUri!.IdnHost, StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(currentUri!.Scheme, expectedUri!.Scheme, StringComparison.OrdinalIgnoreCase))
        {
            SetStatus("Preenchimento cancelado: o site ativo mudou ou não usa uma conexão segura.");
            return;
        }

        // Exact-origin matching and explicit user click are required. Values are JSON-escaped
        // before entering the page; no native host object is exposed to site JavaScript.
        try
        {
            var currentOrigin = currentUri.GetLeftPart(UriPartial.Authority);
            var entry = PasswordVault.FindForExactOrigin(currentOrigin)
                .FirstOrDefault(item => string.Equals(item.Username, username, StringComparison.Ordinal));
            if (entry is null || !string.Equals(entry.Password, password, StringComparison.Ordinal))
            {
                SetStatus("Preenchimento cancelado: esta credencial não está autorizada para o site atual.");
                return;
            }

            var userJson = JsonSerializer.Serialize(username);
            var passJson = JsonSerializer.Serialize(password);
            var script = "(() => { const rxUser = " + userJson + "; const rxPass = " + passJson + "; " +
                "const all = Array.from(document.querySelectorAll('input:not([type=hidden]):not([disabled]):not([readonly])')); " +
                "const pass = all.find(el => (el.type || '').toLowerCase() === 'password'); " +
                "if (!pass) return 'no-password-field'; " +
                "const scope = pass.form || document; " +
                "const candidates = Array.from(scope.querySelectorAll('input:not([type=hidden]):not([disabled]):not([readonly])')).filter(el => el !== pass && ['text','email','tel',''].includes((el.type || '').toLowerCase())); " +
                "const user = candidates.find(el => /user|email|login/i.test((el.autocomplete || '') + ' ' + (el.name || '') + ' ' + (el.id || ''))) || candidates[0]; " +
                "if (!user) return 'no-username-field'; " +
                "const set = (el, value) => { const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const d = Object.getOwnPropertyDescriptor(proto, 'value'); if (d && d.set) d.set.call(el, value); else el.value = value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }; " +
                "set(user, rxUser); set(pass, rxPass); return 'ok'; })();";
            var result = await core.ExecuteScriptAsync(script);
            if (result.Contains("ok", StringComparison.Ordinal)) SetStatus("Credenciais preenchidas. Revise antes de enviar o formulário.");
            else SetStatus("Não encontrei campos de usuário e senha compatíveis nesta página.");
        }
        catch (Exception ex) { SetStatus("Falha ao preencher credenciais: " + ex.Message); }
    }

    private async Task OpenPdfDocumentAsync()
    {
        using var picker = new OpenFileDialog
        {
            Title = "Abrir PDF no RX Browser",
            Filter = "Documentos PDF (*.pdf)|*.pdf|Todos os arquivos (*.*)|*.*",
            CheckFileExists = true,
            Multiselect = false
        };
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var fileUri = new Uri(Path.GetFullPath(picker.FileName)).AbsoluteUri;
            await CreateTabAsync(fileUri, true);
            SetStatus("Documento PDF aberto no leitor integrado do WebView2.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível abrir o PDF. Verifique se o WebView2 Runtime está atualizado e se o arquivo não está bloqueado.\n\n" + ex.Message,
                "Leitor PDF RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenAdBlockerSettings()
    {
        using var form = new AdBlockerForm(_data.AdBlockEnabled, _data.AdBlockLevel, _data.AdBlockCustomDomains);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        _data.AdBlockEnabled = form.IsEnabled;
        _data.AdBlockLevel = form.Level;
        _data.AdBlockCustomDomains = form.CustomDomains;
        BrowserStorage.Save(_data);
        SetStatus($"Bloqueador RX {(form.IsEnabled ? "ativado" : "desativado")} · nível {form.Level} · {form.CustomDomains.Count} domínio(s) personalizado(s). Recarregue páginas para aplicar todos os filtros.");
    }

    private void OpenHomePageSettings()
    {
        using var form = new HomePageSettingsForm(_data);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        BrowserStorage.Save(_data);
        if (_activeTab?.IsHomePage == true) ShowHomePage(_activeTab);
        SetStatus("Página inicial personalizada e salva neste perfil.");
    }

    private async Task OpenVideoManagerAsync()
    {
        var core = _activeTab?.View.CoreWebView2;
        if (core is null) return;
        for (var attempt = 0; attempt < 25; attempt++)
        {
            try
            {
                const string listScript = """
                    (() => JSON.stringify(Array.from(document.querySelectorAll('video')).map((v, i) => {
                      let host = '';
                      try { const u = new URL(v.currentSrc || v.src || location.href); host = u.host; } catch (_) {}
                      return {
                        Index:i,
                        Label:(v.getAttribute('aria-label') || v.getAttribute('title') || document.title || `Vídeo ${i+1}`).slice(0,120),
                        SourceHost:host,
                        Width:v.videoWidth || v.clientWidth || 0,
                        Height:v.videoHeight || v.clientHeight || 0,
                        CurrentTime:Number.isFinite(v.currentTime) ? v.currentTime : 0,
                        Duration:Number.isFinite(v.duration) ? v.duration : 0,
                        Paused:v.paused,
                        Muted:v.muted,
                        Volume:v.volume,
                        PlaybackRate:v.playbackRate
                      };
                    })))()
                    """;
                var raw = await core.ExecuteScriptAsync(listScript);
                var payload = JsonSerializer.Deserialize<string>(raw);
                var videos = string.IsNullOrWhiteSpace(payload)
                    ? new List<PageVideoInfo>()
                    : JsonSerializer.Deserialize<List<PageVideoInfo>>(payload, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<PageVideoInfo>();
                using var form = new VideoManagerForm(videos, _data.VideoPlaybackRate);
                if (form.ShowDialog(this) != DialogResult.OK) return;
                if (form.ActionName == "refresh") continue;
                var indexJson = JsonSerializer.Serialize(form.SelectedVideoIndex);
                var actionJson = JsonSerializer.Serialize(form.ActionName);
                var rateJson = JsonSerializer.Serialize(form.SelectedRate);
                // Use two dollar signs for raw interpolation: JavaScript braces remain literal,
                // while only the three JSON values below are C# interpolations.
                var commandScript = $$"""
                    (async () => {
                      const videos = Array.from(document.querySelectorAll('video'));
                      const video = videos[{{indexJson}}];
                      if (!video) return 'Vídeo não encontrado; atualize a lista.';
                      const action = {{actionJson}};
                      if (action === 'play') { try { await video.play(); return 'Reprodução iniciada.'; } catch (error) { return 'O site impediu a reprodução automática. Clique diretamente no player para iniciar.'; } }
                      if (action === 'pause') { video.pause(); return 'Reprodução pausada.'; }
                      if (action === 'mute') { video.muted = !video.muted; return video.muted ? 'Áudio silenciado.' : 'Áudio ativado.'; }
                      if (action === 'rate') { video.playbackRate = {{rateJson}}; return 'Velocidade ajustada para ' + video.playbackRate + '×.'; }
                      return 'Ação não reconhecida.';
                    })()
                    """;
                var result = await core.ExecuteScriptAsync(commandScript);
                var message = JsonSerializer.Deserialize<string>(result) ?? "Comando enviado ao vídeo.";
                if (form.ActionName == "rate")
                {
                    _data.VideoPlaybackRate = form.SelectedRate;
                    BrowserStorage.Save(_data);
                }
                SetStatus(message);
                await Task.Delay(180);
            }
            catch (Exception ex)
            {
                SetStatus("Não foi possível controlar os vídeos desta página: " + ex.Message);
                return;
            }
        }
    }

    private void OpenCustomization()
    {
        using var form = new CustomizationForm(_data);
        if (form.ShowDialog(this) != DialogResult.OK) return;
        var oldPalette = UiThemePalette.For(_currentInterfaceTheme, CAccent, _data.AccessibilityHighContrast);
        CAccent = _data.AccessibilityHighContrast ? Color.FromArgb(255, 230, 0) : AccentFromData(_data);
        SetInterfaceThemeColors(_data.InterfaceTheme, _data.AccessibilityHighContrast);
        var newPalette = UiThemePalette.For(_data.InterfaceTheme, CAccent, _data.AccessibilityHighContrast);
        ApplyThemePaletteToControls(this, oldPalette, newPalette);
        _currentInterfaceTheme = _data.InterfaceTheme;
        _sidebarPanel.Width = Math.Clamp(_data.SidebarWidth, 180, 360);
        _sidebarPanel.Visible = _data.SidebarVisible;
        BrowserStorage.Save(_data);
        foreach (var tab in _tabs) ApplyTabHeaderStyle(tab);
        var activeProfile = ProfileStore.Find(BrowserStorage.CurrentProfileId);
        Text = $"{_data.ProfileBadge} RX Browser 3.6.0" + (activeProfile is null || activeProfile.Id == "default" ? string.Empty : " — " + activeProfile.Name);
        if (_activeTab?.IsHomePage == true) ShowHomePage(_activeTab);
        SetStatus("Tema e identidade visual salvos neste perfil.");
    }

    private static string _currentInterfaceTheme = "Midnight";

    private static void SetInterfaceThemeColors(string? theme, bool highContrast = false)
    {
        var palette = UiThemePalette.For(theme, CAccent, highContrast);
        CBackground = palette.Background;
        CPanel = palette.Panel;
        CPanel2 = palette.PanelAlt;
        CText = palette.Text;
        CMuted = palette.Muted;
        _currentInterfaceTheme = theme is "Midnight" or "Graphite" or "OLED" or "Light" ? theme : "Midnight";
    }

    private static Color RemapThemeColor(Color value, UiThemePalette oldPalette, UiThemePalette newPalette)
    {
        if (value.ToArgb() == oldPalette.Background.ToArgb()) return newPalette.Background;
        if (value.ToArgb() == oldPalette.Panel.ToArgb()) return newPalette.Panel;
        if (value.ToArgb() == oldPalette.PanelAlt.ToArgb()) return newPalette.PanelAlt;
        if (value.ToArgb() == oldPalette.Accent.ToArgb()) return newPalette.Accent;
        if (value.ToArgb() == oldPalette.Text.ToArgb()) return newPalette.Text;
        if (value.ToArgb() == oldPalette.Muted.ToArgb()) return newPalette.Muted;
        return value;
    }

    private static void ApplyThemePaletteToControls(Control parent, UiThemePalette oldPalette, UiThemePalette newPalette)
    {
        parent.BackColor = RemapThemeColor(parent.BackColor, oldPalette, newPalette);
        parent.ForeColor = RemapThemeColor(parent.ForeColor, oldPalette, newPalette);
        foreach (Control control in parent.Controls)
        {
            control.BackColor = RemapThemeColor(control.BackColor, oldPalette, newPalette);
            control.ForeColor = RemapThemeColor(control.ForeColor, oldPalette, newPalette);
            if (control is Button button)
            {
                button.FlatAppearance.MouseDownBackColor = newPalette.Accent;
                button.FlatAppearance.MouseOverBackColor = newPalette.PanelAlt;
            }
            if (control.HasChildren) ApplyThemePaletteToControls(control, oldPalette, newPalette);
        }
    }

    private static Color AccentFromData(BrowserData data)
    {
        if (!string.IsNullOrWhiteSpace(data.ThemeAccentHex))
        {
            try { return ColorTranslator.FromHtml(data.ThemeAccentHex); }
            catch { /* Falls back to the named accent below. */ }
        }
        return AccentFromName(data.ThemeAccent);
    }

    private static Color AccentFromName(string? name) => name switch
    {
        "Violet" => Color.FromArgb(174, 132, 255),
        "Emerald" => Color.FromArgb(64, 220, 155),
        "Amber" => Color.FromArgb(255, 184, 76),
        "Pink" => Color.FromArgb(255, 111, 174),
        _ => Color.FromArgb(35, 205, 230)
    };

    private static (string Glow, string Mid, string Base) HomePagePalette(string? name) => name switch
    {
        "Midnight" => ("#26364d", "#111827", "#080c13"),
        "Purple" => ("#3b2c60", "#1c1730", "#0b0a12"),
        "Forest" => ("#1d4a43", "#102923", "#08120f"),
        "Sunset" => ("#5a3548", "#2b1c2a", "#100d16"),
        _ => ("#1d3044", "#101925", "#0c1017")
    };

    private async Task ClearBrowsingDataAsync()
    {
        if (MessageBox.Show(this,
            "Isso limpará cookies, cache e dados de sites do perfil normal do RX Browser. Você poderá sair de alguns sites. Favoritos serão mantidos.\n\nDeseja continuar?",
            "Limpar dados de navegação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        try
        {
            var normalCore = _tabs.FirstOrDefault(t => !t.IsPrivate)?.View.CoreWebView2;
            if (normalCore is not null) await normalCore.Profile.ClearBrowsingDataAsync();
            _data.History.Clear();
            BrowserStorage.Save(_data);
            SetStatus("Dados de navegação do perfil normal foram limpos.");
        }
        catch (Exception ex) { SetStatus("Não foi possível limpar os dados: " + ex.Message); }
    }

    private async Task NavigateOrNewTabAsync(string url)
    {
        if (_activeTab is null) await CreateTabAsync(url, true);
        else
        {
            _activeTab.IsHomePage = false;
            _activeTab.View.CoreWebView2?.Navigate(url);
        }
    }

    private void SaveHistory(BrowserTab tab)
    {
        if (tab.IsPrivate) return;
        var url = tab.View.Source?.ToString();
        if (!IsHttpUrl(url)) return;
        var now = DateTime.Now;
        if (_data.History.Count > 0 && _data.History[0].Url == url && (now - _data.History[0].VisitedAt).TotalSeconds < 4) return;
        _data.History.Insert(0, new HistoryItem(tab.Title, url!, now));
        if (_data.History.Count > 2000) _data.History.RemoveRange(2000, _data.History.Count - 2000);
        BrowserStorage.Save(_data);
    }

    private async void RetryDownload(DownloadRecord download)
    {
        if (!IsHttpUrl(download.SourceUri))
        {
            SetStatus("Não foi possível reiniciar este download porque a origem não é HTTP/HTTPS.");
            return;
        }
        try
        {
            await CreateTabAsync(download.SourceUri, true);
            SetStatus("Nova tentativa de download iniciada em outra guia.");
        }
        catch (Exception ex) { SetStatus("Falha ao iniciar nova tentativa: " + ex.Message); }
    }

    private void OpenDownloadsCenter()
    {
        if (_downloadsForm is { IsDisposed: false })
        {
            _downloadsForm.Activate();
            return;
        }
        _downloadsForm = new DownloadsForm(_downloads, BrowserStorage.Downloads, () => PersistDownloadHistory(false), RetryDownload);
        _downloadsForm.Show(this);
    }

    private void OpenDownloadsFolder()
    {
        try
        {
            Directory.CreateDirectory(BrowserStorage.Downloads);
            Process.Start(new ProcessStartInfo(BrowserStorage.Downloads) { UseShellExecute = true });
        }
        catch (Exception ex) { SetStatus("Não foi possível abrir Downloads: " + ex.Message); }
    }

    private void SetStatus(string value)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            try { BeginInvoke(new Action(() => SetStatus(value))); } catch { }
            return;
        }
        _statusText.Text = "RX  •  " + value;
    }

    private void LoadPersistedDownloads()
    {
        foreach (var item in _data.DownloadHistory.OrderByDescending(item => item.StartedAt).Take(100))
        {
            if (string.IsNullOrWhiteSpace(item.FilePath)) continue;
            var state = item.State is "Baixando" or "Pausado"
                ? "Interrompido (sessão anterior)"
                : item.State;
            _downloads.Add(new DownloadRecord
            {
                FilePath = item.FilePath,
                SourceUri = item.SourceUri,
                StartedAt = item.StartedAt,
                BytesReceived = item.BytesReceived,
                TotalBytesToReceive = item.TotalBytesToReceive,
                State = state,
                SecurityLevel = item.SecurityLevel ?? "Baixo",
                SecurityReason = item.SecurityReason ?? string.Empty
            });
        }
    }

    private void PersistDownloadHistory(bool markActiveAsInterrupted)
    {
        var updated = _downloads
            .OrderByDescending(item => item.StartedAt)
            .Take(100)
            .Select(item => new DownloadHistoryItem
            {
                FilePath = item.FilePath,
                SourceUri = item.SourceUri,
                StartedAt = item.StartedAt,
                BytesReceived = item.BytesReceived,
                TotalBytesToReceive = item.TotalBytesToReceive,
                State = markActiveAsInterrupted && (item.State is "Baixando" or "Pausado")
                    ? "Interrompido (sessão anterior)"
                    : item.State,
                SecurityLevel = item.SecurityLevel,
                SecurityReason = item.SecurityReason
            })
            .ToList();
        var unchanged = updated.Count == _data.DownloadHistory.Count && updated.Zip(_data.DownloadHistory).All(pair =>
            string.Equals(pair.First.FilePath, pair.Second.FilePath, StringComparison.Ordinal) &&
            string.Equals(pair.First.SourceUri, pair.Second.SourceUri, StringComparison.Ordinal) &&
            pair.First.StartedAt == pair.Second.StartedAt &&
            pair.First.BytesReceived == pair.Second.BytesReceived &&
            pair.First.TotalBytesToReceive == pair.Second.TotalBytesToReceive &&
            string.Equals(pair.First.State, pair.Second.State, StringComparison.Ordinal) &&
            string.Equals(pair.First.SecurityLevel, pair.Second.SecurityLevel, StringComparison.Ordinal) &&
            string.Equals(pair.First.SecurityReason, pair.Second.SecurityReason, StringComparison.Ordinal));
        if (unchanged) return;
        _data.DownloadHistory = updated;
        BrowserStorage.Save(_data);
    }

    private void SaveSessionSnapshot()
    {
        if (!_data.RestoreLastSession)
        {
            if (_data.LastSessionUrls.Count == 0 && _data.LastSessionTabs.Count == 0 && _data.LastActiveSessionTabIndex == 0) return;
            _data.LastSessionUrls.Clear();
            _data.LastSessionTabs.Clear();
            _data.LastActiveSessionTabIndex = 0;
            _data.SessionSnapshotUtc = DateTime.UtcNow;
            BrowserStorage.Save(_data);
            return;
        }

        var snapshots = new List<SessionTabSnapshot>();
        var activeIndex = 0;
        foreach (var tab in _tabs.Where(tab => !tab.IsPrivate))
        {
            if (snapshots.Count >= 20) break;
            var url = tab.View.Source?.ToString() ?? string.Empty;
            if (!IsHttpUrl(url)) continue;
            if (ReferenceEquals(tab, _activeTab)) activeIndex = snapshots.Count;
            snapshots.Add(new SessionTabSnapshot
            {
                Id = tab.Id,
                Url = url,
                Title = tab.Title,
                IsPinned = tab.IsPinned,
                GroupName = tab.GroupName
            });
        }
        var safeActiveIndex = Math.Clamp(activeIndex, 0, Math.Max(0, snapshots.Count - 1));
        var unchanged = safeActiveIndex == _data.LastActiveSessionTabIndex &&
            snapshots.Count == _data.LastSessionTabs.Count &&
            snapshots.Zip(_data.LastSessionTabs).All(pair =>
                string.Equals(pair.First.Id, pair.Second.Id, StringComparison.Ordinal) &&
                string.Equals(pair.First.Url, pair.Second.Url, StringComparison.Ordinal) &&
                string.Equals(pair.First.Title, pair.Second.Title, StringComparison.Ordinal) &&
                pair.First.IsPinned == pair.Second.IsPinned &&
                string.Equals(pair.First.GroupName, pair.Second.GroupName, StringComparison.Ordinal));
        if (unchanged) return;

        _data.LastSessionTabs = snapshots;
        _data.LastSessionUrls = snapshots.Select(item => item.Url).ToList();
        _data.LastActiveSessionTabIndex = safeActiveIndex;
        _data.SessionSnapshotUtc = DateTime.UtcNow;
        BrowserStorage.Save(_data);
    }

    private static DateTime? ParseEstimatedEndTime(object? value)
    {
        // WebView2 SDK projections have exposed EstimatedEndTime as either DateTime
        // or string across targets. Accept both to keep the download UI source-compatible.
        return value switch
        {
            DateTime date when date != DateTime.MinValue => date,
            DateTimeOffset offset => offset.LocalDateTime,
            string text when DateTime.TryParse(text, out var parsed) => parsed,
            _ => null
        };
    }

    private sealed class BrowserShortcutMessageFilter : IMessageFilter
    {
        private const int WmKeyDown = 0x0100;
        private const int WmSysKeyDown = 0x0104;
        private readonly MainForm _owner;

        public BrowserShortcutMessageFilter(MainForm owner) => _owner = owner;

        public bool PreFilterMessage(ref Message message)
        {
            if (message.Msg is not (WmKeyDown or WmSysKeyDown)) return false;
            if (_owner.IsDisposed || !_owner.IsHandleCreated || Form.ActiveForm != _owner) return false;

            var keyCode = (Keys)(int)message.WParam & Keys.KeyCode;
            var args = new KeyEventArgs(Control.ModifierKeys | keyCode);
            if (!_owner.IsBrowserShortcut(args)) return false;

            // Consume the native accelerator before the WebView2 page sees it. Ignore
            // autorepeat for commands, while still consuming the repeated key messages.
            message.Result = IntPtr.Zero;
            var isAutoRepeat = (((long)message.LParam) & (1L << 30)) != 0;
            if (!isAutoRepeat)
            {
                try
                {
                    _owner.BeginInvoke(new MethodInvoker(() => _owner.MainForm_KeyDown(_owner, args)));
                }
                catch (InvalidOperationException) { /* Includes ObjectDisposedException during shutdown. */ }
            }
            return true;
        }
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        Application.RemoveMessageFilter(_browserShortcutFilter);
        _closing = true;
        _sessionSnapshotTimer.Stop();
        _resourceSweepTimer.Stop();
        _syncMaintenanceTimer.Stop();
        if (!_preserveRestoredDataOnClose)
        {
            SaveSessionSnapshot();
            SyncSessionSnapshot(false);
            PersistDownloadHistory(true);
            _data.LastShutdownClean = true;
            BrowserStorage.Save(_data);
            SyncFavoritesNow(false);
            if (_data.WorkspaceSyncEnabled && !string.IsNullOrWhiteSpace(_data.WorkspaceSyncFolder) && Directory.Exists(_data.WorkspaceSyncFolder))
            { try { WorkspaceSyncStore.Sync(_data); BrowserStorage.Save(_data); } catch { } }
            if (_data.AutoSyncEnabled) PublishPreferencesNow(false);
            if (_data.BackupSyncEnabled && !string.IsNullOrWhiteSpace(_data.BackupSyncFolder))
            {
                try
                {
                    var syncProfileName = ProfileStore.Find(BrowserStorage.CurrentProfileId)?.Name ?? "Pessoal";
                    BackupSyncStore.Publish(_data.BackupSyncFolder, syncProfileName, _data.BackupSyncDeviceId, _data);
                    _data.LastBackupSyncUtc = DateTime.UtcNow;
                    BrowserStorage.Save(_data);
                }
                catch { /* O backup de encerramento é best-effort; os dados locais permanecem salvos. */ }
            }
        }

        try { _downloadsForm?.Close(); } catch { }
        foreach (var tab in _tabs.ToList())
        {
            try { tab.View.Dispose(); } catch { }
        }
        CleanupPrivateSession();
    }

    private void CleanupPrivateSession()
    {
        try { _privateProfile?.Delete(); } catch { }
        _privateProfile = null;
        _privateEnvironment = null;
        if (!string.IsNullOrWhiteSpace(_privateDataPath))
        {
            try { Directory.Delete(_privateDataPath, recursive: true); } catch { }
        }
        _privateDataPath = null;
    }
}
