﻿namespace RXBrowser;

internal sealed class ControlCenterSettingsForm : Form
{
    private readonly CheckedListBox _items = new();
    private readonly TextBox _accent = new();
    private readonly ComboBox _columns = new();

    public List<string> VisibleActions { get; private set; } = new();
    public List<string> ActionOrder { get; private set; } = new();
    public string AccentHex { get; private set; } = string.Empty;
    public int Columns { get; private set; } = 3;

    public ControlCenterSettingsForm(IEnumerable<string>? visibleActions, IEnumerable<string>? actionOrder,
        string? accentHex, int columns)
    {
        Text = "Personalizar Central RX";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(620, 600);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var visible = (visibleActions ?? Array.Empty<string>()).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var order = (actionOrder ?? Array.Empty<string>()).ToList();
        var catalogIndexes = ControlCenterCommands.All
            .Select((command, index) => (command.Id, index))
            .ToDictionary(item => item.Id, item => item.index, StringComparer.OrdinalIgnoreCase);
        var ordered = ControlCenterCommands.All
            .OrderBy(command =>
            {
                var index = order.FindIndex(id => string.Equals(id, command.Id, StringComparison.OrdinalIgnoreCase));
                return index < 0 ? int.MaxValue : index;
            })
            .ThenBy(command => catalogIndexes[command.Id])
            .ToList();

        Controls.Add(new Label
        {
            Text = "PERSONALIZAR CENTRAL RX",
            Left = 22, Top = 18, Width = 560, Height = 34,
            Font = new Font("Segoe UI Black", 16, FontStyle.Bold),
            ForeColor = Color.FromArgb(50, 211, 235)
        });
        Controls.Add(new Label
        {
            Text = "Marque os cartões que deseja mostrar. Use as setas para alterar a ordem.",
            Left = 24, Top = 58, Width = 560, Height = 24,
            ForeColor = Color.FromArgb(160, 176, 194)
        });

        _items.SetBounds(24, 90, 460, 330);
        _items.BackColor = Color.FromArgb(20, 27, 37);
        _items.ForeColor = ForeColor;
        _items.BorderStyle = BorderStyle.FixedSingle;
        _items.CheckOnClick = true;
        foreach (var command in ordered)
            _items.Items.Add(command, visible.Count == 0 || visible.Contains(command.Id));
        Controls.Add(_items);

        var up = MakeButton("↑ Subir", 100);
        up.SetBounds(494, 100, 100, 34);
        up.Click += (_, _) => MoveSelected(-1);
        Controls.Add(up);
        var down = MakeButton("↓ Descer", 100);
        down.SetBounds(494, 142, 100, 34);
        down.Click += (_, _) => MoveSelected(1);
        Controls.Add(down);
        var all = MakeButton("Marcar todos", 100);
        all.SetBounds(494, 202, 100, 34);
        all.Click += (_, _) => SetAll(true);
        Controls.Add(all);
        var none = MakeButton("Desmarcar", 100);
        none.SetBounds(494, 244, 100, 34);
        none.Click += (_, _) => SetAll(false);
        Controls.Add(none);

        Controls.Add(new Label { Text = "Colunas", Left = 24, Top = 442, Width = 110, Height = 26, ForeColor = ForeColor });
        _columns.SetBounds(138, 438, 130, 30);
        _columns.DropDownStyle = ComboBoxStyle.DropDownList;
        _columns.Items.AddRange(new object[] { "2 colunas", "3 colunas", "4 colunas" });
        _columns.SelectedIndex = Math.Clamp(columns - 2, 0, 2);
        Controls.Add(_columns);

        Controls.Add(new Label { Text = "Cor de destaque (HEX)", Left = 24, Top = 484, Width = 170, Height = 26, ForeColor = ForeColor });
        _accent.SetBounds(194, 480, 150, 30);
        _accent.Text = accentHex ?? string.Empty;
        _accent.PlaceholderText = "#32D3EB ou vazio";
        _accent.BackColor = Color.FromArgb(27, 36, 49);
        _accent.ForeColor = ForeColor;
        _accent.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(_accent);
        Controls.Add(new Label
        {
            Text = "Deixe a cor vazia para usar a cor de destaque do perfil. A ordem e a visibilidade ficam salvas neste perfil.",
            Left = 24, Top = 520, Width = 560, Height = 34,
            ForeColor = Color.FromArgb(140, 157, 177), Font = new Font("Segoe UI", 8.5F)
        });

        var cancel = MakeButton("Cancelar", 100);
        cancel.SetBounds(378, 562, 100, 30);
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);
        var save = MakeButton("Salvar", 100, true);
        save.SetBounds(488, 562, 106, 30);
        save.Click += (_, _) => SaveAndClose();
        Controls.Add(save);
        CancelButton = cancel;
        AcceptButton = save;
    }

    private void MoveSelected(int delta)
    {
        var index = _items.SelectedIndex;
        var target = index + delta;
        if (index < 0 || target < 0 || target >= _items.Items.Count) return;
        var item = _items.Items[index];
        var isChecked = _items.GetItemChecked(index);
        _items.Items.RemoveAt(index);
        _items.Items.Insert(target, item);
        _items.SetItemChecked(target, isChecked);
        _items.SelectedIndex = target;
    }

    private void SetAll(bool value)
    {
        for (var i = 0; i < _items.Items.Count; i++) _items.SetItemChecked(i, value);
    }

    private void SaveAndClose()
    {
        var accent = _accent.Text.Trim();
        if (accent.Length > 0 && !System.Text.RegularExpressions.Regex.IsMatch(accent, "^#[0-9A-Fa-f]{6}$"))
        {
            MessageBox.Show(this, "Informe uma cor no formato #RRGGBB ou deixe o campo vazio.",
                "Cor inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        ActionOrder = _items.Items.Cast<ControlCenterCommandDefinition>().Select(item => item.Id).ToList();
        VisibleActions = _items.CheckedItems.Cast<ControlCenterCommandDefinition>().Select(item => item.Id).ToList();
        if (VisibleActions.Count == 0)
        {
            MessageBox.Show(this, "Mantenha pelo menos um cartão visível na Central RX.",
                "Central RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        AccentHex = accent;
        Columns = _columns.SelectedIndex + 2;
        DialogResult = DialogResult.OK;
        Close();
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
