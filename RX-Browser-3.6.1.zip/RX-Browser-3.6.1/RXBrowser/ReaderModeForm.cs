﻿using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Distraction-reduced article view with metadata, typography presets and export.</summary>
internal sealed class ReaderModeForm : Form
{
    private readonly RichTextBox _content = new();
    private readonly Label _meta = new();
    private readonly string _title;
    private readonly string _url;
    private readonly string _author;
    private readonly int _readingMinutes;
    private float _fontSize = 12.5F;
    private bool _lightTheme;
    private bool _serifFont = true;

    public ReaderModeForm(string title, string url, string text, string author = "", int readingMinutes = 1)
    {
        _title = string.IsNullOrWhiteSpace(title) ? "Leitura" : title.Trim();
        _url = url ?? string.Empty;
        _author = author?.Trim() ?? string.Empty;
        _readingMinutes = Math.Max(1, readingMinutes);

        Text = "RX Reader Intelligence — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(660, 540);
        Size = new Size(960, 780);
        BackColor = Color.FromArgb(13, 18, 25);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Panel { Dock = DockStyle.Top, Height = 112, BackColor = Color.FromArgb(20, 28, 39), Padding = new Padding(32, 14, 32, 10) };
        var titleLabel = new Label
        {
            Text = _title, Dock = DockStyle.Top, Height = 45, ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Semibold", 17F, FontStyle.Bold), AutoEllipsis = true
        };
        _meta.Dock = DockStyle.Fill;
        var details = new List<string>();
        if (!string.IsNullOrWhiteSpace(_author)) details.Add("Por " + _author);
        details.Add($"{_readingMinutes} min de leitura estimada");
        _meta.Text = string.Join("  •  ", details) + "\n" + _url;
        _meta.ForeColor = Color.FromArgb(142, 158, 178);
        _meta.AutoEllipsis = true;
        header.Controls.Add(_meta);
        header.Controls.Add(titleLabel);
        Controls.Add(header);

        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50, BackColor = Color.FromArgb(17, 23, 32), Padding = new Padding(20, 8, 12, 5), WrapContents = false, AutoScroll = true };
        var smaller = MakeButton("A−", 42);
        smaller.Click += (_, _) => ChangeFont(-1);
        var larger = MakeButton("A+", 42);
        larger.Click += (_, _) => ChangeFont(1);
        var font = new Button { Text = "Serif", Width = 72, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(27, 36, 49), ForeColor = Color.FromArgb(232, 240, 248), Margin = new Padding(3, 0, 3, 0) };
        font.FlatAppearance.BorderSize = 0;
        font.Click += (_, _) =>
        {
            _serifFont = !_serifFont;
            font.Text = _serifFont ? "Serif" : "Sans";
            ApplyTypography();
        };
        var theme = MakeButton("Tema claro", 94);
        theme.Click += (_, _) => ToggleTheme(theme);
        var copy = MakeButton("Copiar", 76);
        copy.Click += (_, _) =>
        {
            try { Clipboard.SetText(_content.Text); } catch (Exception ex) { MessageBox.Show(this, "Não foi possível copiar o texto.\n\n" + ex.Message, "RX Reader", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        };
        var export = MakeButton("Exportar…", 90);
        export.Click += (_, _) => ExportArticle();
        var select = MakeButton("Selecionar tudo", 112);
        select.Click += (_, _) => { _content.SelectAll(); _content.Focus(); };
        toolbar.Controls.AddRange([smaller, larger, font, theme, copy, export, select]);
        Controls.Add(toolbar);

        _content.Dock = DockStyle.Fill;
        _content.ReadOnly = true;
        _content.BorderStyle = BorderStyle.None;
        _content.BackColor = Color.FromArgb(13, 18, 25);
        _content.ForeColor = Color.FromArgb(225, 230, 237);
        _content.Font = new Font("Georgia", _fontSize);
        _content.WordWrap = true;
        _content.DetectUrls = true;
        _content.ScrollBars = RichTextBoxScrollBars.Vertical;
        _content.Text = string.IsNullOrWhiteSpace(text) ? "Não foi possível identificar o texto principal desta página." : text;
        _content.Select(0, 0);
        _content.Padding = new Padding(38, 24, 38, 30);
        Controls.Add(_content);
    }

    private Button MakeButton(string text, int width)
    {
        var button = new Button { Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(27, 36, 49), ForeColor = Color.FromArgb(232, 240, 248), Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold), Margin = new Padding(3, 0, 3, 0), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void ChangeFont(float amount)
    {
        _fontSize = Math.Clamp(_fontSize + amount, 9F, 24F);
        ApplyTypography();
    }

    private void ApplyTypography()
    {
        var selectionStart = _content.SelectionStart;
        var selectionLength = _content.SelectionLength;
        _content.Font = new Font(_serifFont ? "Georgia" : "Segoe UI", _fontSize);
        _content.Select(Math.Min(selectionStart, _content.TextLength), Math.Min(selectionLength, Math.Max(0, _content.TextLength - selectionStart)));
    }

    private void ToggleTheme(Button button)
    {
        _lightTheme = !_lightTheme;
        BackColor = _lightTheme ? Color.FromArgb(248, 246, 240) : Color.FromArgb(13, 18, 25);
        _content.BackColor = _lightTheme ? Color.FromArgb(248, 246, 240) : Color.FromArgb(13, 18, 25);
        _content.ForeColor = _lightTheme ? Color.FromArgb(38, 42, 48) : Color.FromArgb(225, 230, 237);
        button.Text = _lightTheme ? "Tema escuro" : "Tema claro";
    }

    private void ExportArticle()
    {
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar artigo do RX Reader",
            Filter = "Markdown (*.md)|*.md|Texto simples (*.txt)|*.txt",
            FileName = SanitizeFileName(_title) + ".md",
            AddExtension = true,
            DefaultExt = "md"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        var isMarkdown = string.Equals(Path.GetExtension(dialog.FileName), ".md", StringComparison.OrdinalIgnoreCase);
        var output = isMarkdown
            ? "# " + _title + "\n\n" + (string.IsNullOrWhiteSpace(_author) ? string.Empty : "**Autor:** " + _author + "\n\n") +
              "**Fonte:** " + _url + "\n\n---\n\n" + _content.Text + "\n"
            : _title + "\n" + (string.IsNullOrWhiteSpace(_author) ? string.Empty : "Por " + _author + "\n") + _url + "\n\n" + _content.Text;
        try
        {
            File.WriteAllText(dialog.FileName, output, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            MessageBox.Show(this, "Artigo exportado com sucesso.", "RX Reader", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível exportar o artigo.\n\n" + ex.Message, "RX Reader", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var safe = new string(value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(safe) ? "artigo-rx-reader" : safe.Length > 90 ? safe[..90] : safe;
    }
}
