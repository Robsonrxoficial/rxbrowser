﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed record SpeechVoiceOption(string Name, string Language)
{
    public override string ToString() => string.IsNullOrWhiteSpace(Name)
        ? "Voz padrão do WebView2"
        : $"{Name}  ·  {Language}";
}

internal sealed class SpeechSettingsForm : Form
{
    private readonly ComboBox _voices = new();
    private readonly NumericUpDown _rate = new();
    private readonly NumericUpDown _pitch = new();

    public string VoiceName => _voices.SelectedItem is SpeechVoiceOption option ? option.Name : string.Empty;
    public string VoiceLanguage => _voices.SelectedItem is SpeechVoiceOption option ? option.Language : string.Empty;
    public double Rate => (double)_rate.Value;
    public double Pitch => (double)_pitch.Value;

    public SpeechSettingsForm(IReadOnlyList<SpeechVoiceOption> voices, string selectedVoice, double rate, double pitch)
    {
        Text = "Voz e velocidade — RX Browser 2.3";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(500, 285);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var title = new Label
        {
            Text = "CONFIGURAR LEITURA EM VOZ ALTA",
            Left = 18, Top = 16, Width = 460, Height = 26,
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold)
        };
        Controls.Add(title);

        Controls.Add(new Label { Text = "Voz disponível", Left = 20, Top = 58, Width = 145, Height = 24, ForeColor = ForeColor });
        _voices.Left = 170;
        _voices.Top = 54;
        _voices.Width = 305;
        _voices.DropDownStyle = ComboBoxStyle.DropDownList;
        _voices.BackColor = Color.FromArgb(27, 36, 49);
        _voices.ForeColor = ForeColor;
        _voices.Items.Add(new SpeechVoiceOption(string.Empty, string.Empty));
        foreach (var voice in voices.OrderBy(v => v.Language).ThenBy(v => v.Name))
            _voices.Items.Add(voice);
        var selectedIndex = 0;
        for (var i = 1; i < _voices.Items.Count; i++)
        {
            if (_voices.Items[i] is SpeechVoiceOption voice &&
                string.Equals(voice.Name, selectedVoice, StringComparison.OrdinalIgnoreCase))
            {
                selectedIndex = i;
                break;
            }
        }
        _voices.SelectedIndex = selectedIndex;
        Controls.Add(_voices);

        Controls.Add(new Label { Text = "Velocidade", Left = 20, Top = 103, Width = 145, Height = 24, ForeColor = ForeColor });
        ConfigureNumber(_rate, 170, 99, 305, 0.5M, 2.0M, 0.1M, (decimal)Math.Clamp(rate, 0.5, 2.0));
        Controls.Add(_rate);
        Controls.Add(new Label { Text = "Tom da voz", Left = 20, Top = 148, Width = 145, Height = 24, ForeColor = ForeColor });
        ConfigureNumber(_pitch, 170, 144, 305, 0.5M, 2.0M, 0.1M, (decimal)Math.Clamp(pitch, 0.5, 2.0));
        Controls.Add(_pitch);

        var note = new Label
        {
            Text = voices.Count == 0
                ? "Nenhuma voz foi listada pelo WebView2. A voz padrão ainda pode funcionar."
                : "As vozes disponíveis dependem do Windows e do WebView2 Runtime.",
            Left = 20, Top = 190, Width = 455, Height = 36,
            ForeColor = Color.FromArgb(142, 158, 178)
        };
        Controls.Add(note);

        var save = MakeButton("Salvar", 300, 238, DialogResult.OK);
        var cancel = MakeButton("Cancelar", 390, 238, DialogResult.Cancel);
        Controls.Add(save);
        Controls.Add(cancel);
        AcceptButton = save;
        CancelButton = cancel;
    }

    private static void ConfigureNumber(NumericUpDown input, int left, int top, int width,
        decimal min, decimal max, decimal increment, decimal value)
    {
        input.Left = left;
        input.Top = top;
        input.Width = width;
        input.Minimum = min;
        input.Maximum = max;
        input.Increment = increment;
        input.DecimalPlaces = 1;
        input.Value = Math.Clamp(value, min, max);
        input.BackColor = Color.FromArgb(27, 36, 49);
        input.ForeColor = Color.FromArgb(232, 240, 248);
    }

    private static Button MakeButton(string text, int left, int top, DialogResult result)
    {
        var button = new Button
        {
            Text = text, Left = left, Top = top, Width = 82, Height = 32,
            DialogResult = result, FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(27, 45, 59), ForeColor = Color.FromArgb(232, 240, 248),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderColor = Color.FromArgb(54, 77, 96);
        return button;
    }
}
