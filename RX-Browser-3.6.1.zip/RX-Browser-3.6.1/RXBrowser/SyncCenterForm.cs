﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Unified control panel for bookmark and non-secret preference sync through a user-selected folder.</summary>
internal sealed class SyncCenterForm : Form
{
    private readonly TextBox _folder = new();
    private readonly CheckBox _auto = new();
    public string FolderPath => _folder.Text.Trim();
    public bool AutoSyncEnabled => _auto.Checked;
    public bool ImportRequested { get; private set; }
    public bool SyncNowRequested { get; private set; }

    public SyncCenterForm(string currentFolder, bool autoSync)
    {
        Text = "Central de sincronização — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(650, 345);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label { Text = "SINCRONIZAÇÃO RX", Left = 24, Top = 18, Width = 590, Height = 30, ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold) });
        Controls.Add(new Label { Text = "Pasta compartilhada (OneDrive, Dropbox, rede local ou outra pasta sincronizada)", Left = 24, Top = 65, Width = 600, Height = 24, ForeColor = ForeColor });
        _folder.SetBounds(24, 94, 486, 34);
        _folder.Text = currentFolder;
        _folder.BackColor = Color.FromArgb(27, 36, 49);
        _folder.ForeColor = ForeColor;
        _folder.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(_folder);
        var browse = MakeButton("Escolher…", 112, false);
        browse.SetBounds(516, 94, 110, 34);
        browse.Click += (_, _) =>
        {
            using var picker = new FolderBrowserDialog { Description = "Escolha uma pasta compartilhada entre seus dispositivos.", UseDescriptionForTitle = true, ShowNewFolderButton = true };
            if (Directory.Exists(_folder.Text)) picker.SelectedPath = _folder.Text;
            if (picker.ShowDialog(this) == DialogResult.OK) _folder.Text = picker.SelectedPath;
        };
        Controls.Add(browse);

        _auto.Text = "Sincronizar favoritos em segundo plano a cada minuto e publicar preferências não secretas";
        _auto.SetBounds(26, 149, 600, 28);
        _auto.Checked = autoSync;
        _auto.ForeColor = ForeColor;
        _auto.BackColor = BackColor;
        Controls.Add(_auto);

        var explanation = new Label
        {
            Text = "O RX combina favoritos usando registros de atualização e exclusões. As preferências são publicadas em um arquivo separado por dispositivo; importar configurações de outro computador continua exigindo confirmação. Senhas, cookies, histórico, downloads, extensões e dados do perfil nunca entram nesta sincronização.",
            Left = 26, Top = 190, Width = 596, Height = 82, ForeColor = Color.FromArgb(142, 158, 178), Font = new Font("Segoe UI", 8.5F)
        };
        Controls.Add(explanation);

        var cancel = MakeButton("Cancelar", 104, false);
        cancel.SetBounds(204, 292, 86, 34);
        cancel.DialogResult = DialogResult.Cancel;
        var sync = MakeButton("Sincronizar agora", 130, false);
        sync.SetBounds(294, 292, 126, 34);
        sync.Click += (_, _) => { SyncNowRequested = true; DialogResult = DialogResult.OK; Close(); };
        var import = MakeButton("Importar config.", 126, false);
        import.SetBounds(424, 292, 102, 34);
        import.Click += (_, _) => { ImportRequested = true; DialogResult = DialogResult.OK; Close(); };
        var save = MakeButton("Salvar", 86, true);
        save.SetBounds(530, 292, 96, 34);
        save.Click += (_, _) => { DialogResult = DialogResult.OK; Close(); };
        Controls.AddRange([cancel, sync, import, save]);
        CancelButton = cancel;
        AcceptButton = save;
    }

    private Button MakeButton(string text, int width, bool accent)
    {
        var button = new Button { Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49), ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor, Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
