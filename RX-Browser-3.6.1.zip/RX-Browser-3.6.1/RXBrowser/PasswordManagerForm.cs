﻿using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace RXBrowser;

internal sealed class PasswordManagerForm : Form
{
    private static readonly Color Bg = Color.FromArgb(12, 16, 23);
    private static readonly Color Panel = Color.FromArgb(20, 27, 37);
    private static readonly Color Panel2 = Color.FromArgb(27, 36, 49);
    private static readonly Color Accent = Color.FromArgb(35, 205, 230);
    private static readonly Color TextColor = Color.FromArgb(232, 240, 248);
    private static readonly Color Muted = Color.FromArgb(142, 158, 178);

    private readonly ListView _list = new();
    private readonly TextBox _search = new();
    private readonly Label _count = new();
    private readonly Button _fillButton;
    private readonly List<SavedCredential> _entries;
    private readonly string _currentHost;
    private readonly string _currentOrigin;
    private readonly Action<string, string>? _fillCallback;
    private readonly System.Windows.Forms.Timer _clipboardTimer = new() { Interval = 20000 };
    private string? _clipboardValue;

    public PasswordManagerForm(string? currentUrl = null, bool autofillMasterEnabled = false, Action<string, string>? fillCallback = null)
    {
        Text = "Cofre de senhas — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1000, 590);
        MinimumSize = new Size(860, 470);
        BackColor = Bg;
        ForeColor = TextColor;
        Font = new Font("Segoe UI", 9F);
        _entries = PasswordVault.Load();
        var secureCurrentUrl = PasswordVault.IsSecureHttpUrl(currentUrl, out var currentUri);
        _currentHost = secureCurrentUrl ? currentUri!.IdnHost : string.Empty;
        _currentOrigin = secureCurrentUrl ? currentUri!.GetLeftPart(UriPartial.Authority) : string.Empty;
        _fillCallback = autofillMasterEnabled && !string.IsNullOrWhiteSpace(_currentHost) ? fillCallback : null;

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1, BackColor = Bg, Padding = new Padding(14) };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));
        Controls.Add(root);

        var top = new Panel { Dock = DockStyle.Fill, BackColor = Bg };
        var heading = new Label { Text = "COFRE DE SENHAS", Dock = DockStyle.Left, Width = 220, ForeColor = Accent, Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        _search.Dock = DockStyle.Right;
        _search.Width = 350;
        _search.PlaceholderText = "Filtrar por site ou usuário";
        _search.BackColor = Panel2;
        _search.ForeColor = TextColor;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.TextChanged += (_, _) => RefreshList();
        top.Controls.Add(_search);
        top.Controls.Add(heading);
        root.Controls.Add(top, 0, 0);

        _list.Dock = DockStyle.Fill;
        _list.View = View.Details;
        _list.FullRowSelect = true;
        _list.GridLines = true;
        _list.HideSelection = false;
        _list.MultiSelect = false;
        _list.BackColor = Panel;
        _list.ForeColor = TextColor;
        _list.BorderStyle = BorderStyle.FixedSingle;
        _list.Columns.Add("Site", 360);
        _list.Columns.Add("Usuário", 300);
        _list.Columns.Add("Atualizado", 150);
        _list.Columns.Add("Preenchimento", 120);
        _list.DoubleClick += (_, _) => EditSelected();
        _list.SelectedIndexChanged += (_, _) => UpdateFillButton();
        _list.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Delete) { e.SuppressKeyPress = true; RemoveSelected(); }
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; EditSelected(); }
        };
        root.Controls.Add(_list, 0, 1);

        var bottom = new Panel { Dock = DockStyle.Fill, BackColor = Bg };
        _count.Dock = DockStyle.Left;
        _count.Width = 165;
        _count.ForeColor = Muted;
        _count.TextAlign = ContentAlignment.MiddleLeft;
        var actions = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 790, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, BackColor = Bg };
        var closeButton = MakeButton("Fechar", 76);
        closeButton.Click += (_, _) => Close();
        var removeButton = MakeButton("Remover", 84);
        removeButton.Click += (_, _) => RemoveSelected();
        var copyPasswordButton = MakeButton("Copiar senha", 110);
        copyPasswordButton.Click += (_, _) => CopySelected(password: true);
        var copyUsernameButton = MakeButton("Copiar usuário", 120);
        copyUsernameButton.Click += (_, _) => CopySelected(password: false);
        var editButton = MakeButton("Editar", 78);
        editButton.Click += (_, _) => EditSelected();
        var addButton = MakeButton("Adicionar", 88, true);
        addButton.Click += (_, _) => AddNew();
        _fillButton = MakeButton("Preencher no site", 165, true);
        _fillButton.Enabled = false;
        _fillButton.Click += (_, _) => FillSelected();
        _fillButton.Visible = autofillMasterEnabled;
        actions.Controls.AddRange(new Control[] { closeButton, removeButton, copyPasswordButton, copyUsernameButton, editButton, addButton, _fillButton });
        bottom.Controls.Add(actions);
        bottom.Controls.Add(_count);
        root.Controls.Add(bottom, 0, 2);

        _clipboardTimer.Tick += (_, _) =>
        {
            _clipboardTimer.Stop();
            try
            {
                if (_clipboardValue is not null && Clipboard.ContainsText() && Clipboard.GetText() == _clipboardValue)
                    Clipboard.Clear();
            }
            catch { }
            _clipboardValue = null;
        };
        FormClosed += (_, _) =>
        {
            _clipboardTimer.Stop();
            try
            {
                if (_clipboardValue is not null && Clipboard.ContainsText() && Clipboard.GetText() == _clipboardValue)
                    Clipboard.Clear();
            }
            catch { }
            _clipboardValue = null;
            _clipboardTimer.Dispose();
        };
        RefreshList();
    }

    private static Button MakeButton(string label, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = label, Width = width, Height = 36, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Panel,
            ForeColor = accent ? Accent : TextColor,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            Margin = new Padding(3, 8, 3, 0), Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = Panel2;
        return button;
    }

    private void RefreshList()
    {
        _list.BeginUpdate();
        _list.Items.Clear();
        var filter = _search.Text.Trim();
        foreach (var entry in _entries
                     .Where(x => string.IsNullOrWhiteSpace(filter) ||
                         x.Site.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                         x.Username.Contains(filter, StringComparison.OrdinalIgnoreCase))
                     .OrderBy(x => x.Site, StringComparer.OrdinalIgnoreCase))
        {
            var row = new ListViewItem(entry.Site) { Tag = entry };
            row.SubItems.Add(entry.Username);
            row.SubItems.Add(entry.UpdatedUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm"));
            row.SubItems.Add(entry.AutofillEnabled ? "Autorizado" : "Desativado");
            _list.Items.Add(row);
        }
        _list.EndUpdate();
        _count.Text = _fillCallback is null
            ? $"{_entries.Count} registro(s) · preenchimento indisponível"
            : $"{_entries.Count} registro(s) · site: {_currentHost}";
        UpdateFillButton();
    }

    private void UpdateFillButton()
    {
        if (_fillButton is null || _fillButton.IsDisposed) return;
        var selected = Selected;
        _fillButton.Enabled = _fillCallback is not null && selected is not null && selected.AutofillEnabled &&
            PasswordVault.MatchesExactOrigin(selected.Site, _currentOrigin);
        _fillButton.Text = _fillCallback is null ? "Preenchimento desativado" : "Preencher no site";
    }

    private void FillSelected()
    {
        var selected = Selected;
        if (selected is null || _fillCallback is null || !selected.AutofillEnabled ||
            !PasswordVault.MatchesExactOrigin(selected.Site, _currentOrigin)) return;
        var answer = MessageBox.Show(this,
            $"Preencher manualmente usuário e senha em {_currentOrigin}?\n\nA correspondência exige a origem exata e HTTPS (ou localhost de desenvolvimento). O formulário não será enviado automaticamente.",
            "Confirmar preenchimento — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes) return;
        try
        {
            _fillCallback(selected.Username, selected.Password);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível preencher os campos.\n\n" + ex.Message,
                "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private SavedCredential? Selected => _list.SelectedItems.Count == 0 ? null : _list.SelectedItems[0].Tag as SavedCredential;

    private void AddNew()
    {
        using var dialog = new CredentialEditDialog();
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        var item = dialog.Result;
        if (item is null) return;
        _entries.Add(item);
        SaveAndRefresh();
    }

    private void EditSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        using var dialog = new CredentialEditDialog(selected);
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Result is null) return;
        selected.Site = dialog.Result.Site;
        selected.Username = dialog.Result.Username;
        selected.Password = dialog.Result.Password;
        selected.Notes = dialog.Result.Notes;
        selected.AutofillEnabled = dialog.Result.AutofillEnabled;
        selected.UpdatedUtc = DateTime.UtcNow;
        SaveAndRefresh();
    }

    private void RemoveSelected()
    {
        var selected = Selected;
        if (selected is null) return;
        if (MessageBox.Show(this, $"Remover as credenciais salvas para {selected.Site}?", "Cofre RX", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        _entries.Remove(selected);
        SaveAndRefresh();
    }

    private void CopySelected(bool password)
    {
        var selected = Selected;
        if (selected is null) return;
        var value = password ? selected.Password : selected.Username;
        if (string.IsNullOrEmpty(value)) return;
        try
        {
            _clipboardTimer.Stop();
            Clipboard.SetText(value);
            _clipboardValue = value;
            _clipboardTimer.Start();
            MessageBox.Show(this, password
                ? "Senha copiada. O RX Browser tentará limpar a área de transferência em 20 segundos, se ela ainda contiver este valor."
                : "Nome de usuário copiado.", "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(this, "Não foi possível copiar: " + ex.Message, "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void SaveAndRefresh()
    {
        try { PasswordVault.Save(_entries); RefreshList(); }
        catch (Exception ex) { MessageBox.Show(this, "Não foi possível salvar o cofre.\n\n" + ex.Message, "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}

internal sealed class CredentialEditDialog : Form
{
    private readonly TextBox _site = new();
    private readonly TextBox _username = new();
    private readonly TextBox _password = new();
    private readonly TextBox _notes = new();
    private readonly CheckBox _autofill = new();
    public SavedCredential? Result { get; private set; }

    public CredentialEditDialog(SavedCredential? existing = null)
    {
        Text = existing is null ? "Adicionar credencial" : "Editar credencial";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(500, 365);
        BackColor = Color.FromArgb(20, 27, 37);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        AddField("Site / endereço", _site, 18, existing?.Site ?? string.Empty);
        AddField("Nome de usuário", _username, 77, existing?.Username ?? string.Empty);
        AddField("Senha", _password, 136, existing?.Password ?? string.Empty);
        _password.UseSystemPasswordChar = true;
        _password.Width = 350;
        AddField("Observações (opcional)", _notes, 195, existing?.Notes ?? string.Empty);

        var show = MakeButton("Mostrar", 78, 156);
        show.Left = 404;
        show.Click += (_, _) => _password.UseSystemPasswordChar = !_password.UseSystemPasswordChar;
        _autofill.Text = "Permitir preenchimento manual neste site (origem exata, HTTPS ou localhost)";
        _autofill.Left = 18; _autofill.Top = 252; _autofill.Width = 464; _autofill.Height = 26;
        _autofill.Checked = existing?.AutofillEnabled ?? false;
        _autofill.ForeColor = ForeColor; _autofill.BackColor = BackColor;
        Controls.Add(_autofill);
        var generate = MakeButton("Gerar senha", 100, 310);
        generate.Click += (_, _) => { _password.Text = GeneratePassword(); _password.UseSystemPasswordChar = false; };
        var save = MakeButton("Salvar", 86, 310, true);
        var cancel = MakeButton("Cancelar", 86, 310);
        save.Left = 306;
        cancel.Left = 400;
        save.DialogResult = DialogResult.None;
        cancel.DialogResult = DialogResult.Cancel;
        save.Click += (_, _) => SaveCredential();
        Controls.AddRange(new Control[] { show, generate, save, cancel });
        AcceptButton = save;
        CancelButton = cancel;
        Shown += (_, _) => { _site.Focus(); _site.SelectAll(); };
    }

    private void AddField(string label, TextBox box, int top, string value)
    {
        Controls.Add(new Label { Text = label, Left = 18, Top = top, Width = 185, Height = 22, ForeColor = ForeColor });
        box.Left = 18;
        box.Top = top + 22;
        box.Width = 464;
        box.Height = 27;
        box.Text = value;
        box.BackColor = Color.FromArgb(27, 36, 49);
        box.ForeColor = ForeColor;
        box.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(box);
    }

    private Button MakeButton(string text, int width, int top, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 31, Left = 18, Top = top,
            FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(35, 205, 230) : ForeColor,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void SaveCredential()
    {
        var site = _site.Text.Trim();
        var user = _username.Text.Trim();
        if (string.IsNullOrWhiteSpace(site) || string.IsNullOrWhiteSpace(user) || string.IsNullOrEmpty(_password.Text))
        {
            MessageBox.Show(this, "Preencha o site, o nome de usuário e a senha.", "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (string.IsNullOrWhiteSpace(PasswordVault.NormalizeHost(site)))
        {
            MessageBox.Show(this, "Informe um endereço HTTP ou HTTPS válido, por exemplo https://exemplo.com.", "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var autofillCandidate = site.Contains("://", StringComparison.Ordinal) ? site : "https://" + site;
        if (_autofill.Checked && !PasswordVault.IsSecureHttpUrl(autofillCandidate, out _))
        {
            MessageBox.Show(this, "O preenchimento só pode ser autorizado para HTTPS. HTTP é permitido apenas em localhost/loopback.", "Cofre RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        Result = new SavedCredential
        {
            Site = site,
            Username = user,
            Password = _password.Text,
            Notes = _notes.Text.Trim(),
            AutofillEnabled = _autofill.Checked,
            UpdatedUtc = DateTime.UtcNow
        };
        DialogResult = DialogResult.OK;
        Close();
    }

    private static string GeneratePassword()
    {
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%_-+";
        var result = new StringBuilder(24);
        for (var i = 0; i < 24; i++) result.Append(alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)]);
        return result.ToString();
    }
}
