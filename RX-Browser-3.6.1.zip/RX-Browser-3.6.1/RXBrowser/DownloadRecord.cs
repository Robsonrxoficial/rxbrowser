﻿using Microsoft.Web.WebView2.Core;

namespace RXBrowser;

internal sealed class DownloadRecord
{
    public required string FilePath { get; init; }
    public required string SourceUri { get; init; }
    public required DateTime StartedAt { get; init; }
    public CoreWebView2DownloadOperation? Operation { get; set; }
    public long BytesReceived { get; set; }
    public ulong? TotalBytesToReceive { get; set; }
    public string State { get; set; } = "Preparando";
    public bool WasPausedByUser { get; set; }
    public bool WasCancelledByUser { get; set; }
    public DateTime? EstimatedEndTime { get; set; }
    public string SecurityLevel { get; set; } = "Baixo";
    public string SecurityReason { get; set; } = string.Empty;
    public bool CanResume
    {
        get
        {
            try { return Operation is not null && Operation.State == CoreWebView2DownloadState.Interrupted && !WasCancelledByUser && (WasPausedByUser || Operation.CanResume); }
            catch { return false; }
        }
    }
    public bool CanPause
    {
        get
        {
            try { return Operation?.State == CoreWebView2DownloadState.InProgress && !WasCancelledByUser; }
            catch { return false; }
        }
    }

    // WebView2 expõe TotalBytesToReceive como ulong? (pode ser desconhecido).
    // Preservamos o null para downloads sem Content-Length informado pelo servidor.
    public int ProgressPercent
    {
        get
        {
            var total = TotalBytesToReceive;
            if (!total.HasValue || total.Value == 0) return 0;
            return (int)Math.Clamp(BytesReceived * 100d / (double)total.Value, 0, 100);
        }
    }

    public string ProgressText => TotalBytesToReceive is ulong totalBytes && totalBytes > 0
        ? $"{ProgressPercent}%"
        : FormatBytes(BytesReceived);

    public static string FormatBytes(long bytes)
    {
        if (bytes < 0) return "—";
        return FormatBytes((ulong)bytes);
    }

    public static string FormatBytes(ulong bytes)
    {
        string[] units = ["B", "KB", "MB", "GB", "TB"];
        double value = bytes;
        var unit = 0;
        while (value >= 1024 && unit < units.Length - 1)
        {
            value /= 1024;
            unit++;
        }
        return $"{value:0.#} {units[unit]}";
    }
}
