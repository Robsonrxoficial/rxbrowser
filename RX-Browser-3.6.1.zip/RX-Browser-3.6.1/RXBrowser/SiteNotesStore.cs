﻿using System.Text;
using System.Text.Json;

namespace RXBrowser;

/// <summary>Notas locais vinculadas a um site. O arquivo não faz parte dos dados de sincronização.</summary>
internal sealed class SiteNoteRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "Nova nota";
    public string Url { get; set; } = string.Empty;
    public string Site { get; set; } = "Geral";
    public string Body { get; set; } = string.Empty;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;

    public override string ToString() => $"{Title}  ·  {Site}  ·  {UpdatedUtc.ToLocalTime():dd/MM HH:mm}";
}

internal static class SiteNotesStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static string StoreFile => Path.Combine(BrowserStorage.ProfileRoot, "site-notes.json");

    public static List<SiteNoteRecord> Load()
    {
        Directory.CreateDirectory(BrowserStorage.ProfileRoot);
        if (!File.Exists(StoreFile)) return new List<SiteNoteRecord>();

        try
        {
            var notes = JsonSerializer.Deserialize<List<SiteNoteRecord>>(File.ReadAllText(StoreFile))
                ?? new List<SiteNoteRecord>();
            return notes
                .Where(note => note is not null && Guid.TryParseExact(note.Id, "N", out _))
                .GroupBy(note => note.Id, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.OrderByDescending(note => note.UpdatedUtc).First())
                .OrderByDescending(note => note.UpdatedUtc)
                .Take(500)
                .ToList();
        }
        catch (Exception exception)
        {
            BrowserDiagnosticsLog.Write("SiteNotes.Load", exception);
            return new List<SiteNoteRecord>();
        }
    }

    public static void Save(IReadOnlyCollection<SiteNoteRecord> notes)
    {
        Directory.CreateDirectory(BrowserStorage.ProfileRoot);
        var temporary = StoreFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            var safeNotes = notes
                .Where(note => note is not null && Guid.TryParseExact(note.Id, "N", out _))
                .Take(500)
                .ToList();
            File.WriteAllText(temporary, JsonSerializer.Serialize(safeNotes, JsonOptions), new UTF8Encoding(false));
            File.Move(temporary, StoreFile, true);
        }
        finally
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
        }
    }

    public static string GetSiteLabel(string? url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return "Geral";
        if (uri.Scheme is "http" or "https")
            return uri.IsDefaultPort ? uri.IdnHost : $"{uri.IdnHost}:{uri.Port}";
        return uri.IsFile ? "Arquivo local" : uri.Scheme;
    }

    // Guarda somente a origem: caminhos, parâmetros e fragmentos podem conter tokens ou dados pessoais.
    public static string GetSafeReferenceUrl(string? url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return string.Empty;
        return uri.Scheme is "http" or "https" ? uri.GetLeftPart(UriPartial.Authority) : string.Empty;
    }
}
