﻿using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace RXBrowser;

internal sealed class PdfDocumentNotes
{
    public string FilePath { get; set; } = string.Empty;
    public List<PdfBookmark> Bookmarks { get; set; } = new();
    public List<PdfAnnotation> Annotations { get; set; } = new();
}

internal sealed class PdfBookmark
{
    public int Page { get; set; }
    public string Label { get; set; } = string.Empty;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

internal sealed class PdfAnnotation
{
    public int Page { get; set; }
    public string Text { get; set; } = string.Empty;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
}

internal static class PdfNotesStore
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

    public static PdfDocumentNotes Load(string path)
    {
        var full = Path.GetFullPath(path);
        var file = GetStorePath(full);
        try
        {
            if (File.Exists(file))
            {
                var loaded = JsonSerializer.Deserialize<PdfDocumentNotes>(File.ReadAllText(file));
                if (loaded is not null && string.Equals(Path.GetFullPath(loaded.FilePath), full, StringComparison.OrdinalIgnoreCase))
                    return loaded;
            }
        }
        catch { }
        return new PdfDocumentNotes { FilePath = full };
    }

    public static void Save(PdfDocumentNotes data)
    {
        data.FilePath = Path.GetFullPath(data.FilePath);
        var file = GetStorePath(data.FilePath);
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        var temp = file + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(temp, JsonSerializer.Serialize(data, Options), Encoding.UTF8);
            File.Move(temp, file, true);
        }
        finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
    }

    private static string GetStorePath(string path)
    {
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(path.ToUpperInvariant())));
        return Path.Combine(BrowserStorage.ProfileRoot, "PdfNotes", hash + ".json");
    }
}
