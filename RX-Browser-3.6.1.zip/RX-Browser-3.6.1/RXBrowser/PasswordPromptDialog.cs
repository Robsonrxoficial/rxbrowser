﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal static class PasswordPromptDialog
{
    public static string? Show(IWin32Window owner, string title, string prompt, string confirmPrompt = "", bool numericOnly = false)
    {
        var needsConfirmation = !string.IsNullOrWhiteSpace(confirmPrompt);
        using var dialog = new Form
        {
            Text = title,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MinimizeBox = false,
            MaximizeBox = false,
            ShowInTaskbar = false,
            ClientSize = new Size(470, needsConfirmation ? 240 : 190),
            BackColor = Color.FromArgb(20, 27, 37),
            ForeColor = Color.FromArgb(232, 240, 248),
            Font = new Font("Segoe UI", 9F)
        };
        var label = new Label { Text = prompt, Left = 18, Top = 16, Width = 432, Height = 38, ForeColor = dialog.ForeColor };
        var input = new TextBox { Left = 18, Top = 58, Width = 432, Height = 28, UseSystemPasswordChar = true, BackColor = Color.FromArgb(27, 36, 49), ForeColor = dialog.ForeColor, BorderStyle = BorderStyle.FixedSingle };
        if (numericOnly) input.MaxLength = 12;
        if (numericOnly) input.KeyPress += (_, e) => { if (!char.IsControl(e.KeyChar) && (e.KeyChar < '0' || e.KeyChar > '9')) e.Handled = true; };
        dialog.Controls.AddRange(new Control[] { label, input });
        TextBox? confirmation = null;
        if (needsConfirmation)
        {
            dialog.Controls.Add(new Label { Text = confirmPrompt, Left = 18, Top = 100, Width = 432, Height = 23, ForeColor = dialog.ForeColor });
            confirmation = new TextBox { Left = 18, Top = 126, Width = 432, Height = 28, UseSystemPasswordChar = true, BackColor = Color.FromArgb(27, 36, 49), ForeColor = dialog.ForeColor, BorderStyle = BorderStyle.FixedSingle };
            if (numericOnly) confirmation.MaxLength = 12;
            if (numericOnly) confirmation.KeyPress += (_, e) => { if (!char.IsControl(e.KeyChar) && (e.KeyChar < '0' || e.KeyChar > '9')) e.Handled = true; };
            dialog.Controls.Add(confirmation);
        }
        var ok = new Button { Text = "Continuar", Left = 268, Top = needsConfirmation ? 184 : 134, Width = 86, Height = 34, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Cancelar", Left = 364, Top = needsConfirmation ? 184 : 134, Width = 86, Height = 34, DialogResult = DialogResult.Cancel };
        foreach (var button in new[] { ok, cancel })
        {
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = Color.FromArgb(27, 36, 49);
            button.ForeColor = dialog.ForeColor;
            button.FlatAppearance.BorderSize = 0;
        }
        dialog.Controls.AddRange(new Control[] { ok, cancel });
        dialog.AcceptButton = ok;
        dialog.CancelButton = cancel;
        dialog.Shown += (_, _) => input.Focus();
        if (dialog.ShowDialog(owner) != DialogResult.OK) return null;
        if (numericOnly && (input.Text.Length is < 6 or > 12 || input.Text.Any(ch => ch < '0' || ch > '9')))
        {
            MessageBox.Show(owner, "O PIN deve conter de 6 a 12 dígitos.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return null;
        }
        if (confirmation is not null && !string.Equals(input.Text, confirmation.Text, StringComparison.Ordinal))
        {
            MessageBox.Show(owner, "As senhas não coincidem.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return null;
        }
        return input.Text;
    }
}
