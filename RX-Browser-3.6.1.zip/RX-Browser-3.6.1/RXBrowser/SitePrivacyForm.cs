﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Per-site switches for the RX request filters; unchecked switches create a domain exception.</summary>
internal sealed class SitePrivacyForm : Form
{
    private readonly CheckBox _ads = new();
    private readonly CheckBox _tracking = new();
    private readonly Label _hostLabel = new();
    public bool BlockAds => _ads.Checked;
    public bool BlockTracking => _tracking.Checked;

    public SitePrivacyForm(string host, bool blockAds, bool blockTracking)
    {
        Text = "Privacidade deste site — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(520, 280);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label { Text = "CONTROLES DE PRIVACIDADE POR SITE", Left = 22, Top = 18, Width = 475, Height = 28, ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 11.5F, FontStyle.Bold) });
        _hostLabel.SetBounds(24, 58, 470, 26);
        _hostLabel.Text = host;
        _hostLabel.ForeColor = Color.FromArgb(142, 158, 178);
        Controls.Add(_hostLabel);

        _ads.Text = "Bloquear anúncios e domínios conhecidos de publicidade neste site";
        _ads.SetBounds(26, 100, 470, 30);
        _ads.Checked = blockAds;
        _ads.ForeColor = ForeColor;
        _ads.BackColor = BackColor;
        Controls.Add(_ads);

        _tracking.Text = "Ativar filtros extras do RX contra rastreadores conhecidos neste site";
        _tracking.SetBounds(26, 142, 470, 30);
        _tracking.Checked = blockTracking;
        _tracking.ForeColor = ForeColor;
        _tracking.BackColor = BackColor;
        Controls.Add(_tracking);

        Controls.Add(new Label { Text = "Os filtros extras usam listas locais de domínios e podem bloquear recursos necessários ao funcionamento de alguns sites. A proteção nativa do WebView2 continua separada. Recarregue a página depois de alterar estas opções.", Left = 26, Top = 185, Width = 465, Height = 48, ForeColor = Color.FromArgb(142, 158, 178), Font = new Font("Segoe UI", 8.2F) });
        var cancel = MakeButton("Cancelar", 96, false);
        cancel.SetBounds(286, 236, 96, 32);
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 96, true);
        save.SetBounds(394, 236, 96, 32);
        save.Click += (_, _) => { DialogResult = DialogResult.OK; Close(); };
        Controls.AddRange([cancel, save]);
        CancelButton = cancel;
        AcceptButton = save;
    }

    private Button MakeButton(string text, int width, bool accent)
    {
        var button = new Button { Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49), ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor, Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold) };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
