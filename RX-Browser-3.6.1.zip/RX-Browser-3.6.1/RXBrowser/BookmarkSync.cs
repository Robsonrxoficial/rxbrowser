﻿using System.Text.Json;

namespace RXBrowser;

internal static class BookmarkSync
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private const int MaximumDeviceFiles = 100;
    private const int MaximumRecordsPerFile = 5000;

    public static void Mark(BrowserData data, string title, string url, bool deleted, string? groupName = null)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return;
        var key = NormalizeUrl(uri);
        var existing = data.FavoriteSyncRecords.FirstOrDefault(r => NormalizeUrlString(r.Url) == key);
        if (existing is null)
        {
            existing = new FavoriteSyncRecord { Url = url };
            data.FavoriteSyncRecords.Add(existing);
        }
        existing.Title = string.IsNullOrWhiteSpace(title) ? url : title.Trim()[..Math.Min(title.Trim().Length, 180)];
        existing.Url = url;
        if (!string.IsNullOrWhiteSpace(groupName)) existing.GroupName = groupName.Trim()[..Math.Min(groupName.Trim().Length, 48)];
        else if (string.IsNullOrWhiteSpace(existing.GroupName)) existing.GroupName = "Geral";
        existing.UpdatedUtc = DateTime.UtcNow;
        existing.IsDeleted = deleted;
    }

    /// <summary>
    /// Merges favorite changes using timestamped add/remove records. Version 2.3 writes a
    /// snapshot per device to avoid concurrent devices overwriting each other's updates.
    /// A merged legacy file is also written for interoperability with older RX versions.
    /// The selected folder should be a user-controlled file-sync folder; no cloud account is handled here.
    /// </summary>
    public static int Sync(BrowserData data)
    {
        if (string.IsNullOrWhiteSpace(data.FavoritesSyncFolder)) return 0;

        var folder = Path.GetFullPath(data.FavoritesSyncFolder);
        Directory.CreateDirectory(folder);
        var deviceFolder = Path.Combine(folder, "rx-browser-favorites-devices");
        Directory.CreateDirectory(deviceFolder);
        var legacyFile = Path.Combine(folder, "rx-browser-favorites.json");
        var deviceId = SafeDeviceId(data.SessionSyncDeviceId);

        var remote = new List<FavoriteSyncRecord>();
        foreach (var file in Directory.EnumerateFiles(deviceFolder, "*.json", SearchOption.TopDirectoryOnly).Take(MaximumDeviceFiles))
            remote.AddRange(ReadRecords(file));
        // Import the common ledger written by RX Browser 2.2 and earlier.
        remote.AddRange(ReadRecords(legacyFile, backupInvalid: true));

        // Legacy local favorites enter the ledger with the oldest timestamp, so existing
        // remote tombstones will not be undone merely by upgrading this installation.
        if (data.FavoriteSyncRecords.Count == 0)
        {
            foreach (var favorite in data.Favorites)
                data.FavoriteSyncRecords.Add(new FavoriteSyncRecord
                {
                    Title = favorite.Title,
                    Url = favorite.Url,
                    GroupName = favorite.GroupName,
                    UpdatedUtc = DateTime.MinValue,
                    IsDeleted = false
                });
        }
        else
        {
            var known = new HashSet<string>(data.FavoriteSyncRecords.Select(r => NormalizeUrlString(r.Url)), StringComparer.OrdinalIgnoreCase);
            foreach (var item in remote) known.Add(NormalizeUrlString(item.Url));
            foreach (var favorite in data.Favorites)
            {
                var key = NormalizeUrlString(favorite.Url);
                if (key.Length > 0 && !known.Contains(key)) Mark(data, favorite.Title, favorite.Url, deleted: false, favorite.GroupName);
            }
        }

        var merged = new Dictionary<string, FavoriteSyncRecord>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in remote.Concat(data.FavoriteSyncRecords))
        {
            if (string.IsNullOrWhiteSpace(item.Url)) continue;
            var key = NormalizeUrlString(item.Url);
            if (key.Length == 0) continue;
            if (!merged.TryGetValue(key, out var current) || item.UpdatedUtc >= current.UpdatedUtc)
                merged[key] = new FavoriteSyncRecord
                {
                    Title = string.IsNullOrWhiteSpace(item.Title) ? item.Url : item.Title.Trim()[..Math.Min(item.Title.Trim().Length, 180)],
                    Url = item.Url,
                    GroupName = string.IsNullOrWhiteSpace(item.GroupName) ? "Geral" : item.GroupName.Trim()[..Math.Min(item.GroupName.Trim().Length, 48)],
                    UpdatedUtc = item.UpdatedUtc,
                    IsDeleted = item.IsDeleted
                };
        }

        data.FavoriteSyncRecords = merged.Values
            .OrderByDescending(r => r.UpdatedUtc)
            .Take(MaximumRecordsPerFile)
            .ToList();
        data.Favorites = data.FavoriteSyncRecords
            .Where(r => !r.IsDeleted && Uri.TryCreate(r.Url, UriKind.Absolute, out var u) && u.Scheme is "http" or "https")
            .Select(r => new FavoriteItem(r.Title, r.Url) { GroupName = string.IsNullOrWhiteSpace(r.GroupName) ? "Geral" : r.GroupName.Trim()[..Math.Min(r.GroupName.Trim().Length, 48)] })
            .OrderBy(f => f.Title, StringComparer.CurrentCultureIgnoreCase)
            .Take(2000)
            .ToList();
        foreach (var group in data.Favorites.Select(item => item.GroupName).Distinct(StringComparer.OrdinalIgnoreCase))
            if (data.FavoriteFolders.Count < 100 && !data.FavoriteFolders.Contains(group, StringComparer.OrdinalIgnoreCase)) data.FavoriteFolders.Add(group);

        var json = JsonSerializer.Serialize(data.FavoriteSyncRecords, JsonOptions);
        // Each device owns its own snapshot file. Concurrent updates by other devices therefore
        // cannot overwrite this device's ledger. The next sync merges all discovered snapshots.
        AtomicWrite(Path.Combine(deviceFolder, deviceId + ".json"), json);
        // Compatibility output for RX Browser 2.2 and earlier; 2.3 does not rely on this shared file.
        AtomicWrite(legacyFile, json);
        return data.Favorites.Count;
    }

    private static List<FavoriteSyncRecord> ReadRecords(string file, bool backupInvalid = false)
    {
        if (!File.Exists(file)) return new List<FavoriteSyncRecord>();
        try
        {
            var info = new FileInfo(file);
            if (info.Length <= 0 || info.Length > 5_000_000) return new List<FavoriteSyncRecord>();
            return JsonSerializer.Deserialize<List<FavoriteSyncRecord>>(File.ReadAllText(file))?
                .Where(x => x is not null && !string.IsNullOrWhiteSpace(x.Url) && x.Url.Length <= 4096 &&
                            Uri.TryCreate(x.Url, UriKind.Absolute, out var parsed) && parsed is not null && parsed.Scheme is "http" or "https")
                .Take(MaximumRecordsPerFile).ToList() ?? new List<FavoriteSyncRecord>();
        }
        catch
        {
            if (backupInvalid)
            {
                try
                {
                    var backup = file + ".invalid-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
                    File.Copy(file, backup, false);
                }
                catch { }
            }
            return new List<FavoriteSyncRecord>();
        }
    }

    private static string SafeDeviceId(string? id)
    {
        var safe = new string((id ?? string.Empty).Where(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_').ToArray());
        if (safe.Length == 0) safe = Guid.NewGuid().ToString("N");
        return safe[..Math.Min(safe.Length, 64)];
    }

    private static void AtomicWrite(string path, string content)
    {
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(temp, content);
            File.Move(temp, path, true);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }

    private static string NormalizeUrlString(string value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) ? NormalizeUrl(uri) : string.Empty;

    private static string NormalizeUrl(Uri uri)
    {
        var builder = new UriBuilder(uri) { Fragment = string.Empty };
        return builder.Uri.GetComponents(UriComponents.SchemeAndServer | UriComponents.PathAndQuery, UriFormat.SafeUnescaped).TrimEnd('/');
    }
}
