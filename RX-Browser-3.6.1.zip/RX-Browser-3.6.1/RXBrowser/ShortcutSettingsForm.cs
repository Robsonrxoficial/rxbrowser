﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed record ShortcutDefinition(string Id, string Name, string DefaultGesture)
{
    public override string ToString() => Name;
}

internal static class ShortcutCatalog
{
    public static readonly ShortcutDefinition[] Items =
    [
        new("NewTab", "Nova guia", "Ctrl+T"),
        new("CloseTab", "Fechar guia atual", "Ctrl+W"),
        new("TabManager", "Gerenciador de guias", "Ctrl+Shift+A"),
        new("TabSearch", "Localizar guia aberta", "Ctrl+Shift+Q"),
        new("Workspaces", "Espaços de trabalho", "Ctrl+Shift+W"),
        new("Performance", "Painel de desempenho", "Ctrl+Shift+Y"),
        new("PdfTools", "Marcadores e anotações PDF", "Ctrl+Shift+M"),
        new("Downloads", "Central de downloads", "Ctrl+J"),
        new("Security", "Central de segurança", "Ctrl+Shift+S"),
        new("ReaderMode", "Modo leitor", "Ctrl+Shift+E"),
        new("TranslateSelection", "Traduzir texto selecionado", "Ctrl+Shift+X"),
        new("NextTab", "Próxima guia", "Ctrl+Tab"),
        new("PreviousTab", "Guia anterior", "Ctrl+Shift+Tab"),
        new("FocusAddress", "Focar barra de endereço", "Ctrl+L")
    ];
}

internal sealed class ShortcutSettingsForm : Form
{
    private readonly Dictionary<string, string> _overrides;
    private readonly ComboBox _actions = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Label _current = new();
    private readonly Label _hint = new();
    public Dictionary<string, string> Result { get; private set; }

    public ShortcutSettingsForm(Dictionary<string, string> current)
    {
        _overrides = new Dictionary<string, string>(current, StringComparer.OrdinalIgnoreCase);
        Result = new Dictionary<string, string>(_overrides, StringComparer.OrdinalIgnoreCase);
        Text = "Atalhos personalizáveis — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(540, 300);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label { Text = "ATALHOS DO RX BROWSER", Left = 22, Top = 18, Width = 490, Height = 28, ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold) });
        Controls.Add(new Label { Text = "Ação", Left = 22, Top = 67, Width = 490, Height = 22, ForeColor = ForeColor });
        _actions.SetBounds(22, 92, 490, 34);
        _actions.BackColor = Color.FromArgb(27, 36, 49);
        _actions.ForeColor = ForeColor;
        foreach (var item in ShortcutCatalog.Items) _actions.Items.Add(item);
        _actions.SelectedIndexChanged += (_, _) => RefreshCurrent();
        Controls.Add(_actions);

        _current.SetBounds(22, 142, 490, 28);
        _current.ForeColor = Color.FromArgb(232, 240, 248);
        _current.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
        Controls.Add(_current);
        _hint.SetBounds(22, 174, 490, 34);
        _hint.ForeColor = Color.FromArgb(142, 158, 178);
        _hint.Text = "Use uma combinação com Ctrl, Alt ou Shift. Os atalhos ficam salvos somente neste perfil.";
        Controls.Add(_hint);

        var capture = MakeButton("Alterar combinação", 22, 220, true);
        capture.Click += (_, _) => CaptureSelected();
        var reset = MakeButton("Restaurar padrão", 190, 220, false);
        reset.Click += (_, _) => ResetSelected();
        var cancel = MakeButton("Cancelar", 326, 260, false);
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Salvar", 422, 260, true);
        save.Click += (_, _) => SaveAndClose();
        Controls.AddRange([capture, reset, cancel, save]);
        if (_actions.Items.Count > 0) _actions.SelectedIndex = 0;
        CancelButton = cancel;
        AcceptButton = save;
    }

    private Button MakeButton(string text, int left, int top, bool accent)
    {
        var b = new Button { Text = text, Left = left, Top = top, Width = 116, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49), ForeColor = accent ? Color.FromArgb(35, 205, 230) : ForeColor };
        b.FlatAppearance.BorderSize = 0;
        return b;
    }

    private ShortcutDefinition? Selected => _actions.SelectedItem as ShortcutDefinition;

    private void RefreshCurrent()
    {
        var item = Selected;
        if (item is null) return;
        var gesture = _overrides.TryGetValue(item.Id, out var value) ? value : item.DefaultGesture;
        _current.Text = $"{item.Name}:  {gesture}";
    }

    private void CaptureSelected()
    {
        var item = Selected;
        if (item is null) return;
        using var capture = new ShortcutCaptureForm(item.Name);
        if (capture.ShowDialog(this) != DialogResult.OK || string.IsNullOrWhiteSpace(capture.Gesture)) return;
        _overrides[item.Id] = capture.Gesture;
        RefreshCurrent();
    }

    private void ResetSelected()
    {
        var item = Selected;
        if (item is null) return;
        _overrides.Remove(item.Id);
        RefreshCurrent();
    }

    private void SaveAndClose()
    {
        var all = ShortcutCatalog.Items.ToDictionary(x => x.Id, x => _overrides.TryGetValue(x.Id, out var value) ? value : x.DefaultGesture, StringComparer.OrdinalIgnoreCase);
        var duplicates = all.GroupBy(x => x.Value, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).Select(g => g.Key).ToList();
        if (duplicates.Count > 0)
        {
            MessageBox.Show(this, "Existem atalhos repetidos: " + string.Join(", ", duplicates) + ". Altere as combinações para evitar conflitos.", "Atalhos RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        Result = new Dictionary<string, string>(_overrides, StringComparer.OrdinalIgnoreCase);
        DialogResult = DialogResult.OK;
        Close();
    }
}

internal sealed class ShortcutCaptureForm : Form
{
    public string? Gesture { get; private set; }
    private readonly Label _display = new();

    public ShortcutCaptureForm(string actionName)
    {
        Text = "Capturar atalho";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(430, 170);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        KeyPreview = true;
        Controls.Add(new Label { Text = "Pressione a combinação para: " + actionName, Left = 18, Top = 18, Width = 394, Height = 25, ForeColor = ForeColor });
        _display.SetBounds(18, 54, 394, 38);
        _display.Text = "Aguardando teclado…";
        _display.TextAlign = ContentAlignment.MiddleCenter;
        _display.ForeColor = Color.FromArgb(35, 205, 230);
        _display.BackColor = Color.FromArgb(20, 27, 37);
        _display.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
        Controls.Add(_display);
        var cancel = new Button { Text = "Cancelar", Left = 302, Top = 118, Width = 110, Height = 32, DialogResult = DialogResult.Cancel };
        cancel.FlatStyle = FlatStyle.Flat;
        cancel.BackColor = Color.FromArgb(27, 36, 49);
        cancel.ForeColor = ForeColor;
        Controls.Add(cancel);
        CancelButton = cancel;
        KeyDown += CaptureKeyDown;
    }

    private void CaptureKeyDown(object? sender, KeyEventArgs e)
    {
        e.SuppressKeyPress = true;
        e.Handled = true;
        if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); return; }
        if (e.KeyCode is Keys.ControlKey or Keys.ShiftKey or Keys.Menu or Keys.LWin or Keys.RWin) return;
        if (!e.Control && !e.Alt && !e.Shift)
        {
            _display.Text = "Adicione Ctrl, Alt ou Shift";
            return;
        }
        var parts = new List<string>();
        if (e.Control) parts.Add("Ctrl");
        if (e.Alt) parts.Add("Alt");
        if (e.Shift) parts.Add("Shift");
        parts.Add(e.KeyCode.ToString());
        Gesture = string.Join("+", parts);
        DialogResult = DialogResult.OK;
        Close();
    }
}

internal static class ShortcutMatcher
{
    public static bool Matches(string gesture, KeyEventArgs e)
    {
        var parts = gesture.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0) return false;
        var key = parts[^1];
        if (!Enum.TryParse<Keys>(key, true, out var parsed)) return false;
        var ctrl = parts.Any(x => x.Equals("Ctrl", StringComparison.OrdinalIgnoreCase));
        var alt = parts.Any(x => x.Equals("Alt", StringComparison.OrdinalIgnoreCase));
        var shift = parts.Any(x => x.Equals("Shift", StringComparison.OrdinalIgnoreCase));
        return e.KeyCode == parsed && e.Control == ctrl && e.Alt == alt && e.Shift == shift;
    }
}
