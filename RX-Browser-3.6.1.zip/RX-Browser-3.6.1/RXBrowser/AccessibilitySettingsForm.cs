﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class AccessibilitySettingsForm : Form
{
    private readonly TrackBar _scale = new() { Minimum = 90, Maximum = 140, TickFrequency = 10, SmallChange = 5, LargeChange = 10 };
    private readonly Label _scaleValue = new();
    private readonly CheckBox _highContrast = new();
    public int ScalePercent => _scale.Value;
    public bool HighContrast => _highContrast.Checked;

    public AccessibilitySettingsForm(int currentScale, bool highContrast)
    {
        Text = "Acessibilidade — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(570, 340);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label
        {
            Text = "ACESSIBILIDADE E LEGIBILIDADE",
            Left = 22, Top = 18, Width = 520, Height = 30,
            ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold)
        });
        Controls.Add(new Label
        {
            Text = "Tamanho dos textos da interface",
            Left = 24, Top = 72, Width = 330, Height = 24, ForeColor = ForeColor
        });
        _scale.SetBounds(24, 102, 410, 52);
        _scale.Value = Math.Clamp(currentScale, _scale.Minimum, _scale.Maximum);
        _scale.ValueChanged += (_, _) => UpdateScaleLabel();
        Controls.Add(_scale);
        _scaleValue.SetBounds(448, 106, 90, 30);
        _scaleValue.TextAlign = ContentAlignment.MiddleRight;
        _scaleValue.ForeColor = Color.FromArgb(55, 211, 235);
        _scaleValue.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
        Controls.Add(_scaleValue);
        Controls.Add(new Label
        {
            Text = "90%  •  Compacto                         115%  •  Maior                         140%  •  Ampliado",
            Left = 24, Top = 153, Width = 510, Height = 22, ForeColor = Color.FromArgb(142, 158, 178)
        });

        _highContrast.SetBounds(24, 202, 510, 30);
        _highContrast.Text = "Usar alto contraste na interface do RX Browser";
        _highContrast.Checked = highContrast;
        _highContrast.ForeColor = ForeColor;
        Controls.Add(_highContrast);
        Controls.Add(new Label
        {
            Text = "O tamanho da interface não altera o zoom das páginas. O alto contraste altera a janela principal e a barra do navegador; diálogos especializados mantêm sua própria paleta nesta versão.",
            Left = 24, Top = 240, Width = 510, Height = 42, ForeColor = Color.FromArgb(142, 158, 178)
        });

        var cancel = MakeButton("Cancelar", 326, 294, false);
        cancel.DialogResult = DialogResult.Cancel;
        var save = MakeButton("Aplicar", 434, 294, true);
        save.Click += (_, _) => { DialogResult = DialogResult.OK; Close(); };
        Controls.AddRange([cancel, save]);
        CancelButton = cancel;
        AcceptButton = save;
        UpdateScaleLabel();
    }

    private void UpdateScaleLabel() => _scaleValue.Text = _scale.Value + "%";

    private Button MakeButton(string text, int left, int top, bool accent)
    {
        var button = new Button
        {
            Text = text, Left = left, Top = top, Width = 108, Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
