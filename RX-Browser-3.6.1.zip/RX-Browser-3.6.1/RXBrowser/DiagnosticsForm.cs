﻿namespace RXBrowser;

internal sealed class DiagnosticsForm : Form
{
    public string? RequestedAction { get; private set; }

    public DiagnosticsForm(string profileName, string profilePath, string dataFile,
        string webViewVersion, int openTabs, long memoryBytes, string logPath)
    {
        Text = "Diagnóstico RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.Sizable;
        MinimumSize = new Size(620, 520);
        Size = new Size(760, 620);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(20), ColumnCount = 1, RowCount = 4, BackColor = BackColor };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        Controls.Add(root);

        root.Controls.Add(new Label
        {
            Text = "DIAGNÓSTICO E MANUTENÇÃO",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI Black", 16, FontStyle.Bold),
            ForeColor = Color.FromArgb(50, 211, 235),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);

        var report = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Both,
            WordWrap = false,
            BackColor = Color.FromArgb(20, 27, 37),
            ForeColor = Color.FromArgb(220, 232, 244),
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 9.5F),
            Text = BuildReport(profileName, profilePath, dataFile, webViewVersion, openTabs, memoryBytes, logPath)
        };
        root.Controls.Add(report, 0, 1);

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = true, BackColor = BackColor, Padding = new Padding(0, 12, 0, 0) };
        AddAction(actions, "Exportar backup seletivo…", "export");
        AddAction(actions, "Restaurar backup…", "restore");
        AddAction(actions, "Abrir pasta do perfil", "folder");
        AddAction(actions, "Exportar logs…", "logs");
        root.Controls.Add(actions, 0, 2);

        root.Controls.Add(new Label
        {
            Text = "Backup exclui senhas, cookies, histórico, downloads, PINs, permissões de sites e dados WebView2.",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(151, 168, 187),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 3);
    }

    private static string BuildReport(string profileName, string profilePath, string dataFile,
        string webViewVersion, int openTabs, long memoryBytes, string logPath)
    {
        var dataStatus = File.Exists(dataFile) ? "OK — arquivo de dados encontrado" : "INFO — arquivo será criado ao salvar";
        var backupStatus = File.Exists(dataFile + ".bak") ? "OK — backup automático disponível" : "Ainda não criado";
        string freeSpace;
        try
        {
            var root = Path.GetPathRoot(profilePath);
            freeSpace = !string.IsNullOrWhiteSpace(root) ? $"{new DriveInfo(root).AvailableFreeSpace / (1024d * 1024 * 1024):0.0} GB" : "Indisponível";
        }
        catch { freeSpace = "Indisponível"; }

        return string.Join(Environment.NewLine,
        new[]
        {
            "RX BROWSER 3.6 — RELATÓRIO LOCAL",
            new string('=', 58),
            $"Aplicativo:       {Application.ProductVersion}",
            $"Windows:          {Environment.OSVersion.VersionString}",
            $"Arquitetura:      {(Environment.Is64BitProcess ? "64 bits" : "32 bits")}",
            $".NET:             {Environment.Version}",
            $"WebView2 Runtime: {webViewVersion}",
            "",
            "PERFIL ATUAL",
            new string('-', 58),
            $"Nome:             {profileName}",
            $"Guias abertas:    {openTabs}",
            $"Memória privada:  {Math.Max(0, memoryBytes) / (1024d * 1024):0} MB (processos WebView2 somados)",
            $"Pasta:            {profilePath}",
            $"Log:              {(File.Exists(logPath) ? logPath : "Ainda não criado")}",
            $"Dados:            {dataStatus}",
            $"Backup automático:{backupStatus}",
            $"Espaço livre:     {freeSpace}",
            "",
            "LIMITAÇÕES",
            new string('-', 58),
            "• Métricas podem incluir processos compartilhados do WebView2.",
            "• Este relatório não realiza análise antivírus nem teste de reputação.",
            "• O backup é de preferências e organização, não uma cópia integral do perfil.",
            "• Os logs podem conter mensagens de erro e caminhos locais; revise antes de compartilhar."
        });
    }

    private void AddAction(FlowLayoutPanel host, string caption, string action)
    {
        var button = new Button
        {
            Text = caption,
            AutoSize = true,
            Height = 36,
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(27, 36, 49),
            ForeColor = Color.FromArgb(232, 240, 248),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 8, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += (_, _) => { RequestedAction = action; DialogResult = DialogResult.OK; Close(); };
        host.Controls.Add(button);
    }
}
