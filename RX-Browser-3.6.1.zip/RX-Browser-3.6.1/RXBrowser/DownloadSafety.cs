﻿namespace RXBrowser;

internal enum DownloadRisk
{
    Low = 0,
    Moderate = 1,
    High = 2,
    Critical = 3
}

internal sealed record DownloadSafetyResult(DownloadRisk Risk, string Reason, bool IsScriptLike)
{
    public string Label => Risk switch
    {
        DownloadRisk.Critical => "Crítico",
        DownloadRisk.High => "Alto",
        DownloadRisk.Moderate => "Moderado",
        _ => "Baixo"
    };
}

/// <summary>
/// Heurísticas locais de risco para nomes de arquivos. Não substitui antivírus,
/// SmartScreen nem análise de conteúdo do arquivo.
/// </summary>
internal static class DownloadSafety
{
    private static readonly HashSet<string> ScriptExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".bat", ".cmd", ".ps1", ".psm1", ".psd1", ".vbs", ".vbe", ".js", ".jse",
        ".wsf", ".wsh", ".hta", ".reg", ".sh", ".command", ".desktop"
    };

    private static readonly HashSet<string> ExecutableExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".msi", ".msix", ".appx", ".appxbundle", ".msixbundle", ".com", ".scr",
        ".pif", ".dll", ".sys", ".ocx", ".cpl", ".jar", ".apk", ".lnk", ".url"
    };

    private static readonly HashSet<string> CommonDocumentOrMediaExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".mp3", ".mp4", ".mkv",
        ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".csv"
    };

    private static readonly char[] BidiControls = ['\u202A', '\u202B', '\u202D', '\u202E', '\u2066', '\u2067', '\u2068', '\u2069'];

    public static DownloadSafetyResult Assess(string? fileName, string? sourceUri)
    {
        var name = string.IsNullOrWhiteSpace(fileName) ? "download" : Path.GetFileName(fileName.Trim());
        var extension = Path.GetExtension(name);
        var host = Uri.TryCreate(sourceUri, UriKind.Absolute, out var uri) ? uri.Host : string.Empty;
        var reasons = new List<string>();
        var critical = ScriptExtensions.Contains(extension);
        var high = ExecutableExtensions.Contains(extension);
        var hasBidi = name.IndexOfAny(BidiControls) >= 0;

        if (critical) reasons.Add($"Extensão de script ou comando ({extension})");
        else if (high) reasons.Add($"Formato executável ou capaz de abrir outro aplicativo ({extension})");

        if (hasBidi)
        {
            high = true;
            reasons.Add("O nome contém caracteres Unicode de direção de texto que podem disfarçar a extensão real");
        }

        var parts = name.Split('.', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length >= 3 && (critical || high))
        {
            var previousExtension = "." + parts[^2];
            if (CommonDocumentOrMediaExtensions.Contains(previousExtension))
            {
                high = true;
                critical = false;
                reasons.Add($"Nome com extensão dupla ({previousExtension}{extension})");
            }
        }

        if (extension.Equals(".iso", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".img", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".dmg", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".zip", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".7z", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".rar", StringComparison.OrdinalIgnoreCase))
        {
            if (reasons.Count == 0) reasons.Add("Arquivo compactado ou imagem de disco; confira o conteúdo e a origem antes de abrir");
            return new DownloadSafetyResult(DownloadRisk.Moderate, string.Join("; ", reasons), false);
        }

        if (string.IsNullOrWhiteSpace(host)) reasons.Add("Origem do download não identificada");
        else if (Uri.TryCreate(sourceUri, UriKind.Absolute, out var source) && source.Scheme != Uri.UriSchemeHttps && (critical || high))
            reasons.Add("O download veio de uma conexão sem HTTPS");

        var level = critical ? DownloadRisk.Critical : high ? DownloadRisk.High : reasons.Count > 0 ? DownloadRisk.Moderate : DownloadRisk.Low;
        var reason = reasons.Count == 0 ? "Nenhum padrão de risco conhecido foi encontrado no nome do arquivo" : string.Join("; ", reasons);
        return new DownloadSafetyResult(level, reason, critical);
    }
}
