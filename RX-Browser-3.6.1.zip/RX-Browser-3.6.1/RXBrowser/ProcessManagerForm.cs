﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class ProcessManagerForm : Form
{
    private readonly Func<List<BrowserProcessMetric>> _getProcesses;
    private readonly Action<int> _terminate;
    private readonly ListView _list = new();
    private readonly Label _summary = new();
    private readonly Button _endButton = new();
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 2000 };

    public ProcessManagerForm(Func<List<BrowserProcessMetric>> getProcesses, Action<int> terminate)
    {
        _getProcesses = getProcesses;
        _terminate = terminate;
        Text = "Processos WebView2 — RX Browser 2.3";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(860, 540);
        MinimumSize = new Size(700, 420);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(12), BackColor = BackColor };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 75));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(12, 7, 12, 5) };
        header.Controls.Add(new Label { Text = "GERENCIADOR DE PROCESSOS RX", Dock = DockStyle.Top, Height = 25, ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold) });
        _summary.Dock = DockStyle.Fill;
        _summary.ForeColor = Color.FromArgb(190, 204, 220);
        _summary.Text = "Coletando processos do WebView2…";
        header.Controls.Add(_summary);
        root.Controls.Add(header, 0, 0);

        _list.Dock = DockStyle.Fill;
        _list.View = View.Details;
        _list.FullRowSelect = true;
        _list.HideSelection = false;
        _list.MultiSelect = false;
        _list.BackColor = Color.FromArgb(20, 27, 37);
        _list.ForeColor = Color.FromArgb(232, 240, 248);
        _list.Columns.Add("Tipo", 150);
        _list.Columns.Add("PID", 80);
        _list.Columns.Add("Memória privada", 160);
        _list.Columns.Add("Memória física", 160);
        _list.Columns.Add("Estado", 180);
        _list.SelectedIndexChanged += (_, _) => UpdateEndButton();
        root.Controls.Add(_list, 0, 1);

        var footer = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new Padding(0, 8, 0, 0), BackColor = BackColor };
        _endButton.Text = "Encerrar processo…";
        StyleButton(_endButton, Color.FromArgb(112, 43, 54));
        _endButton.Click += (_, _) => EndSelected();
        var refresh = new Button { Text = "Atualizar" };
        StyleButton(refresh, Color.FromArgb(27, 52, 69));
        refresh.Click += (_, _) => RefreshRows();
        var close = new Button { Text = "Fechar", DialogResult = DialogResult.Cancel };
        StyleButton(close, Color.FromArgb(35, 45, 58));
        footer.Controls.Add(close);
        footer.Controls.Add(_endButton);
        footer.Controls.Add(refresh);
        root.Controls.Add(footer, 0, 2);

        Shown += (_, _) => { RefreshRows(); _timer.Start(); };
        FormClosed += (_, _) => { _timer.Stop(); _timer.Dispose(); };
        _timer.Tick += (_, _) => RefreshRows();
    }

    private static void StyleButton(Button button, Color background)
    {
        button.Width = 138;
        button.Height = 32;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = background;
        button.ForeColor = Color.FromArgb(232, 240, 248);
        button.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
        button.Margin = new Padding(5, 0, 0, 0);
    }

    private void RefreshRows()
    {
        if (IsDisposed) return;
        try
        {
            var selectedPid = SelectedMetric()?.ProcessId;
            var rows = _getProcesses().OrderByDescending(p => p.PrivateBytes).ToList();
            _list.BeginUpdate();
            _list.Items.Clear();
            foreach (var metric in rows)
            {
                var item = new ListViewItem(metric.Kind) { Tag = metric };
                item.SubItems.Add(metric.ProcessId.ToString());
                item.SubItems.Add(FormatBytes(metric.PrivateBytes));
                item.SubItems.Add(FormatBytes(metric.WorkingSetBytes));
                item.SubItems.Add(string.Equals(metric.Kind, "Browser", StringComparison.OrdinalIgnoreCase) ? "Principal — protegido" : "WebView2");
                _list.Items.Add(item);
                if (metric.ProcessId == selectedPid) item.Selected = true;
            }
            _list.EndUpdate();
            _summary.Text = $"{rows.Count} processo(s) WebView2 detectado(s). O processo Browser não pode ser encerrado por aqui.";
            UpdateEndButton();
        }
        catch (Exception ex) { _summary.Text = "Não foi possível atualizar a lista: " + ex.Message; }
    }

    private BrowserProcessMetric? SelectedMetric() => _list.SelectedItems.Count > 0 ? _list.SelectedItems[0].Tag as BrowserProcessMetric : null;

    private void UpdateEndButton()
    {
        var selected = SelectedMetric();
        _endButton.Enabled = selected is not null && !string.Equals(selected.Kind, "Browser", StringComparison.OrdinalIgnoreCase);
    }

    private void EndSelected()
    {
        var selected = SelectedMetric();
        if (selected is null || string.Equals(selected.Kind, "Browser", StringComparison.OrdinalIgnoreCase)) return;
        var result = MessageBox.Show(this,
            $"Encerrar o processo {selected.Kind} (PID {selected.ProcessId})?\n\nO WebView2 pode compartilhar processos entre páginas. Uma ou mais guias podem parar de funcionar e precisar ser recarregadas.",
            "Confirmar encerramento — RX Browser", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;
        _terminate(selected.ProcessId);
        RefreshRows();
    }

    private static string FormatBytes(long bytes)
    {
        if (bytes < 0) return "—";
        double value = bytes;
        var units = new[] { "B", "KB", "MB", "GB" };
        var index = 0;
        while (value >= 1024 && index < units.Length - 1) { value /= 1024; index++; }
        return $"{value:F1} {units[index]}";
    }
}
