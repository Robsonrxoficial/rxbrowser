﻿using System.Drawing;

namespace RXBrowser;

internal readonly record struct UiThemePalette(Color Background, Color Panel, Color PanelAlt, Color Accent, Color Text, Color Muted)
{
    public static UiThemePalette For(string? theme, Color accent, bool highContrast = false)
    {
        if (highContrast)
            return new UiThemePalette(Color.Black, Color.FromArgb(8, 8, 8), Color.FromArgb(28, 28, 28),
                Color.FromArgb(255, 230, 0), Color.White, Color.FromArgb(235, 235, 235));
        return theme switch
        {
        "Graphite" => new(
            Color.FromArgb(22, 25, 31), Color.FromArgb(31, 35, 43), Color.FromArgb(44, 49, 59),
            accent, Color.FromArgb(238, 241, 246), Color.FromArgb(160, 170, 185)),
        "OLED" => new(
            Color.Black, Color.FromArgb(8, 9, 12), Color.FromArgb(22, 23, 27),
            accent, Color.FromArgb(242, 245, 250), Color.FromArgb(145, 155, 170)),
        "Light" => new(
            Color.FromArgb(245, 247, 250), Color.White, Color.FromArgb(229, 235, 242),
            accent, Color.FromArgb(28, 36, 48), Color.FromArgb(91, 105, 123)),
        _ => new(
            Color.FromArgb(12, 16, 23), Color.FromArgb(20, 27, 37), Color.FromArgb(27, 36, 49),
            accent, Color.FromArgb(232, 240, 248), Color.FromArgb(142, 158, 178))
        };
    }
}
