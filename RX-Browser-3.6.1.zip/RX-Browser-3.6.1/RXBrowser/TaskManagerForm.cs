﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class TaskManagerForm : Form
{
    private readonly Func<IReadOnlyList<BrowserTab>> _getTabs;
    private readonly Action<BrowserTab> _selectTab;
    private readonly Func<BrowserTab, Task> _closeTab;
    private readonly Action<BrowserTab> _reloadTab;
    private readonly ListBox _list = new();
    private readonly Label _details = new();
    private List<BrowserTab> _snapshot = new();

    public TaskManagerForm(
        Func<IReadOnlyList<BrowserTab>> getTabs,
        BrowserTab? activeTab,
        Action<BrowserTab> selectTab,
        Func<BrowserTab, Task> closeTab,
        Action<BrowserTab> reloadTab)
    {
        _getTabs = getTabs;
        _selectTab = selectTab;
        _closeTab = closeTab;
        _reloadTab = reloadTab;

        Text = "Gerenciador de tarefas — RX Browser 2.3";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(880, 560);
        MinimumSize = new Size(720, 440);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = BackColor,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(10)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        Controls.Add(root);

        var heading = new Label
        {
            Text = "GERENCIADOR DE TAREFAS RX",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(4, 0, 0, 0)
        };
        root.Controls.Add(heading, 0, 0);

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(20, 27, 37),
            BorderStyle = BorderStyle.FixedSingle
        };
        Shown += (_, _) =>
        {
            try
            {
                split.Panel1MinSize = 220;
                split.Panel2MinSize = 180;
                split.SplitterDistance = Math.Clamp((int)(split.Width * 0.57), split.Panel1MinSize, split.Width - split.Panel2MinSize);
            }
            catch { }
        };
        root.Controls.Add(split, 0, 1);
        split.Panel1.Padding = new Padding(9);
        split.Panel2.Padding = new Padding(14);

        _list.Dock = DockStyle.Fill;
        _list.BackColor = Color.FromArgb(20, 27, 37);
        _list.ForeColor = Color.FromArgb(232, 240, 248);
        _list.BorderStyle = BorderStyle.None;
        _list.Font = new Font("Segoe UI", 9F);
        _list.IntegralHeight = false;
        _list.SelectedIndexChanged += (_, _) => UpdateDetails();
        _list.DoubleClick += (_, _) => SwitchSelected();
        split.Panel1.Controls.Add(_list);

        var detailLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        detailLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        detailLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var detailTitle = new Label
        {
            Text = "DETALHES DA GUIA",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(35, 205, 230),
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };
        _details.Dock = DockStyle.Fill;
        _details.ForeColor = Color.FromArgb(195, 207, 220);
        _details.Font = new Font("Segoe UI", 9F);
        _details.TextAlign = ContentAlignment.TopLeft;
        _details.Padding = new Padding(0, 8, 0, 0);
        detailLayout.Controls.Add(detailTitle, 0, 0);
        detailLayout.Controls.Add(_details, 0, 1);
        split.Panel2.Controls.Add(detailLayout);

        var footer = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            Padding = new Padding(0, 9, 0, 0),
            BackColor = BackColor
        };
        footer.Controls.Add(MakeButton("Fechar guia", Color.FromArgb(111, 42, 53), async (_, _) => await CloseSelectedAsync()));
        footer.Controls.Add(MakeButton("Recarregar", Color.FromArgb(27, 58, 72), (_, _) => ReloadSelected()));
        footer.Controls.Add(MakeButton("Ir para guia", Color.FromArgb(22, 72, 87), (_, _) => SwitchSelected()));
        footer.Controls.Add(MakeButton("Atualizar", Color.FromArgb(27, 36, 49), (_, _) => RefreshItems()));
        root.Controls.Add(footer, 0, 2);

        RefreshItems(activeTab?.Id);
    }

    private static Button MakeButton(string text, Color background, EventHandler onClick)
    {
        var button = new Button
        {
            Text = text,
            Width = 112,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = background,
            ForeColor = Color.FromArgb(232, 240, 248),
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            Margin = new Padding(5, 0, 0, 0),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += onClick;
        return button;
    }

    private void RefreshItems(string? preferredId = null)
    {
        var selectedId = preferredId ?? SelectedTab()?.Id;
        _snapshot = _getTabs().ToList();
        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var tab in _snapshot)
        {
            var url = tab.View.Source?.ToString() ?? "Página ainda não carregada";
            var state = tab.HasCrashed ? " • ERRO" : tab.IsSuspended ? " • SUSPENSA" : tab.IsLocked ? " • BLOQUEADA" : string.Empty;
            if (tab.IsPrivate) state += " • PRIVADA";
            _list.Items.Add(new TabEntry(tab, (tab.Title ?? "Nova guia") + state + Environment.NewLine + url));
        }
        _list.EndUpdate();
        var index = _snapshot.FindIndex(tab => string.Equals(tab.Id, selectedId, StringComparison.OrdinalIgnoreCase));
        if (index < 0 && _list.Items.Count > 0) index = 0;
        if (index >= 0) _list.SelectedIndex = index;
        UpdateDetails();
    }

    private BrowserTab? SelectedTab() => _list.SelectedItem is TabEntry entry ? entry.Tab : null;

    private void UpdateDetails()
    {
        var tab = SelectedTab();
        if (tab is null)
        {
            _details.Text = "Nenhuma guia selecionada.";
            return;
        }
        var state = tab.HasCrashed ? "Falha de processo detectada: " + (tab.LastProcessFailure ?? "desconhecida")
            : tab.IsSuspended ? "Suspensa para economizar memória"
            : tab.IsLocked ? "Protegida por senha"
            : "Em execução";
        _details.Text = $"Título\n{tab.Title}\n\nEndereço\n{tab.View.Source}\n\nEstado\n{state}\n\nPerfil\n{(tab.IsPrivate ? "Privado" : "Normal")}\n\nÚltima ativação\n{tab.LastActivatedUtc.ToLocalTime():dd/MM/yyyy HH:mm:ss}\n\nUse Recarregar para tentar recuperar uma página travada ou Fechar guia para encerrar sua visualização.";
    }

    private void SwitchSelected()
    {
        var tab = SelectedTab();
        if (tab is null) return;
        _selectTab(tab);
        Close();
    }

    private void ReloadSelected()
    {
        var tab = SelectedTab();
        if (tab is null) return;
        try
        {
            _reloadTab(tab);
            tab.HasCrashed = false;
            tab.LastProcessFailure = null;
            RefreshItems(tab.Id);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível recarregar esta guia.\n\n" + ex.Message,
                "Gerenciador de tarefas RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task CloseSelectedAsync()
    {
        var tab = SelectedTab();
        if (tab is null) return;
        try
        {
            await _closeTab(tab);
            RefreshItems();
            if (_snapshot.Count == 0) Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível encerrar esta guia.\n\n" + ex.Message,
                "Gerenciador de tarefas RX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private sealed record TabEntry(BrowserTab Tab, string Label)
    {
        public override string ToString() => Label;
    }
}
