﻿using System.Text.Json;

namespace RXBrowser;

internal sealed record ExtensionManifestInfo(
    string Name,
    string Version,
    int ManifestVersion,
    string Description,
    IReadOnlyList<string> Permissions,
    IReadOnlyList<string> HostPermissions,
    int ContentScriptCount,
    bool HasBackgroundWorker,
    string FolderPath)
{
    public string PermissionSummary => Permissions.Count == 0 && HostPermissions.Count == 0
        ? "Nenhuma permissão declarada no manifest"
        : string.Join(", ", Permissions.Concat(HostPermissions).Distinct(StringComparer.OrdinalIgnoreCase).Take(18));
}

internal static class ExtensionManifestInspector
{
    public static ExtensionManifestInfo Read(string folderPath)
    {
        if (string.IsNullOrWhiteSpace(folderPath) || !Directory.Exists(folderPath))
            throw new DirectoryNotFoundException("A pasta da extensão não foi encontrada.");

        var fullFolder = Path.GetFullPath(folderPath);
        var manifestPath = Path.Combine(fullFolder, "manifest.json");
        if (!File.Exists(manifestPath)) throw new InvalidDataException("A pasta selecionada não contém manifest.json.");
        var manifestFile = new FileInfo(manifestPath);
        if (manifestFile.Length <= 0 || manifestFile.Length > 1_000_000)
            throw new InvalidDataException("O manifest.json está vazio ou excede 1 MB.");

        using var document = JsonDocument.Parse(File.ReadAllText(manifestPath));
        var root = document.RootElement;
        if (root.ValueKind != JsonValueKind.Object) throw new InvalidDataException("O manifest.json precisa conter um objeto JSON.");

        var manifestVersion = root.TryGetProperty("manifest_version", out var mv) && mv.TryGetInt32(out var parsedVersion)
            ? parsedVersion : 0;
        if (manifestVersion is not (2 or 3))
            throw new InvalidDataException("A extensão precisa declarar manifest_version 2 ou 3.");

        var fallbackName = new DirectoryInfo(fullFolder).Name;
        var name = ReadString(root, "name", fallbackName);
        if (name.StartsWith("__MSG_", StringComparison.OrdinalIgnoreCase)) name = fallbackName;
        var version = ReadString(root, "version", "Versão não informada");
        var description = ReadString(root, "description", "Sem descrição");
        if (name.Length > 120) name = name[..120];
        if (version.Length > 40) version = version[..40];
        if (description.Length > 400) description = description[..400];

        var permissions = ReadStringArray(root, "permissions");
        var hostPermissions = ReadStringArray(root, "host_permissions");
        if (root.TryGetProperty("optional_permissions", out var optional))
            permissions = permissions.Concat(ReadStringArray(optional)).Append("(opcionais declaradas)").Distinct(StringComparer.OrdinalIgnoreCase).Take(60).ToList();

        var contentScripts = root.TryGetProperty("content_scripts", out var scripts) && scripts.ValueKind == JsonValueKind.Array
            ? scripts.GetArrayLength() : 0;
        var hasBackground = root.TryGetProperty("background", out var background) && background.ValueKind == JsonValueKind.Object;

        return new ExtensionManifestInfo(name, version, manifestVersion, description,
            permissions, hostPermissions, contentScripts, hasBackground, fullFolder);
    }

    private static string ReadString(JsonElement root, string property, string fallback) =>
        root.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? fallback : fallback;

    private static List<string> ReadStringArray(JsonElement root, string property) =>
        root.TryGetProperty(property, out var value) ? ReadStringArray(value) : new List<string>();

    private static List<string> ReadStringArray(JsonElement value)
    {
        if (value.ValueKind != JsonValueKind.Array) return new List<string>();
        return value.EnumerateArray()
            .Where(item => item.ValueKind == JsonValueKind.String)
            .Select(item => item.GetString() ?? string.Empty)
            .Where(item => !string.IsNullOrWhiteSpace(item))
            .Select(item => item.Length > 160 ? item[..160] : item)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(60)
            .ToList();
    }
}
