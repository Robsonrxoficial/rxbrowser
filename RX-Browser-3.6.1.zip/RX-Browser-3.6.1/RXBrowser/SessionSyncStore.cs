﻿using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace RXBrowser;

/// <summary>
/// Portable, passphrase-encrypted session snapshots. Each installation writes its own file,
/// so devices do not overwrite one another. Password-protected and private tabs are excluded
/// by the caller. The passphrase is held in memory only and is never written to disk.
/// </summary>
internal static class SessionSyncStore
{
    private const int Iterations = 310_000;
    private static readonly byte[] AssociatedData = Encoding.UTF8.GetBytes("RXBrowser.SessionSync.v1");
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public static void Save(string folder, string deviceId, string deviceName,
        IReadOnlyList<SessionTabSnapshot> tabs, int activeIndex, string passphrase)
    {
        Validate(folder, passphrase);
        if (!Guid.TryParseExact(deviceId, "N", out _))
            throw new InvalidOperationException("Identificador do dispositivo inválido.");

        Directory.CreateDirectory(folder);
        var payload = new RemoteSessionSnapshot
        {
            DeviceId = deviceId,
            DeviceName = string.IsNullOrWhiteSpace(deviceName) ? "Outro dispositivo" : deviceName,
            UpdatedUtc = DateTime.UtcNow,
            ActiveIndex = Math.Clamp(activeIndex, 0, Math.Max(0, tabs.Count - 1)),
            Tabs = tabs.Where(t => IsWebUrl(t.Url)).Take(20).Select(t => new SessionTabSnapshot
            {
                Id = Guid.NewGuid().ToString("N"),
                Url = t.Url,
                Title = string.IsNullOrWhiteSpace(t.Title) ? "Guia sincronizada" : t.Title,
                IsPinned = t.IsPinned,
                GroupName = t.GroupName
            }).ToList()
        };

        var plain = JsonSerializer.SerializeToUtf8Bytes(payload, JsonOptions);
        var salt = RandomNumberGenerator.GetBytes(16);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var tag = new byte[16];
        var cipher = new byte[plain.Length];
        var key = Rfc2898DeriveBytes.Pbkdf2(passphrase, salt, Iterations, HashAlgorithmName.SHA256, 32);
        var temp = Path.Combine(folder, ".rx-session-" + deviceId + "." + Guid.NewGuid().ToString("N") + ".tmp");
        var destination = Path.Combine(folder, "rx-session-" + deviceId + ".enc");
        try
        {
            using (var aes = new AesGcm(key, tag.Length))
                aes.Encrypt(nonce, plain, cipher, tag, AssociatedData);
            var envelope = new SessionSyncEnvelope
            {
                Version = 1,
                Iterations = Iterations,
                Salt = Convert.ToBase64String(salt),
                Nonce = Convert.ToBase64String(nonce),
                Tag = Convert.ToBase64String(tag),
                Ciphertext = Convert.ToBase64String(cipher)
            };
            File.WriteAllText(temp, JsonSerializer.Serialize(envelope, JsonOptions));
            File.Move(temp, destination, true);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(plain);
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(cipher);
            CryptographicOperations.ZeroMemory(salt);
            CryptographicOperations.ZeroMemory(nonce);
            CryptographicOperations.ZeroMemory(tag);
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }

    public static List<RemoteSessionSnapshot> ReadOtherDevices(string folder, string currentDeviceId, string passphrase)
    {
        Validate(folder, passphrase);
        if (!Directory.Exists(folder)) return new List<RemoteSessionSnapshot>();
        var result = new List<RemoteSessionSnapshot>();
        var unreadable = 0;
        foreach (var file in Directory.EnumerateFiles(folder, "rx-session-*.enc", SearchOption.TopDirectoryOnly))
        {
            try
            {
                var session = ReadOne(file, passphrase);
                if (session is null || string.Equals(session.DeviceId, currentDeviceId, StringComparison.OrdinalIgnoreCase)) continue;
                session.Tabs = (session.Tabs ?? new List<SessionTabSnapshot>())
                    .Where(t => t is not null && IsWebUrl(t.Url)).Take(20).ToList();
                if (session.Tabs.Count > 0) result.Add(session);
            }
            catch (CryptographicException) { unreadable++; }
            catch (JsonException) { unreadable++; }
            catch (FormatException) { unreadable++; }
            catch (IOException) { }
        }
        if (result.Count == 0 && unreadable > 0)
            throw new CryptographicException("Não foi possível descriptografar as sessões encontradas. Confira a senha de sincronização.");
        return result.OrderByDescending(x => x.UpdatedUtc).ToList();
    }

    private static RemoteSessionSnapshot? ReadOne(string path, string passphrase)
    {
        var envelope = JsonSerializer.Deserialize<SessionSyncEnvelope>(File.ReadAllText(path));
        if (envelope is null || envelope.Version != 1 || envelope.Iterations is < 100_000 or > 1_000_000)
            throw new JsonException("Formato de sincronização desconhecido.");
        var salt = Convert.FromBase64String(envelope.Salt);
        var nonce = Convert.FromBase64String(envelope.Nonce);
        var tag = Convert.FromBase64String(envelope.Tag);
        var cipher = Convert.FromBase64String(envelope.Ciphertext);
        if (salt.Length != 16 || nonce.Length != 12 || tag.Length != 16 || cipher.Length > 2_000_000)
            throw new JsonException("Arquivo de sessão inválido.");
        var key = Rfc2898DeriveBytes.Pbkdf2(passphrase, salt, envelope.Iterations, HashAlgorithmName.SHA256, 32);
        var plain = new byte[cipher.Length];
        try
        {
            using (var aes = new AesGcm(key, tag.Length))
                aes.Decrypt(nonce, cipher, tag, plain, AssociatedData);
            return JsonSerializer.Deserialize<RemoteSessionSnapshot>(plain);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plain);
            CryptographicOperations.ZeroMemory(cipher);
            CryptographicOperations.ZeroMemory(salt);
            CryptographicOperations.ZeroMemory(nonce);
            CryptographicOperations.ZeroMemory(tag);
        }
    }

    private static void Validate(string folder, string passphrase)
    {
        if (string.IsNullOrWhiteSpace(folder)) throw new ArgumentException("Selecione uma pasta de sincronização.", nameof(folder));
        if (string.IsNullOrWhiteSpace(passphrase) || passphrase.Length < 10)
            throw new ArgumentException("A senha de sincronização precisa ter pelo menos 10 caracteres.", nameof(passphrase));
    }

    private static bool IsWebUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";
}

internal sealed class RemoteSessionSnapshot
{
    public string DeviceId { get; set; } = string.Empty;
    public string DeviceName { get; set; } = string.Empty;
    public DateTime UpdatedUtc { get; set; }
    public int ActiveIndex { get; set; }
    public List<SessionTabSnapshot> Tabs { get; set; } = new();
    public override string ToString() => $"{DeviceName}  •  {Tabs.Count} guias  •  {UpdatedUtc.ToLocalTime():dd/MM/yyyy HH:mm}";
}

internal sealed class SessionSyncEnvelope
{
    public int Version { get; set; }
    public int Iterations { get; set; }
    public string Salt { get; set; } = string.Empty;
    public string Nonce { get; set; } = string.Empty;
    public string Tag { get; set; } = string.Empty;
    public string Ciphertext { get; set; } = string.Empty;
}
