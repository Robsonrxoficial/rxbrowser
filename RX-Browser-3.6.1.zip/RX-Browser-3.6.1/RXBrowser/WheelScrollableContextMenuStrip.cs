﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>
/// Enables mouse-wheel scrolling for long WinForms context menus.
/// ToolStripDropDownMenu normally exposes small arrow buttons when its
/// content is taller than the screen, but does not consistently route the
/// wheel to those buttons. This filter forwards wheel notches to the same
/// internal one-item scroll operation used by those buttons.
/// </summary>
internal sealed class WheelScrollableContextMenuStrip : ContextMenuStrip, IMessageFilter
{
    private const int WmMouseWheel = 0x020A;
    private const int WheelDelta = 120;
    private const int ItemsPerNotch = 3;

    private static readonly MethodInfo? ScrollInternalMethod = typeof(ToolStripDropDownMenu).GetMethod(
        "ScrollInternal",
        BindingFlags.Instance | BindingFlags.NonPublic,
        binder: null,
        types: new[] { typeof(bool) },
        modifiers: null);

    private readonly Dictionary<ToolStripDropDownMenu, int> _wheelRemainders = new();
    private bool _filterAttached;

    public WheelScrollableContextMenuStrip()
    {
        Opened += (_, _) => AttachMessageFilter();
        Closed += (_, _) => DetachMessageFilter();
        Disposed += (_, _) => DetachMessageFilter();
    }

    public bool PreFilterMessage(ref Message m)
    {
        if (m.Msg != WmMouseWheel || !Visible || IsDisposed)
            return false;

        var mousePosition = Cursor.Position;
        var target = FindMenuAtPoint(this, mousePosition);
        if (target is null)
            return false;

        var packed = m.WParam.ToInt64();
        var delta = unchecked((short)((packed >> 16) & 0xFFFF));
        if (delta == 0)
            return false;

        ScrollForWheel(target, delta);
        // Consume this wheel message so the browser page behind the menu
        // does not also scroll while the user is navigating the menu.
        return true;
    }

    private void AttachMessageFilter()
    {
        if (_filterAttached || IsDisposed) return;
        Application.AddMessageFilter(this);
        _filterAttached = true;
    }

    private void DetachMessageFilter()
    {
        if (_filterAttached)
        {
            Application.RemoveMessageFilter(this);
            _filterAttached = false;
        }
        _wheelRemainders.Clear();
    }

    private static ToolStripDropDownMenu? FindMenuAtPoint(ToolStripDropDownMenu current, Point screenPoint)
    {
        // Prefer the deepest visible submenu beneath the pointer.
        foreach (ToolStripItem item in current.Items)
        {
            if (item is not ToolStripMenuItem menuItem || !menuItem.DropDown.Visible)
                continue;

            if (menuItem.DropDown is not ToolStripDropDownMenu child || !IsPointInside(child, screenPoint))
                continue;

            return FindMenuAtPoint(child, screenPoint) ?? child;
        }

        return IsPointInside(current, screenPoint) ? current : null;
    }

    private static bool IsPointInside(Control control, Point screenPoint)
    {
        if (!control.IsHandleCreated || control.IsDisposed || !control.Visible)
            return false;

        try { return control.RectangleToScreen(control.ClientRectangle).Contains(screenPoint); }
        catch { return false; }
    }

    private void ScrollForWheel(ToolStripDropDownMenu target, int delta)
    {
        _wheelRemainders.TryGetValue(target, out var remainder);
        remainder += delta;

        while (remainder >= WheelDelta)
        {
            ScrollOneItem(target, up: true);
            remainder -= WheelDelta;
        }

        while (remainder <= -WheelDelta)
        {
            ScrollOneItem(target, up: false);
            remainder += WheelDelta;
        }

        _wheelRemainders[target] = remainder;
    }

    private static void ScrollOneItem(ToolStripDropDownMenu menu, bool up)
    {
        try
        {
            if (ScrollInternalMethod is not null)
            {
                // This is the exact operation used by WinForms' built-in
                // up/down scroll buttons for an overflowing dropdown menu.
                ScrollInternalMethod.Invoke(menu, new object[] { up });
                return;
            }
        }
        catch
        {
            // Fall through to keyboard-style selection as a compatibility fallback.
        }

        try
        {
            var display = menu.DisplayRectangle;
            var candidates = menu.Items.Cast<ToolStripItem>()
                .Where(item => item.Available && item.Enabled && item is not ToolStripSeparator)
                .ToList();
            if (candidates.Count == 0) return;

            var next = up
                ? candidates.LastOrDefault(item => item.Bounds.Bottom <= display.Top + 1) ?? candidates.First()
                : candidates.FirstOrDefault(item => item.Bounds.Top >= display.Bottom - 1) ?? candidates.Last();
            next.Select();
        }
        catch { /* A wheel event must never break or close the menu. */ }
    }
}
