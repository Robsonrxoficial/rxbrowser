﻿using System.Text.Json;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>
/// Synchronizes only non-secret browser preferences through a user-selected shared folder.
/// Password vaults, WebView2 profile data, cookies, sessions, history, downloads and extensions
/// are deliberately excluded. Each device writes a separate file to avoid last-writer file races.
/// </summary>
internal static class PreferencesSyncStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private const int CurrentSchema = 5;

    public static string Publish(BrowserData data, string folder, string deviceId, string deviceName)
    {
        var settingsFolder = GetSettingsFolder(folder);
        Directory.CreateDirectory(settingsFolder);
        var snapshot = CreateSnapshot(data, deviceId, deviceName);
        var path = Path.Combine(settingsFolder, SafeDeviceId(deviceId) + ".json");
        AtomicWrite(path, JsonSerializer.Serialize(snapshot, JsonOptions));
        return path;
    }

    public static PreferencesSyncSnapshot? FindLatestOtherDevice(string folder, string ownDeviceId)
    {
        var settingsFolder = GetSettingsFolder(folder);
        if (!Directory.Exists(settingsFolder)) return null;
        var candidates = new List<PreferencesSyncSnapshot>();
        foreach (var file in Directory.EnumerateFiles(settingsFolder, "*.json", SearchOption.TopDirectoryOnly).Take(100))
        {
            try
            {
                var info = new FileInfo(file);
                if (info.Length > 1_000_000) continue;
                var snapshot = JsonSerializer.Deserialize<PreferencesSyncSnapshot>(File.ReadAllText(file));
                if (snapshot is null || snapshot.Schema is not (1 or 2 or 3 or 4 or CurrentSchema) ||
                    string.IsNullOrWhiteSpace(snapshot.DeviceId) ||
                    string.Equals(snapshot.DeviceId, ownDeviceId, StringComparison.OrdinalIgnoreCase))
                    continue;
                candidates.Add(snapshot);
            }
            catch
            {
                // Ignore incomplete or unsupported files; never overwrite them automatically.
            }
        }
        return candidates.OrderByDescending(x => x.UpdatedUtc).FirstOrDefault();
    }

    public static void Apply(BrowserData data, PreferencesSyncSnapshot snapshot)
    {
        var p = snapshot.Preferences;
        if (p is null) throw new InvalidDataException("O arquivo de configurações não contém preferências.");
        data.ForceDarkMode = p.ForceDarkMode;
        data.ZoomPercent = Math.Clamp(p.ZoomPercent, 50, 200);
        data.SearchEngine = p.SearchEngine is "Google" or "Bing" or "DuckDuckGo" ? p.SearchEngine : "DuckDuckGo";
        data.AdBlockEnabled = p.AdBlockEnabled;
        if (p.AdBlockLevel is not null)
            data.AdBlockLevel = p.AdBlockLevel is "Basic" or "Balanced" or "Strict" ? p.AdBlockLevel : "Balanced";
        data.AdBlockAllowlist = CleanHosts(p.AdBlockAllowlist);
        if (p.PreferredTranslationLanguage is not null)
            data.PreferredTranslationLanguage = p.PreferredTranslationLanguage is "pt" or "en" or "es" or "fr" or "de" or "it" or "ja" or "zh-CN" ? p.PreferredTranslationLanguage : "pt";
        data.TrackingProtectionLevel = p.TrackingProtectionLevel is "Basic" or "Balanced" or "Strict" or "Off" ? p.TrackingProtectionLevel : "Balanced";
        data.DoNotTrack = p.DoNotTrack;
        data.TrackingAllowlist = CleanHosts(p.TrackingAllowlist);
        data.EcoModeEnabled = p.EcoModeEnabled;
        data.ThemeAccent = p.ThemeAccent is "Cyan" or "Violet" or "Emerald" or "Amber" or "Pink" ? p.ThemeAccent : "Cyan";
        data.ThemeAccentHex = IsValidAccentHex(p.ThemeAccentHex) ? p.ThemeAccentHex! : string.Empty;
        data.ProfileBadge = IsValidProfileBadge(p.ProfileBadge) ? p.ProfileBadge! : "🌐";
        data.HomePageTheme = p.HomePageTheme is "Aurora" or "Midnight" or "Purple" or "Forest" or "Sunset" ? p.HomePageTheme : "Aurora";
        if (p.HomePageGreeting is not null)
            data.HomePageGreeting = string.IsNullOrWhiteSpace(p.HomePageGreeting) ? "NAVEGUE DO SEU JEITO" : p.HomePageGreeting.Trim()[..Math.Min(p.HomePageGreeting.Trim().Length, 70)];
        if (p.HomePageShowClock.HasValue) data.HomePageShowClock = p.HomePageShowClock.Value;
        if (p.HomePageShowQuickLinks.HasValue) data.HomePageShowQuickLinks = p.HomePageShowQuickLinks.Value;
        if (p.HomePageShowFavorites.HasValue) data.HomePageShowFavorites = p.HomePageShowFavorites.Value;
        if (p.HomePageShowRecentSites.HasValue) data.HomePageShowRecentSites = p.HomePageShowRecentSites.Value;
        if (p.HomePageFavoriteCount.HasValue) data.HomePageFavoriteCount = Math.Clamp(p.HomePageFavoriteCount.Value, 0, 16);
        if (p.HomePageQuickLinks is not null) data.HomePageQuickLinks = CleanHomeLinks(p.HomePageQuickLinks);
        data.InterfaceTheme = p.InterfaceTheme is "Midnight" or "Graphite" or "OLED" or "Light" ? p.InterfaceTheme : "Midnight";
        if (p.UiScalePercent.HasValue) data.UiScalePercent = Math.Clamp(p.UiScalePercent.Value, 90, 140);
        if (p.AccessibilityHighContrast.HasValue) data.AccessibilityHighContrast = p.AccessibilityHighContrast.Value;
        data.CompactTabs = p.CompactTabs;
        data.SidebarWidth = Math.Clamp(p.SidebarWidth, 180, 360);
        data.SidebarVisible = p.SidebarVisible;
        data.BackgroundTabSuspendDelaySeconds = Math.Clamp(p.BackgroundTabSuspendDelaySeconds, 15, 300);
        data.RestoreLastSession = p.RestoreLastSession;
        data.HomePageCardStyle = p.HomePageCardStyle is "Glass" or "Solid" or "Minimal" ? p.HomePageCardStyle : "Glass";
        data.TranslationSourceLanguage = p.TranslationSourceLanguage is "auto" or "pt" or "en" or "es" or "fr" or "de" or "it" or "ja" or "zh-CN" ? p.TranslationSourceLanguage : "auto";
        data.PhishingProtectionEnabled = p.PhishingProtectionEnabled;
        data.PhishingProtectionLevel = p.PhishingProtectionLevel is "Basic" or "Balanced" or "Strict" ? p.PhishingProtectionLevel : "Balanced";
        // Trusted-site exceptions are local-only: do not propagate a trust decision to another PC.
        data.ShortcutOverrides = CleanShortcutOverrides(p.ShortcutOverrides);
        if (p.ToolbarHiddenButtons is not null)
            data.ToolbarHiddenButtons = p.ToolbarHiddenButtons.Where(ToolbarCatalog.Ids.Contains)
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(ToolbarCatalog.Options.Count).ToList();
    }

    private static PreferencesSyncSnapshot CreateSnapshot(BrowserData data, string deviceId, string deviceName) => new()
    {
        Schema = CurrentSchema,
        DeviceId = SafeDeviceId(deviceId),
        DeviceName = string.IsNullOrWhiteSpace(deviceName) ? "Dispositivo" : deviceName[..Math.Min(deviceName.Length, 80)],
        UpdatedUtc = DateTime.UtcNow,
        Preferences = new SyncedBrowserPreferences
        {
            ForceDarkMode = data.ForceDarkMode,
            ZoomPercent = data.ZoomPercent,
            SearchEngine = data.SearchEngine,
            AdBlockEnabled = data.AdBlockEnabled,
            AdBlockLevel = data.AdBlockLevel,
            AdBlockAllowlist = CleanHosts(data.AdBlockAllowlist),
            PreferredTranslationLanguage = data.PreferredTranslationLanguage,
            TrackingProtectionLevel = data.TrackingProtectionLevel,
            DoNotTrack = data.DoNotTrack,
            TrackingAllowlist = CleanHosts(data.TrackingAllowlist),
            EcoModeEnabled = data.EcoModeEnabled,
            ThemeAccent = data.ThemeAccent,
            ThemeAccentHex = data.ThemeAccentHex,
            ProfileBadge = data.ProfileBadge,
            HomePageTheme = data.HomePageTheme,
            HomePageGreeting = data.HomePageGreeting,
            HomePageShowClock = data.HomePageShowClock,
            HomePageShowQuickLinks = data.HomePageShowQuickLinks,
            HomePageShowFavorites = data.HomePageShowFavorites,
            HomePageShowRecentSites = data.HomePageShowRecentSites,
            HomePageFavoriteCount = data.HomePageFavoriteCount,
            HomePageQuickLinks = CleanHomeLinks(data.HomePageQuickLinks),
            InterfaceTheme = data.InterfaceTheme,
            UiScalePercent = data.UiScalePercent,
            AccessibilityHighContrast = data.AccessibilityHighContrast,
            CompactTabs = data.CompactTabs,
            SidebarWidth = data.SidebarWidth,
            SidebarVisible = data.SidebarVisible,
            BackgroundTabSuspendDelaySeconds = data.BackgroundTabSuspendDelaySeconds,
            RestoreLastSession = data.RestoreLastSession,
            ShortcutOverrides = CleanShortcutOverrides(data.ShortcutOverrides),
            HomePageCardStyle = data.HomePageCardStyle,
            TranslationSourceLanguage = data.TranslationSourceLanguage,
            PhishingProtectionEnabled = data.PhishingProtectionEnabled,
            PhishingProtectionLevel = data.PhishingProtectionLevel,
            ToolbarHiddenButtons = data.ToolbarHiddenButtons.Where(ToolbarCatalog.Ids.Contains)
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(ToolbarCatalog.Options.Count).ToList(),
        }
    };

    private static bool IsValidAccentHex(string? value) =>
        !string.IsNullOrWhiteSpace(value) && System.Text.RegularExpressions.Regex.IsMatch(value, "^#[0-9A-Fa-f]{6}$");

    private static bool IsValidProfileBadge(string? value) =>
        value is "🌐" or "💼" or "🎮" or "🎨" or "📚" or "🏠" or "🚀";

    private static List<SidebarLink> CleanHomeLinks(IEnumerable<SidebarLink>? links) => (links ?? Array.Empty<SidebarLink>())
        .Where(link => link is not null && !string.IsNullOrWhiteSpace(link.Title) && !string.IsNullOrWhiteSpace(link.Url))
        .Where(link => link.Title.Length <= 36 && link.Url.Length <= 2048 &&
            Uri.TryCreate(link.Url, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https"))
        .GroupBy(link => link.Url, StringComparer.OrdinalIgnoreCase).Select(group => group.First()).Take(16).ToList();

    private static Dictionary<string, string> CleanShortcutOverrides(Dictionary<string, string>? shortcuts)
    {
        var knownIds = ShortcutCatalog.Items.Select(item => item.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in shortcuts ?? new Dictionary<string, string>())
        {
            if (!knownIds.Contains(pair.Key) || string.IsNullOrWhiteSpace(pair.Value) || pair.Value.Length > 64) continue;
            var parts = pair.Value.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (parts.Length < 2 || parts.Length > 4) continue;
            if (!parts.Take(parts.Length - 1).All(part => part is "Ctrl" or "Alt" or "Shift")) continue;
            if (parts.Take(parts.Length - 1).Distinct(StringComparer.OrdinalIgnoreCase).Count() != parts.Length - 1) continue;
            if (!Enum.TryParse<Keys>(parts[^1], true, out var key) || key is Keys.ControlKey or Keys.ShiftKey or Keys.Menu or Keys.LWin or Keys.RWin) continue;
            if (parts[^1].Length > 24 || parts[^1].Any(char.IsControl)) continue;
            if (result.Values.Contains(pair.Value, StringComparer.OrdinalIgnoreCase)) continue;
            result[pair.Key] = pair.Value;
            if (result.Count >= 20) break;
        }
        return result;
    }

    private static List<string> CleanHosts(IEnumerable<string>? hosts) => (hosts ?? Array.Empty<string>())
        .Where(x => !string.IsNullOrWhiteSpace(x))
        .Select(x => x.Trim().TrimStart('.').ToLowerInvariant())
        .Where(x => x.Length <= 253 && x.All(c => char.IsAsciiLetterOrDigit(c) || c is '.' or '-'))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .Take(500)
        .ToList();

    private static string SafeDeviceId(string? id)
    {
        var safe = new string((id ?? string.Empty)
            .Where(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_').ToArray());
        if (safe.Length == 0) return Guid.NewGuid().ToString("N");
        return safe[..Math.Min(safe.Length, 64)];
    }

    private static string GetSettingsFolder(string folder) =>
        Path.Combine(Path.GetFullPath(folder), "rx-browser-settings");

    private static void AtomicWrite(string path, string content)
    {
        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(temporary, content);
            File.Move(temporary, path, true);
        }
        finally
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
        }
    }
}

internal sealed class PreferencesSyncSnapshot
{
    public int Schema { get; set; }
    public string DeviceId { get; set; } = string.Empty;
    public string DeviceName { get; set; } = string.Empty;
    public DateTime UpdatedUtc { get; set; }
    public SyncedBrowserPreferences Preferences { get; set; } = new();
}

internal sealed class SyncedBrowserPreferences
{
    public bool ForceDarkMode { get; set; }
    public int ZoomPercent { get; set; } = 100;
    public string SearchEngine { get; set; } = "DuckDuckGo";
    public bool AdBlockEnabled { get; set; } = true;
    public string? AdBlockLevel { get; set; }
    public List<string> AdBlockAllowlist { get; set; } = new();
    public string? PreferredTranslationLanguage { get; set; }
    public string TrackingProtectionLevel { get; set; } = "Balanced";
    public bool DoNotTrack { get; set; } = true;
    public List<string> TrackingAllowlist { get; set; } = new();
    public bool EcoModeEnabled { get; set; } = true;
    public string ThemeAccent { get; set; } = "Cyan";
    public string? ThemeAccentHex { get; set; }
    public string? ProfileBadge { get; set; }
    public string HomePageTheme { get; set; } = "Aurora";
    public string? HomePageGreeting { get; set; }
    public bool? HomePageShowClock { get; set; }
    public bool? HomePageShowQuickLinks { get; set; }
    public bool? HomePageShowFavorites { get; set; }
    public bool? HomePageShowRecentSites { get; set; }
    public int? HomePageFavoriteCount { get; set; }
    public List<SidebarLink>? HomePageQuickLinks { get; set; }
    public string InterfaceTheme { get; set; } = "Midnight";
    public int? UiScalePercent { get; set; }
    public bool? AccessibilityHighContrast { get; set; }
    public bool CompactTabs { get; set; }
    public int SidebarWidth { get; set; } = 226;
    public bool SidebarVisible { get; set; } = true;
    public int BackgroundTabSuspendDelaySeconds { get; set; } = 45;
    public bool RestoreLastSession { get; set; } = true;
    public Dictionary<string, string> ShortcutOverrides { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public string HomePageCardStyle { get; set; } = "Glass";
    public string TranslationSourceLanguage { get; set; } = "auto";
    public bool PhishingProtectionEnabled { get; set; } = true;
    public string PhishingProtectionLevel { get; set; } = "Balanced";
    public List<string>? ToolbarHiddenButtons { get; set; }
}
