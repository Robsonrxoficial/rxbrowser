﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class TabSearchForm : Form
{
    private sealed class Entry
    {
        public required BrowserTab Tab { get; init; }
        public required string SearchText { get; init; }
        public override string ToString() => SearchText;
    }

    private readonly List<BrowserTab> _tabs;
    private readonly BrowserTab? _active;
    private readonly TextBox _search = new();
    private readonly ListBox _results = new();
    private readonly Label _summary = new();
    private readonly Action<BrowserTab> _activate;

    public TabSearchForm(IEnumerable<BrowserTab> tabs, BrowserTab? active, Action<BrowserTab> activate)
    {
        _tabs = tabs.ToList();
        _active = active;
        _activate = activate;
        Text = "Localizar guia — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.SizableToolWindow;
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(650, 470);
        MinimumSize = new Size(520, 360);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Label
        {
            Text = "LOCALIZAR GUIA ABERTA", Dock = DockStyle.Top, Height = 46,
            Padding = new Padding(18, 12, 0, 0), ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        };
        Controls.Add(header);
        var searchPanel = new Panel { Dock = DockStyle.Top, Height = 52, Padding = new Padding(18, 5, 18, 8), BackColor = Color.FromArgb(18, 25, 35) };
        _search.Dock = DockStyle.Fill;
        _search.PlaceholderText = "Digite o título, endereço, grupo ou perfil privado…";
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.BackColor = Color.FromArgb(27, 36, 49);
        _search.ForeColor = ForeColor;
        _search.Font = new Font("Segoe UI", 10F);
        _search.TextChanged += (_, _) => RenderResults();
        searchPanel.Controls.Add(_search);
        Controls.Add(searchPanel);

        _results.Dock = DockStyle.Fill;
        _results.BorderStyle = BorderStyle.None;
        _results.BackColor = Color.FromArgb(15, 21, 30);
        _results.ForeColor = ForeColor;
        _results.Font = new Font("Segoe UI", 9.5F);
        _results.IntegralHeight = false;
        _results.HorizontalScrollbar = true;
        _results.DoubleClick += (_, _) => ActivateSelected();
        Controls.Add(_results);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 54, BackColor = Color.FromArgb(18, 25, 35), Padding = new Padding(14, 8, 14, 8) };
        _summary.Dock = DockStyle.Left;
        _summary.Width = 300;
        _summary.TextAlign = ContentAlignment.MiddleLeft;
        _summary.ForeColor = Color.FromArgb(142, 158, 178);
        var close = MakeButton("Fechar", 88, false);
        close.Dock = DockStyle.Right;
        close.DialogResult = DialogResult.Cancel;
        var activateButton = MakeButton("Abrir guia", 105, true);
        activateButton.Dock = DockStyle.Right;
        activateButton.Click += (_, _) => ActivateSelected();
        footer.Controls.Add(_summary);
        footer.Controls.Add(close);
        footer.Controls.Add(activateButton);
        Controls.Add(footer);
        CancelButton = close;
        AcceptButton = activateButton;
        Shown += (_, _) => { _search.Focus(); RenderResults(); };
    }

    private Button MakeButton(string text, int width, bool accent)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : ForeColor,
            Margin = new Padding(4, 0, 4, 0), Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void RenderResults()
    {
        var query = _search.Text.Trim();
        var entries = _tabs
            .Where(tab => !tab.View.IsDisposed)
            .OrderByDescending(tab => ReferenceEquals(tab, _active))
            .ThenByDescending(tab => tab.LastActivatedUtc)
            .Select(tab =>
            {
                var url = tab.View.Source?.ToString() ?? string.Empty;
                var flags = string.Join(" · ", new[]
                {
                    tab.IsPrivate ? "Privada" : null,
                    tab.IsPasswordProtected ? "Protegida" : null,
                    tab.IsPinned ? "Fixada" : null,
                    string.IsNullOrWhiteSpace(tab.GroupName) ? null : "Grupo: " + tab.GroupName
                }.Where(x => !string.IsNullOrWhiteSpace(x)));
                var label = (ReferenceEquals(tab, _active) ? "●  " : "    ") + tab.Title +
                    (string.IsNullOrWhiteSpace(flags) ? string.Empty : "  —  " + flags) +
                    (string.IsNullOrWhiteSpace(url) ? string.Empty : "  ·  " + url);
                return new Entry { Tab = tab, SearchText = label };
            })
            .Where(entry => query.Length == 0 || entry.SearchText.Contains(query, StringComparison.CurrentCultureIgnoreCase))
            .ToList();
        _results.BeginUpdate();
        _results.Items.Clear();
        foreach (var entry in entries) _results.Items.Add(entry);
        _results.EndUpdate();
        _summary.Text = $"{entries.Count} de {_tabs.Count} guia(s)";
        if (_results.Items.Count > 0) _results.SelectedIndex = 0;
    }

    private void ActivateSelected()
    {
        if (_results.SelectedItem is not Entry entry || entry.Tab.View.IsDisposed) return;
        _activate(entry.Tab);
        DialogResult = DialogResult.OK;
        Close();
    }
}
