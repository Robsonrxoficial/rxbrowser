﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class PdfReaderToolsForm : Form
{
    private readonly PdfDocumentNotes _notes;
    private readonly Action<int> _goToPage;
    private readonly ListView _items = new();
    private readonly NumericUpDown _page = new() { Minimum = 1, Maximum = 99999, Value = 1, Width = 90 };

    public PdfReaderToolsForm(PdfDocumentNotes notes, Action<int> goToPage)
    {
        _notes = notes;
        _goToPage = goToPage;
        Text = "Marcadores e anotações PDF — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(760, 520);
        MinimumSize = new Size(620, 400);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var top = new Panel { Dock = DockStyle.Top, Height = 76, Padding = new Padding(16, 12, 16, 8), BackColor = Color.FromArgb(20, 27, 37) };
        top.Controls.Add(new Label { Text = Path.GetFileName(notes.FilePath), Dock = DockStyle.Top, Height = 25, ForeColor = Color.FromArgb(35, 205, 230), Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold), AutoEllipsis = true });
        top.Controls.Add(new Label { Text = "Marcadores e notas ficam salvos localmente neste perfil do RX Browser.", Dock = DockStyle.Bottom, Height = 22, ForeColor = Color.FromArgb(142, 158, 178) });
        Controls.Add(top);

        _items.Dock = DockStyle.Fill;
        _items.View = View.Details;
        _items.FullRowSelect = true;
        _items.HideSelection = false;
        _items.BackColor = Color.FromArgb(20, 27, 37);
        _items.ForeColor = Color.FromArgb(232, 240, 248);
        _items.Columns.Add("Tipo", 110);
        _items.Columns.Add("Página", 75);
        _items.Columns.Add("Marcador / anotação", 500);
        _items.DoubleClick += (_, _) => JumpSelected();
        Controls.Add(_items);

        var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 58, Padding = new Padding(10), WrapContents = false, AutoScroll = true, BackColor = Color.FromArgb(20, 27, 37) };
        footer.Controls.Add(new Label { Text = "Página:", AutoSize = true, Padding = new Padding(0, 8, 0, 0), ForeColor = ForeColor });
        footer.Controls.Add(_page);
        footer.Controls.Add(MakeButton("Adicionar marcador", AddBookmark, true));
        footer.Controls.Add(MakeButton("Adicionar anotação", AddAnnotation));
        footer.Controls.Add(MakeButton("Ir à página", JumpSelected));
        footer.Controls.Add(MakeButton("Editar", EditSelected));
        footer.Controls.Add(MakeButton("Excluir", DeleteSelected));
        Controls.Add(footer);
        RefreshItems();
    }

    private static Button MakeButton(string text, Action click, bool accent = false)
    {
        var b = new Button { Text = text, AutoSize = true, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49), ForeColor = accent ? Color.FromArgb(35, 205, 230) : Color.FromArgb(232, 240, 248), Margin = new Padding(4, 0, 4, 0) };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (_, _) => click();
        return b;
    }

    private void AddBookmark()
    {
        var page = decimal.ToInt32(_page.Value);
        var label = PromptDialog.Show(this, "Novo marcador", "Nome do marcador:", $"Página {page}");
        if (string.IsNullOrWhiteSpace(label)) return;
        _notes.Bookmarks.RemoveAll(x => x.Page == page && string.Equals(x.Label, label.Trim(), StringComparison.OrdinalIgnoreCase));
        _notes.Bookmarks.Add(new PdfBookmark { Page = page, Label = label.Trim() });
        SaveAndRefresh();
    }

    private void AddAnnotation()
    {
        var page = decimal.ToInt32(_page.Value);
        var text = PromptDialog.Show(this, "Anotação PDF", $"Escreva uma nota para a página {page}:", "", multiline: true);
        if (string.IsNullOrWhiteSpace(text)) return;
        _notes.Annotations.Add(new PdfAnnotation { Page = page, Text = text.Trim() });
        SaveAndRefresh();
    }

    private void JumpSelected()
    {
        if (_items.SelectedItems.Count == 0) return;
        if (_items.SelectedItems[0].Tag is int page && page > 0)
        {
            _goToPage(page);
            _page.Value = Math.Clamp(page, 1, (int)_page.Maximum);
        }
    }

    private void EditSelected()
    {
        if (_items.SelectedItems.Count == 0) return;
        var row = _items.SelectedItems[0];
        if (row.Tag is not int page || row.SubItems.Count < 3) return;
        var oldText = row.SubItems[2].Text;
        var updated = PromptDialog.Show(this,
            row.SubItems[0].Text == "Marcador" ? "Editar marcador" : "Editar anotação",
            "Atualize o texto:", oldText, multiline: row.SubItems[0].Text != "Marcador");
        if (string.IsNullOrWhiteSpace(updated)) return;
        if (row.SubItems[0].Text == "Marcador")
        {
            var item = _notes.Bookmarks.FirstOrDefault(x => x.Page == page && x.Label == oldText);
            if (item is not null) item.Label = updated.Trim();
        }
        else
        {
            var item = _notes.Annotations.FirstOrDefault(x => x.Page == page && x.Text == oldText);
            if (item is not null) { item.Text = updated.Trim(); item.UpdatedUtc = DateTime.UtcNow; }
        }
        SaveAndRefresh();
    }

    private void DeleteSelected()
    {
        if (_items.SelectedItems.Count == 0) return;
        var row = _items.SelectedItems[0];
        if (row.Tag is not int page || row.SubItems.Count < 3) return;
        if (row.SubItems[0].Text == "Marcador")
        {
            var label = row.SubItems[2].Text;
            var item = _notes.Bookmarks.FirstOrDefault(x => x.Page == page && x.Label == label);
            if (item is not null) _notes.Bookmarks.Remove(item);
        }
        else
        {
            var noteText = row.SubItems[2].Text;
            var item = _notes.Annotations.FirstOrDefault(x => x.Page == page && x.Text == noteText);
            if (item is not null) _notes.Annotations.Remove(item);
        }
        SaveAndRefresh();
    }

    private void SaveAndRefresh()
    {
        try { PdfNotesStore.Save(_notes); RefreshItems(); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "RX Browser PDF", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void RefreshItems()
    {
        _items.BeginUpdate();
        _items.Items.Clear();
        foreach (var mark in _notes.Bookmarks.OrderBy(x => x.Page))
        {
            var row = new ListViewItem("Marcador");
            row.SubItems.Add(mark.Page.ToString());
            row.SubItems.Add(mark.Label);
            row.Tag = mark.Page;
            _items.Items.Add(row);
        }
        foreach (var note in _notes.Annotations.OrderBy(x => x.Page))
        {
            var row = new ListViewItem("Anotação");
            row.SubItems.Add(note.Page.ToString());
            row.SubItems.Add(note.Text);
            row.Tag = note.Page;
            _items.Items.Add(row);
        }
        _items.EndUpdate();
    }
}
