﻿namespace RXBrowser;

internal sealed record ToolbarOption(string Id, string Label)
{
    public override string ToString() => Label;
}

internal static class ToolbarCatalog
{
    public static readonly IReadOnlyList<ToolbarOption> Options = new[]
    {
        new ToolbarOption("back", "Voltar"),
        new ToolbarOption("forward", "Avançar"),
        new ToolbarOption("reload", "Recarregar"),
        new ToolbarOption("home", "Página inicial"),
        new ToolbarOption("translate", "Traduzir página"),
        new ToolbarOption("security", "Segurança"),
        new ToolbarOption("performance", "Desempenho"),
        new ToolbarOption("tabs", "Gerenciador de guias"),
        new ToolbarOption("downloads", "Downloads"),
        new ToolbarOption("history", "Histórico"),
        new ToolbarOption("favorites", "Favoritos"),
        new ToolbarOption("favorite", "Adicionar favorito"),
        new ToolbarOption("workspaces", "Espaços de trabalho")
    };

    public static HashSet<string> Ids { get; } = Options.Select(option => option.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
}

internal sealed class ToolbarSettingsForm : Form
{
    private readonly CheckedListBox _items = new();
    public List<string> HiddenIds => ToolbarCatalog.Options
        .Where(option => !_items.CheckedItems.Cast<ToolbarOption>().Any(item => item.Id == option.Id))
        .Select(option => option.Id).ToList();

    public ToolbarSettingsForm(IEnumerable<string> hiddenIds)
    {
        Text = "Personalizar barra de ferramentas — RX Browser 3.6";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(470, 530);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        Controls.Add(new Label
        {
            Text = "BARRA DE FERRAMENTAS",
            Left = 22, Top = 20, Width = 420, Height = 30,
            ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold)
        });
        Controls.Add(new Label
        {
            Text = "Marque os botões que deseja manter visíveis. A barra de endereço e o menu Mais opções permanecem disponíveis.",
            Left = 24, Top = 58, Width = 420, Height = 44,
            ForeColor = Color.FromArgb(155, 171, 190)
        });
        _items.SetBounds(24, 112, 420, 330);
        _items.BackColor = Color.FromArgb(20, 27, 37);
        _items.ForeColor = ForeColor;
        _items.BorderStyle = BorderStyle.FixedSingle;
        _items.CheckOnClick = true;
        var hidden = (hiddenIds ?? Array.Empty<string>()).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var option in ToolbarCatalog.Options) _items.Items.Add(option, !hidden.Contains(option.Id));
        Controls.Add(_items);

        var all = MakeButton("Mostrar todos", 112);
        all.SetBounds(24, 456, 112, 34);
        all.Click += (_, _) => { for (var i = 0; i < _items.Items.Count; i++) _items.SetItemChecked(i, true); };
        Controls.Add(all);
        var none = MakeButton("Ocultar opcionais", 132);
        none.SetBounds(144, 456, 132, 34);
        none.Click += (_, _) => { for (var i = 0; i < _items.Items.Count; i++) _items.SetItemChecked(i, false); };
        Controls.Add(none);
        var cancel = MakeButton("Cancelar", 78);
        cancel.SetBounds(282, 456, 78, 34);
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);
        var save = MakeButton("Salvar", 78, true);
        save.SetBounds(366, 456, 78, 34);
        save.DialogResult = DialogResult.OK;
        Controls.Add(save);
        AcceptButton = save;
        CancelButton = cancel;
    }

    private Button MakeButton(string text, int width, bool accent = false)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(55, 211, 235) : Color.FromArgb(232, 240, 248),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }
}
