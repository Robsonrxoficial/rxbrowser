﻿namespace RXBrowser;

internal sealed record ControlCenterCommandDefinition(string Id, string Icon, string Title, string Description)
{
    public string DisplayText => $"{Icon}  {Title}";
}

internal static class ControlCenterCommands
{
    public static readonly IReadOnlyList<ControlCenterCommandDefinition> All = new[]
    {
        new ControlCenterCommandDefinition("tabs", "▦", "Gerenciar guias", "Pesquisar, visualizar e organizar guias abertas"),
        new ControlCenterCommandDefinition("workspaces", "▤", "Espaços de trabalho", "Salvar conjuntos de páginas"),
        new ControlCenterCommandDefinition("favorites", "☆", "Favoritos", "Organizar favoritos e pastas"),
        new ControlCenterCommandDefinition("history", "◷", "Histórico", "Consultar sua linha do tempo local"),
        new ControlCenterCommandDefinition("site-notes", "✎", "Caderno RX", "Criar notas locais associadas aos sites"),
        new ControlCenterCommandDefinition("downloads", "↓", "Downloads", "Acompanhar arquivos e transferências"),
        new ControlCenterCommandDefinition("passwords", "▣", "Cofre de senhas", "Gerenciar credenciais locais protegidas"),
        new ControlCenterCommandDefinition("extensions", "⬡", "Extensões", "Instalar e administrar extensões compatíveis"),
        new ControlCenterCommandDefinition("security", "盾", "Segurança", "Privacidade, permissões e proteção de sites"),
        new ControlCenterCommandDefinition("privacy-activity", "◉", "Monitor de privacidade", "Ver bloqueios e alertas desta sessão em tempo real"),
        new ControlCenterCommandDefinition("permissions", "◉", "Permissões de sites", "Revisar câmera, microfone, localização e outras decisões"),
        new ControlCenterCommandDefinition("performance", "◴", "Desempenho", "Consultar uso de recursos do WebView2"),
        new ControlCenterCommandDefinition("appearance", "⚙", "Aparência", "Temas, cores e personalização"),
        new ControlCenterCommandDefinition("homepage", "⌂", "Página inicial", "Configurar atalhos e cartões iniciais"),
        new ControlCenterCommandDefinition("backup-sync", "⇄", "Backup entre dispositivos", "Configurar publicação e importação"),
        new ControlCenterCommandDefinition("sync-dashboard", "◫", "Painel de sincronização", "Ver dispositivos, estado e última publicação"),
        new ControlCenterCommandDefinition("toolbar", "☷", "Barra de ferramentas", "Mostrar ou ocultar botões da barra superior"),
        new ControlCenterCommandDefinition("diagnostics", "⌁", "Diagnóstico e backup local", "Verificar o ambiente, exportar logs e proteger dados do perfil"),
        new ControlCenterCommandDefinition("accessibility", "Aa", "Acessibilidade", "Tamanho da interface e alto contraste")
    };

    public static HashSet<string> KnownIds { get; } = All.Select(item => item.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
}
