﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

/// <summary>Prepares a website translation with explicit language selection and disclosure.</summary>
internal sealed class TranslationSetupForm : Form
{
    private readonly ComboBox _source = new();
    private readonly ComboBox _target = new();
    private readonly TextBox _address = new();

    public string SourceLanguageCode => (_source.SelectedItem as LanguageChoice)?.Code ?? "auto";
    public string TargetLanguageCode => (_target.SelectedItem as LanguageChoice)?.Code ?? "pt";
    public string TargetLanguageName => (_target.SelectedItem as LanguageChoice)?.Name ?? "Português (Brasil)";
    public string SourceLanguageName => (_source.SelectedItem as LanguageChoice)?.Name ?? "Detectar automaticamente";

    public TranslationSetupForm(string pageUrl, string sourceCode, string targetCode,
        IEnumerable<(string Code, string Name)> languages)
    {
        Text = "RX Translate — traduzir página";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(590, 340);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, Padding = new Padding(22), ColumnCount = 1, RowCount = 6,
            BackColor = BackColor
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 74));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        Controls.Add(root);

        root.Controls.Add(new Label
        {
            Text = "TRADUÇÃO DE SITES", Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(55, 211, 235),
            Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);
        root.Controls.Add(new Label { Text = "Endereço que será aberto no serviço de tradução:", Dock = DockStyle.Fill, ForeColor = Color.FromArgb(164, 179, 197) }, 0, 1);
        _address.Dock = DockStyle.Fill;
        _address.ReadOnly = true;
        _address.Text = pageUrl;
        _address.BackColor = Color.FromArgb(27, 36, 49);
        _address.ForeColor = Color.FromArgb(232, 240, 248);
        _address.BorderStyle = BorderStyle.FixedSingle;
        root.Controls.Add(_address, 0, 2);

        var languagesList = languages.Select(item => new LanguageChoice(item.Code, item.Name)).ToList();
        var sourceChoices = new List<LanguageChoice> { new("auto", "Detectar automaticamente") };
        sourceChoices.AddRange(languagesList);
        var languagePanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = BackColor };
        languagePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        languagePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        languagePanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        languagePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        languagePanel.Controls.Add(new Label { Text = "Idioma de origem", Dock = DockStyle.Fill, ForeColor = Color.FromArgb(164, 179, 197) }, 0, 0);
        languagePanel.Controls.Add(new Label { Text = "Traduzir para", Dock = DockStyle.Fill, ForeColor = Color.FromArgb(164, 179, 197) }, 1, 0);
        ConfigureCombo(_source, sourceChoices, sourceCode);
        ConfigureCombo(_target, languagesList, targetCode);
        languagePanel.Controls.Add(_source, 0, 1);
        languagePanel.Controls.Add(_target, 1, 1);
        root.Controls.Add(languagePanel, 0, 3);

        root.Controls.Add(new Label
        {
            Dock = DockStyle.Fill, AutoSize = false,
            Text = "Privacidade: o endereço será copiado e enviado ao Google Tradutor, que poderá acessar e processar o conteúdo da página. A tradução depende da disponibilidade do serviço e da região. Não use com páginas confidenciais.",
            ForeColor = Color.FromArgb(184, 194, 207),
            BackColor = Color.FromArgb(20, 27, 37), Padding = new Padding(12),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 4);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
        var start = MakeButton("Preparar tradução", true, 146);
        start.DialogResult = DialogResult.OK;
        var cancel = MakeButton("Cancelar", false, 92);
        cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.Add(start);
        buttons.Controls.Add(cancel);
        root.Controls.Add(buttons, 0, 5);
        AcceptButton = start;
        CancelButton = cancel;
    }

    private static void ConfigureCombo(ComboBox combo, List<LanguageChoice> items, string selectedCode)
    {
        combo.Dock = DockStyle.Fill;
        combo.DropDownStyle = ComboBoxStyle.DropDownList;
        combo.BackColor = Color.FromArgb(27, 36, 49);
        combo.ForeColor = Color.FromArgb(232, 240, 248);
        combo.FlatStyle = FlatStyle.Flat;
        combo.DisplayMember = nameof(LanguageChoice.Name);
        combo.Items.AddRange(items.Cast<object>().ToArray());
        var index = items.FindIndex(item => string.Equals(item.Code, selectedCode, StringComparison.OrdinalIgnoreCase));
        combo.SelectedIndex = index >= 0 ? index : 0;
    }

    private static Button MakeButton(string text, bool accent, int width)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 65, 78) : Color.FromArgb(27, 36, 49),
            ForeColor = accent ? Color.FromArgb(90, 225, 242) : Color.FromArgb(222, 230, 239),
            Margin = new Padding(6, 3, 0, 0), Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private sealed record LanguageChoice(string Code, string Name)
    {
        public override string ToString() => Name;
    }
}
