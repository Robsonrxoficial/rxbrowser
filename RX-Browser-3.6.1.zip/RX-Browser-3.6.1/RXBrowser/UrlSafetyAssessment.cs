﻿using System.Globalization;
using System.Net;
using System.Text;

namespace RXBrowser;

/// <summary>
/// Heurísticas locais para identificar sinais comuns de falsificação de endereço.
/// Não é uma lista de reputação em tempo real e nunca declara, por si só, que um site é malicioso.
/// O SmartScreen do Windows permanece como verificação externa complementar.
/// </summary>
internal static class UrlSafetyAssessment
{
    private static readonly HashSet<string> LinkShortenerDomains = new(StringComparer.OrdinalIgnoreCase)
    {
        "bit.ly", "t.co", "tinyurl.com", "cutt.ly", "is.gd", "rebrand.ly", "shorturl.at", "rb.gy", "ow.ly", "buff.ly"
    };

    private static readonly (string Brand, string[] Domains)[] ProtectedBrands =
    {
        ("google", new[] { "google.com", "google.co.uk", "google.com.br", "google.ca", "google.com.au", "google.de", "google.fr", "google.es", "google.co.jp", "google.co.in", "googleusercontent.com", "gstatic.com", "googleapis.com", "googlevideo.com", "youtube.com", "ytimg.com" }),
        ("microsoft", new[] { "microsoft.com", "microsoftonline.com", "office.com", "outlook.com", "live.com", "microsoft365.com", "sharepoint.com", "windows.net", "azure.com", "bing.com", "msn.com" }),
        ("apple", new[] { "apple.com", "icloud.com" }),
        ("paypal", new[] { "paypal.com", "paypal.me" }),
        ("nubank", new[] { "nubank.com.br", "nubank.com" }),
        ("itau", new[] { "itau.com.br", "itau.com" }),
        ("bradesco", new[] { "bradesco.com.br" }),
        ("santander", new[] { "santander.com.br", "santander.com" }),
        ("caixa", new[] { "caixa.gov.br", "caixa.com.br" }),
        ("mercadolivre", new[] { "mercadolivre.com.br", "mercadolivre.com" }),
        ("mercadopago", new[] { "mercadopago.com.br", "mercadopago.com" }),
        ("picpay", new[] { "picpay.com" }),
        ("amazon", new[] { "amazon.com", "amazon.com.br", "amazon.co.uk", "amazon.de", "amazon.co.jp", "amazonaws.com" }),
        ("facebook", new[] { "facebook.com", "fb.com", "fbcdn.net", "fbsbx.com", "messenger.com" }),
        ("instagram", new[] { "instagram.com", "cdninstagram.com" }),
        ("roblox", new[] { "roblox.com" }),
        ("steam", new[] { "steampowered.com", "steamcommunity.com" }),
        ("netflix", new[] { "netflix.com" }),
        ("whatsapp", new[] { "whatsapp.com" }),
        ("discord", new[] { "discord.com", "discord.gg" }),
        ("dropbox", new[] { "dropbox.com" }),
        ("adobe", new[] { "adobe.com" }),
        ("github", new[] { "github.com", "githubusercontent.com", "githubassets.com" })
    };

    public static string? GetWarning(string value) => GetWarning(value, "Balanced", null);

    public static string? GetWarning(string value, string? protectionLevel, IEnumerable<string>? allowlist)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
            return null;

        var displayHost = uri.Host.TrimEnd('.').ToLowerInvariant();
        var host = uri.IdnHost.TrimEnd('.').ToLowerInvariant();
        if ((allowlist ?? Array.Empty<string>()).Any(allowed => HostMatches(host, allowed))) return null;

        var reasons = new List<string>();
        var score = 0;
        var level = protectionLevel is "Basic" or "Balanced" or "Strict" ? protectionLevel : "Balanced";

        if (!string.IsNullOrWhiteSpace(uri.UserInfo))
        {
            score += 4;
            reasons.Add("O endereço contém usuário ou senha antes do domínio; isso pode esconder o destino real.");
        }

        if (ContainsBidirectionalControls(value))
        {
            score += 4;
            reasons.Add("O endereço contém caracteres invisíveis de controle de direção de texto. Eles podem fazer partes da URL parecerem estar em outra ordem.");
        }

        if (LinkShortenerDomains.Any(domain => HostMatches(host, domain)))
        {
            score += 1;
            reasons.Add("O endereço usa um encurtador de links e esconde o domínio de destino. Confira o destino antes de fornecer informações ou baixar arquivos.");
        }

        if ((uri.HostNameType is UriHostNameType.IPv4 or UriHostNameType.IPv6) && IPAddress.TryParse(uri.Host, out _))
        {
            score += 3;
            reasons.Add("O site usa um endereço IP direto em vez de um domínio conhecido.");
        }

        var asciiHost = host;
        try { asciiHost = new IdnMapping().GetAscii(host); } catch { }
        var labels = asciiHost.Split('.', StringSplitOptions.RemoveEmptyEntries);
        if (labels.Any(label => label.StartsWith("xn--", StringComparison.OrdinalIgnoreCase)))
        {
            score += 3;
            reasons.Add("O domínio usa Punycode (caracteres internacionalizados). Confira cuidadosamente a grafia exibida.");
        }

        if (ContainsMixedScripts(displayHost))
        {
            score += 3;
            reasons.Add("O nome do domínio mistura alfabetos diferentes, uma técnica que pode imitar letras de marcas conhecidas.");
        }

        var brandWarning = FindBrandImpersonation(host, labels);
        if (brandWarning is not null)
        {
            score += 3;
            reasons.Add(brandWarning);
        }

        if (labels.Length >= (level == "Strict" ? 5 : 7))
        {
            score += 1;
            reasons.Add("O domínio tem muitos níveis de subdomínio; confira qual é o domínio principal.");
        }

        if (labels.Any(label => label.Length >= 32 || CountChar(label, '-') >= 3))
        {
            score += 1;
            reasons.Add("Uma parte do domínio é incomumente longa ou usa muitos hífens.");
        }

        var sensitivePath = uri.AbsolutePath.Contains("login", StringComparison.OrdinalIgnoreCase) ||
                            uri.AbsolutePath.Contains("signin", StringComparison.OrdinalIgnoreCase) ||
                            uri.AbsolutePath.Contains("account", StringComparison.OrdinalIgnoreCase) ||
                            uri.AbsolutePath.Contains("password", StringComparison.OrdinalIgnoreCase);
        if (uri.Scheme == "http" && sensitivePath)
        {
            score += 2;
            reasons.Add("A página parece relacionada a uma conta ou login, mas a conexão não usa HTTPS.");
        }

        if (score < (level == "Strict" ? 2 : level == "Basic" ? 4 : 3)) return null;

        var severity = score >= 6 ? "ALERTA ELEVADO" : score >= 4 ? "ATENÇÃO" : "VERIFICAÇÃO RECOMENDADA";
        return $"{severity} — o RX Browser encontrou sinais que merecem conferência neste endereço:\n\n• " +
               string.Join("\n\n• ", reasons) +
               "\n\nEsses sinais são heurísticos e podem gerar falsos positivos. Eles não confirmam que a página seja maliciosa. Verifique o domínio por um canal confiável antes de inserir dados pessoais.";
    }

    private static bool HostMatches(string host, string allowed)
    {
        if (string.IsNullOrWhiteSpace(allowed)) return false;
        var normalized = allowed.Trim().TrimStart('.').ToLowerInvariant();
        return host.Equals(normalized, StringComparison.OrdinalIgnoreCase) || host.EndsWith("." + normalized, StringComparison.OrdinalIgnoreCase);
    }

    private static string? FindBrandImpersonation(string host, string[] labels)
    {
        foreach (var (brand, officialDomains) in ProtectedBrands)
        {
            if (officialDomains.Any(domain => host.Equals(domain, StringComparison.OrdinalIgnoreCase) ||
                host.EndsWith("." + domain, StringComparison.OrdinalIgnoreCase)))
                continue;

            // Ex.: paypal.com.conta-falsa.example — o domínio oficial aparece apenas como isca.
            var embeddedOfficial = officialDomains.FirstOrDefault(domain => host.Contains(domain, StringComparison.OrdinalIgnoreCase));
            if (embeddedOfficial is not null)
                return $"O domínio menciona '{embeddedOfficial}', mas não termina no domínio oficial dessa marca.";

            foreach (var label in labels.Take(Math.Max(0, labels.Length - 1)))
            {
                if (label.Equals("www", StringComparison.OrdinalIgnoreCase) ||
                    label.Equals("login", StringComparison.OrdinalIgnoreCase) ||
                    label.Equals("secure", StringComparison.OrdinalIgnoreCase) ||
                    label.Equals("account", StringComparison.OrdinalIgnoreCase) ||
                    label.Equals("auth", StringComparison.OrdinalIgnoreCase)) continue;
                var normalized = NormalizeLookalikes(label);
                var compact = normalized.Replace("-", string.Empty, StringComparison.Ordinal).Replace("_", string.Empty, StringComparison.Ordinal);
                var embedsBrand = compact.Length <= brand.Length + 14 && compact.Contains(brand, StringComparison.OrdinalIgnoreCase);
                if (embedsBrand || DamerauLevenshtein(compact, brand) <= (brand.Length >= 7 ? 2 : 1))
                    return $"Uma parte do domínio é parecida com o nome '{brand}', mas não pertence a um dos domínios oficiais conhecidos: {string.Join(", ", officialDomains.Take(3))}.";
            }
        }
        return null;
    }

    private static string NormalizeLookalikes(string value) => value.ToLowerInvariant()
        .Replace('0', 'o').Replace('1', 'l').Replace('3', 'e').Replace('5', 's').Replace('7', 't')
        // Common Cyrillic/Greek lookalikes used in visually deceptive domain labels.
        .Replace('а', 'a').Replace('е', 'e').Replace('о', 'o').Replace('р', 'p').Replace('с', 'c')
        .Replace('х', 'x').Replace('і', 'i').Replace('ј', 'j').Replace('ӏ', 'l')
        .Replace('α', 'a').Replace('ο', 'o').Replace('ρ', 'p').Replace('χ', 'x').Replace('ι', 'i')
        .Replace("rn", "m", StringComparison.Ordinal);

    private static bool ContainsBidirectionalControls(string value)
    {
        foreach (var rune in value.EnumerateRunes())
        {
            var code = rune.Value;
            if (code is >= 0x202A and <= 0x202E or >= 0x2066 and <= 0x2069 or 0x200E or 0x200F or 0x061C)
                return true;
        }
        return false;
    }

    private static bool ContainsMixedScripts(string value)
    {
        var scripts = new HashSet<int>();
        foreach (var rune in value.EnumerateRunes())
        {
            var n = rune.Value;
            if (n is >= 0x0041 and <= 0x024F) scripts.Add(1);       // Latin
            else if (n is >= 0x0370 and <= 0x03FF) scripts.Add(2);  // Greek
            else if (n is >= 0x0400 and <= 0x052F) scripts.Add(3);  // Cyrillic
        }
        return scripts.Count > 1;
    }

    private static int CountChar(string value, char target) => value.Count(c => c == target);

    private static int DamerauLevenshtein(string source, string target)
    {
        if (source.Length > 64 || target.Length > 64) return int.MaxValue;
        var d = new int[source.Length + 1, target.Length + 1];
        for (var i = 0; i <= source.Length; i++) d[i, 0] = i;
        for (var j = 0; j <= target.Length; j++) d[0, j] = j;
        for (var i = 1; i <= source.Length; i++)
        for (var j = 1; j <= target.Length; j++)
        {
            var cost = source[i - 1] == target[j - 1] ? 0 : 1;
            d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
            if (i > 1 && j > 1 && source[i - 1] == target[j - 2] && source[i - 2] == target[j - 1])
                d[i, j] = Math.Min(d[i, j], d[i - 2, j - 2] + 1);
        }
        return d[source.Length, target.Length];
    }
}
