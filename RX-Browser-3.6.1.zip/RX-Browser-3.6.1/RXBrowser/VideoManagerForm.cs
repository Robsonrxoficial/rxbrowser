﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed record PageVideoInfo(
    int Index,
    string Label,
    string SourceHost,
    int Width,
    int Height,
    double CurrentTime,
    double Duration,
    bool Paused,
    bool Muted,
    double Volume,
    double PlaybackRate);

internal sealed class VideoManagerForm : Form
{
    private readonly ListView _videos = new();
    private readonly ComboBox _rate = new();
    private readonly Label _summary = new();
    public string ActionName { get; private set; } = string.Empty;
    public int SelectedVideoIndex { get; private set; } = -1;
    public double SelectedRate => (_rate.SelectedItem as RateChoice)?.Value ?? 1.0;

    public VideoManagerForm(IEnumerable<PageVideoInfo> videos, double preferredRate)
    {
        Text = "Gerenciador de vídeos — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(760, 480);
        Size = new Size(990, 600);
        BackColor = Color.FromArgb(12, 16, 23);
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9.5F);

        var header = new Label
        {
            Text = "CONTROLE DE VÍDEOS DESTA PÁGINA",
            Dock = DockStyle.Top, Height = 48, Padding = new Padding(18, 13, 0, 0),
            ForeColor = Color.FromArgb(55, 211, 235), Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        };
        Controls.Add(header);

        _videos.Dock = DockStyle.Fill;
        _videos.View = View.Details;
        _videos.FullRowSelect = true;
        _videos.HideSelection = false;
        _videos.MultiSelect = false;
        _videos.BorderStyle = BorderStyle.None;
        _videos.BackColor = Color.FromArgb(15, 21, 30);
        _videos.ForeColor = ForeColor;
        _videos.Font = new Font("Segoe UI", 9F);
        _videos.Columns.Add("Vídeo", 260);
        _videos.Columns.Add("Origem", 170);
        _videos.Columns.Add("Resolução", 105);
        _videos.Columns.Add("Tempo", 120);
        _videos.Columns.Add("Estado", 110);
        _videos.Columns.Add("Velocidade", 90);
        // Materialize once so the list and its count use the same snapshot.
        var videoList = videos.ToList();
        foreach (var video in videoList)
        {
            var duration = FormatTime(video.CurrentTime) + " / " + (double.IsFinite(video.Duration) ? FormatTime(video.Duration) : "--:--");
            var item = new ListViewItem(string.IsNullOrWhiteSpace(video.Label) ? $"Vídeo {video.Index + 1}" : video.Label);
            item.SubItems.Add(video.SourceHost);
            item.SubItems.Add($"{video.Width} × {video.Height}");
            item.SubItems.Add(duration);
            item.SubItems.Add(video.Paused ? "Pausado" : "Reproduzindo");
            item.SubItems.Add(video.PlaybackRate.ToString("0.##") + "×");
            item.Tag = video.Index;
            _videos.Items.Add(item);
        }
        if (_videos.Items.Count > 0) _videos.Items[0].Selected = true;
        Controls.Add(_videos);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 112, Padding = new Padding(14, 8, 14, 8), BackColor = Color.FromArgb(18, 25, 35) };
        _summary.Dock = DockStyle.Top;
        _summary.Height = 24;
        _summary.ForeColor = Color.FromArgb(142, 158, 178);
        _summary.Text = videoList.Count == 0 ? "Nenhum elemento HTML vídeo encontrado nesta página." : $"{videoList.Count} vídeo(s) encontrado(s). Selecione um item para controlar a reprodução.";
        footer.Controls.Add(_summary);

        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, BackColor = footer.BackColor, Padding = new Padding(0, 8, 0, 0) };
        controls.Controls.Add(MakeButton("Reproduzir", 100, () => Run("play")));
        controls.Controls.Add(MakeButton("Pausar", 84, () => Run("pause")));
        controls.Controls.Add(MakeButton("Alternar mudo", 112, () => Run("mute")));
        var speedLabel = new Label { Text = "Velocidade", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter, ForeColor = ForeColor, Padding = new Padding(8, 9, 0, 0) };
        controls.Controls.Add(speedLabel);
        _rate.Width = 88;
        _rate.DropDownStyle = ComboBoxStyle.DropDownList;
        _rate.BackColor = Color.FromArgb(27, 36, 49);
        _rate.ForeColor = ForeColor;
        foreach (var value in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0 }) _rate.Items.Add(new RateChoice(value));
        var selectedRateIndex = Enumerable.Range(0, _rate.Items.Count)
            .FirstOrDefault(index => Math.Abs(((_rate.Items[index] as RateChoice)?.Value ?? 1.0) - preferredRate) < 0.001);
        _rate.SelectedIndex = selectedRateIndex;
        controls.Controls.Add(_rate);
        controls.Controls.Add(MakeButton("Aplicar", 82, () => Run("rate")));
        controls.Controls.Add(MakeButton("Atualizar", 84, () => Run("refresh")));
        var close = MakeButton("Fechar", 80, () => { DialogResult = DialogResult.Cancel; Close(); });
        controls.Controls.Add(close);
        footer.Controls.Add(controls);
        Controls.Add(footer);
        CancelButton = close;
    }

    private void Run(string action)
    {
        if (action != "refresh")
        {
            if (_videos.SelectedItems.Count == 0 || _videos.SelectedItems[0].Tag is not int index)
            {
                MessageBox.Show(this, "Selecione um vídeo primeiro.", "Gerenciador de vídeos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            SelectedVideoIndex = index;
        }
        ActionName = action;
        DialogResult = DialogResult.OK;
        Close();
    }

    private Button MakeButton(string text, int width, Action click)
    {
        var button = new Button
        {
            Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(27, 36, 49), ForeColor = ForeColor,
            Cursor = Cursors.Hand, Margin = new Padding(3, 0, 3, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += (_, _) => click();
        return button;
    }

    private static string FormatTime(double value)
    {
        if (!double.IsFinite(value) || value < 0) return "--:--";
        var total = (int)Math.Min(value, 359999);
        return total >= 3600 ? TimeSpan.FromSeconds(total).ToString(@"h\:mm\:ss") : TimeSpan.FromSeconds(total).ToString(@"mm\:ss");
    }

    private sealed record RateChoice(double Value)
    {
        public override string ToString() => Value.ToString("0.##") + "×";
    }
}
