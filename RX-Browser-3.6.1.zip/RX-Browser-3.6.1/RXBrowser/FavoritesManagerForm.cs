﻿using System.Drawing;
using System.Windows.Forms;

namespace RXBrowser;

internal sealed class FavoritesManagerForm : Form
{
    private static readonly Color Bg = Color.FromArgb(12, 16, 23);
    private static readonly Color Panel = Color.FromArgb(20, 27, 37);
    private static readonly Color Alt = Color.FromArgb(27, 36, 49);
    private static readonly Color Accent = Color.FromArgb(55, 211, 235);
    private readonly List<FavoriteItem> _favorites;
    private readonly List<string> _folders;
    private readonly TextBox _search = new();
    private readonly ComboBox _filterGroup = new();
    private readonly ComboBox _moveToGroup = new();
    private readonly ListView _list = new();
    private readonly Action<string> _openUrl;

    public List<FavoriteItem> ResultFavorites => _favorites;
    public List<string> ResultFolders => _folders;

    public FavoritesManagerForm(IEnumerable<FavoriteItem> favorites, IEnumerable<string> folders, Action<string> openUrl)
    {
        _favorites = favorites.ToList();
        _folders = folders.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (!_folders.Contains("Geral", StringComparer.OrdinalIgnoreCase)) _folders.Insert(0, "Geral");
        _openUrl = openUrl;
        Text = "Favoritos e grupos — RX Browser";
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1020, 650);
        MinimumSize = new Size(820, 500);
        BackColor = Bg;
        ForeColor = Color.FromArgb(232, 240, 248);
        Font = new Font("Segoe UI", 9F);

        var header = new Panel { Dock = DockStyle.Top, Height = 62, BackColor = Panel, Padding = new Padding(18, 9, 18, 8) };
        header.Controls.Add(new Label { Text = "FAVORITOS RX", Dock = DockStyle.Top, Height = 25,
            ForeColor = Accent, Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold) });
        header.Controls.Add(new Label { Text = "Organize seus sites em pastas e mova favoritos entre grupos.", Dock = DockStyle.Bottom, Height = 20,
            ForeColor = Color.FromArgb(142, 158, 178) });
        Controls.Add(header);

        var filters = new Panel { Dock = DockStyle.Top, Height = 48, BackColor = Bg, Padding = new Padding(14, 7, 14, 7) };
        _filterGroup.DropDownStyle = ComboBoxStyle.DropDownList;
        _filterGroup.Width = 190;
        _filterGroup.Dock = DockStyle.Right;
        _filterGroup.BackColor = Alt;
        _filterGroup.ForeColor = ForeColor;
        _filterGroup.SelectedIndexChanged += (_, _) => RenderRows();
        _search.Dock = DockStyle.Fill;
        _search.PlaceholderText = "Pesquisar por título ou endereço...";
        _search.BackColor = Alt;
        _search.ForeColor = ForeColor;
        _search.BorderStyle = BorderStyle.FixedSingle;
        _search.TextChanged += (_, _) => RenderRows();
        filters.Controls.Add(_search);
        filters.Controls.Add(_filterGroup);
        Controls.Add(filters);

        _list.Dock = DockStyle.Fill;
        _list.View = View.Details;
        _list.FullRowSelect = true;
        _list.HideSelection = false;
        _list.BorderStyle = BorderStyle.None;
        _list.BackColor = Panel;
        _list.ForeColor = ForeColor;
        _list.Columns.Add("Título", 280);
        _list.Columns.Add("Endereço", 500);
        _list.Columns.Add("Grupo", 150);
        _list.DoubleClick += (_, _) => OpenSelected();
        _list.SelectedIndexChanged += (_, _) => SyncMoveTarget();
        Controls.Add(_list);

        var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 66, WrapContents = false, AutoScroll = true,
            Padding = new Padding(10, 14, 8, 8), BackColor = Panel };
        footer.Controls.Add(MakeButton("Nova pasta", 88, true, AddFolder));
        footer.Controls.Add(MakeButton("Renomear pasta", 104, false, RenameFolder));
        footer.Controls.Add(MakeButton("Excluir pasta", 94, false, DeleteFolder));
        footer.Controls.Add(MakeButton("Remover favorito", 112, false, RemoveSelected));
        footer.Controls.Add(MakeButton("Importar…", 86, false, ImportFavorites));
        footer.Controls.Add(MakeButton("Exportar…", 86, true, ExportFavorites));
        _moveToGroup.DropDownStyle = ComboBoxStyle.DropDownList;
        _moveToGroup.Width = 150;
        _moveToGroup.Height = 32;
        _moveToGroup.BackColor = Alt;
        _moveToGroup.ForeColor = ForeColor;
        _moveToGroup.Margin = new Padding(5, 1, 4, 0);
        footer.Controls.Add(_moveToGroup);
        footer.Controls.Add(MakeButton("Mover", 68, true, MoveSelected));
        footer.Controls.Add(MakeButton("Abrir", 70, false, OpenSelected));
        footer.Controls.Add(MakeButton("Fechar", 72, false, Close));
        Controls.Add(footer);

        RefreshGroupChoices();
        RenderRows();
    }

    private static Button MakeButton(string text, int width, bool accent, Action action)
    {
        var button = new Button { Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.Flat,
            BackColor = accent ? Color.FromArgb(22, 53, 66) : Alt,
            ForeColor = accent ? Accent : Color.FromArgb(205, 216, 229),
            Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold), Margin = new Padding(3, 0, 3, 0), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        button.Click += (_, _) => action();
        return button;
    }

    private FavoriteItem? Selected => _list.SelectedItems.Count == 0 ? null : _list.SelectedItems[0].Tag as FavoriteItem;
    private string SelectedGroup => _filterGroup.SelectedItem?.ToString() ?? "Todos";

    private void RefreshGroupChoices()
    {
        var selected = SelectedGroup;
        _filterGroup.BeginUpdate();
        _filterGroup.Items.Clear();
        _filterGroup.Items.Add("Todos");
        foreach (var folder in _folders.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)) _filterGroup.Items.Add(folder);
        _filterGroup.SelectedItem = _filterGroup.Items.Contains(selected) ? selected : "Todos";
        _filterGroup.EndUpdate();

        var target = _moveToGroup.SelectedItem?.ToString();
        _moveToGroup.BeginUpdate();
        _moveToGroup.Items.Clear();
        foreach (var folder in _folders.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)) _moveToGroup.Items.Add(folder);
        _moveToGroup.SelectedItem = target is not null && _moveToGroup.Items.Contains(target) ? target : "Geral";
        if (_moveToGroup.SelectedIndex < 0 && _moveToGroup.Items.Count > 0) _moveToGroup.SelectedIndex = 0;
        _moveToGroup.EndUpdate();
    }

    private void RenderRows()
    {
        var selectedUrl = Selected?.Url;
        var query = _search.Text.Trim();
        var group = SelectedGroup;
        var items = _favorites.Where(item => (group == "Todos" || string.Equals(item.GroupName, group, StringComparison.OrdinalIgnoreCase)) &&
            (query.Length == 0 || item.Title.Contains(query, StringComparison.OrdinalIgnoreCase) || item.Url.Contains(query, StringComparison.OrdinalIgnoreCase)))
            .OrderBy(item => item.GroupName, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(item => item.Title, StringComparer.CurrentCultureIgnoreCase).ToList();
        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var favorite in items)
        {
            var row = new ListViewItem(favorite.Title);
            row.SubItems.Add(favorite.Url);
            row.SubItems.Add(favorite.GroupName);
            row.Tag = favorite;
            if (selectedUrl is not null && string.Equals(selectedUrl, favorite.Url, StringComparison.OrdinalIgnoreCase)) row.Selected = true;
            _list.Items.Add(row);
        }
        _list.EndUpdate();
        SyncMoveTarget();
    }

    private void SyncMoveTarget()
    {
        if (Selected is { } item && _moveToGroup.Items.Contains(item.GroupName)) _moveToGroup.SelectedItem = item.GroupName;
    }

    private void AddFolder()
    {
        var name = PromptDialog.Show(this, "Nova pasta de favoritos", "Nome da pasta:", "Nova pasta");
        if (string.IsNullOrWhiteSpace(name)) return;
        var clean = name.Trim()[..Math.Min(48, name.Trim().Length)];
        if (clean.Equals("Todos", StringComparison.OrdinalIgnoreCase) || _folders.Contains(clean, StringComparer.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "Já existe uma pasta com esse nome.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (_folders.Count >= 100) return;
        _folders.Add(clean);
        RefreshGroupChoices();
        _filterGroup.SelectedItem = clean;
    }

    private void RenameFolder()
    {
        var selected = Selected?.GroupName ?? (SelectedGroup == "Todos" ? "" : SelectedGroup);
        if (string.IsNullOrWhiteSpace(selected) || selected.Equals("Geral", StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "Selecione um grupo diferente de Geral para renomear.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var name = PromptDialog.Show(this, "Renomear pasta", "Novo nome:", selected);
        if (string.IsNullOrWhiteSpace(name)) return;
        var clean = name.Trim()[..Math.Min(48, name.Trim().Length)];
        if (clean.Equals("Todos", StringComparison.OrdinalIgnoreCase) || _folders.Any(x => !x.Equals(selected, StringComparison.OrdinalIgnoreCase) && x.Equals(clean, StringComparison.OrdinalIgnoreCase))) return;
        _folders.RemoveAll(x => x.Equals(selected, StringComparison.OrdinalIgnoreCase));
        _folders.Add(clean);
        for (var i = 0; i < _favorites.Count; i++)
            if (_favorites[i].GroupName.Equals(selected, StringComparison.OrdinalIgnoreCase)) _favorites[i] = _favorites[i] with { GroupName = clean };
        RefreshGroupChoices();
        _filterGroup.SelectedItem = clean;
        RenderRows();
    }

    private void DeleteFolder()
    {
        var selected = Selected?.GroupName ?? (SelectedGroup == "Todos" ? "" : SelectedGroup);
        if (string.IsNullOrWhiteSpace(selected) || selected.Equals("Geral", StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "Selecione uma pasta diferente de Geral para excluir.", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show(this, $"Excluir a pasta ‘{selected}’? Os favoritos serão movidos para Geral.", "RX Browser",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        _folders.RemoveAll(x => x.Equals(selected, StringComparison.OrdinalIgnoreCase));
        for (var i = 0; i < _favorites.Count; i++)
            if (_favorites[i].GroupName.Equals(selected, StringComparison.OrdinalIgnoreCase)) _favorites[i] = _favorites[i] with { GroupName = "Geral" };
        RefreshGroupChoices();
        _filterGroup.SelectedItem = "Todos";
        RenderRows();
    }

    private void MoveSelected()
    {
        var item = Selected;
        var target = _moveToGroup.SelectedItem?.ToString();
        if (item is null || string.IsNullOrWhiteSpace(target)) return;
        var index = _favorites.FindIndex(x => string.Equals(x.Url, item.Url, StringComparison.OrdinalIgnoreCase));
        if (index < 0) return;
        _favorites[index] = _favorites[index] with { GroupName = target };
        RenderRows();
    }

    private void RemoveSelected()
    {
        var item = Selected;
        if (item is null) return;
        _favorites.RemoveAll(x => string.Equals(x.Url, item.Url, StringComparison.OrdinalIgnoreCase));
        RenderRows();
    }

    private void ImportFavorites()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Importar favoritos",
            Filter = "Todos os formatos compatíveis|*.json;*.html;*.htm;*.csv|Favoritos HTML|*.html;*.htm|JSON RX|*.json|CSV|*.csv",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var imported = FavoritesTransferService.Import(dialog.FileName);
            var choice = MessageBox.Show(this,
                $"Foram encontrados {imported.Favorites.Count} favorito(s) e {imported.Folders.Count} pasta(s).\n\nSim: mesclar com os favoritos atuais.\nNão: substituir a lista atual.\nCancelar: não importar.",
                "Importar favoritos", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Cancel) return;
            if (choice == DialogResult.No)
            {
                _favorites.Clear();
                _folders.Clear();
                _folders.Add("Geral");
            }
            foreach (var folder in imported.Folders)
                if (!_folders.Contains(folder, StringComparer.OrdinalIgnoreCase) && _folders.Count < 100) _folders.Add(folder);
            var knownUrls = _favorites.Select(item => item.Url).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var item in imported.Favorites)
            {
                if (knownUrls.Add(item.Url) && _favorites.Count < 5000)
                {
                    _favorites.Add(item);
                    if (!_folders.Contains(item.GroupName, StringComparer.OrdinalIgnoreCase) && _folders.Count < 100) _folders.Add(item.GroupName);
                }
            }
            RefreshGroupChoices();
            RenderRows();
            MessageBox.Show(this, $"Importação concluída. Total atual: {_favorites.Count} favorito(s).", "RX Browser", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível importar o arquivo de favoritos.\n\n" + ex.Message, "Importação de favoritos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void ExportFavorites()
    {
        using var dialog = new SaveFileDialog
        {
            Title = "Exportar favoritos",
            Filter = "HTML de favoritos (Netscape)|*.html|JSON RX Browser|*.json|CSV|*.csv",
            FilterIndex = 1,
            FileName = "RX-Browser-Favoritos.html",
            AddExtension = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            FavoritesTransferService.Export(dialog.FileName, _favorites, _folders);
            MessageBox.Show(this, $"{_favorites.Count} favorito(s) exportado(s).", "Exportação concluída", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Não foi possível exportar os favoritos.\n\n" + ex.Message, "Exportação de favoritos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void OpenSelected()
    {
        var item = Selected;
        if (item is null) return;
        _openUrl(item.Url);
    }
}
