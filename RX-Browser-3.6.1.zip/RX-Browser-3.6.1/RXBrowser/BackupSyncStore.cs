﻿using System.Security.Cryptography;
using System.Text;

namespace RXBrowser;

internal sealed record BackupSyncDashboardSummary(int DeviceCount, int OtherDeviceCount, DateTime? LatestRemoteUtc, bool OwnBackupExists, DateTime? OwnBackupUtc, long SharedBytes);

internal sealed record BackupSyncCandidate(string FilePath, string DeviceId, DateTime UpdatedUtc)
{
    public string DisplayName => $"Dispositivo {DeviceId[..Math.Min(DeviceId.Length, 8)]}  •  {UpdatedUtc.ToLocalTime():dd/MM/yyyy HH:mm}";
}

/// <summary>Publica backups seletivos, um arquivo por perfil e dispositivo, em uma pasta compartilhada.</summary>
internal static class BackupSyncStore
{
    private const string FolderName = "rx-browser-backups";

    public static string GetStorageFolder(string sharedFolder)
    {
        if (string.IsNullOrWhiteSpace(sharedFolder)) throw new ArgumentException("Selecione uma pasta compartilhada.", nameof(sharedFolder));
        return Path.Combine(Path.GetFullPath(sharedFolder), FolderName);
    }

    public static string Publish(string sharedFolder, string profileKey, string deviceId, BrowserData data)
    {
        ArgumentNullException.ThrowIfNull(data);
        var directory = GetStorageFolder(sharedFolder);
        Directory.CreateDirectory(directory);
        var safeProfile = SafePart(profileKey, "default");
        var safeDevice = SafePart(deviceId, Guid.NewGuid().ToString("N"));
        var destination = Path.Combine(directory, $"rx-{safeProfile}-{safeDevice}.rxbackup");
        var temporary = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            ProfileBackupService.Export(temporary, data);
            File.Move(temporary, destination, true);
            return destination;
        }
        finally
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
        }
    }

    public static List<BackupSyncCandidate> ListOtherDevices(string sharedFolder, string profileKey, string ownDeviceId)
    {
        var directory = GetStorageFolder(sharedFolder);
        if (!Directory.Exists(directory)) return new List<BackupSyncCandidate>();
        var safeProfile = SafePart(profileKey, "default");
        var prefix = $"rx-{safeProfile}-";
        var own = SafePart(ownDeviceId, string.Empty);
        var result = new List<BackupSyncCandidate>();
        foreach (var path in Directory.EnumerateFiles(directory, prefix + "*.rxbackup", SearchOption.TopDirectoryOnly).Take(100))
        {
            var name = Path.GetFileNameWithoutExtension(path);
            if (!name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
            var deviceId = name[prefix.Length..];
            if (deviceId.Length < 8 || string.Equals(deviceId, own, StringComparison.OrdinalIgnoreCase)) continue;
            try { result.Add(new BackupSyncCandidate(path, deviceId, File.GetLastWriteTimeUtc(path))); }
            catch { /* Ignora arquivos que desapareceram durante a enumeração da pasta compartilhada. */ }
        }
        return result.OrderByDescending(item => item.UpdatedUtc).ToList();
    }

    public static BackupSyncDashboardSummary GetDashboardSummary(string sharedFolder, string profileKey, string ownDeviceId)
    {
        if (string.IsNullOrWhiteSpace(sharedFolder)) return new BackupSyncDashboardSummary(0, 0, null, false, null, 0);
        var directory = GetStorageFolder(sharedFolder);
        if (!Directory.Exists(directory)) return new BackupSyncDashboardSummary(0, 0, null, false, null, 0);
        var safeProfile = SafePart(profileKey, "default");
        var prefix = "rx-" + safeProfile + "-";
        var own = SafePart(ownDeviceId, string.Empty);
        var remoteCount = 0;
        var deviceCount = 0;
        var ownExists = false;
        DateTime? ownUtc = null;
        DateTime? remoteUtc = null;
        long bytes = 0;
        var seenDevices = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var path in Directory.EnumerateFiles(directory, prefix + "*.rxbackup", SearchOption.TopDirectoryOnly).Take(250))
        {
            try
            {
                var fileName = Path.GetFileNameWithoutExtension(path);
                if (!fileName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                var device = fileName[prefix.Length..];
                if (device.Length < 8) continue;
                var info = new FileInfo(path);
                bytes += info.Length;
                seenDevices.Add(device);
                if (string.Equals(device, own, StringComparison.OrdinalIgnoreCase))
                {
                    ownExists = true;
                    if (ownUtc is null || info.LastWriteTimeUtc > ownUtc.Value) ownUtc = info.LastWriteTimeUtc;
                }
                else
                {
                    remoteCount++;
                    if (remoteUtc is null || info.LastWriteTimeUtc > remoteUtc.Value) remoteUtc = info.LastWriteTimeUtc;
                }
            }
            catch { /* File may be syncing or disappear during enumeration. */ }
        }
        deviceCount = seenDevices.Count;
        return new BackupSyncDashboardSummary(deviceCount, remoteCount, remoteUtc, ownExists, ownUtc, bytes);
    }

    public static bool IsOtherDeviceBackup(string filePath, string profileKey, string ownDeviceId)
    {
        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath)) return false;
        var safeProfile = SafePart(profileKey, "default");
        var prefix = $"rx-{safeProfile}-";
        var name = Path.GetFileNameWithoutExtension(filePath);
        if (!name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) return false;
        var deviceId = name[prefix.Length..];
        return deviceId.Length >= 8 && !string.Equals(deviceId, SafePart(ownDeviceId, string.Empty), StringComparison.OrdinalIgnoreCase);
    }

    public static bool PublishIfDue(BrowserData data, string profileKey)
    {
        if (!data.BackupSyncEnabled || string.IsNullOrWhiteSpace(data.BackupSyncFolder)) return false;
        var interval = TimeSpan.FromMinutes(Math.Clamp(data.BackupSyncIntervalMinutes, 5, 60));
        if (data.LastBackupSyncUtc != DateTime.MinValue && DateTime.UtcNow - data.LastBackupSyncUtc < interval) return false;
        Publish(data.BackupSyncFolder, profileKey, data.BackupSyncDeviceId, data);
        data.LastBackupSyncUtc = DateTime.UtcNow;
        return true;
    }

    private static string SafePart(string? value, string fallback)
    {
        var raw = (value ?? string.Empty).Trim().ToLowerInvariant();
        if (raw.Length == 0) return fallback;
        var slug = new string(raw.Where(char.IsAsciiLetterOrDigit).Take(40).ToArray());
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        var suffix = Convert.ToHexString(hash.AsSpan(0, 4)).ToLowerInvariant();
        return (slug.Length == 0 ? "profile" : slug) + "-" + suffix;
    }
}
