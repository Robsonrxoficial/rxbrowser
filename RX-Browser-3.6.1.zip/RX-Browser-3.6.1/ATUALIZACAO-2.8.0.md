# RX Browser 2.8.0 — cofre protegido e segurança renovada

## Cofre de senhas aprimorado
- Cofre local criptografado pela DPAPI no escopo do usuário Windows atual.
- Coluna de estado do preenchimento por credencial.
- Preenchimento manual iniciado pelo usuário, nunca automático ao carregar a página.
- Opt-in separado por credencial e uma chave geral na Central de Segurança.
- Correspondência de origem exata (esquema, host e porta); subdomínios e portas diferentes não herdam credenciais.
- Somente HTTPS é aceito, com exceção de `localhost`/loopback para desenvolvimento.
- A página não é enviada automaticamente após o preenchimento.
- O cofre, as senhas e as autorizações individuais não são sincronizados.
- O navegador limpa a cópia temporária da área de transferência ao fechar o cofre, se o conteúdo ainda for o mesmo.

## Bloqueio de guias por PIN
- PIN numérico de 6 a 12 dígitos.
- Derivação PBKDF2-HMAC-SHA256 com salt individual e 280.000 iterações.
- Compatibilidade mantida com guias antigas protegidas por senha.
- Cinco tentativas incorretas geram pausa de 30 segundos na sessão atual.

## Central de Segurança renovada
- Mostra a situação do site atual e contadores de proteção.
- Controle geral para permitir ou desativar o preenchimento manual pelo cofre.
- Mostra total de credenciais, credenciais autorizadas e guias protegidas por PIN.
- Limpeza de exceções cobre anúncios, rastreamento e pop-ups.

## Limitações e segurança
- O preenchimento é manual e só tenta localizar campos comuns de usuário e senha no documento principal. Sites com formulários dentro de iframes ou campos personalizados podem não funcionar.
- O PIN bloqueia a troca para uma guia dentro da interface do navegador; não criptografa o conteúdo do site nem os arquivos inteiros do perfil. O conteúdo continua sujeito às permissões da conta Windows.
- O cofre DPAPI é destinado ao mesmo usuário Windows e ao mesmo ambiente de perfil; não copie o arquivo para outra conta esperando que possa ser aberto.
- Senhas e dados do cofre não são enviados à sincronização de favoritos, espaços de trabalho ou preferências.
- O preenchimento não envia formulários nem clica em botões de login.
