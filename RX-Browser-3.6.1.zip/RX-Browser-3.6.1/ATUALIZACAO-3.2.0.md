# RX Browser 3.2.0

## Novidades desta versão

- **Painel visual de sincronização:** mostra estado da publicação, dispositivos encontrados, tamanho dos backups compartilhados e datas da publicação local/remota. Ações rápidas para configurar, publicar e importar.
- **Proteção adicional contra sites falsos:** heurísticas locais reforçadas para caracteres de direção bidirecional invisíveis, homógrafos latinos/cirílicos/ gregos, domínios que imitam marcas e links encurtados. Os avisos continuam sendo sinais heurísticos, não uma confirmação de malware.
- **Importação e exportação avançada de favoritos:** formatos JSON RX, HTML Netscape e CSV; valida URLs HTTP/HTTPS, limita o tamanho do arquivo e permite mesclar ou substituir favoritos.
- **Barra de ferramentas personalizável:** pode mostrar ou ocultar botões de navegação, tradução, segurança, desempenho, guias, downloads, histórico, favoritos e espaços. O menu Mais opções e a barra de endereço permanecem disponíveis.
- **Recuperação de sessões e perfil:** rotação de três gerações de backup (`.bak`, `.bak.1`, `.bak.2`), cópia do arquivo principal danificado e indicação do arquivo usado para recuperação.

## Dados e privacidade

Os arquivos de favoritos exportados são texto legível e contêm títulos, endereços e nomes de grupos. Os backups seletivos entre dispositivos continuam sem incluir senhas, PINs, cookies, histórico, downloads, permissões, extensões instaladas ou dados WebView2.

## Compilação e teste

No Windows, extraia o ZIP e execute `CRIAR-EXE.bat`. O projeto usa .NET 10 para Windows x64 e Microsoft Edge WebView2. A compilação e os testes funcionais finais precisam ser realizados em Windows.
