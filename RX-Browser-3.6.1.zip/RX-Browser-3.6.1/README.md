# RX Browser 3.6.1

Navegador para Windows com interface própria em C# WinForms e renderização de páginas pelo Microsoft Edge WebView2 (Chromium).

## Correções da 3.6.1 e recursos da 3.6.0

### RX Privacy Monitor
- Painel de privacidade com atualização automática durante a sessão.
- Contadores de requisições externas observadas, bloqueios totais, anúncios, rastreadores, pop-ups e alertas heurísticos de endereço.
- Lista dos domínios mais bloqueados e até 300 eventos recentes, com filtro pelo site atual.
- Os registros ficam somente na memória da sessão; não são gravados no perfil nem sincronizados.
- O monitor guarda apenas host/domínio, categoria do recurso e horário. Não registra URL completa, caminho, parâmetros, conteúdo de páginas ou referenciadores.
- Guias privadas são excluídas da telemetria do painel.
- Acesso pelo menu Mais, pela Central RX/Paleta de comandos.

### RX AdBlock — listas pessoais aprimoradas
- Importação e exportação de listas de domínios em TXT.
- Aceita um domínio por linha, comentários iniciados por `#` ou `!` e a notação simples `||dominio^`.
- Limite aumentado para 5.000 domínios personalizados por perfil.
- Linhas de regras complexas EasyList/uBlock são ignoradas; o RX não declara compatibilidade completa com esses formatos.
- As exceções por site e os níveis Básico, Equilibrado e Rigoroso continuam disponíveis.

### Proteção contra phishing e rastreamento
- Mantida a análise local heurística de URLs, agora com padrões adicionais para marcas de serviços brasileiros (Nubank, Itaú, Bradesco, Santander, Caixa, Mercado Livre, Mercado Pago e PicPay), além de alertas antes de abrir endereços suspeitos e SmartScreen do WebView2.
- Os alertas heurísticos também aparecem no monitor temporário de privacidade.
- Filtros locais de anúncios e rastreadores continuam aplicados via `WebResourceRequested`, com contagem por tipo de evento.
- As proteções são complementares e não garantem identificar todos os sites maliciosos nem bloquear todos os anúncios/rastreadores.

## Recursos mantidos
- RX Translate com preparação guiada da tradução por serviço externo.
- RX Reader Intelligence com extração local de artigos e exportação.
- RX Tab Manager 2.0 com pesquisa, filtros, ordenação e fechamento em lote.
- Caderno RX com notas locais por site, salvamento automático e exportação Markdown/TXT; excluído da sincronização e indisponível em guias privadas.
- Histórico, sessões salvas, acessibilidade, logs de diagnóstico, sincronização seletiva, espaços de trabalho, favoritos, permissões e proteção de downloads.

## Correções da 3.6.1
- Corrigida referência de cor inexistente (`Panel2`) no painel RX Privacy Monitor.
- Removida, na fase de resolução de assemblies, a referência ao wrapper WPF não utilizado do WebView2 em projeto exclusivamente WinForms, evitando o conflito `WindowsBase`/`MSB3277`.
- Corrigido o aviso de nulabilidade no valor alternativo do intervalo de backup.

## Compilar no Windows
1. Extraia o pacote completo.
2. Execute `CRIAR-EXE.bat`.
3. O script usa o SDK .NET 10 local quando disponível ou tenta preparar uma cópia local.
4. O resultado esperado é `DIST\RXBrowser.exe`.

O projeto exige o Microsoft Edge WebView2 Runtime instalado separadamente. O ZIP contém código-fonte e scripts; não contém executável pré-compilado.
