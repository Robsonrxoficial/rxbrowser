# Histórico — RX Browser 2.9.0

Versão anterior com verificações heurísticas locais de URL, sincronização de preferências não secretas, tradução mais integrada e recuperação de sessão. Mantida como parte do histórico do projeto.
