@echo off
if exist "%~dp0DIST\RXBrowser.exe" (
  start "" "%~dp0DIST\RXBrowser.exe"
) else (
  echo RXBrowser.exe ainda nao foi gerado.
  echo Execute CRIAR-EXE.bat primeiro.
  pause
)
