# Créditos e licenças

- RX Browser: código e interface originais do projeto.
- Microsoft Edge WebView2: componente Microsoft usado para renderização web; sujeito aos termos e à licença da Microsoft.
- Microsoft.Web.WebView2 NuGet package: dependência declarada no arquivo `.csproj`.
- Ícones, fontes e recursos do Windows: fornecidos pelo sistema operacional.

Consulte os arquivos de licença dos componentes de terceiros e os termos aplicáveis do Microsoft Edge WebView2.
