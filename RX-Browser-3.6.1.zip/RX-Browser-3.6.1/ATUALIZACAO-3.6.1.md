# RX Browser 3.6.1 — correção de compilação

Esta atualização mantém os recursos da versão 3.6.0 e corrige os problemas encontrados ao executar `CRIAR-EXE.bat` no Windows.

## Correções
- `PrivacyActivityDashboardForm.cs`: substituída a referência inexistente `Panel2` por `PanelAltColor`, que já é a cor alternativa definida pelo formulário. Corrige `CS0103`.
- `RXBrowser.csproj`: adicionado o alvo `RemoveUnusedWebView2WpfReference`, que remove apenas o wrapper WPF não utilizado antes de `ResolveAssemblyReferences`. O projeto permanece WinForms e continua usando `Microsoft.Web.WebView2.WinForms`. Isso evita o conflito de versões de `WindowsBase` (`MSB3277`) causado pela referência WPF desnecessária.
- `BackupSyncForm.cs`: suprimida a possibilidade nula do item padrão do ComboBox com `!`, eliminando o aviso `CS8600` na linha indicada pelo build.

## Como testar
1. Extraia o ZIP completo.
2. Execute `CRIAR-EXE.bat`.
3. Confirme que o script publica `DIST\RXBrowser.exe`.

A compilação real ainda precisa ser confirmada no Windows do usuário; esta sessão não possui SDK .NET para executar MSBuild. O pacote inclui fonte e scripts, não um EXE pré-compilado.
