@echo off
chcp 65001 >nul
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CRIAR-EXE.ps1"
if errorlevel 1 (
  echo.
  echo O processo terminou com erro. Veja a mensagem acima.
)
echo.
pause
