# Correção RX Browser 2.6.1

## Erro corrigido

A compilação 2.6.0 falhava em `MainForm.cs` na construção do JavaScript do gerenciador de vídeos. O código usava uma string raw interpolada com um único `$` e chaves JavaScript consecutivas. Em strings raw interpoladas do C#, as chaves são delimitadores de interpolação e não usam o escape `{{`/`}}` das strings interpoladas convencionais.

## Alteração

- O template foi alterado de `$"""` para `$$"""`.
- As chaves do JavaScript passaram a ser literais simples.
- As três interpolações C# foram explicitadas como `{{indexJson}}`, `{{actionJson}}` e `{{rateJson}}`.
- O script JavaScript resultante foi extraído com valores de teste e validado com `node --check`.

## Sobre o aviso MSB3277 / WindowsBase

O aviso de conflito entre WindowsBase 4.0 e 5.0 é separado dos erros C# que interrompiam a compilação. Ele vem das referências do pacote WebView2 e não é tratado como erro nesta correção. Se permanecer após esta versão, pode ser analisado separadamente; não foi ocultado artificialmente.

## Validação

- XML do projeto validado.
- Estrutura e delimitadores C# verificados estaticamente.
- JavaScript do gerenciador de vídeos validado com `node --check`.
- ZIP testado com CRC.
- Compilação real não executada neste ambiente Linux sem SDK .NET disponível.
