# Atualização RX Browser 2.5.0

Esta versão evolui a 2.4.0 sem remover espaços de trabalho, proteção de guias, sessões, leitor PDF, cofre local, sincronização de favoritos, segurança e ferramentas de mídia.

## Sincronizar espaços de trabalho
1. Abra **Espaços** na barra superior.
2. Clique em **Pasta sync** e selecione uma pasta compartilhada entre os computadores (por exemplo, pasta do OneDrive já sincronizada localmente).
3. Feche o painel. O RX Browser faz a primeira sincronização.
4. Repita a seleção da mesma pasta nos outros computadores. Use **Desativar sync** para interromper a sincronização neste perfil; os arquivos compartilhados não são apagados.

Cada dispositivo mantém seu próprio arquivo em `rx-browser-workspaces-devices`. Alterações mais recentes vencem; exclusões são propagadas com tombstones. A sincronização também ocorre ao abrir/fechar o gerenciador e, automaticamente a cada três minutos, sem depender da opção de sincronização de favoritos/configurações.

## Grupos de favoritos
Abra **Favoritos** e escolha **Gerenciar favoritos e grupos**. Crie pastas, renomeie, exclua (os itens voltam para Geral), mova favoritos e pesquise por título/endereço. Os nomes de grupo associados a favoritos acompanham os registros sincronizados; pastas vazias permanecem locais até receberem um favorito.

## Central de downloads
Use `Ctrl+J` ou o botão de downloads. Filtre por estado, pesquise nome/origem, acompanhe o progresso e veja o total transferido.

## Segurança de sincronização
Os arquivos de espaços contêm somente identificadores, nomes, títulos e URLs HTTP/HTTPS. Não sincronizam cookies, senhas, histórico ou dados privados. A pasta deve ser controlada pelo usuário e sincronizada pelo serviço de arquivos que ele já utiliza.

## Gerar o executável
Execute `CRIAR-EXE.bat` no Windows. O resultado será `DIST\RXBrowser.exe`. O pacote ainda precisa ser compilado e testado no Windows com o SDK .NET 10 e o Microsoft Edge WebView2 Runtime instalado.
