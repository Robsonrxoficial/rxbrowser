# RX Browser 3.1.0

## Novidades

- Backup seletivo entre dispositivos por pasta compartilhada, com um arquivo por perfil e dispositivo.
- Publicação automática configurável em intervalos de 5, 10, 15, 30 ou 60 minutos.
- Importação manual de um backup de outro dispositivo com confirmação e cópia de segurança prévia dos dados atuais.
- Central RX personalizável: cartões visíveis, ordem, cor de destaque e número de colunas salvos por perfil.
- Gerenciador de permissões de sites: filtrar por domínio/tipo, permitir, bloquear, remover regras e apagar todas as decisões.
- Manutenção de desempenho: varreduras de suspensão menos frequentes e ignoradas quando há poucas guias ou a janela está minimizada.

## Sincronização e privacidade

O backup é seletivo e contém favoritos, pastas, espaços de trabalho, preferências não secretas e personalização da Central RX. Não inclui senhas, PINs, cookies, histórico, downloads, permissões de sites, extensões instaladas ou dados do WebView2.

Os arquivos `.rxbackup` são arquivos ZIP com JSON legível; não são criptografados. Use uma pasta compartilhada privada e confiável. Cada dispositivo publica seu próprio arquivo; a importação de outro dispositivo é manual e pede confirmação.

## Compilação

No Windows, extraia o ZIP e execute `CRIAR-EXE.bat`. O projeto tem como alvo .NET 10 Windows x64 e usa Microsoft Edge WebView2 Runtime. A compilação e a execução final devem ser verificadas em Windows.
