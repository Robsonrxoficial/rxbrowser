﻿# Checklist de teste — RX Browser 3.6.0

## Compilação e inicialização
- [ ] Execute `CRIAR-EXE.bat` em Windows 10/11 64 bits com SDK .NET 10.
- [ ] Confirme a criação de `DIST\RXBrowser.exe`.
- [ ] Confirme que o WebView2 Runtime está instalado e que páginas comuns abrem.

## RX Translate
- [ ] Abra um site HTTP/HTTPS e clique no botão 文.
- [ ] Verifique que a janela mostra o URL correto e os idiomas de origem/destino.
- [ ] Cancele e confirme que não há cópia/abertura de serviço.
- [ ] Confirme, aceitando, que o URL é copiado e o Google Tradutor abre em nova guia.
- [ ] Na área Sites, cole o URL e execute a tradução; teste origem automática e idiomas distintos.
- [ ] Confirme que as preferências selecionadas persistem após reiniciar.
- [ ] Teste tradução de texto selecionado e o atalho Ctrl+Shift+X.

## RX Reader Intelligence
- [ ] Teste em artigo com título, autor, cabeçalhos, parágrafos e listas.
- [ ] Confirme estimativa de leitura, remoção de menus e conteúdo de navegação.
- [ ] Teste páginas com pouco texto e confirme a mensagem apropriada.
- [ ] Teste A−/A+, Serif/Sans e tema claro/escuro.
- [ ] Copie o conteúdo e exporte Markdown e TXT.
- [ ] Confirme que a página de origem continua aberta após fechar o leitor.

## RX Tab Manager 2.0
- [ ] Abra várias guias normais, privadas, fixadas, agrupadas e suspensas.
- [ ] Pesquise por título, domínio e nome de grupo.
- [ ] Teste todos os filtros e os três modos de ordenação.
- [ ] Confirme pré-visualizações e identificação de estado nos cartões.
- [ ] Feche uma guia individual e confirme atualização da contagem.
- [ ] Teste fechar guias não fixadas e confirme o aviso sobre guias privadas e a preservação de uma guia quando não houver fixadas.

## Recursos anteriores
- [ ] Teste Caderno RX, histórico filtrável, sessões salvas e acessibilidade.
- [ ] Teste sincronização seletiva e backup; confirme que notas locais seguem excluídas.


## RX Privacy Monitor 3.6
- [ ] Abra páginas com conteúdo de terceiros e confirme o aumento do contador de requisições externas.
- [ ] Confirme eventos de anúncios/rastreadores bloqueados e os domínios mostrados no painel.
- [ ] Alterne o filtro do site atual e confira a lista de eventos; as métricas do topo representam a sessão inteira.
- [ ] Confirme que o painel atualiza sem ser fechado e que Limpar atividade zera somente as métricas temporárias.
- [ ] Abra uma guia privada e confirme que ela não gera registros no monitor.
- [ ] Reinicie o RX Browser e confirme que os eventos temporários não foram persistidos.

## RX AdBlock — listas pessoais
- [ ] Exporte a lista personalizada para TXT e confira que ela contém somente domínios, sem histórico.
- [ ] Importe um TXT com domínios simples, comentários e linhas `||dominio^`; confirme que os itens válidos são acrescentados.
- [ ] Confirme que regras avançadas/coringas são ignoradas e que a interface informa as linhas não reconhecidas.
- [ ] Salve, feche e reabra as configurações para verificar a persistência dos domínios.
- [ ] Teste um domínio bloqueado e uma exceção por site; recarregue a página e confirme o comportamento esperado.

## Proteção contra phishing
- [ ] Confirme que a verificação heurística está ativada e teste o alerta usando um endereço de teste que corresponda a um padrão local sinalizado.
- [ ] Escolha cancelar e confirme que a navegação não prossegue.
- [ ] Confirme que o aviso aparece no monitor e que nenhuma URL completa é mostrada/armazenada nele.
- [ ] Confirme em diagnóstico que a verificação de reputação SmartScreen continua solicitada pelo WebView2.
