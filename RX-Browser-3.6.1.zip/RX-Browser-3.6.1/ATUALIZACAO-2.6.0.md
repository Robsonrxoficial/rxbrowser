# Atualização RX Browser 2.6.0

## Bloqueador avançado
No menu `•••`, abra `Configurar filtros de anúncios`. Escolha Básica, Equilibrada ou Rigorosa, adicione domínios personalizados e salve. As mudanças afetam novas requisições; recarregue a página. Para quebrar menos sites, comece em Equilibrada. Este é um filtro por domínio, não um motor EasyList/uBlock.

## Tradução integrada
Clique em `文` ao lado da barra de endereço. Use o idioma padrão ou escolha outro. Para alterar o idioma padrão, escolha `Definir idioma padrão`. A tradução de site abre o Google Tradutor e copia o endereço; na página externa, use a opção Sites, cole o endereço e comece. A tradução de trechos abre a interface de tradução com o texto selecionado. Não envie conteúdo confidencial.

## Gerenciador de vídeos
No menu `•••`, escolha `Gerenciador de vídeos desta página`. Selecione um vídeo HTML e use reproduzir, pausar, alternar mudo ou aplicar velocidade. Conteúdo de players incorporados/DRM pode não ser detectado; use o botão RX PiP da própria página para tentar abrir Picture-in-Picture.

## Personalizar nova guia
Abra `•••` > `Personalizar página inicial` ou use o botão na própria nova guia. Escolha a saudação, tema, relógio, seções de atalhos/favoritos/sites recentes, quantidade de favoritos e atalhos próprios HTTP/HTTPS.

## Sincronização
O idioma preferido e as opções de página inicial acompanham a sincronização de preferências se configurada. Os domínios de bloqueio personalizados permanecem locais para evitar copiar filtros pessoais sem intenção.

## Compilação
Extraia o ZIP e execute `CRIAR-EXE.bat` em Windows 10/11 64 bits com .NET SDK 10. O Microsoft Edge WebView2 Runtime é um requisito separado. O EXE ainda não está incluído.
