# RX Browser 3.5.0 — Tradução, leitura e guias

## RX Translate
O botão de tradução abre uma janela de preparação onde é possível selecionar idioma de origem e destino. Após a confirmação, o endereço é copiado e o Google Tradutor é aberto na área Sites. O usuário ainda precisa colar o endereço e iniciar a tradução no próprio serviço. Isso não é tradução local nem automática. O serviço externo pode acessar e processar a página; não use esse fluxo com conteúdo confidencial. A disponibilidade de tradução de sites varia por região.

## RX Reader Intelligence
A extração agora compara áreas semânticas (article, main e variantes), considera quantidade de texto, parágrafos e densidade de links, e remove elementos conhecidos como navegação, anúncios, consentimento e conteúdo oculto. O leitor apresenta autor quando detectado, estimativa de tempo de leitura, alternância de fonte e tema, ajuste de tamanho e exportação Markdown/TXT. Páginas com conteúdo dinâmico, paywalls ou layouts incomuns ainda podem exigir revisão.

## RX Tab Manager 2.0
O gerenciador de guias oferece busca por título, URL e grupo; filtros por tipo/estado; ordenação por atividade, título ou grupo; metadados nos cartões; e fechamento em lote das guias não fixadas com confirmação. Se não houver guias fixadas, uma guia é preservada para manter o navegador aberto; o aviso confirma que guias privadas também entram nesse fechamento.

## Compatibilidade e limitações
- Mantém C# WinForms e Microsoft Edge WebView2 para renderização.
- Requer WebView2 Runtime instalado no Windows.
- O ZIP contém projeto e scripts de compilação, não um executável pré-compilado.
- A compilação final precisa ser validada em Windows com SDK .NET 10.
