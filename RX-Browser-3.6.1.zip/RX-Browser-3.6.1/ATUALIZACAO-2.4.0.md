# RX Browser 2.4.0 — atualização

A atualização mantém a série 2.x e acrescenta dois recursos de produtividade.

## Espaços de trabalho
Salve até 30 conjuntos com até 20 guias cada. Os conjuntos preservam título, URL, grupo e estado de fixação. É possível renomear, excluir, pesquisar, importar e exportar. Ao abrir, o navegador adiciona as guias ao conjunto atual sem fechar as que já estavam abertas.

Guias privadas e protegidas por senha são intencionalmente excluídas. O arquivo exportado contém apenas metadados e URLs; não contém senhas, cookies, histórico ou dados de sessão.

## Localizar guia aberta
Use `Ctrl+Shift+Q` para pesquisar as guias atuais por título, URL, grupo e estado. Selecione uma entrada para voltar à guia correspondente. O bloqueio por senha continua aplicado quando uma guia protegida é selecionada.

## Atalhos
Use `Ctrl+Shift+W` para abrir os espaços de trabalho. Os dois atalhos novos podem ser personalizados em Mais opções → Atalhos.

## Compilação
Extraia em pasta nova e execute `CRIAR-EXE.bat` no Windows com .NET 10 e WebView2 Runtime.
