﻿# RX Browser 3.3.0

## Histórico mais completo
- Filtros por período: todas as datas, hoje, últimos 7 dias e últimos 30 dias.
- Filtro por site/host e pesquisa por título ou URL.
- Exportação do resultado filtrado em CSV (UTF-8).
- Atalhos no diálogo: Ctrl+F pesquisa, Ctrl+E exporta, Delete remove e Enter abre.
- O histórico apresentado continua sendo apenas o histórico local não privado.

## Sessões salvas com pré-visualização
- Pesquisa por nome da sessão, título de guia ou URL.
- Pré-visualização de data, quantidade de guias, guia ativa, guias fixadas e grupos.
- Abertura, renomeação e exclusão continuam usando as ações da versão anterior.

## Acessibilidade
- Escala da janela principal, barra lateral e novas guias ajustável de 90% a 140%, independente do zoom das páginas.
- Alto contraste na janela principal com fundo preto, texto branco e destaque amarelo; diálogos especializados mantêm a própria paleta nesta versão.
- Preferências armazenadas por perfil e incluídas na sincronização de preferências não secretas.
- Atalho Ctrl+Shift+U para abrir as opções de acessibilidade.

## Diagnóstico e logs
- Log local rotativo com limite aproximado de 2 MB por arquivo e uma geração anterior.
- Registro de exceções não tratadas da interface, AppDomain e tarefas não observadas.
- Exportação manual do log pelo painel Diagnóstico.
- O log pode conter mensagens de erro e caminhos locais; revisar antes de compartilhar.

## Privacidade
- Guias privadas não entram no histórico comum nem na exportação CSV.
- Logs são locais ao perfil e não são sincronizados.
- Os backups seletivos continuam excluindo senhas, PINs, cookies, histórico, downloads, permissões de sites e dados WebView2.
