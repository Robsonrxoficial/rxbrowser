# RX Browser 3.6.0 — Proteção, privacidade e bloqueio aprimorados

## RX Privacy Monitor
- Novo painel de atividade com atualização automática a cada 1,2 segundo enquanto estiver aberto.
- Mostra requisições externas observadas, requisições bloqueadas, anúncios, rastreadores, pop-ups e alertas heurísticos.
- Classifica requisições bloqueadas por domínio e tipo de recurso do WebView2.
- Mantém no máximo 300 eventos recentes em memória e permite filtrar os eventos pelo site atual.
- O painel não persiste eventos; guias privadas são excluídas. Nenhum caminho, query string, URL completa, conteúdo de página ou referenciador é salvo.
- Acesso pelo menu Mais, pela Central RX e pela Paleta de comandos.

## RX AdBlock — listas personalizadas
- Importação e exportação TXT de domínios personalizados.
- Parser restrito a hostnames simples e à forma básica `||dominio^`; comentários `#` e `!` são descartados.
- Regras com curingas, opções ou caminhos são ignoradas intencionalmente, em vez de serem interpretadas parcialmente.
- Limite local aumentado de 500 para 5.000 domínios por perfil.
- Persistência do limite atualizada no carregamento do perfil.

## Proteção contra phishing
- Os alertas heurísticos de navegação passam a compor a atividade temporária do monitor.
- Ampliados os padrões locais de falsificação de domínio para marcas conhecidas do Brasil, além das marcas internacionais que já estavam contempladas.
- SmartScreen/reputation checking continua solicitado explicitamente pelo WebView2.
- O RX mantém a distinção entre heurísticas locais e reputação externa: alertas não são prova definitiva de fraude, e ausência de alerta não certifica segurança.

## Limites conhecidos
- O filtro de anúncios continua baseado em hostnames e listas locais; não interpreta integralmente EasyList/uBlock e pode afetar recursos legítimos.
- O monitor contabiliza requisições observadas pelo evento `WebResourceRequested`; não representa um relatório de rede completo do Edge.
- Contagens e eventos do monitor são temporários e reiniciam ao encerrar o aplicativo ou ao limpar a atividade.
