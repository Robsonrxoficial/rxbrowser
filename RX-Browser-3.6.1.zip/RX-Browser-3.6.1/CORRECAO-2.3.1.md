# RX Browser 2.3.1 — correção dos erros de compilação

Esta atualização responde ao relatório de compilação enviado para a versão 2.3.0.

## Erros corrigidos

1. **CS1061 — `WebView2.AcceleratorKeyPressed`:** o projeto não pode depender desse evento na classe WinForms usada pelo pacote instalado. A captura de atalhos agora usa `Application.AddMessageFilter`/`IMessageFilter`, ativa somente quando a janela principal está em foco e remove o filtro durante o fechamento.
2. **CS1061 — `CoreWebView2Settings.IsPasswordAutofillEnabled`:** removida a referência estática que impedia a compilação. O projeto continua desligando o salvamento de senhas e o preenchimento geral com propriedades suportadas; também tenta desligar o preenchimento de senhas por reflexão, se a projeção WebView2 presente em tempo de execução expuser essa propriedade.
3. **CS1503 — `DateTime` para `string`:** `ParseEstimatedEndTime` agora recebe `object?` e aceita `DateTime`, `DateTimeOffset` e `string`.

## Script de publicação

O `CRIAR-EXE.ps1` agora procura primeiro o SDK .NET 10 na pasta local `%LOCALAPPDATA%\RXBrowser\dotnet-sdk`. Assim, se o SDK já estiver instalado localmente, não tenta baixar o instalador novamente. A mensagem de falha também diferencia um erro de compilação de um problema de conexão.

## Aviso MSB3277

O aviso de conflito `WindowsBase` informado no log não era um dos erros fatais que interromperam a compilação. Ele pode continuar aparecendo durante a resolução de referências do pacote WebView2/WPF, embora o aplicativo use WinForms. Não ocultei o aviso; confirme o resultado pelo código de saída de `dotnet publish`.

## Teste

1. Extraia este ZIP em uma pasta nova (não sobreponha arquivos da versão 2.3.0).
2. Execute `CRIAR-EXE.bat`.
3. Confirme que não aparecem os erros CS1061/CS1503 relatados e que o script cria `DIST\RXBrowser.exe`.
4. Teste `Ctrl+T`, `Ctrl+W`, `Ctrl+L`, `Ctrl+Shift+G` e os demais atalhos enquanto o foco está no conteúdo de uma página.
5. Abra um diálogo de configurações e confirme que os atalhos do navegador não são acionados enquanto o diálogo estiver ativo.

O ZIP contém o código-fonte e o script de publicação, não um executável pré-compilado. A compilação final precisa ser confirmada no Windows do usuário.
