# Histórico de versões — RX Browser

## 3.6.1
- Corrigido erro de compilação CS0103 no painel RX Privacy Monitor (`Panel2` inexistente).
- Removida referência WPF WebView2 não utilizada em projeto WinForms para evitar conflito de `WindowsBase` (MSB3277).
- Corrigido aviso CS8600 na seleção alternativa do intervalo de backup.
- Mantidos os recursos funcionais da versão 3.6.0.

## 3.6.0
- RX Privacy Monitor com métricas temporárias, eventos recentes, domínios bloqueados e filtro pelo site atual.
- Telemetria mínima em memória: somente hosts, categoria e horário; sem URLs completas e sem guias privadas.
- Importação/exportação de listas simples no RX AdBlock e limite aumentado para 5.000 domínios personalizados.
- Alertas heurísticos de phishing integrados à atividade de privacidade.
- Mantidas as verificações SmartScreen do WebView2, as exceções por site e os recursos anteriores.

## 3.5.0
- RX Translate: diálogo de preparação de tradução, seleção de idiomas e persistência das preferências; fluxo de sites externo documentado com aviso de privacidade.
- RX Reader Intelligence: extração de conteúdo com heurísticas semânticas, metadados e estimativa de leitura; preferências de leitura e exportação Markdown/TXT.
- RX Tab Manager 2.0: pesquisa, filtros por estado, ordenação e fechamento em lote de guias não fixadas.
- Atualização de identidade visual e documentação para 3.5.0.

## 3.4.0
- Caderno RX para criar e administrar notas locais associadas ao site ativo.
- Salvamento automático, armazenamento separado por perfil e exportação para Markdown/TXT.
- Bloqueio da abertura do Caderno RX em guias privadas.
- Notas excluídas da sincronização e do backup seletivo.

## 3.3.0
- Histórico com filtros por data e site, pesquisa e exportação CSV.
- Gerenciador de sessões salvas com pesquisa e pré-visualização.
- Acessibilidade: escala de interface, alto contraste e atalho dedicado.
- Preferências de acessibilidade incluídas no snapshot de sincronização (schema 5).
- Log local rotativo e exportação manual pelo painel de diagnóstico.
- Mantidas as proteções e os módulos da versão 3.2.0.

## 3.2.0
- Painel visual de sincronização.
- Proteção adicional contra URLs suspeitas.
- Importação e exportação de favoritos.
- Barra de ferramentas personalizável.
- Recuperação de dados e sessões.
