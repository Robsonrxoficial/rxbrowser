# Atualização RX Browser 2.7.0

Esta versão parte da 2.6.2. As correções de rolagem das configurações e do gerenciador de vídeos foram preservadas.

## 1. Central de extensões
- Pesquisa por nome, ID, versão e permissões declaradas.
- Prévia do manifesto antes da instalação.
- Destaque de permissões sensíveis e padrões de acesso amplo.
- Detalhes, alternância, abertura da pasta, atualização e remoção.
- Registro local por perfil da versão e da pasta de origem.

As extensões WebExtension precisam ser compatíveis com o WebView2. A análise do manifesto não é uma auditoria do código nem garante que a extensão seja segura. Instale apenas extensões de fontes confiáveis.

## 2. Proteção de downloads
- Desativada: não mostra avisos adicionais.
- Equilibrada: pede confirmação para formatos executáveis e semelhantes.
- Rigorosa: confirma formatos moderados/altos e bloqueia automaticamente scripts/comandos classificados como críticos.
- A central identifica o nível estimado de risco e mostra o motivo.
- SHA-256 pode ser calculado para um arquivo concluído.

A classificação usa o nome/extensão e a origem declarada. Não examina o conteúdo e não substitui SmartScreen ou antivírus. O hash só ajuda a comparar integridade com uma referência confiável.

## 3. Perfis visuais independentes
Cada perfil pode ter um ícone e uma cor de destaque personalizados. As opções são gravadas nos dados daquele perfil. Os campos visuais não secretos podem ser incluídos na sincronização de preferências já existente.

## 4. Navegação por teclado
- Ctrl+Tab e Ctrl+Shift+Tab alternam guias.
- Ctrl+1…8 seleciona uma das oito primeiras guias; Ctrl+9 seleciona a última.
- Ctrl+PageUp/PageDown também alterna guias.
- F6 alterna foco entre a barra de endereço e o conteúdo.
- Ctrl+L permanece configurável no painel de atalhos.

## Compilação
Extraia o ZIP e execute `CRIAR-EXE.bat` no Windows com SDK .NET 10. O destino é `DIST\RXBrowser.exe`. O WebView2 Runtime precisa estar instalado separadamente.
