$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$project = Join-Path $PSScriptRoot 'RXBrowser\RXBrowser.csproj'
if (-not (Test-Path $project)) { throw "Projeto nao encontrado: $project" }

function Get-DotNetCommand {
    $cmd = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

$dotnet = Get-DotNetCommand
$hasSdk10 = $false
if ($dotnet) {
    $sdkList = & $dotnet --list-sdks 2>$null
    $hasSdk10 = [bool]($sdkList | Select-String '^\s*10\.')
}

# The local installer directory is intentionally not added to the permanent PATH.
# Check it explicitly so a previously installed SDK is reused without downloading it again.
$installDir = Join-Path $env:LOCALAPPDATA 'RXBrowser\dotnet-sdk'
$localDotnet = Join-Path $installDir 'dotnet.exe'
if (-not $hasSdk10 -and (Test-Path $localDotnet)) {
    $localSdkList = & $localDotnet --list-sdks 2>$null
    $hasSdk10 = [bool]($localSdkList | Select-String '^\s*10\.')
    if ($hasSdk10) {
        $dotnet = $localDotnet
        $env:DOTNET_ROOT = $installDir
        $env:PATH = "$installDir;$env:PATH"
        Write-Host 'SDK .NET 10 local encontrado. Reutilizando a instalacao existente.' -ForegroundColor Green
    }
}

if (-not $hasSdk10) {
    Write-Host 'O SDK .NET 10 nao foi encontrado. Vou instalar uma copia local para compilar o RX Browser.' -ForegroundColor Cyan
    $installer = Join-Path $env:TEMP 'dotnet-install-rxbrowser.ps1'
    Invoke-WebRequest 'https://dot.net/v1/dotnet-install.ps1' -OutFile $installer
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Channel '10.0' -InstallDir $installDir
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar o SDK .NET 10.' }
    $env:DOTNET_ROOT = $installDir
    $env:PATH = "$installDir;$env:PATH"
    $dotnet = Join-Path $installDir 'dotnet.exe'
}

Write-Host ''
Write-Host 'Restaurando dependencias e publicando RXBrowser.exe para Windows 64-bit...' -ForegroundColor Cyan
$outDir = Join-Path $PSScriptRoot 'DIST'
if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }
& $dotnet publish $project -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:IncludeAllContentForSelfExtract=true `
    -p:DebugType=None `
    -o $outDir
if ($LASTEXITCODE -ne 0) { throw 'A compilacao/publicacao falhou. O SDK foi localizado; consulte os erros C# ou avisos acima. A conexao so e necessaria para restaurar pacotes que ainda nao estejam em cache.' }

$exe = Join-Path $outDir 'RXBrowser.exe'
if (-not (Test-Path $exe)) { throw 'A compilacao terminou, mas RXBrowser.exe nao foi encontrado.' }
Write-Host ''
Write-Host "RX Browser criado: $exe" -ForegroundColor Green
Write-Host 'O .NET esta incorporado no executavel. O Microsoft Edge WebView2 Runtime e um componente separado.' -ForegroundColor Yellow
Start-Process $exe
