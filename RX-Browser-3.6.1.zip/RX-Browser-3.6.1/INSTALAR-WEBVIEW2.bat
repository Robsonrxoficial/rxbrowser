@echo off
start "WebView2 Runtime" "https://developer.microsoft.com/microsoft-edge/webview2/"
