# RX Browser 2.3.2 — correção do scroll do mouse

## Problema
O menu `Mais opções e configurações` pode ser mais alto que a área disponível da tela. O WinForms mostra setas de rolagem, mas a roda do mouse não era encaminhada para esse menu.

## Correção
- Adicionada a classe `WheelScrollableContextMenuStrip`.
- Intercepta `WM_MOUSEWHEEL` somente quando o cursor está sobre um menu RX aberto.
- Encaminha a roda para a operação de rolagem interna do `ToolStripDropDownMenu` usada pelos botões de rolagem nativos.
- Detecta submenus visíveis e rola o submenu sob o cursor.
- Consome o evento para impedir que a página web ao fundo role junto.
- Remove o filtro de mensagens quando o menu fecha ou é descartado.
- Inclui fallback por seleção de itens caso o método interno não esteja disponível.

## Teste no Windows
1. Abra o RX Browser.
2. Clique em `•••` (Mais opções e configurações).
3. Posicione o ponteiro sobre o menu e role para baixo e para cima.
4. Abra um submenu e teste a roda sobre ele.
5. Confirme que a página web atrás do menu não se move enquanto o menu está aberto.

Não foi possível executar uma compilação WinForms neste ambiente; compile e teste com o `CRIAR-EXE.bat` no Windows.
