# RX Browser 3.4.0 — Caderno RX

## Caderno RX: notas por site
- Novo gerenciador de notas disponível pelo menu Mais e pela Paleta de comandos.
- Ao criar uma nota, o navegador associa o título da guia e a origem do site; caminhos, parâmetros e fragmentos da URL não são armazenados, reduzindo o risco de guardar tokens de sessão.
- Edição de título e conteúdo com salvamento automático após 800 ms sem digitação e ao fechar a janela.
- Lista de notas do perfil atual, com criação, exclusão confirmada e exportação individual em Markdown ou texto.
- Limite de 500 notas por perfil e 100.000 caracteres por conteúdo, para evitar arquivos de perfil excessivamente grandes.

## Privacidade e armazenamento
- As notas ficam no arquivo separado `site-notes.json` dentro da pasta do perfil.
- O Caderno RX é bloqueado em guias privadas para evitar que conteúdo de sessão privada seja salvo no perfil normal.
- Notas não são sincronizadas e não entram no backup seletivo.
- O arquivo é armazenamento local comum, não um cofre criptografado; não guardar senhas ou segredos nele.

## Como testar
1. Abra um site em uma guia normal e acesse Mais > Caderno RX.
2. Crie uma nota, edite o título e escreva algum conteúdo.
3. Aguarde o salvamento automático e feche/reabra o Caderno RX para verificar persistência.
4. Crie uma nota em outro domínio e confira que ambas aparecem na lista.
5. Exporte uma nota para `.md` e confira os metadados e o texto.
6. Exclua uma nota de teste e confirme que ela não reaparece ao reabrir.
7. Abra uma guia privada e tente abrir o Caderno RX: o navegador deve avisar e não abrir o gerenciador.
8. Confira que `site-notes.json` está na pasta local do perfil e que não aparece no fluxo de sincronização.
