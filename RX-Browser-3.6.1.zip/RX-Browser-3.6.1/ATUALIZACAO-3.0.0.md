# Histórico — RX Browser 3.0.0

Versão anterior que introduziu a Central RX, a paleta de comandos, diagnóstico local e backup seletivo do perfil.
